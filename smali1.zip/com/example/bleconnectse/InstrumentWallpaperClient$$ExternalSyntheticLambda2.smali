# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/InstrumentWallpaperClient;

.field public final synthetic f$1:Ljava/io/OutputStream;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/InstrumentWallpaperClient;Ljava/io/OutputStream;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda2;->f$0:Lcom/example/bleconnectse/InstrumentWallpaperClient;

    iput-object p2, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda2;->f$1:Ljava/io/OutputStream;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda2;->f$0:Lcom/example/bleconnectse/InstrumentWallpaperClient;

    iget-object p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda2;->f$1:Ljava/io/OutputStream;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->startHeartbeat$lambda$8(Lcom/example/bleconnectse/InstrumentWallpaperClient;Ljava/io/OutputStream;)V

    return-void
.end method
