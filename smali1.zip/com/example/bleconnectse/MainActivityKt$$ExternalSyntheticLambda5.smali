# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$1:Lcom/example/bleconnectse/BleTileSource;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/BleTileClient;Lcom/example/bleconnectse/BleTileSource;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda5;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda5;->f$1:Lcom/example/bleconnectse/BleTileSource;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda5;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda5;->f$1:Lcom/example/bleconnectse/BleTileSource;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/MainActivityKt;->BleTileOverlay$lambda$70$lambda$69$lambda$68$lambda$66$lambda$65(Lcom/example/bleconnectse/BleTileClient;Lcom/example/bleconnectse/BleTileSource;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
