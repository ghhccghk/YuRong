# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda22;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/activity/result/ActivityResultCallback;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/MainActivity;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda22;->f$0:Lcom/example/bleconnectse/MainActivity;

    return-void
.end method


# virtual methods
.method public final onActivityResult(Ljava/lang/Object;)V
    .registers 2

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda22;->f$0:Lcom/example/bleconnectse/MainActivity;

    check-cast p1, Ljava/util/Map;

    invoke-static {p0, p1}, Lcom/example/bleconnectse/MainActivity;->permissionLauncher$lambda$2(Lcom/example/bleconnectse/MainActivity;Ljava/util/Map;)V

    return-void
.end method
