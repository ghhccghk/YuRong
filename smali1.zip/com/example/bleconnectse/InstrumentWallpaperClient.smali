# classes2.dex

.class public final Lcom/example/bleconnectse/InstrumentWallpaperClient;
.super Ljava/lang/Object;
.source "InstrumentWallpaperClient.kt"

# interfaces
.implements Ljava/lang/AutoCloseable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/InstrumentWallpaperClient$Companion;,
        Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInstrumentWallpaperClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InstrumentWallpaperClient.kt\ncom/example/bleconnectse/InstrumentWallpaperClient\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,424:1\n1#2:425\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000p\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0001\u0018\u0000 /2\u00060\u0001j\u0002`\u0002:\u0002./B7\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0012\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u0006\u0012\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u0006¢\u0006\u0004\b\n\u0010\u000bJ\u000e\u0010\u0011\u001a\u00020\b2\u0006\u0010\u0012\u001a\u00020\u0013J\u0010\u0010\u0014\u001a\u00020\b2\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u0018\u0010\u0017\u001a\u00020\b2\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0013H\u0002J\u0018\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001eH\u0002J\u0010\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u0013H\u0002J\u0010\u0010\"\u001a\u00020\b2\u0006\u0010!\u001a\u00020\u0013H\u0002J\u0018\u0010#\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010$\u001a\u00020 H\u0002J \u0010%\u001a\u00020\u00132\u0006\u0010&\u001a\u00020\'2\u0006\u0010(\u001a\u00020)2\u0006\u0010*\u001a\u00020+H\u0002J\u0010\u0010,\u001a\u00020\u00132\u0006\u0010&\u001a\u00020\'H\u0002J\b\u0010-\u001a\u00020\bH\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u000e\u001a\n \u0010*\u0004\u0018\u00010\u000f0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u00060"
    }
    d2 = {
        "Lcom/example/bleconnectse/InstrumentWallpaperClient;",
        "Ljava/lang/AutoCloseable;",
        "Lkotlin/AutoCloseable;",
        "socket",
        "Ljava/net/Socket;",
        "onStatus",
        "Lkotlin/Function1;",
        "",
        "",
        "onLog",
        "<init>",
        "(Ljava/net/Socket;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V",
        "writeLock",
        "",
        "heartbeat",
        "Ljava/util/concurrent/ScheduledExecutorService;",
        "kotlin.jvm.PlatformType",
        "upload",
        "source",
        "",
        "startHeartbeat",
        "output",
        "Ljava/io/OutputStream;",
        "send",
        "inner",
        "await",
        "Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;",
        "input",
        "Ljava/io/InputStream;",
        "expectedCommand",
        "",
        "parseDisplay",
        "Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;",
        "data",
        "requireDataAccepted",
        "formatImage",
        "display",
        "compress",
        "bitmap",
        "Landroid/graphics/Bitmap;",
        "format",
        "Landroid/graphics/Bitmap$CompressFormat;",
        "limitSize",
        "",
        "compressNv21Jpeg",
        "close",
        "DisplayConfig",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final CHUNK_SIZE:I = 0x59a
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CMD_DATA_REQUEST:I = 0x12
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CMD_DATA_RESPONSE:I = 0x24
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CMD_END_REQUEST:I = 0x13
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CMD_END_RESPONSE:I = 0x23
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CMD_HEARTBEAT:I = 0x1f
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CMD_NEGATIVE_RESPONSE:I = 0xf1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CMD_PARAM_REQUEST:I = 0x11
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CMD_PARAM_RESPONSE:I = 0x21
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CMD_START_REQUEST:I = 0x10
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final CMD_START_RESPONSE:I = 0x20
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static final Companion:Lcom/example/bleconnectse/InstrumentWallpaperClient$Companion;

.field public static final DATA_STATUS_ACCEPTED:I = 0x0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final DISPLAY_JIELI_RLE:I = 0x3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final DISPLAY_JPEG:I = 0x2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final DISPLAY_NV21_JPEG:I = 0x0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final DISPLAY_PNG:I = 0x1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static final END_SUCCESS_PAYLOAD:[B

.field public static final MAX_IMAGE_BYTES:I = 0x20000
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final MIN_JPEG_QUALITY:I = 0x5
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static final PARAM_RESERVED:[B

.field public static final RESPONSE_TIMEOUT_MS:I = 0x3a98
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static final START_PAYLOAD:[B


# instance fields
.field private final heartbeat:Ljava/util/concurrent/ScheduledExecutorService;

.field private final onLog:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final onStatus:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final socket:Ljava/net/Socket;

.field private final writeLock:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    new-instance v0, Lcom/example/bleconnectse/InstrumentWallpaperClient$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/InstrumentWallpaperClient$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->Companion:Lcom/example/bleconnectse/InstrumentWallpaperClient$Companion;

    const/16 v0, 0x8

    sput v0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->$stable:I

    .line 266
    new-array v0, v0, [B

    fill-array-data v0, :array_34

    sput-object v0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->START_PAYLOAD:[B

    const/4 v0, 0x4

    .line 267
    new-array v0, v0, [B

    fill-array-data v0, :array_3c

    sput-object v0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->PARAM_RESERVED:[B

    const/4 v0, 0x1

    .line 268
    new-array v0, v0, [B

    const/4 v1, -0x3

    const/4 v2, 0x0

    aput-byte v1, v0, v2

    const/4 v1, 0x7

    new-array v3, v1, [B

    :goto_25
    if-ge v2, v1, :cond_2d

    const/4 v4, -0x1

    aput-byte v4, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_25

    :cond_2d
    invoke-static {v0, v3}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object v0

    sput-object v0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->END_SUCCESS_PAYLOAD:[B

    return-void

    :array_34
    .array-data 1
        0x5t
        -0x66t
        -0xdt
        -0x1t
        0x0t
        0x0t
        0x5t
        -0x66t
    .end array-data

    :array_3c
    .array-data 1
        -0xat
        -0x1t
        -0x1t
        -0x1t
    .end array-data
.end method

.method public constructor <init>(Ljava/net/Socket;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/net/Socket;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "socket"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onStatus"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onLog"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    iput-object p1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->socket:Ljava/net/Socket;

    .line 22
    iput-object p2, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onStatus:Lkotlin/jvm/functions/Function1;

    .line 23
    iput-object p3, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onLog:Lkotlin/jvm/functions/Function1;

    .line 25
    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->writeLock:Ljava/lang/Object;

    .line 26
    new-instance p1, Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda1;

    invoke-direct {p1}, Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda1;-><init>()V

    invoke-static {p1}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->heartbeat:Ljava/util/concurrent/ScheduledExecutorService;

    return-void
.end method

.method public static final synthetic access$getEND_SUCCESS_PAYLOAD$cp()[B
    .registers 1

    .line 20
    sget-object v0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->END_SUCCESS_PAYLOAD:[B

    return-object v0
.end method

.method public static final synthetic access$getPARAM_RESERVED$cp()[B
    .registers 1

    .line 20
    sget-object v0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->PARAM_RESERVED:[B

    return-object v0
.end method

.method public static final synthetic access$getSTART_PAYLOAD$cp()[B
    .registers 1

    .line 20
    sget-object v0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->START_PAYLOAD:[B

    return-object v0
.end method

.method private final await(Ljava/io/InputStream;I)Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;
    .registers 13

    .line 126
    :cond_0
    :goto_0
    sget-object v0, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    invoke-virtual {v0, p1}, Lcom/example/bleconnectse/WallpaperProtocol;->readOuterFrame(Ljava/io/InputStream;)[B

    move-result-object v0

    .line 127
    sget-object v1, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    invoke-virtual {v1, v0}, Lcom/example/bleconnectse/WallpaperProtocol;->parseInner([B)Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;

    move-result-object v0

    .line 128
    invoke-virtual {v0}, Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;->getCommand()I

    move-result v1

    if-ne v1, p2, :cond_13

    return-object v0

    :cond_13
    const/16 v2, 0x1f

    if-eq v1, v2, :cond_0

    const/16 v2, 0xf1

    if-eq v1, v2, :cond_42

    const/16 v2, 0x24

    if-eq v1, v2, :cond_0

    .line 135
    iget-object v1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onLog:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v0}, Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;->getCommand()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    invoke-static {v0, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string/jumbo v2, "壁纸：忽略响应 CMD=0x%02X"

    invoke-static {v2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "format(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    .line 131
    :cond_42
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 132
    invoke-virtual {v0}, Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;->getData()[B

    move-result-object v1

    const-string p1, " "

    move-object v2, p1

    check-cast v2, Ljava/lang/CharSequence;

    new-instance v7, Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda0;

    invoke-direct {v7}, Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda0;-><init>()V

    const/16 v8, 0x1e

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v1 .. v9}, Lkotlin/collections/ArraysKt;->joinToString$default([BLjava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "仪表返回失败响应："

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static final await$lambda$10(B)Ljava/lang/CharSequence;
    .registers 2

    and-int/lit16 p0, p0, 0xff

    .line 132
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const/4 v0, 0x1

    invoke-static {p0, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const-string v0, "%02X"

    invoke-static {v0, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "format(...)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Ljava/lang/CharSequence;

    return-object p0
.end method

.method private final compress(Landroid/graphics/Bitmap;Landroid/graphics/Bitmap$CompressFormat;Z)[B
    .registers 7

    const/16 p0, 0x64

    :goto_2
    const/4 v0, 0x5

    if-lt p0, v0, :cond_43

    .line 190
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    check-cast v0, Ljava/io/Closeable;

    :try_start_c
    move-object v1, v0

    check-cast v1, Ljava/io/ByteArrayOutputStream;

    .line 191
    move-object v2, v1

    check-cast v2, Ljava/io/OutputStream;

    invoke-virtual {p1, p2, p0, v2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    move-result v2

    if-eqz v2, :cond_2f

    .line 192
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1
    :try_end_1c
    .catchall {:try_start_c .. :try_end_1c} :catchall_3c

    const/4 v2, 0x0

    .line 190
    invoke-static {v0, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    if-eqz p3, :cond_2b

    .line 194
    array-length v0, v1

    const/high16 v2, 0x20000

    if-gt v0, v2, :cond_28

    goto :goto_2b

    :cond_28
    add-int/lit8 p0, p0, -0x5

    goto :goto_2

    :cond_2b
    :goto_2b
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    return-object v1

    .line 191
    :cond_2f
    :try_start_2f
    const-string/jumbo p0, "图片编码失败"

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_3c
    .catchall {:try_start_2f .. :try_end_3c} :catchall_3c

    :catchall_3c
    move-exception p0

    .line 190
    :try_start_3d
    throw p0
    :try_end_3e
    .catchall {:try_start_3d .. :try_end_3e} :catchall_3e

    :catchall_3e
    move-exception p1

    invoke-static {v0, p0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1

    .line 195
    :cond_43
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 197
    const-string/jumbo p1, "图片压缩后仍超过 128 KiB"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private final compressNv21Jpeg(Landroid/graphics/Bitmap;)[B
    .registers 16

    .line 201
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    .line 202
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    .line 203
    rem-int/lit8 p0, v3, 0x2

    if-nez p0, :cond_ee

    rem-int/lit8 p0, v4, 0x2

    if-nez p0, :cond_ee

    mul-int p0, v3, v4

    .line 204
    new-array v1, p0, [I

    move v7, v4

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v2, 0x0

    move v6, v3

    move-object v0, p1

    .line 205
    invoke-virtual/range {v0 .. v7}, Landroid/graphics/Bitmap;->getPixels([IIIIIII)V

    mul-int/lit8 p1, p0, 0x3

    .line 206
    div-int/lit8 p1, p1, 0x2

    new-array p1, p1, [B

    const/4 v6, 0x0

    move v0, v6

    move v2, v0

    :goto_26
    if-ge v0, v7, :cond_90

    move v4, v6

    :goto_29
    if-ge v4, v3, :cond_8d

    mul-int v5, v0, v3

    add-int/2addr v5, v4

    .line 211
    aget v5, v1, v5

    .line 212
    invoke-static {v5}, Landroid/graphics/Color;->red(I)I

    move-result v8

    .line 213
    invoke-static {v5}, Landroid/graphics/Color;->green(I)I

    move-result v9

    .line 214
    invoke-static {v5}, Landroid/graphics/Color;->blue(I)I

    move-result v5

    mul-int/lit8 v10, v8, 0x4d

    mul-int/lit16 v11, v9, 0x96

    add-int/2addr v10, v11

    mul-int/lit8 v11, v5, 0x1d

    add-int/2addr v10, v11

    add-int/lit16 v10, v10, 0x80

    shr-int/lit8 v10, v10, 0x8

    const/16 v11, 0xff

    .line 215
    invoke-static {v10, v6, v11}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v10

    mul-int/lit8 v12, v8, -0x2b

    mul-int/lit8 v13, v9, 0x54

    sub-int/2addr v12, v13

    mul-int/lit8 v13, v5, 0x7f

    add-int/2addr v12, v13

    add-int/lit16 v12, v12, 0x80

    shr-int/lit8 v12, v12, 0x8

    add-int/lit16 v12, v12, 0x80

    .line 216
    invoke-static {v12, v6, v11}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v12

    mul-int/lit8 v8, v8, 0x7f

    mul-int/lit8 v9, v9, 0x6a

    sub-int/2addr v8, v9

    mul-int/lit8 v5, v5, 0x15

    sub-int/2addr v8, v5

    add-int/lit16 v8, v8, 0x80

    shr-int/lit8 v5, v8, 0x8

    add-int/lit16 v5, v5, 0x80

    .line 217
    invoke-static {v5, v6, v11}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v5

    add-int/lit8 v8, v2, 0x1

    int-to-byte v9, v10

    .line 218
    aput-byte v9, p1, v2

    .line 219
    rem-int/lit8 v2, v0, 0x2

    if-nez v2, :cond_89

    rem-int/lit8 v2, v4, 0x2

    if-nez v2, :cond_89

    add-int/lit8 v2, p0, 0x1

    int-to-byte v5, v5

    .line 220
    aput-byte v5, p1, p0

    add-int/lit8 p0, p0, 0x2

    int-to-byte v5, v12

    .line 221
    aput-byte v5, p1, v2

    :cond_89
    add-int/lit8 v4, v4, 0x1

    move v2, v8

    goto :goto_29

    :cond_8d
    add-int/lit8 v0, v0, 0x1

    goto :goto_26

    :cond_90
    const/16 p0, 0x64

    :goto_92
    const/4 v0, 0x5

    if-lt p0, v0, :cond_e2

    .line 227
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    move-object v8, v0

    check-cast v8, Ljava/io/Closeable;

    :try_start_9d
    move-object v9, v8

    check-cast v9, Ljava/io/ByteArrayOutputStream;

    .line 228
    new-instance v0, Landroid/graphics/YuvImage;

    const/16 v2, 0x11

    const/4 v5, 0x0

    move-object v1, p1

    move v4, v7

    invoke-direct/range {v0 .. v5}, Landroid/graphics/YuvImage;-><init>([BIII[I)V

    .line 229
    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1, v6, v6, v3, v7}, Landroid/graphics/Rect;-><init>(IIII)V

    move-object v2, v9

    check-cast v2, Ljava/io/OutputStream;

    invoke-virtual {v0, p1, p0, v2}, Landroid/graphics/YuvImage;->compressToJpeg(Landroid/graphics/Rect;ILjava/io/OutputStream;)Z

    move-result p1

    if-eqz p1, :cond_cd

    .line 232
    invoke-virtual {v9}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1
    :try_end_bc
    .catchall {:try_start_9d .. :try_end_bc} :catchall_d9

    const/4 v0, 0x0

    .line 227
    invoke-static {v8, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 234
    array-length v0, p1

    const/high16 v2, 0x20000

    if-gt v0, v2, :cond_c9

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    return-object p1

    :cond_c9
    add-int/lit8 p0, p0, -0x5

    move-object p1, v1

    goto :goto_92

    .line 230
    :cond_cd
    :try_start_cd
    const-string p0, "NV21 JPEG 编码失败"

    .line 228
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_d9
    .catchall {:try_start_cd .. :try_end_d9} :catchall_d9

    :catchall_d9
    move-exception v0

    move-object p0, v0

    .line 227
    :try_start_db
    throw p0
    :try_end_dc
    .catchall {:try_start_db .. :try_end_dc} :catchall_dc

    :catchall_dc
    move-exception v0

    move-object p1, v0

    invoke-static {v8, p0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1

    .line 235
    :cond_e2
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 237
    const-string p1, "NV21 JPEG 压缩后仍超过 128 KiB"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_ee
    move v7, v4

    .line 203
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "NV21 壁纸尺寸必须为偶数："

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string/jumbo p1, "x"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private final formatImage([BLcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;)[B
    .registers 12

    const-string/jumbo v0, "不支持的仪表壁纸格式："

    .line 159
    array-length v1, p1

    const/4 v2, 0x0

    invoke-static {p1, v2, v1}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object p1

    if-eqz p1, :cond_a7

    .line 161
    invoke-virtual {p2}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getWidth()I

    move-result v1

    invoke-virtual {p2}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getHeight()I

    move-result v3

    const/4 v4, 0x1

    invoke-static {p1, v1, v3, v4}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v1

    const-string v3, "createScaledBitmap(...)"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 162
    invoke-virtual {p2}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getType()I

    move-result v3

    const/4 v5, 0x3

    if-ne v3, v4, :cond_26

    move-object v3, v1

    goto :goto_49

    .line 165
    :cond_26
    invoke-virtual {p2}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getWidth()I

    move-result v3

    invoke-virtual {p2}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getHeight()I

    move-result v6

    sget-object v7, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v3, v6, v7}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v3

    .line 166
    new-instance v6, Landroid/graphics/Canvas;

    invoke-direct {v6, v3}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 v7, -0x1

    .line 167
    invoke-virtual {v6, v7}, Landroid/graphics/Canvas;->drawColor(I)V

    .line 168
    new-instance v7, Landroid/graphics/Paint;

    invoke-direct {v7, v5}, Landroid/graphics/Paint;-><init>(I)V

    const/4 v8, 0x0

    invoke-virtual {v6, v1, v8, v8, v7}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 164
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 173
    :goto_49
    :try_start_49
    invoke-virtual {p2}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getType()I

    move-result v6

    if-eqz v6, :cond_86

    if-eq v6, v4, :cond_7f

    const/4 v2, 0x2

    if-eq v6, v2, :cond_78

    if-ne v6, v5, :cond_5d

    .line 177
    sget-object p0, Lcom/example/bleconnectse/JieliRleEncoder;->INSTANCE:Lcom/example/bleconnectse/JieliRleEncoder;

    invoke-virtual {p0, v3}, Lcom/example/bleconnectse/JieliRleEncoder;->encode(Landroid/graphics/Bitmap;)[B

    move-result-object p0

    goto :goto_8a

    :cond_5d
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 178
    invoke-virtual {p2}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getType()I

    move-result p2

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 176
    :cond_78
    sget-object p2, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    invoke-direct {p0, v3, p2, v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->compress(Landroid/graphics/Bitmap;Landroid/graphics/Bitmap$CompressFormat;Z)[B

    move-result-object p0

    goto :goto_8a

    .line 175
    :cond_7f
    sget-object p2, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    invoke-direct {p0, v3, p2, v2}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->compress(Landroid/graphics/Bitmap;Landroid/graphics/Bitmap$CompressFormat;Z)[B

    move-result-object p0

    goto :goto_8a

    .line 174
    :cond_86
    invoke-direct {p0, v3}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->compressNv21Jpeg(Landroid/graphics/Bitmap;)[B

    move-result-object p0
    :try_end_8a
    .catchall {:try_start_49 .. :try_end_8a} :catchall_98

    :goto_8a
    if-eq v3, v1, :cond_8f

    .line 181
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->recycle()V

    :cond_8f
    if-eq v1, p1, :cond_94

    .line 182
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 183
    :cond_94
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->recycle()V

    return-object p0

    :catchall_98
    move-exception p0

    if-eq v3, v1, :cond_9e

    .line 181
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->recycle()V

    :cond_9e
    if-eq v1, p1, :cond_a3

    .line 182
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 183
    :cond_a3
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->recycle()V

    throw p0

    .line 159
    :cond_a7
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 160
    const-string/jumbo p1, "无法解码所选图片"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static final heartbeat$lambda$1(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .registers 3

    .line 27
    new-instance v0, Ljava/lang/Thread;

    const-string v1, "instrument-wallpaper-heartbeat"

    invoke-direct {v0, p0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    const/4 p0, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/Thread;->setDaemon(Z)V

    return-object v0
.end method

.method private final parseDisplay([B)Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;
    .registers 5

    .line 141
    array-length p0, p1

    const/16 v0, 0x8

    if-lt p0, v0, :cond_53

    .line 142
    sget-object p0, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/example/bleconnectse/WallpaperProtocol;->readInt16([BI)I

    move-result p0

    .line 143
    sget-object v1, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    const/4 v2, 0x2

    invoke-virtual {v1, p1, v2}, Lcom/example/bleconnectse/WallpaperProtocol;->readInt16([BI)I

    move-result v1

    const/4 v2, 0x4

    .line 144
    aget-byte p1, p1, v2

    and-int/lit16 p1, p1, 0xff

    const/4 v2, 0x3

    if-le p1, v2, :cond_1c

    goto :goto_1d

    :cond_1c
    move v0, p1

    :goto_1d
    const/4 p1, 0x1

    if-gt p1, p0, :cond_2e

    const/16 v2, 0x1001

    if-ge p0, v2, :cond_2e

    if-gt p1, v1, :cond_2e

    if-ge v1, v2, :cond_2e

    .line 147
    new-instance p1, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;

    invoke-direct {p1, p0, v1, v0}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;-><init>(III)V

    return-object p1

    .line 146
    :cond_2e
    new-instance p1, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "仪表返回的壁纸尺寸无效："

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string/jumbo p1, "x"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 141
    :cond_53
    array-length p0, p1

    new-instance p1, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "仪表壁纸参数长度不足："

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private final requireDataAccepted([B)V
    .registers 2

    .line 151
    invoke-static {p1}, Lkotlin/collections/ArraysKt;->firstOrNull([B)Ljava/lang/Byte;

    move-result-object p0

    if-eqz p0, :cond_32

    invoke-virtual {p0}, Ljava/lang/Byte;->byteValue()B

    move-result p0

    and-int/lit16 p0, p0, 0xff

    if-nez p0, :cond_f

    return-void

    .line 154
    :cond_f
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const/4 p1, 0x1

    invoke-static {p0, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const-string/jumbo p1, "仪表拒绝壁纸分包，状态=0x%02X"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "format(...)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 153
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 151
    :cond_32
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 152
    const-string/jumbo p1, "仪表未返回壁纸分包状态"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private final send(Ljava/io/OutputStream;[B)V
    .registers 7

    .line 117
    sget-object v0, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, p2, v3, v1, v2}, Lcom/example/bleconnectse/WallpaperProtocol;->outerFrame$default(Lcom/example/bleconnectse/WallpaperProtocol;[BIILjava/lang/Object;)[B

    move-result-object p2

    .line 118
    iget-object p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->writeLock:Ljava/lang/Object;

    monitor-enter p0

    .line 119
    :try_start_c
    invoke-virtual {p1, p2}, Ljava/io/OutputStream;->write([B)V

    .line 120
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    .line 121
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_14
    .catchall {:try_start_c .. :try_end_14} :catchall_16

    .line 118
    monitor-exit p0

    return-void

    :catchall_16
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method private final startHeartbeat(Ljava/io/OutputStream;)V
    .registers 9

    .line 98
    iget-object v0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->heartbeat:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p1}, Lcom/example/bleconnectse/InstrumentWallpaperClient$$ExternalSyntheticLambda2;-><init>(Lcom/example/bleconnectse/InstrumentWallpaperClient;Ljava/io/OutputStream;)V

    const-wide/16 v4, 0x1

    .line 113
    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x0

    .line 98
    invoke-interface/range {v0 .. v6}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleAtFixedRate(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    return-void
.end method

.method static final startHeartbeat$lambda$8(Lcom/example/bleconnectse/InstrumentWallpaperClient;Ljava/io/OutputStream;)V
    .registers 13

    .line 99
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    .line 100
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    const/4 v1, 0x1

    .line 102
    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v2

    rem-int/lit8 v2, v2, 0x64

    int-to-byte v2, v2

    const/4 v3, 0x2

    .line 103
    invoke-virtual {v0, v3}, Ljava/util/Calendar;->get(I)I

    move-result v4

    add-int/2addr v4, v1

    int-to-byte v4, v4

    const/4 v5, 0x5

    .line 104
    invoke-virtual {v0, v5}, Ljava/util/Calendar;->get(I)I

    move-result v6

    int-to-byte v6, v6

    const/16 v7, 0xb

    .line 105
    invoke-virtual {v0, v7}, Ljava/util/Calendar;->get(I)I

    move-result v7

    int-to-byte v7, v7

    const/16 v8, 0xc

    .line 106
    invoke-virtual {v0, v8}, Ljava/util/Calendar;->get(I)I

    move-result v8

    int-to-byte v8, v8

    const/16 v9, 0xd

    .line 107
    invoke-virtual {v0, v9}, Ljava/util/Calendar;->get(I)I

    move-result v0

    int-to-byte v0, v0

    const/16 v9, 0x8

    .line 109
    new-array v9, v9, [B

    const/4 v10, 0x0

    aput-byte v2, v9, v10

    aput-byte v4, v9, v1

    aput-byte v6, v9, v3

    const/4 v1, 0x3

    aput-byte v7, v9, v1

    const/4 v1, 0x4

    aput-byte v8, v9, v1

    aput-byte v0, v9, v5

    const/4 v0, 0x6

    const/4 v1, -0x1

    aput-byte v1, v9, v0

    const/4 v0, 0x7

    aput-byte v1, v9, v0

    .line 111
    sget-object v0, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    const/16 v1, 0x1f

    invoke-virtual {v0, v1, v9}, Lcom/example/bleconnectse/WallpaperProtocol;->command(I[B)[B

    move-result-object v0

    invoke-direct {p0, p1, v0}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->send(Ljava/io/OutputStream;[B)V

    .line 112
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 99
    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_5b
    .catchall {:try_start_0 .. :try_end_5b} :catchall_5c

    goto :goto_67

    :catchall_5c
    move-exception p1

    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    .line 112
    :goto_67
    invoke-static {p1}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p1

    if-eqz p1, :cond_86

    iget-object p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onLog:Lkotlin/jvm/functions/Function1;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "壁纸心跳停止："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_86
    return-void
.end method


# virtual methods
.method public close()V
    .registers 2

    .line 241
    iget-object v0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->heartbeat:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ScheduledExecutorService;->shutdownNow()Ljava/util/List;

    .line 242
    :try_start_5
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/InstrumentWallpaperClient;

    iget-object p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->socket:Ljava/net/Socket;

    invoke-virtual {p0}, Ljava/net/Socket;->close()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_14
    .catchall {:try_start_5 .. :try_end_14} :catchall_15

    return-void

    :catchall_15
    move-exception p0

    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final upload([B)V
    .registers 15

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    array-length v0, p1

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_c

    move v0, v1

    goto :goto_d

    :cond_c
    move v0, v2

    :goto_d
    if-nez v0, :cond_21f

    .line 32
    iget-object v0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->socket:Ljava/net/Socket;

    const/16 v3, 0x3a98

    invoke-virtual {v0, v3}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 33
    iget-object v0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->socket:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    .line 34
    iget-object v3, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->socket:Ljava/net/Socket;

    invoke-virtual {v3}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v3

    .line 35
    iget-object v4, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onStatus:Lkotlin/jvm/functions/Function1;

    const-string/jumbo v5, "正在读取仪表壁纸参数"

    invoke-interface {v4, v5}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    sget-object v4, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    const/16 v5, 0x10

    sget-object v6, Lcom/example/bleconnectse/InstrumentWallpaperClient;->START_PAYLOAD:[B

    invoke-virtual {v4, v5, v6}, Lcom/example/bleconnectse/WallpaperProtocol;->command(I[B)[B

    move-result-object v4

    invoke-direct {p0, v3, v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->send(Ljava/io/OutputStream;[B)V

    .line 40
    invoke-direct {p0, v3}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->startHeartbeat(Ljava/io/OutputStream;)V

    .line 41
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/16 v4, 0x20

    invoke-direct {p0, v0, v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->await(Ljava/io/InputStream;I)Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;

    move-result-object v4

    invoke-virtual {v4}, Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;->getData()[B

    move-result-object v4

    invoke-direct {p0, v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->parseDisplay([B)Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;

    move-result-object v4

    .line 42
    iget-object v5, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onLog:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getWidth()I

    move-result v6

    invoke-virtual {v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getHeight()I

    move-result v7

    invoke-virtual {v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getType()I

    move-result v8

    new-instance v9, Ljava/lang/StringBuilder;

    const-string/jumbo v10, "壁纸：仪表要求 "

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string/jumbo v9, "x"

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string/jumbo v7, "，格式="

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v5, v6}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    iget-object v5, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onStatus:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getWidth()I

    move-result v6

    invoke-virtual {v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->getHeight()I

    move-result v7

    new-instance v8, Ljava/lang/StringBuilder;

    const-string/jumbo v9, "正在转换 "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string/jumbo v8, "×"

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " 图片"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v5, v6}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    invoke-direct {p0, p1, v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->formatImage([BLcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;)[B

    move-result-object p1

    .line 46
    iget-object v4, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onLog:Lkotlin/jvm/functions/Function1;

    array-length v5, p1

    new-instance v6, Ljava/lang/StringBuilder;

    const-string/jumbo v7, "壁纸：转换后 "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " 字节"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v4, v5}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    sget-object v4, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    array-length v5, p1

    invoke-virtual {v4, v5}, Lcom/example/bleconnectse/WallpaperProtocol;->int32(I)[B

    move-result-object v4

    sget-object v5, Lcom/example/bleconnectse/InstrumentWallpaperClient;->PARAM_RESERVED:[B

    invoke-static {v4, v5}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object v4

    .line 52
    sget-object v5, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    const/16 v6, 0x11

    invoke-virtual {v5, v6, v4}, Lcom/example/bleconnectse/WallpaperProtocol;->command(I[B)[B

    move-result-object v4

    invoke-direct {p0, v3, v4}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->send(Ljava/io/OutputStream;[B)V

    .line 53
    sget-object v4, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    const/16 v5, 0x21

    .line 54
    invoke-direct {p0, v0, v5}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->await(Ljava/io/InputStream;I)Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;

    move-result-object v5

    invoke-virtual {v5}, Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;->getData()[B

    move-result-object v5

    .line 53
    invoke-virtual {v4, v5, v2}, Lcom/example/bleconnectse/WallpaperProtocol;->readInt32([BI)I

    move-result v4

    .line 57
    array-length v5, p1

    if-ne v4, v5, :cond_1f4

    .line 61
    sget-object v4, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    invoke-virtual {v4, p1}, Lcom/example/bleconnectse/WallpaperProtocol;->crc16ModbusBytes([B)[B

    move-result-object v4

    .line 62
    array-length v5, p1

    int-to-double v5, v5

    const-wide v7, 0x4096680000000000L  # 1434.0

    div-double/2addr v5, v7

    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v5

    double-to-int v5, v5

    .line 63
    iget-object v6, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onStatus:Lkotlin/jvm/functions/Function1;

    const-string/jumbo v7, "正在上传壁纸 0%"

    invoke-interface {v6, v7}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move v6, v2

    :goto_11a
    if-ge v6, v5, :cond_1a5

    mul-int/lit16 v7, v6, 0x59a

    .line 66
    array-length v8, p1

    sub-int/2addr v8, v7

    const/16 v9, 0x59a

    invoke-static {v9, v8}, Ljava/lang/Math;->min(II)I

    move-result v8

    .line 67
    new-instance v9, Ljava/io/ByteArrayOutputStream;

    add-int/lit8 v10, v8, 0x12

    invoke-direct {v9, v10}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 68
    invoke-virtual {v9, v4}, Ljava/io/ByteArrayOutputStream;->write([B)V

    .line 69
    sget-object v10, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    invoke-virtual {v10, v8}, Lcom/example/bleconnectse/WallpaperProtocol;->int16(I)[B

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/io/ByteArrayOutputStream;->write([B)V

    .line 72
    sget-object v10, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    invoke-virtual {v10, v2}, Lcom/example/bleconnectse/WallpaperProtocol;->int32(I)[B

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/io/ByteArrayOutputStream;->write([B)V

    .line 73
    sget-object v10, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    array-length v11, p1

    invoke-virtual {v10, v11}, Lcom/example/bleconnectse/WallpaperProtocol;->int32(I)[B

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/io/ByteArrayOutputStream;->write([B)V

    .line 74
    sget-object v10, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    invoke-virtual {v10, v7}, Lcom/example/bleconnectse/WallpaperProtocol;->int32(I)[B

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/io/ByteArrayOutputStream;->write([B)V

    .line 75
    sget-object v10, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    long-to-int v11, v11

    invoke-virtual {v10, v11}, Lcom/example/bleconnectse/WallpaperProtocol;->int32(I)[B

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/io/ByteArrayOutputStream;->write([B)V

    .line 76
    invoke-virtual {v9, p1, v7, v8}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 77
    invoke-virtual {v9}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v7

    .line 78
    sget-object v8, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    invoke-static {v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/16 v9, 0x12

    invoke-virtual {v8, v9, v7}, Lcom/example/bleconnectse/WallpaperProtocol;->command(I[B)[B

    move-result-object v7

    invoke-direct {p0, v3, v7}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->send(Ljava/io/OutputStream;[B)V

    add-int/lit8 v7, v6, 0x1

    mul-int/lit8 v8, v7, 0x64

    .line 79
    div-int/2addr v8, v5

    const/16 v9, 0x64

    if-eq v8, v9, :cond_187

    if-eqz v6, :cond_187

    .line 80
    rem-int/lit8 v6, v8, 0xa

    if-nez v6, :cond_1a2

    .line 81
    :cond_187
    iget-object v6, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onStatus:Lkotlin/jvm/functions/Function1;

    new-instance v9, Ljava/lang/StringBuilder;

    const-string/jumbo v10, "正在上传壁纸 "

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "%"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6, v8}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1a2
    move v6, v7

    goto/16 :goto_11a

    :cond_1a5
    const/16 p1, 0x24

    .line 87
    invoke-direct {p0, v0, p1}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->await(Ljava/io/InputStream;I)Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;

    move-result-object p1

    invoke-virtual {p1}, Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;->getData()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->requireDataAccepted([B)V

    .line 88
    iget-object p1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onStatus:Lkotlin/jvm/functions/Function1;

    const-string/jumbo v4, "仪表确认壁纸 100%"

    invoke-interface {p1, v4}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 89
    sget-object p1, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    const/16 v4, 0x13

    sget-object v5, Lcom/example/bleconnectse/InstrumentWallpaperClient;->END_SUCCESS_PAYLOAD:[B

    invoke-virtual {p1, v4, v5}, Lcom/example/bleconnectse/WallpaperProtocol;->command(I[B)[B

    move-result-object p1

    invoke-direct {p0, v3, p1}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->send(Ljava/io/OutputStream;[B)V

    const/16 p1, 0x23

    .line 90
    invoke-direct {p0, v0, p1}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->await(Ljava/io/InputStream;I)Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;

    move-result-object p1

    invoke-virtual {p1}, Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;->getData()[B

    move-result-object p1

    .line 91
    array-length v0, p1

    if-nez v0, :cond_1d5

    goto :goto_1d6

    :cond_1d5
    move v1, v2

    :goto_1d6
    if-nez v1, :cond_1e7

    aget-byte p1, p1, v2

    and-int/lit8 p1, p1, 0x3

    if-eqz p1, :cond_1e7

    .line 94
    iget-object p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient;->onStatus:Lkotlin/jvm/functions/Function1;

    const-string/jumbo p1, "壁纸设置成功"

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 91
    :cond_1e7
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string/jumbo p1, "仪表未确认壁纸生效"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 58
    :cond_1f4
    array-length p0, p1

    new-instance p1, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "仪表确认的图片长度 "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, " 与本地 "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string p1, " 不一致"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 57
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 31
    :cond_21f
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo p1, "壁纸文件为空"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
