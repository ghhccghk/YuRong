# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda35;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda35;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda35;->f$1:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda35;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda35;->f$1:Ljava/lang/String;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->startInstrumentWallpaper$lambda$44$lambda$41(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
