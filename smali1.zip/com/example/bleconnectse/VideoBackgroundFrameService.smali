# classes2.dex

.class public final Lcom/example/bleconnectse/VideoBackgroundFrameService;
.super Landroid/app/Service;
.source "VideoBackgroundFrameService.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nVideoBackgroundFrameService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 VideoBackgroundFrameService.kt\ncom/example/bleconnectse/VideoBackgroundFrameService\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,204:1\n1#2:205\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 &2\u00020\u0001:\u0001&B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0014\u0010\b\u001a\u0004\u0018\u00010\t2\b\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0016J\"\u0010\f\u001a\u00020\r2\b\u0010\n\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\rH\u0016J\u0012\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u000bH\u0016J\b\u0010\u0013\u001a\u00020\u0011H\u0016J0\u0010\u0014\u001a\u00020\u00112\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001bH\u0002J*\u0010\u001d\u001a\u0004\u0018\u00010\u001e2\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u00182\u0006\u0010!\u001a\u00020\r2\u0006\u0010\"\u001a\u00020\rH\u0002J$\u0010#\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\r0$2\u0006\u0010!\u001a\u00020\r2\u0006\u0010\"\u001a\u00020\rH\u0002J\b\u0010%\u001a\u00020\u0011H\u0002R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\'"
    }
    d2 = {
        "Lcom/example/bleconnectse/VideoBackgroundFrameService;",
        "Landroid/app/Service;",
        "<init>",
        "()V",
        "executor",
        "Ljava/util/concurrent/ScheduledExecutorService;",
        "retriever",
        "Landroid/media/MediaMetadataRetriever;",
        "onBind",
        "Landroid/os/IBinder;",
        "intent",
        "Landroid/content/Intent;",
        "onStartCommand",
        "",
        "flags",
        "startId",
        "onTaskRemoved",
        "",
        "rootIntent",
        "onDestroy",
        "startDecoding",
        "uri",
        "Landroid/net/Uri;",
        "initialPositionMs",
        "",
        "suppliedDurationMs",
        "playing",
        "",
        "looping",
        "frameAt",
        "Landroid/graphics/Bitmap;",
        "source",
        "positionMs",
        "width",
        "height",
        "scaledSize",
        "Lkotlin/Pair;",
        "startAsForeground",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field private static final ACTION_STOP:Ljava/lang/String; = "com.example.bleconnectse.STOP_BACKGROUND_VIDEO_FRAMES"

.field private static final CHANNEL_ID:Ljava/lang/String; = "background_video_mirror"

.field public static final Companion:Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;

.field private static final EXTRA_DURATION_MS:Ljava/lang/String; = "duration_ms"

.field private static final EXTRA_IS_LOOPING:Ljava/lang/String; = "is_looping"

.field private static final EXTRA_IS_PLAYING:Ljava/lang/String; = "is_playing"

.field private static final EXTRA_POSITION_MS:Ljava/lang/String; = "position_ms"

.field private static final EXTRA_URI:Ljava/lang/String; = "uri"

.field private static final FRAME_INTERVAL_MS:J = 0x64L

.field private static final MAX_CAPTURE_EDGE:I = 0x500

.field private static final NOTIFICATION_ID:I = 0x3ed

.field private static final TAG:Ljava/lang/String; = "VideoBackgroundFrames"


# instance fields
.field private executor:Ljava/util/concurrent/ScheduledExecutorService;

.field private retriever:Landroid/media/MediaMetadataRetriever;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->Companion:Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;

    const/16 v0, 0x8

    sput v0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 24
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method private final frameAt(Landroid/media/MediaMetadataRetriever;JII)Landroid/graphics/Bitmap;
    .registers 14

    const-wide/16 v0, 0x0

    .line 114
    invoke-static {p2, p3, v0, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide p2

    const-wide/16 v0, 0x3e8

    mul-long v3, p2, v0

    .line 115
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p2, 0x1b

    if-lt p0, p2, :cond_1d

    if-lez p4, :cond_1d

    if-lez p5, :cond_1d

    const/4 v5, 0x3

    move-object v2, p1

    move v6, p4

    move v7, p5

    .line 116
    invoke-virtual/range {v2 .. v7}, Landroid/media/MediaMetadataRetriever;->getScaledFrameAtTime(JIII)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0

    :cond_1d
    move-object v2, p1

    move v6, p4

    move v7, p5

    const/4 p0, 0x3

    .line 123
    invoke-virtual {v2, v3, v4, p0}, Landroid/media/MediaMetadataRetriever;->getFrameAtTime(JI)Landroid/graphics/Bitmap;

    move-result-object p0

    if-nez p0, :cond_29

    const/4 p0, 0x0

    return-object p0

    :cond_29
    if-lez v6, :cond_43

    if-lez v7, :cond_43

    .line 124
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result p1

    if-ne p1, v6, :cond_3a

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result p1

    if-ne p1, v7, :cond_3a

    goto :goto_43

    :cond_3a
    const/4 p1, 0x1

    .line 127
    invoke-static {p0, v6, v7, p1}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object p1

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->recycle()V

    return-object p1

    :cond_43
    :goto_43
    return-object p0
.end method

.method private final scaledSize(II)Lkotlin/Pair;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    if-lez p1, :cond_35

    if-gtz p2, :cond_5

    goto :goto_35

    .line 132
    :cond_5
    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    move-result p0

    int-to-float p0, p0

    const/high16 v0, 0x44a00000  # 1280.0f

    div-float/2addr v0, p0

    const/high16 p0, 0x3f800000  # 1.0f

    invoke-static {p0, v0}, Ljava/lang/Math;->min(FF)F

    move-result p0

    int-to-float p1, p1

    mul-float/2addr p1, p0

    .line 133
    invoke-static {p1}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result p1

    const/4 v0, 0x2

    invoke-static {p1, v0}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    int-to-float p2, p2

    mul-float/2addr p2, p0

    .line 134
    invoke-static {p2}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result p0

    invoke-static {p0, v0}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    .line 133
    invoke-static {p1, p0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object p0

    return-object p0

    :cond_35
    :goto_35
    const/4 p0, 0x0

    .line 131
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-static {p1, p0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object p0

    return-object p0
.end method

.method private final startAsForeground()V
    .registers 6

    .line 138
    const-class v0, Landroid/app/NotificationManager;

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/VideoBackgroundFrameService;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 139
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    const-string v3, "background_video_mirror"

    if-lt v1, v2, :cond_1e

    .line 141
    new-instance v1, Landroid/app/NotificationChannel;

    const-string/jumbo v2, "后台视频投屏"

    check-cast v2, Ljava/lang/CharSequence;

    const/4 v4, 0x2

    invoke-direct {v1, v3, v2, v4}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 140
    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 144
    :cond_1e
    new-instance v0, Landroidx/core/app/NotificationCompat$Builder;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-direct {v0, v1, v3}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v1, 0x1080024

    .line 145
    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->setSmallIcon(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    .line 146
    const-string/jumbo v1, "正在后台投屏视频"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    .line 147
    const-string/jumbo v1, "独立解码画面并发送到仪表"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->setContentText(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    const/4 v1, 0x1

    .line 148
    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->setOngoing(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    .line 149
    invoke-virtual {v0}, Landroidx/core/app/NotificationCompat$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    const-string v1, "build(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 151
    check-cast p0, Landroid/app/Service;

    .line 154
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1d

    if-lt v1, v2, :cond_58

    const/16 v1, 0x10

    goto :goto_59

    :cond_58
    const/4 v1, 0x0

    :goto_59
    const/16 v2, 0x3ed

    .line 150
    invoke-static {p0, v2, v0, v1}, Landroidx/core/app/ServiceCompat;->startForeground(Landroid/app/Service;ILandroid/app/Notification;I)V

    return-void
.end method

.method private final startDecoding(Landroid/net/Uri;JJZZ)V
    .registers 22

    .line 76
    iget-object v0, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    if-eqz v0, :cond_7

    invoke-interface {v0}, Ljava/util/concurrent/ScheduledExecutorService;->shutdownNow()Ljava/util/List;

    .line 77
    :cond_7
    iget-object v0, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->retriever:Landroid/media/MediaMetadataRetriever;

    if-eqz v0, :cond_e

    invoke-virtual {v0}, Landroid/media/MediaMetadataRetriever;->release()V

    .line 78
    :cond_e
    new-instance v11, Landroid/media/MediaMetadataRetriever;

    invoke-direct {v11}, Landroid/media/MediaMetadataRetriever;-><init>()V

    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    invoke-virtual {v11, v0, p1}, Landroid/media/MediaMetadataRetriever;->setDataSource(Landroid/content/Context;Landroid/net/Uri;)V

    .line 79
    iput-object v11, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->retriever:Landroid/media/MediaMetadataRetriever;

    const/16 p1, 0x9

    .line 80
    invoke-virtual {v11, p1}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    if-eqz p1, :cond_29

    .line 81
    invoke-static {p1}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p1

    goto :goto_2a

    :cond_29
    move-object p1, v0

    :goto_2a
    invoke-static {p1}, Lcom/example/bleconnectse/VideoBackgroundFrameServiceKt;->access$orEmptyDuration(Ljava/lang/Long;)J

    move-result-wide v1

    .line 82
    invoke-static/range {p4 .. p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    move-object v3, p1

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    const-wide/16 v5, 0x0

    cmp-long v3, v3, v5

    if-lez v3, :cond_40

    goto :goto_41

    :cond_40
    move-object p1, v0

    :goto_41
    if-eqz p1, :cond_47

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    :cond_47
    move-wide v7, v1

    const/16 p1, 0x12

    .line 83
    invoke-virtual {v11, p1}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_55

    .line 84
    invoke-static {p1}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p1

    goto :goto_56

    :cond_55
    move-object p1, v0

    :goto_56
    invoke-static {p1}, Lcom/example/bleconnectse/VideoBackgroundFrameServiceKt;->access$orEmptyDimension(Ljava/lang/Integer;)I

    move-result p1

    const/16 v1, 0x13

    .line 85
    invoke-virtual {v11, v1}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_66

    .line 86
    invoke-static {v1}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    :cond_66
    invoke-static {v0}, Lcom/example/bleconnectse/VideoBackgroundFrameServiceKt;->access$orEmptyDimension(Ljava/lang/Integer;)I

    move-result v0

    .line 87
    invoke-direct {p0, p1, v0}, Lcom/example/bleconnectse/VideoBackgroundFrameService;->scaledSize(II)Lkotlin/Pair;

    move-result-object p1

    invoke-virtual {p1}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v12

    invoke-virtual {p1}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result v13

    .line 88
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    .line 89
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p1

    .line 90
    iput-object p1, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    .line 91
    new-instance v1, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;

    move-object v10, p0

    move-wide/from16 v5, p2

    move/from16 v2, p6

    move/from16 v9, p7

    invoke-direct/range {v1 .. v13}, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;-><init>(ZJJJZLcom/example/bleconnectse/VideoBackgroundFrameService;Landroid/media/MediaMetadataRetriever;II)V

    const-wide/16 v2, 0x64

    .line 105
    sget-object p0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v4, 0x0

    move-object/from16 p6, p0

    move-object p0, p1

    move-object p1, v1

    move-wide/from16 p4, v2

    move-wide/from16 p2, v4

    .line 91
    invoke-interface/range {p0 .. p6}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    return-void
.end method

.method static final startDecoding$lambda$3(ZJJJZLcom/example/bleconnectse/VideoBackgroundFrameService;Landroid/media/MediaMetadataRetriever;II)V
    .registers 16

    const-wide/16 v0, 0x0

    if-eqz p0, :cond_a

    .line 93
    :try_start_4
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    sub-long/2addr v2, p1

    goto :goto_b

    :cond_a
    move-wide v2, v0

    :goto_b
    add-long/2addr p3, v2

    cmp-long p0, p5, v0

    if-gtz p0, :cond_16

    :goto_10
    move-object p5, p8

    move-object p6, p9

    move p9, p10

    move p10, p11

    move-wide p7, p3

    goto :goto_1f

    :cond_16
    if-eqz p7, :cond_1a

    .line 97
    rem-long/2addr p3, p5

    goto :goto_10

    .line 98
    :cond_1a
    invoke-static {p3, p4, p5, p6}, Lkotlin/ranges/RangesKt;->coerceAtMost(JJ)J

    move-result-wide p3

    goto :goto_10

    .line 100
    :goto_1f
    invoke-direct/range {p5 .. p10}, Lcom/example/bleconnectse/VideoBackgroundFrameService;->frameAt(Landroid/media/MediaMetadataRetriever;JII)Landroid/graphics/Bitmap;

    move-result-object p0

    if-eqz p0, :cond_2a

    .line 101
    sget-object p1, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {p1, p0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->submit(Landroid/graphics/Bitmap;)V
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_2a} :catch_2a

    :catch_2a
    :cond_2a
    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 2

    const/4 p0, 0x0

    return-object p0
.end method

.method public onDestroy()V
    .registers 3

    .line 62
    iget-object v0, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    if-eqz v0, :cond_7

    invoke-interface {v0}, Ljava/util/concurrent/ScheduledExecutorService;->shutdownNow()Ljava/util/List;

    :cond_7
    const/4 v0, 0x0

    .line 63
    iput-object v0, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->executor:Ljava/util/concurrent/ScheduledExecutorService;

    .line 64
    iget-object v1, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->retriever:Landroid/media/MediaMetadataRetriever;

    if-eqz v1, :cond_11

    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V

    .line 65
    :cond_11
    iput-object v0, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->retriever:Landroid/media/MediaMetadataRetriever;

    .line 66
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 13

    if-eqz p1, :cond_7

    .line 31
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    goto :goto_8

    :cond_7
    const/4 p2, 0x0

    :goto_8
    const-string p3, "com.example.bleconnectse.STOP_BACKGROUND_VIDEO_FRAMES"

    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    const/4 p3, 0x2

    if-eqz p2, :cond_15

    .line 32
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoBackgroundFrameService;->stopSelf()V

    return p3

    :cond_15
    if-eqz p1, :cond_5e

    .line 35
    const-string p2, "uri"

    invoke-static {p1, p2}, Lcom/example/bleconnectse/VideoBackgroundFrameServiceKt;->access$uriExtra(Landroid/content/Intent;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    if-nez v2, :cond_20

    goto :goto_5e

    .line 39
    :cond_20
    invoke-direct {p0}, Lcom/example/bleconnectse/VideoBackgroundFrameService;->startAsForeground()V

    .line 43
    :try_start_23
    const-string p2, "position_ms"

    const-wide/16 v0, 0x0

    invoke-virtual {p1, p2, v0, v1}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v3

    .line 44
    const-string p2, "duration_ms"

    invoke-virtual {p1, p2, v0, v1}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v5

    .line 45
    const-string p2, "is_playing"

    const/4 v0, 0x1

    invoke-virtual {p1, p2, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v7

    .line 46
    const-string p2, "is_looping"

    invoke-virtual {p1, p2, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v8
    :try_end_3e
    .catch Ljava/lang/Exception; {:try_start_23 .. :try_end_3e} :catch_45

    move-object v1, p0

    .line 41
    :try_start_3f
    invoke-direct/range {v1 .. v8}, Lcom/example/bleconnectse/VideoBackgroundFrameService;->startDecoding(Landroid/net/Uri;JJZZ)V
    :try_end_42
    .catch Ljava/lang/Exception; {:try_start_3f .. :try_end_42} :catch_43

    goto :goto_5d

    :catch_43
    move-exception v0

    goto :goto_47

    :catch_45
    move-exception v0

    move-object v1, p0

    :goto_47
    move-object p0, v0

    .line 49
    const-string/jumbo p1, "无法启动后台视频取帧"

    check-cast p0, Ljava/lang/Throwable;

    const-string p2, "VideoBackgroundFrames"

    invoke-static {p2, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 50
    sget-object p0, Lcom/example/bleconnectse/MirrorTaskCleanup;->INSTANCE:Lcom/example/bleconnectse/MirrorTaskCleanup;

    move-object p1, v1

    check-cast p1, Landroid/content/Context;

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/MirrorTaskCleanup;->stopAll(Landroid/content/Context;)V

    .line 51
    invoke-virtual {v1}, Lcom/example/bleconnectse/VideoBackgroundFrameService;->stopSelf()V

    :goto_5d
    return p3

    :cond_5e
    :goto_5e
    move-object v1, p0

    .line 35
    move-object p0, v1

    check-cast p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;

    .line 36
    invoke-virtual {v1}, Lcom/example/bleconnectse/VideoBackgroundFrameService;->stopSelf()V

    return p3
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .registers 2

    .line 57
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    .line 58
    sget-object p1, Lcom/example/bleconnectse/MirrorTaskCleanup;->INSTANCE:Lcom/example/bleconnectse/MirrorTaskCleanup;

    check-cast p0, Landroid/content/Context;

    invoke-virtual {p1, p0}, Lcom/example/bleconnectse/MirrorTaskCleanup;->stopAll(Landroid/content/Context;)V

    return-void
.end method
