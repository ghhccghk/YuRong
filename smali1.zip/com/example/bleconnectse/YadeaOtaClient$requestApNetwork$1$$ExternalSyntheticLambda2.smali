# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Lcom/example/bleconnectse/YadeaWifiProfile;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Lcom/example/bleconnectse/YadeaWifiProfile;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda2;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;

    iput-object p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda2;->f$2:Lcom/example/bleconnectse/YadeaWifiProfile;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda2;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda2;->f$2:Lcom/example/bleconnectse/YadeaWifiProfile;

    invoke-static {v0, v1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;->onAvailable$lambda$0(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Lcom/example/bleconnectse/YadeaWifiProfile;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
