# classes2.dex

.class public final Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;
.super Ljava/lang/Object;
.source "AmapNavigationView.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/AmapNavigationView;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016¨\u0006\u0004"
    }
    d2 = {
        "com/example/bleconnectse/AmapNavigationView$framePublisher$1",
        "Ljava/lang/Runnable;",
        "run",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/AmapNavigationView;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/AmapNavigationView;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    .line 290
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 292
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getPublishing$p(Lcom/example/bleconnectse/AmapNavigationView;)Z

    move-result v0

    if-eqz v0, :cond_22

    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getClosed$p(Lcom/example/bleconnectse/AmapNavigationView;)Z

    move-result v0

    if-eqz v0, :cond_11

    goto :goto_22

    .line 293
    :cond_11
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 294
    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v2, v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->access$requestPixelCopyFrame(Lcom/example/bleconnectse/AmapNavigationView;J)Z

    move-result v2

    if-nez v2, :cond_22

    .line 295
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0, v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->access$requestMapSnapshotFrame(Lcom/example/bleconnectse/AmapNavigationView;J)V

    :cond_22
    :goto_22
    return-void
.end method
