# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/VideoMirrorController;

.field public final synthetic f$1:J

.field public final synthetic f$2:J

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/VideoMirrorController;JJLandroidx/compose/runtime/MutableState;)V
    .registers 7

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda11;->f$0:Lcom/example/bleconnectse/VideoMirrorController;

    iput-wide p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda11;->f$1:J

    iput-wide p4, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda11;->f$2:J

    iput-object p6, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda11;->f$3:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda11;->f$0:Lcom/example/bleconnectse/VideoMirrorController;

    iget-wide v1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda11;->f$1:J

    iget-wide v3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda11;->f$2:J

    iget-object v5, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda11;->f$3:Landroidx/compose/runtime/MutableState;

    move-object v6, p1

    check-cast v6, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-static/range {v0 .. v7}, Lcom/example/bleconnectse/MainActivityKt;->VideoMirrorDialog$lambda$97(Lcom/example/bleconnectse/VideoMirrorController;JJLandroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
