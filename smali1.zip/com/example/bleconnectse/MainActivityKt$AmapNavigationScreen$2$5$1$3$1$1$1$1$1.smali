# classes2.dex

.class final Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;
.super Ljava/lang/Object;
.source "MainActivity.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/MainActivityKt;->AmapNavigationScreen(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/NavigationTransport;Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $destinationSuggestions$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/AmapDestinationSuggestion;",
            ">;>;"
        }
    .end annotation
.end field

.field final synthetic $destinationText$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $navigationViewHolder:[Lcom/example/bleconnectse/AmapNavigationView;

.field final synthetic $suggestion:Lcom/example/bleconnectse/AmapDestinationSuggestion;


# direct methods
.method constructor <init>([Lcom/example/bleconnectse/AmapNavigationView;Lcom/example/bleconnectse/AmapDestinationSuggestion;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lcom/example/bleconnectse/AmapNavigationView;",
            "Lcom/example/bleconnectse/AmapDestinationSuggestion;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/AmapDestinationSuggestion;",
            ">;>;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;->$navigationViewHolder:[Lcom/example/bleconnectse/AmapNavigationView;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;->$suggestion:Lcom/example/bleconnectse/AmapDestinationSuggestion;

    iput-object p3, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;->$destinationText$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;->$destinationSuggestions$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 1

    .line 769
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;->invoke()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public final invoke()V
    .registers 3

    .line 770
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;->$navigationViewHolder:[Lcom/example/bleconnectse/AmapNavigationView;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    if-eqz v0, :cond_c

    .line 771
    iget-object v1, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;->$suggestion:Lcom/example/bleconnectse/AmapDestinationSuggestion;

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->selectDestinationSuggestion(Lcom/example/bleconnectse/AmapDestinationSuggestion;)V

    .line 772
    :cond_c
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;->$destinationText$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v1, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;->$suggestion:Lcom/example/bleconnectse/AmapDestinationSuggestion;

    invoke-virtual {v1}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/example/bleconnectse/MainActivityKt;->access$AmapNavigationScreen$lambda$3(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    .line 773
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$2$5$1$3$1$1$1$1$1;->$destinationSuggestions$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/example/bleconnectse/MainActivityKt;->access$AmapNavigationScreen$lambda$6(Landroidx/compose/runtime/MutableState;Ljava/util/List;)V

    return-void
.end method
