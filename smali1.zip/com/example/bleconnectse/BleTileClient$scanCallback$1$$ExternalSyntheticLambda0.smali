# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:Lcom/example/bleconnectse/BleTileClient;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Lcom/example/bleconnectse/BleTileClient;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda0;->f$0:Ljava/util/List;

    iput-object p2, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda0;->f$1:Lcom/example/bleconnectse/BleTileClient;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda0;->f$0:Ljava/util/List;

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda0;->f$1:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;->onBatchScanResults$lambda$1(Ljava/util/List;Lcom/example/bleconnectse/BleTileClient;)V

    return-void
.end method
