# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/SyntheticMapRenderer$WhenMappings;
.super Ljava/lang/Object;
.source "SyntheticMapRenderer.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/bleconnectse/SyntheticMapRenderer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1019
    name = "WhenMappings"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I

.field public static final synthetic $EnumSwitchMapping$1:[I


# direct methods
.method static constructor <clinit>()V
    .registers 5

    invoke-static {}, Lcom/example/bleconnectse/SyntheticAreaType;->values()[Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    const/4 v1, 0x1

    :try_start_8
    sget-object v2, Lcom/example/bleconnectse/SyntheticAreaType;->Building:Lcom/example/bleconnectse/SyntheticAreaType;

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticAreaType;->ordinal()I

    move-result v2

    aput v1, v0, v2
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_10} :catch_10

    :catch_10
    const/4 v2, 0x2

    :try_start_11
    sget-object v3, Lcom/example/bleconnectse/SyntheticAreaType;->Park:Lcom/example/bleconnectse/SyntheticAreaType;

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticAreaType;->ordinal()I

    move-result v3

    aput v2, v0, v3
    :try_end_19
    .catch Ljava/lang/NoSuchFieldError; {:try_start_11 .. :try_end_19} :catch_19

    :catch_19
    const/4 v3, 0x3

    :try_start_1a
    sget-object v4, Lcom/example/bleconnectse/SyntheticAreaType;->Water:Lcom/example/bleconnectse/SyntheticAreaType;

    invoke-virtual {v4}, Lcom/example/bleconnectse/SyntheticAreaType;->ordinal()I

    move-result v4

    aput v3, v0, v4
    :try_end_22
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1a .. :try_end_22} :catch_22

    :catch_22
    sput-object v0, Lcom/example/bleconnectse/SyntheticMapRenderer$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-static {}, Lcom/example/bleconnectse/SyntheticTraffic;->values()[Lcom/example/bleconnectse/SyntheticTraffic;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_2b
    sget-object v4, Lcom/example/bleconnectse/SyntheticTraffic;->Clear:Lcom/example/bleconnectse/SyntheticTraffic;

    invoke-virtual {v4}, Lcom/example/bleconnectse/SyntheticTraffic;->ordinal()I

    move-result v4

    aput v1, v0, v4
    :try_end_33
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2b .. :try_end_33} :catch_33

    :catch_33
    :try_start_33
    sget-object v1, Lcom/example/bleconnectse/SyntheticTraffic;->Slow:Lcom/example/bleconnectse/SyntheticTraffic;

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticTraffic;->ordinal()I

    move-result v1

    aput v2, v0, v1
    :try_end_3b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_33 .. :try_end_3b} :catch_3b

    :catch_3b
    :try_start_3b
    sget-object v1, Lcom/example/bleconnectse/SyntheticTraffic;->Congested:Lcom/example/bleconnectse/SyntheticTraffic;

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticTraffic;->ordinal()I

    move-result v1

    aput v3, v0, v1
    :try_end_43
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3b .. :try_end_43} :catch_43

    :catch_43
    sput-object v0, Lcom/example/bleconnectse/SyntheticMapRenderer$WhenMappings;->$EnumSwitchMapping$1:[I

    return-void
.end method
