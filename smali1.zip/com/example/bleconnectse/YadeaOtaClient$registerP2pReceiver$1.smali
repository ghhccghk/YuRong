# classes2.dex

.class public final Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;
.super Landroid/content/BroadcastReceiver;
.source "YadeaOtaClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/YadeaOtaClient;->registerP2pReceiver(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nYadeaOtaClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 YadeaOtaClient.kt\ncom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,2252:1\n295#2,2:2253\n295#2,2:2256\n1563#2:2258\n1634#2,3:2259\n1#3:2255\n*S KotlinDebug\n*F\n+ 1 YadeaOtaClient.kt\ncom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1\n*L\n1893#1:2253,2\n1918#1:2256,2\n1886#1:2258\n1886#1:2259,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001d\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0017¨\u0006\b"
    }
    d2 = {
        "com/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1",
        "Landroid/content/BroadcastReceiver;",
        "onReceive",
        "",
        "ctx",
        "Landroid/content/Context;",
        "intent",
        "Landroid/content/Intent;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $channel:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

.field final synthetic $manager:Landroid/net/wifi/p2p/WifiP2pManager;

.field final synthetic this$0:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V
    .registers 4

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->$manager:Landroid/net/wifi/p2p/WifiP2pManager;

    iput-object p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->$channel:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    .line 1879
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method static final onReceive$lambda$12(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/wifi/p2p/WifiP2pInfo;)V
    .registers 5

    const-string v0, "info"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1937
    iget-object v0, p3, Landroid/net/wifi/p2p/WifiP2pInfo;->groupOwnerAddress:Ljava/net/InetAddress;

    if-eqz v0, :cond_e

    invoke-virtual {v0}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v0

    goto :goto_f

    :cond_e
    const/4 v0, 0x0

    .line 1938
    :goto_f
    iget-boolean p3, p3, Landroid/net/wifi/p2p/WifiP2pInfo;->groupFormed:Z

    if-eqz p3, :cond_1e

    if-eqz v0, :cond_1e

    .line 1939
    new-instance p3, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda1;

    invoke-direct {p3, p2, v0, p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    invoke-virtual {p0, p1, p3}, Landroid/net/wifi/p2p/WifiP2pManager;->requestGroupInfo(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pManager$GroupInfoListener;)V

    return-void

    .line 1972
    :cond_1e
    new-instance p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda2;

    invoke-direct {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda2;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-static {p2, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$post(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method static final onReceive$lambda$12$lambda$10(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pGroup;)V
    .registers 15

    .line 1940
    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$getSelectedP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;)Lcom/example/bleconnectse/P2pPeer;

    move-result-object v7

    const/4 v0, 0x0

    if-eqz p4, :cond_c

    .line 1941
    invoke-virtual {p4}, Landroid/net/wifi/p2p/WifiP2pGroup;->getOwner()Landroid/net/wifi/p2p/WifiP2pDevice;

    move-result-object p4

    goto :goto_d

    :cond_c
    move-object p4, v0

    :goto_d
    if-eqz p4, :cond_12

    .line 1942
    iget-object v1, p4, Landroid/net/wifi/p2p/WifiP2pDevice;->deviceAddress:Ljava/lang/String;

    goto :goto_13

    :cond_12
    move-object v1, v0

    :goto_13
    const-string v2, ""

    if-nez v1, :cond_19

    move-object v6, v2

    goto :goto_1a

    :cond_19
    move-object v6, v1

    :goto_1a
    if-eqz p4, :cond_1e

    .line 1943
    iget-object v0, p4, Landroid/net/wifi/p2p/WifiP2pDevice;->deviceName:Ljava/lang/String;

    :cond_1e
    if-nez v0, :cond_22

    move-object v5, v2

    goto :goto_23

    :cond_22
    move-object v5, v0

    :goto_23
    const/4 p4, 0x0

    const/4 v0, 0x1

    if-eqz v7, :cond_3b

    .line 1945
    invoke-static {p0, v6}, Lcom/example/bleconnectse/YadeaOtaClient;->access$normalizeMac(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->access$normalizeMac(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3b

    move v1, v0

    goto :goto_3c

    :cond_3b
    move v1, p4

    :goto_3c
    if-eqz v7, :cond_4a

    .line 1947
    invoke-virtual {v7}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v5, v2, v0}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_4a

    move v2, v0

    goto :goto_4b

    :cond_4a
    move v2, p4

    .line 1948
    :goto_4b
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;

    move-object v3, p0

    move-object v4, p1

    move-object v8, p2

    move-object v9, p3

    invoke-direct/range {v0 .. v9}, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;-><init>(ZZLcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/example/bleconnectse/P2pPeer;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    invoke-static {v3, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$post(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method static final onReceive$lambda$12$lambda$10$lambda$9(ZZLcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/example/bleconnectse/P2pPeer;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)Lkotlin/Unit;
    .registers 10

    if-nez p0, :cond_5a

    if-eqz p1, :cond_5

    goto :goto_5a

    :cond_5
    const/4 p0, 0x0

    .line 1960
    invoke-static {p2, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setP2pPeerVerified$p(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 1961
    invoke-static {p2, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setP2pReady(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    const/4 p0, 0x0

    .line 1962
    invoke-static {p2, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setP2pGroupOwnerIp$p(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    if-eqz p6, :cond_17

    .line 1964
    invoke-virtual {p6}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object p1

    goto :goto_18

    :cond_17
    move-object p1, p0

    :goto_18
    if-eqz p6, :cond_1f

    invoke-virtual {p6}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object p3

    goto :goto_20

    :cond_1f
    move-object p3, p0

    .line 1965
    :goto_20
    new-instance p6, Ljava/lang/StringBuilder;

    const-string v0, "P2P 目标校验失败：期望="

    invoke-direct {p6, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p6, "/"

    invoke-virtual {p1, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo p3, "，实际="

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo p3, "，禁止投屏"

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 1963
    invoke-static {p2, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 1967
    invoke-virtual {p7, p8, p0}, Landroid/net/wifi/p2p/WifiP2pManager;->removeGroup(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;)V

    goto :goto_aa

    :cond_5a
    :goto_5a
    const/4 p0, 0x1

    .line 1950
    invoke-static {p2, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setP2pPeerVerified$p(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 1951
    invoke-static {p2, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setP2pReady(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 1952
    invoke-static {p2, p3}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setP2pGroupOwnerIp$p(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 1953
    invoke-static {p2, p3}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setTargetIp(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 1954
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p6, "P2P 已连接并校验通过："

    invoke-direct {p1, p6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 1956
    check-cast p4, Ljava/lang/CharSequence;

    invoke-static {p4}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_84

    move-object p4, p5

    .line 1957
    :cond_84
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "P2P 目标校验通过："

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string p1, " owner="

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string p1, " IP="

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 1955
    invoke-static {p2, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 1969
    :goto_aa
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onReceive$lambda$12$lambda$11(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    const/4 v0, 0x0

    .line 1973
    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setP2pPeerVerified$p(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 1974
    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setP2pReady(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    const/4 v0, 0x0

    .line 1975
    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setP2pGroupOwnerIp$p(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 1976
    const-string v0, "P2P 已断开"

    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 1977
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onReceive$lambda$7(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pDeviceList;)V
    .registers 6

    const-string v0, "peers"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1886
    invoke-virtual {p3}, Landroid/net/wifi/p2p/WifiP2pDeviceList;->getDeviceList()Ljava/util/Collection;

    move-result-object p3

    const-string v0, "getDeviceList(...)"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p3, Ljava/lang/Iterable;

    .line 2258
    new-instance v0, Ljava/util/ArrayList;

    const/16 v1, 0xa

    invoke-static {p3, v1}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v0, Ljava/util/Collection;

    .line 2259
    invoke-interface {p3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_21
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_38

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    .line 2260
    check-cast v1, Landroid/net/wifi/p2p/WifiP2pDevice;

    .line 1886
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$toPeer(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/wifi/p2p/WifiP2pDevice;)Lcom/example/bleconnectse/P2pPeer;

    move-result-object v1

    .line 2260
    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_21

    .line 2261
    :cond_38
    check-cast v0, Ljava/util/List;

    .line 1887
    new-instance p3, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;

    invoke-direct {p3, p0, v0, p1, p2}, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/util/List;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    invoke-static {p0, p3}, Lcom/example/bleconnectse/YadeaOtaClient;->access$post(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method static final onReceive$lambda$7$lambda$6(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/util/List;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)Lkotlin/Unit;
    .registers 11

    .line 1888
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getP2pPeers()Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    .line 1889
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getP2pPeers()Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-result-object v0

    move-object v1, p1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v0, v1}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->addAll(Ljava/util/Collection;)Z

    .line 1890
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "发现 P2P 设备："

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 1891
    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$getPendingP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;)Lcom/example/bleconnectse/P2pPeer;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_6d

    .line 1893
    move-object v2, p1

    check-cast v2, Ljava/lang/Iterable;

    .line 2253
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_36
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_69

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    move-object v4, v3

    check-cast v4, Lcom/example/bleconnectse/P2pPeer;

    .line 1894
    invoke-virtual {v4}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v5

    invoke-static {p0, v5}, Lcom/example/bleconnectse/YadeaOtaClient;->access$normalizeMac(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 1895
    invoke-virtual {v0}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v6

    invoke-static {p0, v6}, Lcom/example/bleconnectse/YadeaOtaClient;->access$normalizeMac(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 1894
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_6a

    .line 1896
    invoke-virtual {v4}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v4

    .line 1897
    invoke-virtual {v0}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x1

    .line 1896
    invoke-static {v4, v5, v6}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v4

    if-eqz v4, :cond_36

    goto :goto_6a

    :cond_69
    move-object v3, v1

    .line 2254
    :cond_6a
    :goto_6a
    check-cast v3, Lcom/example/bleconnectse/P2pPeer;

    goto :goto_6e

    :cond_6d
    move-object v3, v1

    :goto_6e
    if-eqz v0, :cond_a8

    if-eqz v3, :cond_a8

    .line 1903
    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$getPendingP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;)Lcom/example/bleconnectse/P2pPeer;

    move-result-object v2

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a8

    .line 1905
    invoke-static {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setPendingP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V

    .line 1906
    invoke-static {p0, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setSelectedP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V

    .line 1909
    invoke-virtual {v3}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_92

    invoke-virtual {v3}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v0

    :cond_92
    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v4, "已重新发现目标 P2P，开始连接："

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 1907
    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 1911
    invoke-static {p0, p2, p3, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->access$issueP2pConnect(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Lcom/example/bleconnectse/P2pPeer;)V

    .line 1913
    :cond_a8
    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$lockedBleWifiProfile(Lcom/example/bleconnectse/YadeaOtaClient;)Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p2

    .line 1914
    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$getAutoConnectLockedP2pAfterScan$p(Lcom/example/bleconnectse/YadeaOtaClient;)Z

    move-result p3

    if-eqz p3, :cond_107

    .line 1915
    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$getPendingP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;)Lcom/example/bleconnectse/P2pPeer;

    move-result-object p3

    if-nez p3, :cond_107

    if-eqz p2, :cond_107

    .line 1918
    check-cast p1, Ljava/lang/Iterable;

    .line 2256
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_c0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_d4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    move-object v0, p3

    check-cast v0, Lcom/example/bleconnectse/P2pPeer;

    .line 1919
    invoke-static {p0, v0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->access$peerMatchesProfile(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;Lcom/example/bleconnectse/YadeaWifiProfile;)Z

    move-result v0

    if-eqz v0, :cond_c0

    goto :goto_d5

    :cond_d4
    move-object p3, v1

    .line 1918
    :goto_d5
    check-cast p3, Lcom/example/bleconnectse/P2pPeer;

    if-eqz p3, :cond_107

    const/4 p1, 0x0

    .line 1922
    invoke-static {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setAutoConnectLockedP2pAfterScan$p(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 1923
    invoke-static {p0, p3}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setSelectedP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V

    .line 1926
    invoke-virtual {p3}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object p2

    check-cast p2, Ljava/lang/CharSequence;

    invoke-static {p2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_f0

    invoke-virtual {p3}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object p2

    :cond_f0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "已发现锁定 P2P，开始连接："

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 1924
    invoke-static {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    const/4 p2, 0x2

    .line 1928
    invoke-static {p0, p3, p1, p2, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->connectP2p$default(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;ZILjava/lang/Object;)V

    .line 1931
    :cond_107
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 4

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "intent"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1882
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_57

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result p2

    const v0, -0x69a8390a

    if-eq p2, v0, :cond_40

    const v0, -0x532207c3

    if-eq p2, v0, :cond_1f

    goto :goto_57

    :cond_1f
    const-string p2, "android.net.wifi.p2p.PEERS_CHANGED"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_28

    goto :goto_57

    .line 1884
    :cond_28
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-static {p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$hasWifiPermission(Lcom/example/bleconnectse/YadeaOtaClient;)Z

    move-result p1

    if-nez p1, :cond_31

    goto :goto_57

    .line 1885
    :cond_31
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->$manager:Landroid/net/wifi/p2p/WifiP2pManager;

    iget-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->$channel:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda4;

    invoke-direct {v0, p0, p1, p2}, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda4;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    invoke-virtual {p1, p2, v0}, Landroid/net/wifi/p2p/WifiP2pManager;->requestPeers(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pManager$PeerListListener;)V

    return-void

    .line 1882
    :cond_40
    const-string p2, "android.net.wifi.p2p.CONNECTION_STATE_CHANGE"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_49

    goto :goto_57

    .line 1936
    :cond_49
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->$manager:Landroid/net/wifi/p2p/WifiP2pManager;

    iget-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->$channel:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda5;

    invoke-direct {v0, p1, p2, p0}, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda5;-><init>(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-virtual {p1, p2, v0}, Landroid/net/wifi/p2p/WifiP2pManager;->requestConnectionInfo(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pManager$ConnectionInfoListener;)V

    :cond_57
    :goto_57
    return-void
.end method
