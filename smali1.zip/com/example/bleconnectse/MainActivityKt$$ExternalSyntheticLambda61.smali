# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$2:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$3:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$4:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$5:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$6:Z

.field public final synthetic f$7:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$8:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$9:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .registers 11

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$1:Lkotlin/jvm/functions/Function0;

    iput-object p3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$2:Lkotlin/jvm/functions/Function0;

    iput-object p4, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$3:Lkotlin/jvm/functions/Function0;

    iput-object p5, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$4:Lkotlin/jvm/functions/Function0;

    iput-object p6, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$5:Lkotlin/jvm/functions/Function0;

    iput-boolean p7, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$6:Z

    iput-object p8, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$7:Lkotlin/jvm/functions/Function0;

    iput-object p9, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$8:Lkotlin/jvm/functions/Function0;

    iput-object p10, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$9:Lkotlin/jvm/functions/Function0;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 17

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$1:Lkotlin/jvm/functions/Function0;

    iget-object v2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$2:Lkotlin/jvm/functions/Function0;

    iget-object v3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$3:Lkotlin/jvm/functions/Function0;

    iget-object v4, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$4:Lkotlin/jvm/functions/Function0;

    iget-object v5, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$5:Lkotlin/jvm/functions/Function0;

    iget-boolean v6, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$6:Z

    iget-object v7, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$7:Lkotlin/jvm/functions/Function0;

    iget-object v8, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$8:Lkotlin/jvm/functions/Function0;

    iget-object v9, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda61;->f$9:Lkotlin/jvm/functions/Function0;

    move-object v10, p1

    check-cast v10, Landroidx/compose/foundation/lazy/LazyItemScope;

    move-object v11, p2

    check-cast v11, Landroidx/compose/runtime/Composer;

    move-object/from16 p0, p3

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result v12

    invoke-static/range {v0 .. v12}, Lcom/example/bleconnectse/MainActivityKt;->MirrorNavScreen$lambda$105$lambda$104$lambda$102(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
