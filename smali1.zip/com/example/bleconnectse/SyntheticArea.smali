# classes2.dex

.class public final Lcom/example/bleconnectse/SyntheticArea;
.super Ljava/lang/Object;
.source "SyntheticMapData.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\'\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0006HÆ\u0003J\t\u0010\u0013\u001a\u00020\bHÆ\u0003J-\u0010\u0014\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001J\t\u0010\u001a\u001a\u00020\bHÖ\u0001R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010¨\u0006\u001b"
    }
    d2 = {
        "Lcom/example/bleconnectse/SyntheticArea;",
        "",
        "points",
        "",
        "Lcom/example/bleconnectse/SyntheticPoint;",
        "areaType",
        "Lcom/example/bleconnectse/SyntheticAreaType;",
        "name",
        "",
        "<init>",
        "(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)V",
        "getPoints",
        "()Ljava/util/List;",
        "getAreaType",
        "()Lcom/example/bleconnectse/SyntheticAreaType;",
        "getName",
        "()Ljava/lang/String;",
        "component1",
        "component2",
        "component3",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final areaType:Lcom/example/bleconnectse/SyntheticAreaType;

.field private final name:Ljava/lang/String;

.field private final points:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;",
            "Lcom/example/bleconnectse/SyntheticAreaType;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const-string v0, "points"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "areaType"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 34
    iput-object p1, p0, Lcom/example/bleconnectse/SyntheticArea;->points:Ljava/util/List;

    .line 35
    iput-object p2, p0, Lcom/example/bleconnectse/SyntheticArea;->areaType:Lcom/example/bleconnectse/SyntheticAreaType;

    .line 36
    iput-object p3, p0, Lcom/example/bleconnectse/SyntheticArea;->name:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 6

    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_6

    .line 36
    const-string p3, ""

    .line 33
    :cond_6
    invoke-direct {p0, p1, p2, p3}, Lcom/example/bleconnectse/SyntheticArea;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic copy$default(Lcom/example/bleconnectse/SyntheticArea;Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;ILjava/lang/Object;)Lcom/example/bleconnectse/SyntheticArea;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget-object p1, p0, Lcom/example/bleconnectse/SyntheticArea;->points:Ljava/util/List;

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget-object p2, p0, Lcom/example/bleconnectse/SyntheticArea;->areaType:Lcom/example/bleconnectse/SyntheticAreaType;

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    iget-object p3, p0, Lcom/example/bleconnectse/SyntheticArea;->name:Ljava/lang/String;

    :cond_12
    invoke-virtual {p0, p1, p2, p3}, Lcom/example/bleconnectse/SyntheticArea;->copy(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)Lcom/example/bleconnectse/SyntheticArea;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;"
        }
    .end annotation

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticArea;->points:Ljava/util/List;

    return-object p0
.end method

.method public final component2()Lcom/example/bleconnectse/SyntheticAreaType;
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticArea;->areaType:Lcom/example/bleconnectse/SyntheticAreaType;

    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticArea;->name:Ljava/lang/String;

    return-object p0
.end method

.method public final copy(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)Lcom/example/bleconnectse/SyntheticArea;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;",
            "Lcom/example/bleconnectse/SyntheticAreaType;",
            "Ljava/lang/String;",
            ")",
            "Lcom/example/bleconnectse/SyntheticArea;"
        }
    .end annotation

    const-string p0, "points"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "areaType"

    invoke-static {p2, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "name"

    invoke-static {p3, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p0, Lcom/example/bleconnectse/SyntheticArea;

    invoke-direct {p0, p1, p2, p3}, Lcom/example/bleconnectse/SyntheticArea;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/example/bleconnectse/SyntheticArea;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/example/bleconnectse/SyntheticArea;

    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticArea;->points:Ljava/util/List;

    iget-object v3, p1, Lcom/example/bleconnectse/SyntheticArea;->points:Ljava/util/List;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticArea;->areaType:Lcom/example/bleconnectse/SyntheticAreaType;

    iget-object v3, p1, Lcom/example/bleconnectse/SyntheticArea;->areaType:Lcom/example/bleconnectse/SyntheticAreaType;

    if-eq v1, v3, :cond_1e

    return v2

    :cond_1e
    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticArea;->name:Ljava/lang/String;

    iget-object p1, p1, Lcom/example/bleconnectse/SyntheticArea;->name:Ljava/lang/String;

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_29

    return v2

    :cond_29
    return v0
.end method

.method public final getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;
    .registers 1

    .line 35
    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticArea;->areaType:Lcom/example/bleconnectse/SyntheticAreaType;

    return-object p0
.end method

.method public final getName()Ljava/lang/String;
    .registers 1

    .line 36
    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticArea;->name:Ljava/lang/String;

    return-object p0
.end method

.method public final getPoints()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;"
        }
    .end annotation

    .line 34
    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticArea;->points:Ljava/util/List;

    return-object p0
.end method

.method public hashCode()I
    .registers 3

    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticArea;->points:Ljava/util/List;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticArea;->areaType:Lcom/example/bleconnectse/SyntheticAreaType;

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticAreaType;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticArea;->name:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 5

    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticArea;->points:Ljava/util/List;

    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticArea;->areaType:Lcom/example/bleconnectse/SyntheticAreaType;

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticArea;->name:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "SyntheticArea(points="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", areaType="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", name="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ")"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
