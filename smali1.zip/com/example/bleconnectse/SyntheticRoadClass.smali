# classes2.dex

.class public final enum Lcom/example/bleconnectse/SyntheticRoadClass;
.super Ljava/lang/Enum;
.source "SyntheticMapData.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/example/bleconnectse/SyntheticRoadClass;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\b\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0011\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\n¨\u0006\u000b"
    }
    d2 = {
        "Lcom/example/bleconnectse/SyntheticRoadClass;",
        "",
        "wireValue",
        "",
        "<init>",
        "(Ljava/lang/String;II)V",
        "getWireValue",
        "()I",
        "Local",
        "Main",
        "Navigation",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/example/bleconnectse/SyntheticRoadClass;

.field public static final enum Local:Lcom/example/bleconnectse/SyntheticRoadClass;

.field public static final enum Main:Lcom/example/bleconnectse/SyntheticRoadClass;

.field public static final enum Navigation:Lcom/example/bleconnectse/SyntheticRoadClass;


# instance fields
.field private final wireValue:I


# direct methods
.method private static final synthetic $values()[Lcom/example/bleconnectse/SyntheticRoadClass;
    .registers 3

    sget-object v0, Lcom/example/bleconnectse/SyntheticRoadClass;->Local:Lcom/example/bleconnectse/SyntheticRoadClass;

    sget-object v1, Lcom/example/bleconnectse/SyntheticRoadClass;->Main:Lcom/example/bleconnectse/SyntheticRoadClass;

    sget-object v2, Lcom/example/bleconnectse/SyntheticRoadClass;->Navigation:Lcom/example/bleconnectse/SyntheticRoadClass;

    filled-new-array {v0, v1, v2}, [Lcom/example/bleconnectse/SyntheticRoadClass;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 3

    .line 8
    new-instance v0, Lcom/example/bleconnectse/SyntheticRoadClass;

    const-string v1, "Local"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/example/bleconnectse/SyntheticRoadClass;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/example/bleconnectse/SyntheticRoadClass;->Local:Lcom/example/bleconnectse/SyntheticRoadClass;

    .line 9
    new-instance v0, Lcom/example/bleconnectse/SyntheticRoadClass;

    const-string v1, "Main"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2, v2}, Lcom/example/bleconnectse/SyntheticRoadClass;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/example/bleconnectse/SyntheticRoadClass;->Main:Lcom/example/bleconnectse/SyntheticRoadClass;

    .line 10
    new-instance v0, Lcom/example/bleconnectse/SyntheticRoadClass;

    const-string v1, "Navigation"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2, v2}, Lcom/example/bleconnectse/SyntheticRoadClass;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/example/bleconnectse/SyntheticRoadClass;->Navigation:Lcom/example/bleconnectse/SyntheticRoadClass;

    invoke-static {}, Lcom/example/bleconnectse/SyntheticRoadClass;->$values()[Lcom/example/bleconnectse/SyntheticRoadClass;

    move-result-object v0

    sput-object v0, Lcom/example/bleconnectse/SyntheticRoadClass;->$VALUES:[Lcom/example/bleconnectse/SyntheticRoadClass;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/example/bleconnectse/SyntheticRoadClass;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .line 7
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lcom/example/bleconnectse/SyntheticRoadClass;->wireValue:I

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/example/bleconnectse/SyntheticRoadClass;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/example/bleconnectse/SyntheticRoadClass;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/example/bleconnectse/SyntheticRoadClass;
    .registers 2

    const-class v0, Lcom/example/bleconnectse/SyntheticRoadClass;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/example/bleconnectse/SyntheticRoadClass;

    return-object p0
.end method

.method public static values()[Lcom/example/bleconnectse/SyntheticRoadClass;
    .registers 1

    sget-object v0, Lcom/example/bleconnectse/SyntheticRoadClass;->$VALUES:[Lcom/example/bleconnectse/SyntheticRoadClass;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/example/bleconnectse/SyntheticRoadClass;

    return-object v0
.end method


# virtual methods
.method public final getWireValue()I
    .registers 1

    .line 7
    iget p0, p0, Lcom/example/bleconnectse/SyntheticRoadClass;->wireValue:I

    return p0
.end method
