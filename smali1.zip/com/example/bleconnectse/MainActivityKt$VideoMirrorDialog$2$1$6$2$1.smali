# classes2.dex

.class final synthetic Lcom/example/bleconnectse/MainActivityKt$VideoMirrorDialog$2$1$6$2$1;
.super Lkotlin/jvm/internal/FunctionReferenceImpl;
.source "MainActivity.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/MainActivityKt;->VideoMirrorDialog(Lcom/example/bleconnectse/VideoMirrorController;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1018
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/FunctionReferenceImpl;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .registers 9

    const-class v3, Lcom/example/bleconnectse/VideoMirrorController;

    const-string v5, "togglePlayback()V"

    const/4 v6, 0x0

    const/4 v1, 0x0

    const-string v4, "togglePlayback"

    move-object v0, p0

    move-object v2, p1

    invoke-direct/range {v0 .. v6}, Lkotlin/jvm/internal/FunctionReferenceImpl;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 1

    .line 1116
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivityKt$VideoMirrorDialog$2$1$6$2$1;->invoke()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public final invoke()V
    .registers 1

    .line 1116
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$VideoMirrorDialog$2$1$6$2$1;->receiver:Ljava/lang/Object;

    check-cast p0, Lcom/example/bleconnectse/VideoMirrorController;

    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->togglePlayback()V

    return-void
.end method
