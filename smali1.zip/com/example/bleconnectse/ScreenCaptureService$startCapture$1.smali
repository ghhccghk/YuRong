# classes2.dex

.class public final Lcom/example/bleconnectse/ScreenCaptureService$startCapture$1;
.super Landroid/media/projection/MediaProjection$Callback;
.source "ScreenCaptureService.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/ScreenCaptureService;->startCapture(ILandroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016¨\u0006\u0004"
    }
    d2 = {
        "com/example/bleconnectse/ScreenCaptureService$startCapture$1",
        "Landroid/media/projection/MediaProjection$Callback;",
        "onStop",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/ScreenCaptureService;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/ScreenCaptureService;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/ScreenCaptureService$startCapture$1;->this$0:Lcom/example/bleconnectse/ScreenCaptureService;

    .line 103
    invoke-direct {p0}, Landroid/media/projection/MediaProjection$Callback;-><init>()V

    return-void
.end method


# virtual methods
.method public onStop()V
    .registers 2

    .line 105
    iget-object v0, p0, Lcom/example/bleconnectse/ScreenCaptureService$startCapture$1;->this$0:Lcom/example/bleconnectse/ScreenCaptureService;

    invoke-static {v0}, Lcom/example/bleconnectse/ScreenCaptureService;->access$getStopping$p(Lcom/example/bleconnectse/ScreenCaptureService;)Z

    move-result v0

    if-nez v0, :cond_11

    sget-object v0, Lcom/example/bleconnectse/MirrorTaskCleanup;->INSTANCE:Lcom/example/bleconnectse/MirrorTaskCleanup;

    iget-object p0, p0, Lcom/example/bleconnectse/ScreenCaptureService$startCapture$1;->this$0:Lcom/example/bleconnectse/ScreenCaptureService;

    check-cast p0, Landroid/content/Context;

    invoke-virtual {v0, p0}, Lcom/example/bleconnectse/MirrorTaskCleanup;->stopAll(Landroid/content/Context;)V

    :cond_11
    return-void
.end method
