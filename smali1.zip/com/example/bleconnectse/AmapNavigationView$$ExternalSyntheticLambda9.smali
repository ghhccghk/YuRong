# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/amap/api/services/help/Inputtips$InputtipsListener;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/AmapNavigationView;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/AmapNavigationView;I)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda9;->f$0:Lcom/example/bleconnectse/AmapNavigationView;

    iput p2, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda9;->f$1:I

    return-void
.end method


# virtual methods
.method public final onGetInputtips(Ljava/util/List;I)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda9;->f$0:Lcom/example/bleconnectse/AmapNavigationView;

    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda9;->f$1:I

    invoke-static {v0, p0, p1, p2}, Lcom/example/bleconnectse/AmapNavigationView;->searchDestinationSuggestions$lambda$11$lambda$10(Lcom/example/bleconnectse/AmapNavigationView;ILjava/util/List;I)V

    return-void
.end method
