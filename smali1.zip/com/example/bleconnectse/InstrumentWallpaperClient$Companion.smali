# classes2.dex

.class final Lcom/example/bleconnectse/InstrumentWallpaperClient$Companion;
.super Ljava/lang/Object;
.source "InstrumentWallpaperClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/bleconnectse/InstrumentWallpaperClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0012\n\u0002\u0010\u0012\n\u0002\b\b\b\u0082\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u0011\u0010\u0017\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\u001b\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001aR\u0011\u0010\u001d\u001a\u00020\u0018¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001aR\u000e\u0010\u001f\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000¨\u0006 "
    }
    d2 = {
        "Lcom/example/bleconnectse/InstrumentWallpaperClient$Companion;",
        "",
        "<init>",
        "()V",
        "RESPONSE_TIMEOUT_MS",
        "",
        "CHUNK_SIZE",
        "MAX_IMAGE_BYTES",
        "MIN_JPEG_QUALITY",
        "CMD_START_REQUEST",
        "CMD_PARAM_REQUEST",
        "CMD_DATA_REQUEST",
        "CMD_END_REQUEST",
        "CMD_HEARTBEAT",
        "CMD_START_RESPONSE",
        "CMD_PARAM_RESPONSE",
        "CMD_END_RESPONSE",
        "CMD_DATA_RESPONSE",
        "CMD_NEGATIVE_RESPONSE",
        "DISPLAY_NV21_JPEG",
        "DISPLAY_PNG",
        "DISPLAY_JPEG",
        "DISPLAY_JIELI_RLE",
        "START_PAYLOAD",
        "",
        "getSTART_PAYLOAD",
        "()[B",
        "PARAM_RESERVED",
        "getPARAM_RESERVED",
        "END_SUCCESS_PAYLOAD",
        "getEND_SUCCESS_PAYLOAD",
        "DATA_STATUS_ACCEPTED",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 247
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/example/bleconnectse/InstrumentWallpaperClient$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final getEND_SUCCESS_PAYLOAD()[B
    .registers 1

    .line 268
    invoke-static {}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->access$getEND_SUCCESS_PAYLOAD$cp()[B

    move-result-object p0

    return-object p0
.end method

.method public final getPARAM_RESERVED()[B
    .registers 1

    .line 267
    invoke-static {}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->access$getPARAM_RESERVED$cp()[B

    move-result-object p0

    return-object p0
.end method

.method public final getSTART_PAYLOAD()[B
    .registers 1

    .line 266
    invoke-static {}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->access$getSTART_PAYLOAD$cp()[B

    move-result-object p0

    return-object p0
.end method
