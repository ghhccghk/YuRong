# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$1:Landroid/bluetooth/BluetoothGattCharacteristic;

.field public final synthetic f$2:[B


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGattCharacteristic;[B)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda6;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iput-object p2, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda6;->f$1:Landroid/bluetooth/BluetoothGattCharacteristic;

    iput-object p3, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda6;->f$2:[B

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda6;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda6;->f$1:Landroid/bluetooth/BluetoothGattCharacteristic;

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda6;->f$2:[B

    invoke-static {v0, v1, p0}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->onCharacteristicChanged$lambda$6(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGattCharacteristic;[B)V

    return-void
.end method
