# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:Landroid/net/Network;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Network;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda1;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda1;->f$1:Landroid/net/Network;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda1;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda1;->f$1:Landroid/net/Network;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;->onLost$lambda$2(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Network;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
