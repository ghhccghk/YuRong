# classes2.dex

.class public final enum Lcom/example/bleconnectse/OtaNetworkMode;
.super Ljava/lang/Enum;
.source "YadeaOtaClient.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/example/bleconnectse/OtaNetworkMode;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0011\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007j\u0002\b\bj\u0002\b\t¨\u0006\n"
    }
    d2 = {
        "Lcom/example/bleconnectse/OtaNetworkMode;",
        "",
        "title",
        "",
        "<init>",
        "(Ljava/lang/String;ILjava/lang/String;)V",
        "getTitle",
        "()Ljava/lang/String;",
        "Ap",
        "P2p",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/example/bleconnectse/OtaNetworkMode;

.field public static final enum Ap:Lcom/example/bleconnectse/OtaNetworkMode;

.field public static final enum P2p:Lcom/example/bleconnectse/OtaNetworkMode;


# instance fields
.field private final title:Ljava/lang/String;


# direct methods
.method private static final synthetic $values()[Lcom/example/bleconnectse/OtaNetworkMode;
    .registers 2

    sget-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->Ap:Lcom/example/bleconnectse/OtaNetworkMode;

    sget-object v1, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;

    filled-new-array {v0, v1}, [Lcom/example/bleconnectse/OtaNetworkMode;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 4

    .line 85
    new-instance v0, Lcom/example/bleconnectse/OtaNetworkMode;

    const/4 v1, 0x0

    const-string v2, "AP"

    const-string v3, "Ap"

    invoke-direct {v0, v3, v1, v2}, Lcom/example/bleconnectse/OtaNetworkMode;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->Ap:Lcom/example/bleconnectse/OtaNetworkMode;

    .line 86
    new-instance v0, Lcom/example/bleconnectse/OtaNetworkMode;

    const/4 v1, 0x1

    const-string v2, "P2P"

    const-string v3, "P2p"

    invoke-direct {v0, v3, v1, v2}, Lcom/example/bleconnectse/OtaNetworkMode;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-static {}, Lcom/example/bleconnectse/OtaNetworkMode;->$values()[Lcom/example/bleconnectse/OtaNetworkMode;

    move-result-object v0

    sput-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->$VALUES:[Lcom/example/bleconnectse/OtaNetworkMode;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 84
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lcom/example/bleconnectse/OtaNetworkMode;->title:Ljava/lang/String;

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/example/bleconnectse/OtaNetworkMode;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/example/bleconnectse/OtaNetworkMode;
    .registers 2

    const-class v0, Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/example/bleconnectse/OtaNetworkMode;

    return-object p0
.end method

.method public static values()[Lcom/example/bleconnectse/OtaNetworkMode;
    .registers 1

    sget-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->$VALUES:[Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/example/bleconnectse/OtaNetworkMode;

    return-object v0
.end method


# virtual methods
.method public final getTitle()Ljava/lang/String;
    .registers 1

    .line 84
    iget-object p0, p0, Lcom/example/bleconnectse/OtaNetworkMode;->title:Ljava/lang/String;

    return-object p0
.end method
