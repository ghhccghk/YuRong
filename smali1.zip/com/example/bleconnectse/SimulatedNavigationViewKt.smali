# classes2.dex

.class public final Lcom/example/bleconnectse/SimulatedNavigationViewKt;
.super Ljava/lang/Object;
.source "SimulatedNavigationView.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0018\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0007\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000¨\u0006\b"
    }
    d2 = {
        "MIRROR_FRAME_WIDTH",
        "",
        "MIRROR_FRAME_HEIGHT",
        "MIRROR_FRAME_INTERVAL_MS",
        "",
        "VEHICLE_SPEED_WORLD_UNITS_PER_SECOND",
        "",
        "BLE_TILE_LOOKAHEAD_WORLD_UNITS",
        "app"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final BLE_TILE_LOOKAHEAD_WORLD_UNITS:F = 600.0f

.field private static final MIRROR_FRAME_HEIGHT:I = 0x2d0

.field private static final MIRROR_FRAME_INTERVAL_MS:J = 0x64L

.field private static final MIRROR_FRAME_WIDTH:I = 0x500

.field private static final VEHICLE_SPEED_WORLD_UNITS_PER_SECOND:F = 120.0f
