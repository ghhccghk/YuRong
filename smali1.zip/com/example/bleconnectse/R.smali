# classes2.dex

.class public final Lcom/example/bleconnectse/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/R$color;,
        Lcom/example/bleconnectse/R$drawable;,
        Lcom/example/bleconnectse/R$mipmap;,
        Lcom/example/bleconnectse/R$string;,
        Lcom/example/bleconnectse/R$style;,
        Lcom/example/bleconnectse/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
