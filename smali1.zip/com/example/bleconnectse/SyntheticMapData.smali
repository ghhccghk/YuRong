# classes2.dex

.class public final Lcom/example/bleconnectse/SyntheticMapData;
.super Ljava/lang/Object;
.source "SyntheticMapData.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSyntheticMapData.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SyntheticMapData.kt\ncom/example/bleconnectse/SyntheticMapData\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,347:1\n1878#2,3:348\n1563#2:353\n1634#2,3:354\n1563#2:357\n1634#2,3:358\n1563#2:364\n1634#2,3:365\n1563#2:368\n1634#2,3:369\n1563#2:375\n1634#2,3:376\n1563#2:379\n1634#2,3:380\n1563#2:386\n1634#2,3:387\n1563#2:390\n1634#2,3:391\n1878#2,3:395\n3575#2,10:404\n13567#3,2:351\n13569#3:361\n13567#3,2:362\n13569#3:372\n13567#3,2:373\n13569#3:383\n13567#3,2:384\n13569#3:394\n13567#3,2:398\n13567#3,3:400\n13569#3:403\n*S KotlinDebug\n*F\n+ 1 SyntheticMapData.kt\ncom/example/bleconnectse/SyntheticMapData\n*L\n89#1:348,3\n118#1:353\n118#1:354,3\n134#1:357\n134#1:358,3\n146#1:364\n146#1:365,3\n158#1:368\n158#1:369,3\n170#1:375\n170#1:376,3\n176#1:379\n176#1:380,3\n187#1:386\n187#1:387,3\n193#1:390\n193#1:391,3\n305#1:395,3\n79#1:404,10\n117#1:351,2\n117#1:361\n145#1:362,2\n145#1:372\n168#1:373,2\n168#1:383\n185#1:384,2\n185#1:394\n318#1:398,2\n319#1:400,3\n318#1:403\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001a\u0010 \u001a\u000e\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020\u001c0!2\u0006\u0010\"\u001a\u00020\u001cJ\u0016\u0010#\u001a\u00020\u00052\u0006\u0010$\u001a\u00020\u00052\u0006\u0010%\u001a\u00020\u0005J\u000e\u0010&\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eH\u0002J\u000e\u0010\'\u001a\b\u0012\u0004\u0012\u00020\u00130\u000eH\u0002J\u000e\u0010(\u001a\b\u0012\u0004\u0012\u00020\u00160\u000eH\u0002J:\u0010)\u001a\u00020\u00132\u0006\u0010*\u001a\u00020\u00052\u0006\u0010+\u001a\u00020\u00052\u0006\u0010,\u001a\u00020\u00052\u0006\u0010-\u001a\u00020\u00052\u0006\u0010.\u001a\u00020/2\b\b\u0002\u00100\u001a\u000201H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0017\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00130\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0011R\u0017\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00160\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0011R\u0017\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00190\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0011R\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001c0\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u001d\u001a\u00020\u001c¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001f¨\u00062"
    }
    d2 = {
        "Lcom/example/bleconnectse/SyntheticMapData;",
        "",
        "<init>",
        "()V",
        "VIEWPORT_WIDTH",
        "",
        "VIEWPORT_HEIGHT",
        "WORLD_WIDTH",
        "WORLD_HEIGHT",
        "TILE_WIDTH",
        "TILE_HEIGHT",
        "TILE_COLUMNS",
        "TILE_ROWS",
        "roads",
        "",
        "Lcom/example/bleconnectse/SyntheticRoad;",
        "getRoads",
        "()Ljava/util/List;",
        "areas",
        "Lcom/example/bleconnectse/SyntheticArea;",
        "getAreas",
        "junctions",
        "Lcom/example/bleconnectse/SyntheticJunction;",
        "getJunctions",
        "navigationRoute",
        "Lcom/example/bleconnectse/SyntheticPoint;",
        "getNavigationRoute",
        "routeSegmentLengths",
        "",
        "routeLength",
        "getRouteLength",
        "()F",
        "pointAlongRoute",
        "Lkotlin/Pair;",
        "distance",
        "tileId",
        "tileX",
        "tileY",
        "buildRoads",
        "buildAreas",
        "buildJunctions",
        "rectangleArea",
        "left",
        "top",
        "right",
        "bottom",
        "type",
        "Lcom/example/bleconnectse/SyntheticAreaType;",
        "name",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

.field public static final TILE_COLUMNS:I = 0x8

.field public static final TILE_HEIGHT:I = 0x1e0

.field public static final TILE_ROWS:I = 0x5

.field public static final TILE_WIDTH:I = 0x320

.field public static final VIEWPORT_HEIGHT:I = 0x2d0

.field public static final VIEWPORT_WIDTH:I = 0x500

.field public static final WORLD_HEIGHT:I = 0x960

.field public static final WORLD_WIDTH:I = 0x1900

.field private static final areas:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticArea;",
            ">;"
        }
    .end annotation
.end field

.field private static final junctions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticJunction;",
            ">;"
        }
    .end annotation
.end field

.field private static final navigationRoute:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;"
        }
    .end annotation
.end field

.field private static final roads:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticRoad;",
            ">;"
        }
    .end annotation
.end field

.field private static final routeLength:F

.field private static final routeSegmentLengths:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 10

    new-instance v0, Lcom/example/bleconnectse/SyntheticMapData;

    invoke-direct {v0}, Lcom/example/bleconnectse/SyntheticMapData;-><init>()V

    sput-object v0, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    .line 60
    invoke-direct {v0}, Lcom/example/bleconnectse/SyntheticMapData;->buildRoads()Ljava/util/List;

    move-result-object v1

    sput-object v1, Lcom/example/bleconnectse/SyntheticMapData;->roads:Ljava/util/List;

    .line 61
    invoke-direct {v0}, Lcom/example/bleconnectse/SyntheticMapData;->buildAreas()Ljava/util/List;

    move-result-object v1

    sput-object v1, Lcom/example/bleconnectse/SyntheticMapData;->areas:Ljava/util/List;

    .line 62
    invoke-direct {v0}, Lcom/example/bleconnectse/SyntheticMapData;->buildJunctions()Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/example/bleconnectse/SyntheticMapData;->junctions:Ljava/util/List;

    const/16 v0, 0xd

    .line 64
    new-array v0, v0, [Lcom/example/bleconnectse/SyntheticPoint;

    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v2, 0xb4

    const/16 v3, 0x10e

    invoke-direct {v1, v2, v3}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v4, 0x0

    aput-object v1, v0, v4

    .line 65
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v4, 0x47e

    const/16 v5, 0x11d

    invoke-direct {v1, v4, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v4, 0x1

    aput-object v1, v0, v4

    .line 66
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v4, 0x802

    const/16 v5, 0x2d0

    invoke-direct {v1, v4, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v4, 0x2

    aput-object v1, v0, v4

    .line 67
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v4, 0xdde

    const/16 v5, 0x2c6

    invoke-direct {v1, v4, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v4, 0x3

    aput-object v1, v0, v4

    .line 68
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v4, 0x13ec

    const/16 v5, 0x49c

    invoke-direct {v1, v4, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v4, 0x4

    aput-object v1, v0, v4

    .line 69
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v4, 0x1798

    const/16 v6, 0x668

    invoke-direct {v1, v4, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v4, 0x5

    aput-object v1, v0, v4

    .line 70
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v4, 0x1450

    const/16 v7, 0x834

    invoke-direct {v1, v4, v7}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v4, 0x6

    aput-object v1, v0, v4

    .line 71
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v4, 0xe42

    const/16 v8, 0x820

    invoke-direct {v1, v4, v8}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v4, 0x7

    aput-object v1, v0, v4

    .line 72
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v4, 0xb04

    invoke-direct {v1, v4, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v4, 0x8

    aput-object v1, v0, v4

    .line 73
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x500

    const/16 v8, 0x67c

    invoke-direct {v1, v6, v8}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v6, 0x9

    aput-object v1, v0, v6

    .line 74
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x1a4

    invoke-direct {v1, v6, v7}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v6, 0xa

    aput-object v1, v0, v6

    .line 75
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x186

    invoke-direct {v1, v6, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v5, 0xb

    aput-object v1, v0, v5

    .line 76
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v1, v2, v3}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v2, 0xc

    aput-object v1, v0, v2

    .line 63
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/example/bleconnectse/SyntheticMapData;->navigationRoute:Ljava/util/List;

    .line 79
    check-cast v0, Ljava/lang/Iterable;

    .line 404
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 405
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_cb

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    goto :goto_10a

    .line 406
    :cond_cb
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    check-cast v1, Ljava/util/List;

    .line 407
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .line 408
    :goto_d6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_109

    .line 409
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .line 410
    move-object v5, v3

    check-cast v5, Lcom/example/bleconnectse/SyntheticPoint;

    check-cast v2, Lcom/example/bleconnectse/SyntheticPoint;

    .line 80
    invoke-virtual {v5}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v6

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v7

    sub-int/2addr v6, v7

    int-to-float v6, v6

    float-to-double v6, v6

    invoke-virtual {v5}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v5

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v2

    sub-int/2addr v5, v2

    int-to-float v2, v5

    float-to-double v8, v2

    invoke-static {v6, v7, v8, v9}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v5

    double-to-float v2, v5

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    .line 410
    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-object v2, v3

    goto :goto_d6

    :cond_109
    move-object v0, v1

    .line 79
    :goto_10a
    sput-object v0, Lcom/example/bleconnectse/SyntheticMapData;->routeSegmentLengths:Ljava/util/List;

    .line 82
    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->sumOfFloat(Ljava/lang/Iterable;)F

    move-result v0

    sput v0, Lcom/example/bleconnectse/SyntheticMapData;->routeLength:F

    sput v4, Lcom/example/bleconnectse/SyntheticMapData;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 50
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final buildAreas()Ljava/util/List;
    .registers 29
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticArea;",
            ">;"
        }
    .end annotation

    .line 225
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    check-cast v0, Ljava/util/List;

    const/4 v1, 0x0

    move v2, v1

    :goto_9
    const/16 v3, 0x8

    const/4 v4, 0x5

    if-ge v2, v4, :cond_7c

    move v4, v1

    :goto_f
    if-ge v4, v3, :cond_79

    mul-int/lit16 v5, v4, 0x320

    mul-int/lit16 v6, v2, 0x1e0

    mul-int/lit8 v7, v4, 0x13

    mul-int/lit8 v8, v2, 0x7

    add-int/2addr v7, v8

    .line 230
    rem-int/lit8 v7, v7, 0x28

    add-int/lit8 v7, v7, 0x46

    mul-int/lit8 v8, v4, 0xb

    mul-int/lit8 v9, v2, 0x11

    add-int/2addr v8, v9

    .line 231
    rem-int/lit8 v8, v8, 0x22

    add-int/lit8 v8, v8, 0x3a

    .line 232
    move-object v9, v0

    check-cast v9, Ljava/util/Collection;

    add-int v11, v5, v7

    add-int v12, v6, v8

    add-int/lit16 v13, v5, 0x136

    add-int/lit16 v14, v6, 0xcd

    .line 237
    sget-object v15, Lcom/example/bleconnectse/SyntheticAreaType;->Building:Lcom/example/bleconnectse/SyntheticAreaType;

    const/16 v17, 0x20

    const/16 v18, 0x0

    const/16 v16, 0x0

    move-object/from16 v10, p0

    .line 232
    invoke-static/range {v10 .. v18}, Lcom/example/bleconnectse/SyntheticMapData;->rectangleArea$default(Lcom/example/bleconnectse/SyntheticMapData;IIIILcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;ILjava/lang/Object;)Lcom/example/bleconnectse/SyntheticArea;

    move-result-object v7

    invoke-interface {v9, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit16 v11, v5, 0x1c7

    add-int/lit8 v12, v6, 0x40

    add-int/lit16 v13, v5, 0x2d0

    add-int/lit16 v14, v6, 0xd7

    .line 244
    sget-object v15, Lcom/example/bleconnectse/SyntheticAreaType;->Building:Lcom/example/bleconnectse/SyntheticAreaType;

    .line 239
    invoke-static/range {v10 .. v18}, Lcom/example/bleconnectse/SyntheticMapData;->rectangleArea$default(Lcom/example/bleconnectse/SyntheticMapData;IIIILcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;ILjava/lang/Object;)Lcom/example/bleconnectse/SyntheticArea;

    move-result-object v7

    invoke-interface {v9, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v11, v5, 0x5f

    add-int/lit16 v12, v6, 0x12c

    add-int/lit16 v13, v5, 0x15e

    add-int/lit16 v14, v6, 0x1a9

    .line 251
    sget-object v15, Lcom/example/bleconnectse/SyntheticAreaType;->Building:Lcom/example/bleconnectse/SyntheticAreaType;

    .line 246
    invoke-static/range {v10 .. v18}, Lcom/example/bleconnectse/SyntheticMapData;->rectangleArea$default(Lcom/example/bleconnectse/SyntheticMapData;IIIILcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;ILjava/lang/Object;)Lcom/example/bleconnectse/SyntheticArea;

    move-result-object v7

    invoke-interface {v9, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit16 v11, v5, 0x1d6

    add-int/lit16 v12, v6, 0x124

    add-int/lit16 v13, v5, 0x2df

    add-int/lit16 v14, v6, 0x1a4

    .line 258
    sget-object v15, Lcom/example/bleconnectse/SyntheticAreaType;->Building:Lcom/example/bleconnectse/SyntheticAreaType;

    .line 253
    invoke-static/range {v10 .. v18}, Lcom/example/bleconnectse/SyntheticMapData;->rectangleArea$default(Lcom/example/bleconnectse/SyntheticMapData;IIIILcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;ILjava/lang/Object;)Lcom/example/bleconnectse/SyntheticArea;

    move-result-object v5

    invoke-interface {v9, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_f

    :cond_79
    add-int/lit8 v2, v2, 0x1

    goto :goto_9

    .line 263
    :cond_7c
    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    new-instance v5, Lcom/example/bleconnectse/SyntheticArea;

    const/4 v6, 0x7

    .line 265
    new-array v7, v6, [Lcom/example/bleconnectse/SyntheticPoint;

    new-instance v8, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v9, 0x208

    const/16 v10, 0x2d0

    invoke-direct {v8, v10, v9}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v8, v7, v1

    new-instance v8, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v9, 0x41a

    const/16 v11, 0x1d6

    invoke-direct {v8, v9, v11}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v9, 0x1

    aput-object v8, v7, v9

    .line 266
    new-instance v8, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v11, 0x596

    const/16 v12, 0x262

    invoke-direct {v8, v11, v12}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v11, 0x2

    aput-object v8, v7, v11

    new-instance v8, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v12, 0x37a

    const/16 v13, 0x5e6

    invoke-direct {v8, v13, v12}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v12, 0x3

    aput-object v8, v7, v12

    .line 267
    new-instance v8, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v14, 0x528

    const/16 v15, 0x456

    invoke-direct {v8, v14, v15}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v14, 0x4

    aput-object v8, v7, v14

    new-instance v8, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v15, 0x398

    move/from16 v16, v3

    const/16 v3, 0x438

    invoke-direct {v8, v15, v3}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v8, v7, v4

    .line 268
    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v8, 0x2b2

    const/16 v15, 0x334

    invoke-direct {v3, v8, v15}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v8, 0x6

    aput-object v3, v7, v8

    .line 264
    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    .line 270
    sget-object v7, Lcom/example/bleconnectse/SyntheticAreaType;->Water:Lcom/example/bleconnectse/SyntheticAreaType;

    move/from16 p0, v6

    .line 271
    const-string v6, "WEST LAKE"

    .line 263
    invoke-direct {v5, v3, v7, v6}, Lcom/example/bleconnectse/SyntheticArea;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)V

    invoke-interface {v2, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 273
    new-instance v3, Lcom/example/bleconnectse/SyntheticArea;

    const/16 v5, 0xe

    .line 275
    new-array v5, v5, [Lcom/example/bleconnectse/SyntheticPoint;

    new-instance v6, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v7, 0x1342

    invoke-direct {v6, v7, v1}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v6, v5, v1

    new-instance v6, Lcom/example/bleconnectse/SyntheticPoint;

    move/from16 v17, v8

    const/16 v8, 0x141e

    invoke-direct {v6, v8, v1}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v6, v5, v9

    .line 276
    new-instance v6, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v8, 0x1482

    move/from16 v18, v1

    const/16 v1, 0x19a

    invoke-direct {v6, v8, v1}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v6, v5, v11

    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x1400

    const/16 v8, 0x2f8

    invoke-direct {v1, v6, v8}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v1, v5, v12

    .line 277
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x14be

    move/from16 v19, v9

    const/16 v9, 0x460

    invoke-direct {v1, v6, v9}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v1, v5, v14

    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x1446

    invoke-direct {v1, v6, v13}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v1, v5, v4

    .line 278
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x14f0

    move/from16 v20, v11

    const/16 v11, 0x758

    invoke-direct {v1, v6, v11}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v1, v5, v17

    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x14aa

    const/16 v11, 0x960

    invoke-direct {v1, v6, v11}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v1, v5, p0

    .line 279
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x13a6

    invoke-direct {v1, v6, v11}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v1, v5, v16

    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x13d8

    move/from16 p0, v12

    const/16 v12, 0x76c

    invoke-direct {v1, v6, v12}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v6, 0x9

    aput-object v1, v5, v6

    .line 280
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v1, v7, v13}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v6, 0xa

    aput-object v1, v5, v6

    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x13c4

    invoke-direct {v1, v6, v9}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v6, 0xb

    aput-object v1, v5, v6

    .line 281
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x1306

    invoke-direct {v1, v6, v8}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v6, 0xc

    aput-object v1, v5, v6

    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v6, 0x1374

    const/16 v7, 0x186

    invoke-direct {v1, v6, v7}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v6, 0xd

    aput-object v1, v5, v6

    .line 274
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    .line 283
    sget-object v5, Lcom/example/bleconnectse/SyntheticAreaType;->Water:Lcom/example/bleconnectse/SyntheticAreaType;

    .line 284
    const-string v6, "EAST RIVER"

    .line 273
    invoke-direct {v3, v1, v5, v6}, Lcom/example/bleconnectse/SyntheticArea;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)V

    invoke-interface {v2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 286
    new-instance v1, Lcom/example/bleconnectse/SyntheticArea;

    .line 288
    new-array v3, v4, [Lcom/example/bleconnectse/SyntheticPoint;

    new-instance v4, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x6f4

    const/16 v6, 0x1568

    invoke-direct {v4, v6, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v4, v3, v18

    new-instance v4, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x1702

    const/16 v7, 0x6a4

    invoke-direct {v4, v5, v7}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v4, v3, v19

    .line 289
    new-instance v4, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x18b0

    const/16 v8, 0x730

    invoke-direct {v4, v5, v8}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v4, v3, v20

    new-instance v4, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x1900

    invoke-direct {v4, v5, v11}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v4, v3, p0

    .line 290
    new-instance v4, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v4, v6, v11}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v4, v3, v14

    .line 287
    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    .line 292
    sget-object v4, Lcom/example/bleconnectse/SyntheticAreaType;->Water:Lcom/example/bleconnectse/SyntheticAreaType;

    .line 293
    const-string v5, "HARBOR BAY"

    .line 286
    invoke-direct {v1, v3, v4, v5}, Lcom/example/bleconnectse/SyntheticArea;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)V

    invoke-interface {v2, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/16 v1, 0x546

    const/16 v3, 0x24e

    const/16 v4, 0x12c

    const/16 v5, 0x726

    .line 297
    filled-new-array {v1, v4, v5, v3}, [I

    move-result-object v21

    const/16 v1, 0xbc2

    const/16 v3, 0x442

    const/16 v4, 0x9c4

    .line 298
    filled-new-array {v4, v15, v1, v3}, [I

    move-result-object v22

    const/16 v1, 0x1068

    const/16 v3, 0x5fa

    const/16 v4, 0xe60

    const/16 v6, 0x4ec

    .line 299
    filled-new-array {v4, v6, v1, v3}, [I

    move-result-object v23

    const/16 v1, 0x50a

    const/16 v3, 0x618

    const/16 v4, 0x104

    .line 300
    filled-new-array {v4, v1, v10, v3}, [I

    move-result-object v24

    const/16 v1, 0x1734

    const/16 v3, 0x370

    const/16 v4, 0x1518

    const/16 v6, 0x212

    .line 301
    filled-new-array {v4, v6, v1, v3}, [I

    move-result-object v25

    const/16 v1, 0x8c0

    const/16 v3, 0x898

    .line 302
    filled-new-array {v7, v5, v1, v3}, [I

    move-result-object v26

    const/16 v1, 0x12c0

    const/16 v3, 0x870

    const/16 v4, 0x10cc

    const/16 v5, 0x6d6

    .line 303
    filled-new-array {v4, v5, v1, v3}, [I

    move-result-object v27

    filled-new-array/range {v21 .. v27}, [[I

    move-result-object v1

    .line 297
    check-cast v1, [Ljava/lang/Object;

    .line 296
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    .line 305
    check-cast v1, Ljava/lang/Iterable;

    .line 396
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move/from16 v3, v18

    :goto_23b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_272

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    add-int/lit8 v5, v3, 0x1

    if-gez v3, :cond_24c

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_24c
    check-cast v4, [I

    .line 306
    sget-object v6, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    .line 307
    aget v7, v4, v18

    aget v8, v4, v19

    aget v9, v4, v20

    aget v10, v4, p0

    sget-object v11, Lcom/example/bleconnectse/SyntheticAreaType;->Park:Lcom/example/bleconnectse/SyntheticAreaType;

    .line 308
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "PARK "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    .line 306
    invoke-direct/range {v6 .. v12}, Lcom/example/bleconnectse/SyntheticMapData;->rectangleArea(IIIILcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)Lcom/example/bleconnectse/SyntheticArea;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move v3, v5

    goto :goto_23b

    :cond_272
    return-object v0
.end method

.method private final buildJunctions()Ljava/util/List;
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticJunction;",
            ">;"
        }
    .end annotation

    .line 315
    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    check-cast p0, Ljava/util/List;

    const/16 v0, 0x8

    .line 316
    new-array v1, v0, [I

    fill-array-data v1, :array_5e

    const/16 v2, 0x668

    const/16 v3, 0x834

    const/16 v4, 0x10e

    const/16 v5, 0x2d0

    const/16 v6, 0x49c

    .line 317
    filled-new-array {v4, v5, v6, v2, v3}, [I

    move-result-object v2

    const/4 v3, 0x0

    move v4, v3

    move v5, v4

    :goto_1f
    if-ge v4, v0, :cond_5d

    .line 399
    aget v6, v1, v4

    add-int/lit8 v5, v5, 0x1

    move v7, v3

    move v8, v7

    :goto_27
    const/4 v9, 0x5

    if-ge v7, v9, :cond_5a

    .line 401
    aget v9, v2, v7

    add-int/lit8 v8, v8, 0x1

    .line 320
    move-object v10, p0

    check-cast v10, Ljava/util/Collection;

    new-instance v11, Lcom/example/bleconnectse/SyntheticJunction;

    .line 321
    new-instance v12, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v12, v6, v9}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 322
    new-instance v9, Ljava/lang/StringBuilder;

    const-string v13, "J"

    invoke-direct {v9, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v13, "-"

    invoke-virtual {v9, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .line 320
    invoke-direct {v11, v12, v9}, Lcom/example/bleconnectse/SyntheticJunction;-><init>(Lcom/example/bleconnectse/SyntheticPoint;Ljava/lang/String;)V

    invoke-interface {v10, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v7, v7, 0x1

    goto :goto_27

    :cond_5a
    add-int/lit8 v4, v4, 0x1

    goto :goto_1f

    :cond_5d
    return-object p0

    :array_5e
    .array-data 4
        0x186
        0x4b0
        0x7e4
        0xb04
        0xe24
        0x1144
        0x1464
        0x1784
    .end array-data
.end method

.method private final buildRoads()Ljava/util/List;
    .registers 33
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticRoad;",
            ">;"
        }
    .end annotation

    .line 112
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    check-cast v0, Ljava/util/List;

    const/16 v1, 0x10e

    const/16 v2, 0x2d0

    const/16 v3, 0x49c

    const/16 v4, 0x668

    const/16 v5, 0x834

    .line 113
    filled-new-array {v1, v2, v3, v4, v5}, [I

    move-result-object v1

    const/4 v2, 0x5

    .line 115
    new-array v4, v2, [Ljava/lang/String;

    const-string v6, "NORTH BELT"

    const/4 v7, 0x0

    aput-object v6, v4, v7

    const-string v6, "CIVIC ROAD"

    const/4 v8, 0x1

    aput-object v6, v4, v8

    const-string v6, "CENTRAL AVE"

    const/4 v9, 0x2

    aput-object v6, v4, v9

    const-string v6, "SOUTH BLVD"

    const/4 v10, 0x3

    aput-object v6, v4, v10

    const-string v6, "HARBOR ROAD"

    const/4 v11, 0x4

    aput-object v6, v4, v11

    move v6, v7

    move v12, v6

    :goto_33
    const/16 v14, 0x9

    const/16 v15, 0x8

    const/16 v5, 0xa

    if-ge v6, v2, :cond_10f

    .line 352
    aget v3, v1, v6

    add-int/lit8 v17, v12, 0x1

    const/16 v18, 0x384

    .line 118
    new-instance v13, Lkotlin/ranges/IntRange;

    invoke-direct {v13, v7, v15}, Lkotlin/ranges/IntRange;-><init>(II)V

    check-cast v13, Ljava/lang/Iterable;

    .line 353
    new-instance v15, Ljava/util/ArrayList;

    move/from16 v19, v9

    invoke-static {v13, v5}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v9

    invoke-direct {v15, v9}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v15, Ljava/util/Collection;

    .line 354
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_59
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_86

    move-object v13, v9

    check-cast v13, Lkotlin/collections/IntIterator;

    invoke-virtual {v13}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v13

    move/from16 v20, v2

    .line 119
    new-instance v2, Lcom/example/bleconnectse/SyntheticPoint;

    mul-int/lit16 v5, v13, 0x320

    .line 121
    new-array v11, v14, [I

    fill-array-data v11, :array_4dc

    aget v11, v11, v13

    add-int/2addr v11, v3

    const/16 v13, 0x960

    .line 122
    invoke-static {v11, v7, v13}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v11

    .line 119
    invoke-direct {v2, v5, v11}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 355
    invoke-interface {v15, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move/from16 v2, v20

    const/16 v5, 0xa

    const/4 v11, 0x4

    goto :goto_59

    :cond_86
    move/from16 v20, v2

    .line 356
    move-object/from16 v23, v15

    check-cast v23, Ljava/util/List;

    .line 125
    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    .line 127
    sget-object v24, Lcom/example/bleconnectse/SyntheticRoadClass;->Main:Lcom/example/bleconnectse/SyntheticRoadClass;

    if-eq v12, v8, :cond_9b

    if-eq v12, v10, :cond_98

    .line 131
    sget-object v5, Lcom/example/bleconnectse/SyntheticTraffic;->Clear:Lcom/example/bleconnectse/SyntheticTraffic;

    goto :goto_9d

    .line 130
    :cond_98
    sget-object v5, Lcom/example/bleconnectse/SyntheticTraffic;->Congested:Lcom/example/bleconnectse/SyntheticTraffic;

    goto :goto_9d

    .line 129
    :cond_9b
    sget-object v5, Lcom/example/bleconnectse/SyntheticTraffic;->Slow:Lcom/example/bleconnectse/SyntheticTraffic;

    :goto_9d
    move-object/from16 v25, v5

    .line 133
    aget-object v26, v4, v12

    const/4 v5, 0x4

    .line 134
    new-array v9, v5, [Ljava/lang/Integer;

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v9, v7

    const/16 v5, 0x9c4

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v9, v8

    const/16 v5, 0x1004

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v9, v19

    const/16 v5, 0x1644

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v9, v10

    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .line 357
    new-instance v9, Ljava/util/ArrayList;

    const/16 v11, 0xa

    invoke-static {v5, v11}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v11

    invoke-direct {v9, v11}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v9, Ljava/util/Collection;

    .line 358
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_d9
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_f2

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .line 359
    check-cast v11, Ljava/lang/Number;

    invoke-virtual {v11}, Ljava/lang/Number;->intValue()I

    move-result v11

    .line 135
    new-instance v12, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v12, v11, v3}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 359
    invoke-interface {v9, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_d9

    .line 360
    :cond_f2
    move-object/from16 v27, v9

    check-cast v27, Ljava/util/List;

    .line 125
    new-instance v22, Lcom/example/bleconnectse/SyntheticRoad;

    invoke-direct/range {v22 .. v27}, Lcom/example/bleconnectse/SyntheticRoad;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticRoadClass;Lcom/example/bleconnectse/SyntheticTraffic;Ljava/lang/String;Ljava/util/List;)V

    move-object/from16 v3, v22

    invoke-interface {v2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    move/from16 v12, v17

    move/from16 v9, v19

    move/from16 v2, v20

    const/16 v3, 0x49c

    const/16 v5, 0x834

    const/4 v11, 0x4

    goto/16 :goto_33

    :cond_10f
    move/from16 v20, v2

    move/from16 v19, v9

    const/16 v18, 0x384

    .line 140
    new-array v1, v15, [I

    fill-array-data v1, :array_4f2

    .line 142
    new-array v2, v15, [Ljava/lang/String;

    const-string v3, "WEST AVE"

    aput-object v3, v2, v7

    const-string v3, "LAKE AVE"

    aput-object v3, v2, v8

    const-string v3, "MUSEUM AVE"

    aput-object v3, v2, v19

    const-string v3, "GARDEN AVE"

    aput-object v3, v2, v10

    .line 143
    const-string v3, "MARKET AVE"

    const/16 v21, 0x4

    aput-object v3, v2, v21

    const-string v3, "RIVER AVE"

    aput-object v3, v2, v20

    const-string v3, "EAST AVE"

    const/4 v4, 0x6

    aput-object v3, v2, v4

    const-string v3, "PORT AVE"

    const/4 v5, 0x7

    aput-object v3, v2, v5

    move v3, v7

    move v6, v3

    :goto_142
    const/16 v9, 0x1900

    if-ge v3, v15, :cond_207

    .line 363
    aget v11, v1, v3

    add-int/lit8 v12, v6, 0x1

    .line 146
    new-instance v13, Lkotlin/ranges/IntRange;

    move/from16 v17, v8

    move/from16 v8, v20

    invoke-direct {v13, v7, v8}, Lkotlin/ranges/IntRange;-><init>(II)V

    check-cast v13, Ljava/lang/Iterable;

    .line 364
    new-instance v8, Ljava/util/ArrayList;

    const/16 v14, 0xa

    invoke-static {v13, v14}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v8, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v8, Ljava/util/Collection;

    .line 365
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_166
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_18c

    move-object v13, v5

    check-cast v13, Lkotlin/collections/IntIterator;

    invoke-virtual {v13}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v13

    .line 147
    new-instance v14, Lcom/example/bleconnectse/SyntheticPoint;

    .line 148
    new-array v15, v4, [I

    fill-array-data v15, :array_506

    aget v15, v15, v13

    add-int/2addr v15, v11

    .line 149
    invoke-static {v15, v7, v9}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v15

    mul-int/lit16 v13, v13, 0x1e0

    .line 147
    invoke-direct {v14, v15, v13}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 366
    invoke-interface {v8, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/16 v15, 0x8

    goto :goto_166

    .line 367
    :cond_18c
    move-object/from16 v26, v8

    check-cast v26, Ljava/util/List;

    .line 153
    move-object v5, v0

    check-cast v5, Ljava/util/Collection;

    .line 155
    sget-object v27, Lcom/example/bleconnectse/SyntheticRoadClass;->Main:Lcom/example/bleconnectse/SyntheticRoadClass;

    const/4 v8, 0x5

    if-ne v6, v8, :cond_19b

    .line 156
    sget-object v8, Lcom/example/bleconnectse/SyntheticTraffic;->Slow:Lcom/example/bleconnectse/SyntheticTraffic;

    goto :goto_19d

    :cond_19b
    sget-object v8, Lcom/example/bleconnectse/SyntheticTraffic;->Clear:Lcom/example/bleconnectse/SyntheticTraffic;

    :goto_19d
    move-object/from16 v28, v8

    .line 157
    aget-object v29, v2, v6

    .line 158
    new-array v6, v10, [Ljava/lang/Integer;

    const/16 v8, 0x1a4

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v7

    const/16 v8, 0x474

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v17

    const/16 v8, 0x744

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v6, v19

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    .line 368
    new-instance v8, Ljava/util/ArrayList;

    const/16 v14, 0xa

    invoke-static {v6, v14}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v9

    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v8, Ljava/util/Collection;

    .line 369
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_1d2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_1eb

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .line 370
    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    move-result v9

    .line 159
    new-instance v13, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v13, v11, v9}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 370
    invoke-interface {v8, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1d2

    .line 371
    :cond_1eb
    move-object/from16 v30, v8

    check-cast v30, Ljava/util/List;

    .line 153
    new-instance v25, Lcom/example/bleconnectse/SyntheticRoad;

    invoke-direct/range {v25 .. v30}, Lcom/example/bleconnectse/SyntheticRoad;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticRoadClass;Lcom/example/bleconnectse/SyntheticTraffic;Ljava/lang/String;Ljava/util/List;)V

    move-object/from16 v6, v25

    invoke-interface {v5, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    move v6, v12

    move/from16 v8, v17

    const/4 v5, 0x7

    const/16 v14, 0x9

    const/16 v15, 0x8

    const/16 v20, 0x5

    goto/16 :goto_142

    :cond_207
    move/from16 v17, v8

    const/16 v1, 0x74e

    const/16 v2, 0x8f2

    const/16 v3, 0x1ea

    const/16 v5, 0x3b6

    const/16 v6, 0x582

    .line 164
    filled-new-array {v3, v5, v6, v1, v2}, [I

    move-result-object v1

    const/4 v8, 0x5

    .line 166
    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "CANAL ST"

    aput-object v3, v2, v7

    const-string v3, "STATION ST"

    aput-object v3, v2, v17

    const-string v3, "TECH ROAD"

    aput-object v3, v2, v19

    const-string v3, "OLD TOWN ST"

    aput-object v3, v2, v10

    const-string v3, "COAST ROAD"

    const/16 v21, 0x4

    aput-object v3, v2, v21

    move v3, v7

    move v5, v3

    :goto_232
    const/4 v8, 0x5

    if-ge v3, v8, :cond_2f0

    .line 374
    aget v6, v1, v3

    add-int/lit8 v8, v5, 0x1

    .line 169
    move-object v11, v0

    check-cast v11, Ljava/util/Collection;

    .line 170
    new-instance v12, Lkotlin/ranges/IntRange;

    const/16 v13, 0x8

    invoke-direct {v12, v7, v13}, Lkotlin/ranges/IntRange;-><init>(II)V

    check-cast v12, Ljava/lang/Iterable;

    .line 375
    new-instance v14, Ljava/util/ArrayList;

    const/16 v15, 0xa

    invoke-static {v12, v15}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v13

    invoke-direct {v14, v13}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v14, Ljava/util/Collection;

    .line 376
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_256
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_27a

    move-object v13, v12

    check-cast v13, Lkotlin/collections/IntIterator;

    invoke-virtual {v13}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v13

    .line 171
    new-instance v15, Lcom/example/bleconnectse/SyntheticPoint;

    mul-int/lit16 v9, v13, 0x320

    rem-int/lit8 v13, v13, 0x2

    if-nez v13, :cond_26e

    const/16 v13, -0xa

    goto :goto_270

    :cond_26e
    const/16 v13, 0xe

    :goto_270
    add-int/2addr v13, v6

    invoke-direct {v15, v9, v13}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 377
    invoke-interface {v14, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/16 v9, 0x1900

    goto :goto_256

    .line 378
    :cond_27a
    move-object/from16 v27, v14

    check-cast v27, Ljava/util/List;

    .line 173
    sget-object v28, Lcom/example/bleconnectse/SyntheticRoadClass;->Local:Lcom/example/bleconnectse/SyntheticRoadClass;

    move/from16 v9, v19

    if-ne v5, v9, :cond_287

    .line 174
    sget-object v9, Lcom/example/bleconnectse/SyntheticTraffic;->Slow:Lcom/example/bleconnectse/SyntheticTraffic;

    goto :goto_289

    :cond_287
    sget-object v9, Lcom/example/bleconnectse/SyntheticTraffic;->Clear:Lcom/example/bleconnectse/SyntheticTraffic;

    :goto_289
    move-object/from16 v29, v9

    .line 175
    aget-object v30, v2, v5

    .line 176
    new-array v5, v10, [Ljava/lang/Integer;

    const/16 v9, 0x5dc

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v5, v7

    const/16 v9, 0xce4

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    aput-object v9, v5, v17

    const/16 v9, 0x13ec

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    const/16 v19, 0x2

    aput-object v9, v5, v19

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .line 379
    new-instance v9, Ljava/util/ArrayList;

    const/16 v14, 0xa

    invoke-static {v5, v14}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v12

    invoke-direct {v9, v12}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v9, Ljava/util/Collection;

    .line 380
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2c0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_2d9

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .line 381
    check-cast v12, Ljava/lang/Number;

    invoke-virtual {v12}, Ljava/lang/Number;->intValue()I

    move-result v12

    .line 176
    new-instance v13, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v13, v12, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 381
    invoke-interface {v9, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2c0

    .line 382
    :cond_2d9
    move-object/from16 v31, v9

    check-cast v31, Ljava/util/List;

    .line 169
    new-instance v26, Lcom/example/bleconnectse/SyntheticRoad;

    invoke-direct/range {v26 .. v31}, Lcom/example/bleconnectse/SyntheticRoad;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticRoadClass;Lcom/example/bleconnectse/SyntheticTraffic;Ljava/lang/String;Ljava/util/List;)V

    move-object/from16 v5, v26

    invoke-interface {v11, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    move v5, v8

    const/16 v9, 0x1900

    const/16 v19, 0x2

    goto/16 :goto_232

    :cond_2f0
    const/4 v3, 0x7

    .line 180
    new-array v1, v3, [I

    fill-array-data v1, :array_516

    .line 182
    new-array v2, v3, [Ljava/lang/String;

    const-string v3, "UNIVERSITY RD"

    aput-object v3, v2, v7

    const-string v3, "FOREST LN"

    aput-object v3, v2, v17

    const-string v3, "LIBRARY RD"

    const/16 v19, 0x2

    aput-object v3, v2, v19

    const-string v3, "SUNSET LN"

    aput-object v3, v2, v10

    .line 183
    const-string v3, "WETLAND DR"

    const/16 v21, 0x4

    aput-object v3, v2, v21

    const-string v3, "HILL LN"

    const/4 v8, 0x5

    aput-object v3, v2, v8

    const-string v3, "BAY STREET"

    aput-object v3, v2, v4

    move v3, v7

    move v5, v3

    :goto_31b
    const/4 v6, 0x7

    if-ge v3, v6, :cond_3d0

    .line 385
    aget v6, v1, v3

    add-int/lit8 v9, v5, 0x1

    .line 186
    move-object v11, v0

    check-cast v11, Ljava/util/Collection;

    .line 187
    new-instance v12, Lkotlin/ranges/IntRange;

    invoke-direct {v12, v7, v8}, Lkotlin/ranges/IntRange;-><init>(II)V

    check-cast v12, Ljava/lang/Iterable;

    .line 386
    new-instance v8, Ljava/util/ArrayList;

    const/16 v14, 0xa

    invoke-static {v12, v14}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v13

    invoke-direct {v8, v13}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v8, Ljava/util/Collection;

    .line 387
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_33d
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_35f

    move-object v13, v12

    check-cast v13, Lkotlin/collections/IntIterator;

    invoke-virtual {v13}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v13

    .line 188
    new-instance v14, Lcom/example/bleconnectse/SyntheticPoint;

    rem-int/lit8 v15, v13, 0x2

    if-nez v15, :cond_353

    const/16 v15, 0x9

    goto :goto_355

    :cond_353
    const/16 v15, -0xc

    :goto_355
    add-int/2addr v15, v6

    mul-int/lit16 v13, v13, 0x1e0

    invoke-direct {v14, v15, v13}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 388
    invoke-interface {v8, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_33d

    .line 389
    :cond_35f
    move-object/from16 v27, v8

    check-cast v27, Ljava/util/List;

    .line 190
    sget-object v28, Lcom/example/bleconnectse/SyntheticRoadClass;->Local:Lcom/example/bleconnectse/SyntheticRoadClass;

    if-ne v5, v4, :cond_36a

    .line 191
    sget-object v8, Lcom/example/bleconnectse/SyntheticTraffic;->Congested:Lcom/example/bleconnectse/SyntheticTraffic;

    goto :goto_36c

    :cond_36a
    sget-object v8, Lcom/example/bleconnectse/SyntheticTraffic;->Clear:Lcom/example/bleconnectse/SyntheticTraffic;

    :goto_36c
    move-object/from16 v29, v8

    .line 192
    aget-object v30, v2, v5

    .line 193
    new-array v5, v10, [Ljava/lang/Integer;

    const/16 v8, 0x28a

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v5, v7

    const/16 v8, 0x55a

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v5, v17

    const/16 v8, 0x82a

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/16 v19, 0x2

    aput-object v8, v5, v19

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .line 390
    new-instance v8, Ljava/util/ArrayList;

    const/16 v14, 0xa

    invoke-static {v5, v14}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v12

    invoke-direct {v8, v12}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v8, Ljava/util/Collection;

    .line 391
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_3a3
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_3bc

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .line 392
    check-cast v12, Ljava/lang/Number;

    invoke-virtual {v12}, Ljava/lang/Number;->intValue()I

    move-result v12

    .line 193
    new-instance v13, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v13, v6, v12}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 392
    invoke-interface {v8, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_3a3

    .line 393
    :cond_3bc
    move-object/from16 v31, v8

    check-cast v31, Ljava/util/List;

    .line 186
    new-instance v26, Lcom/example/bleconnectse/SyntheticRoad;

    invoke-direct/range {v26 .. v31}, Lcom/example/bleconnectse/SyntheticRoad;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticRoadClass;Lcom/example/bleconnectse/SyntheticTraffic;Ljava/lang/String;Ljava/util/List;)V

    move-object/from16 v5, v26

    invoke-interface {v11, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    move v5, v9

    const/4 v8, 0x5

    goto/16 :goto_31b

    .line 197
    :cond_3d0
    move-object v1, v0

    check-cast v1, Ljava/util/Collection;

    new-instance v26, Lcom/example/bleconnectse/SyntheticRoad;

    const/4 v3, 0x7

    .line 199
    new-array v2, v3, [Lcom/example/bleconnectse/SyntheticPoint;

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x50

    invoke-direct {v3, v7, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v7

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x186

    move/from16 v6, v18

    invoke-direct {v3, v6, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v17

    .line 200
    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x76c

    const/16 v6, 0x2f8

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v19, 0x2

    aput-object v3, v2, v19

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0xc1c

    const/16 v6, 0x49c

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v10

    .line 201
    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x10cc

    const/16 v6, 0x636

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v21, 0x4

    aput-object v3, v2, v21

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x157c

    const/16 v6, 0x802

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v20, 0x5

    aput-object v3, v2, v20

    .line 202
    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x910

    const/16 v6, 0x1900

    invoke-direct {v3, v6, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v4

    .line 198
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v27

    .line 204
    sget-object v28, Lcom/example/bleconnectse/SyntheticRoadClass;->Local:Lcom/example/bleconnectse/SyntheticRoadClass;

    .line 205
    sget-object v29, Lcom/example/bleconnectse/SyntheticTraffic;->Clear:Lcom/example/bleconnectse/SyntheticTraffic;

    const/4 v9, 0x2

    .line 207
    new-array v2, v9, [Lcom/example/bleconnectse/SyntheticPoint;

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x6d6

    const/16 v6, 0x2bc

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v7

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x1194

    const/16 v6, 0x67c

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v17

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v31

    .line 197
    const-string v30, "UNIVERSITY LINK"

    invoke-direct/range {v26 .. v31}, Lcom/example/bleconnectse/SyntheticRoad;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticRoadClass;Lcom/example/bleconnectse/SyntheticTraffic;Ljava/lang/String;Ljava/util/List;)V

    move-object/from16 v2, v26

    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 209
    new-instance v11, Lcom/example/bleconnectse/SyntheticRoad;

    const/4 v3, 0x7

    .line 211
    new-array v2, v3, [Lcom/example/bleconnectse/SyntheticPoint;

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x8ac

    invoke-direct {v3, v7, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v7

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x44c

    const/16 v6, 0x776

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v17

    .line 212
    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x898

    const/16 v6, 0x5e6

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v19, 0x2

    aput-object v3, v2, v19

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0xd48

    const/16 v6, 0x438

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v10

    .line 213
    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x125c

    const/16 v6, 0x26c

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v21, 0x4

    aput-object v3, v2, v21

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x1644

    const/16 v6, 0x104

    invoke-direct {v3, v5, v6}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/16 v20, 0x5

    aput-object v3, v2, v20

    .line 214
    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v5, 0x50

    const/16 v6, 0x1900

    invoke-direct {v3, v6, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v4

    .line 210
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v12

    .line 216
    sget-object v13, Lcom/example/bleconnectse/SyntheticRoadClass;->Local:Lcom/example/bleconnectse/SyntheticRoadClass;

    .line 217
    sget-object v14, Lcom/example/bleconnectse/SyntheticTraffic;->Slow:Lcom/example/bleconnectse/SyntheticTraffic;

    const/4 v9, 0x2

    .line 219
    new-array v2, v9, [Lcom/example/bleconnectse/SyntheticPoint;

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v4, 0x604

    const/16 v5, 0x834

    invoke-direct {v3, v5, v4}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v7

    new-instance v3, Lcom/example/bleconnectse/SyntheticPoint;

    const/16 v4, 0x12f2

    const/16 v5, 0x23a

    invoke-direct {v3, v4, v5}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    aput-object v3, v2, v17

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v16

    .line 209
    const-string v15, "GARDEN LINK"

    invoke-direct/range {v11 .. v16}, Lcom/example/bleconnectse/SyntheticRoad;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticRoadClass;Lcom/example/bleconnectse/SyntheticTraffic;Ljava/lang/String;Ljava/util/List;)V

    invoke-interface {v1, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    return-object v0

    :array_4dc
    .array-data 4
        0x0
        0x12
        -0xe
        0xc
        -0x14
        0x10
        -0x8
        0xe
        0x0
    .end array-data

    :array_4f2
    .array-data 4
        0x186
        0x4b0
        0x7e4
        0xb04
        0xe24
        0x1144
        0x1464
        0x1784
    .end array-data

    :array_506
    .array-data 4
        0x0
        0xe
        -0x12
        0xc
        -0xa
        0x0
    .end array-data

    :array_516
    .array-data 4
        0x316
        0x640
        0x960
        0xc94
        0xfb4
        0x12d4
        0x15f4
    .end array-data
.end method

.method private final rectangleArea(IIIILcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)Lcom/example/bleconnectse/SyntheticArea;
    .registers 10

    .line 336
    new-instance p0, Lcom/example/bleconnectse/SyntheticArea;

    const/4 v0, 0x4

    .line 338
    new-array v0, v0, [Lcom/example/bleconnectse/SyntheticPoint;

    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v1, p1, p2}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 v2, 0x0

    aput-object v1, v0, v2

    .line 339
    new-instance v1, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v1, p3, p2}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 p2, 0x1

    aput-object v1, v0, p2

    .line 340
    new-instance p2, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {p2, p3, p4}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 p3, 0x2

    aput-object p2, v0, p3

    .line 341
    new-instance p2, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {p2, p1, p4}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    const/4 p1, 0x3

    aput-object p2, v0, p1

    .line 337
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    .line 336
    invoke-direct {p0, p1, p5, p6}, Lcom/example/bleconnectse/SyntheticArea;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)V

    return-object p0
.end method

.method static synthetic rectangleArea$default(Lcom/example/bleconnectse/SyntheticMapData;IIIILcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;ILjava/lang/Object;)Lcom/example/bleconnectse/SyntheticArea;
    .registers 16

    and-int/lit8 p7, p7, 0x20

    if-eqz p7, :cond_6

    .line 335
    const-string p6, ""

    :cond_6
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, p5

    move-object v6, p6

    .line 329
    invoke-direct/range {v0 .. v6}, Lcom/example/bleconnectse/SyntheticMapData;->rectangleArea(IIIILcom/example/bleconnectse/SyntheticAreaType;Ljava/lang/String;)Lcom/example/bleconnectse/SyntheticArea;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final getAreas()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticArea;",
            ">;"
        }
    .end annotation

    .line 61
    sget-object p0, Lcom/example/bleconnectse/SyntheticMapData;->areas:Ljava/util/List;

    return-object p0
.end method

.method public final getJunctions()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticJunction;",
            ">;"
        }
    .end annotation

    .line 62
    sget-object p0, Lcom/example/bleconnectse/SyntheticMapData;->junctions:Ljava/util/List;

    return-object p0
.end method

.method public final getNavigationRoute()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;"
        }
    .end annotation

    .line 63
    sget-object p0, Lcom/example/bleconnectse/SyntheticMapData;->navigationRoute:Ljava/util/List;

    return-object p0
.end method

.method public final getRoads()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticRoad;",
            ">;"
        }
    .end annotation

    .line 60
    sget-object p0, Lcom/example/bleconnectse/SyntheticMapData;->roads:Ljava/util/List;

    return-object p0
.end method

.method public final getRouteLength()F
    .registers 1

    .line 82
    sget p0, Lcom/example/bleconnectse/SyntheticMapData;->routeLength:F

    return p0
.end method

.method public final pointAlongRoute(F)Lkotlin/Pair;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F)",
            "Lkotlin/Pair<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    .line 85
    sget-object p0, Lcom/example/bleconnectse/SyntheticMapData;->navigationRoute:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    .line 86
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    if-lt p0, v0, :cond_b5

    .line 85
    sget p0, Lcom/example/bleconnectse/SyntheticMapData;->routeLength:F

    cmpg-float v0, p0, v2

    if-gtz v0, :cond_17

    goto/16 :goto_b5

    :cond_17
    rem-float/2addr p1, p0

    add-float/2addr p1, p0

    rem-float/2addr p1, p0

    .line 89
    sget-object p0, Lcom/example/bleconnectse/SyntheticMapData;->routeSegmentLengths:Ljava/util/List;

    check-cast p0, Ljava/lang/Iterable;

    .line 349
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_22
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_aa

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    add-int/lit8 v4, v1, 0x1

    if-gez v1, :cond_33

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_33
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    cmpg-float v5, p1, v0

    if-lez v5, :cond_49

    .line 90
    sget-object v5, Lcom/example/bleconnectse/SyntheticMapData;->routeSegmentLengths:Ljava/util/List;

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->getLastIndex(Ljava/util/List;)I

    move-result v5

    if-ne v1, v5, :cond_46

    goto :goto_49

    :cond_46
    sub-float/2addr p1, v0

    move v1, v4

    goto :goto_22

    .line 91
    :cond_49
    :goto_49
    sget-object p0, Lcom/example/bleconnectse/SyntheticMapData;->navigationRoute:Ljava/util/List;

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/example/bleconnectse/SyntheticPoint;

    .line 92
    invoke-interface {p0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/example/bleconnectse/SyntheticPoint;

    cmpl-float v3, v0, v2

    if-lez v3, :cond_5d

    div-float v2, p1, v0

    .line 94
    :cond_5d
    new-instance p1, Lcom/example/bleconnectse/SyntheticPoint;

    .line 95
    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v3

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v4

    sub-int/2addr v3, v4

    int-to-float v3, v3

    mul-float/2addr v3, v2

    add-float/2addr v0, v3

    float-to-int v0, v0

    .line 96
    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {p0}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v4

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v5

    sub-int/2addr v4, v5

    int-to-float v4, v4

    mul-float/2addr v4, v2

    add-float/2addr v3, v4

    float-to-int v2, v3

    .line 94
    invoke-direct {p1, v0, v2}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 99
    invoke-virtual {p0}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v0

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v2

    sub-int/2addr v0, v2

    int-to-float v0, v0

    float-to-double v2, v0

    .line 100
    invoke-virtual {p0}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result p0

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v0

    sub-int/2addr p0, v0

    int-to-float p0, p0

    float-to-double v0, p0

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v0

    double-to-float p0, v0

    .line 102
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    invoke-static {p1, p0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object p0

    return-object p0

    .line 106
    :cond_aa
    sget-object p0, Lcom/example/bleconnectse/SyntheticMapData;->navigationRoute:Ljava/util/List;

    invoke-static {p0}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object p0

    return-object p0

    .line 86
    :cond_b5
    :goto_b5
    new-instance p0, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {p0, v1, v1}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    invoke-static {p0, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object p0

    return-object p0
.end method

.method public final tileId(II)I
    .registers 3

    mul-int/lit8 p2, p2, 0x8

    add-int/2addr p2, p1

    return p2
.end method
