# classes2.dex

.class final Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;
.super Ljava/lang/Object;
.source "SyntheticTileRepository.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/bleconnectse/SyntheticTileRepository;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "DoublePoint"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0006\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\u0014"
    }
    d2 = {
        "Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;",
        "",
        "x",
        "",
        "y",
        "<init>",
        "(DD)V",
        "getX",
        "()D",
        "getY",
        "component1",
        "component2",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final x:D

.field private final y:D


# direct methods
.method public constructor <init>(DD)V
    .registers 5

    .line 266
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->x:D

    iput-wide p3, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->y:D

    return-void
.end method

.method public static synthetic copy$default(Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;DDILjava/lang/Object;)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;
    .registers 7

    and-int/lit8 p6, p5, 0x1

    if-eqz p6, :cond_6

    iget-wide p1, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->x:D

    :cond_6
    and-int/lit8 p5, p5, 0x2

    if-eqz p5, :cond_c

    iget-wide p3, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->y:D

    :cond_c
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->copy(DD)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()D
    .registers 3

    iget-wide v0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->x:D

    return-wide v0
.end method

.method public final component2()D
    .registers 3

    iget-wide v0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->y:D

    return-wide v0
.end method

.method public final copy(DD)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;
    .registers 5

    new-instance p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;-><init>(DD)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 9

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    iget-wide v3, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->x:D

    iget-wide v5, p1, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->x:D

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Double;->compare(DD)I

    move-result v1

    if-eqz v1, :cond_17

    return v2

    :cond_17
    iget-wide v3, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->y:D

    iget-wide p0, p1, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->y:D

    invoke-static {v3, v4, p0, p1}, Ljava/lang/Double;->compare(DD)I

    move-result p0

    if-eqz p0, :cond_22

    return v2

    :cond_22
    return v0
.end method

.method public final getX()D
    .registers 3

    .line 266
    iget-wide v0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->x:D

    return-wide v0
.end method

.method public final getY()D
    .registers 3

    .line 266
    iget-wide v0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->y:D

    return-wide v0
.end method

.method public hashCode()I
    .registers 4

    iget-wide v0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->x:D

    invoke-static {v0, v1}, Ljava/lang/Double;->hashCode(D)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->y:D

    invoke-static {v1, v2}, Ljava/lang/Double;->hashCode(D)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 6

    iget-wide v0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->x:D

    iget-wide v2, p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->y:D

    new-instance p0, Ljava/lang/StringBuilder;

    const-string v4, "DoublePoint(x="

    invoke-direct {p0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0, v1}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ", y="

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ")"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
