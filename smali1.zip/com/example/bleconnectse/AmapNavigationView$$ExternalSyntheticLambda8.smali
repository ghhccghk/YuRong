# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/internal/Ref$BooleanRef;

.field public final synthetic f$1:I

.field public final synthetic f$2:Lcom/example/bleconnectse/AmapNavigationView;

.field public final synthetic f$3:J


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/internal/Ref$BooleanRef;ILcom/example/bleconnectse/AmapNavigationView;J)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;->f$0:Lkotlin/jvm/internal/Ref$BooleanRef;

    iput p2, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;->f$1:I

    iput-object p3, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;->f$2:Lcom/example/bleconnectse/AmapNavigationView;

    iput-wide p4, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;->f$3:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;->f$0:Lkotlin/jvm/internal/Ref$BooleanRef;

    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;->f$1:I

    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;->f$2:Lcom/example/bleconnectse/AmapNavigationView;

    iget-wide v3, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;->f$3:J

    invoke-static {v0, v1, v2, v3, v4}, Lcom/example/bleconnectse/AmapNavigationView;->requestMapSnapshotFrame$lambda$24(Lkotlin/jvm/internal/Ref$BooleanRef;ILcom/example/bleconnectse/AmapNavigationView;J)V

    return-void
.end method
