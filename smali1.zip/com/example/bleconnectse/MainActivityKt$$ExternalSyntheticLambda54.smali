# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda54;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Landroidx/lifecycle/LifecycleOwner;

.field public final synthetic f$1:[Lcom/example/bleconnectse/AmapNavigationView;

.field public final synthetic f$2:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(Landroidx/lifecycle/LifecycleOwner;[Lcom/example/bleconnectse/AmapNavigationView;Lkotlin/jvm/functions/Function1;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda54;->f$0:Landroidx/lifecycle/LifecycleOwner;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda54;->f$1:[Lcom/example/bleconnectse/AmapNavigationView;

    iput-object p3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda54;->f$2:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda54;->f$0:Landroidx/lifecycle/LifecycleOwner;

    iget-object v1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda54;->f$1:[Lcom/example/bleconnectse/AmapNavigationView;

    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda54;->f$2:Lkotlin/jvm/functions/Function1;

    check-cast p1, Landroidx/compose/runtime/DisposableEffectScope;

    invoke-static {v0, v1, p0, p1}, Lcom/example/bleconnectse/MainActivityKt;->AmapNavigationScreen$lambda$42$lambda$41(Landroidx/lifecycle/LifecycleOwner;[Lcom/example/bleconnectse/AmapNavigationView;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p0

    return-object p0
.end method
