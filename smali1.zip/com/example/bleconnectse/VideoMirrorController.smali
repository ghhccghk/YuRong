# classes2.dex

.class public final Lcom/example/bleconnectse/VideoMirrorController;
.super Ljava/lang/Object;
.source "VideoMirrorController.kt"

# interfaces
.implements Landroid/view/TextureView$SurfaceTextureListener;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nVideoMirrorController.kt\nKotlin\n*S Kotlin\n*F\n+ 1 VideoMirrorController.kt\ncom/example/bleconnectse/VideoMirrorController\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,333:1\n85#2:334\n117#2,2:335\n85#2:337\n117#2,2:338\n85#2:340\n117#2,2:341\n85#2:343\n117#2,2:344\n85#2:346\n117#2,2:347\n85#2:349\n117#2,2:350\n85#2:352\n117#2,2:353\n85#2:355\n117#2,2:356\n85#2:358\n117#2,2:359\n1#3:361\n*S KotlinDebug\n*F\n+ 1 VideoMirrorController.kt\ncom/example/bleconnectse/VideoMirrorController\n*L\n38#1:334\n38#1:335,2\n40#1:337\n40#1:338,2\n42#1:340\n42#1:341,2\n44#1:343\n44#1:344,2\n46#1:346\n46#1:347,2\n48#1:349\n48#1:350,2\n50#1:352\n50#1:353,2\n52#1:355\n52#1:356,2\n54#1:358\n54#1:359,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000o\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\"\n\u0002\u0010\u0007\n\u0002\b\u000b\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u000e*\u0001J\b\u0007\u0018\u00002\u00020\u0001B1\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\t¢\u0006\u0004\b\n\u0010\u000bJ\u000e\u0010L\u001a\u00020\u00072\u0006\u0010M\u001a\u00020\u0017J\u000e\u0010N\u001a\u00020\u00072\u0006\u0010O\u001a\u00020\u0013J\u0006\u0010P\u001a\u00020\u0007J\u000e\u0010Q\u001a\u00020\u00072\u0006\u0010R\u001a\u00020\u0019J\u000e\u0010S\u001a\u00020\u00072\u0006\u0010\u0002\u001a\u00020\u0003J\u000e\u0010T\u001a\u00020\u00072\u0006\u0010\u0002\u001a\u00020\u0003J\u000e\u0010U\u001a\u00020\u00072\u0006\u0010V\u001a\u00020\u001bJ\u000e\u0010W\u001a\u00020\u00072\u0006\u0010X\u001a\u00020\u001bJ\u0006\u0010Y\u001a\u00020\u0007J \u0010Z\u001a\u00020\u00072\u0006\u0010[\u001a\u00020\\2\u0006\u0010]\u001a\u00020^2\u0006\u0010_\u001a\u00020^H\u0016J \u0010`\u001a\u00020\u00072\u0006\u0010[\u001a\u00020\\2\u0006\u0010]\u001a\u00020^2\u0006\u0010_\u001a\u00020^H\u0016J\u0010\u0010a\u001a\u00020\u00192\u0006\u0010[\u001a\u00020\\H\u0016J\u0010\u0010b\u001a\u00020\u00072\u0006\u0010[\u001a\u00020\\H\u0016J\u0010\u0010c\u001a\u00020\u00072\u0006\u0010[\u001a\u00020\\H\u0002J\b\u0010d\u001a\u00020\u0007H\u0002J\b\u0010e\u001a\u00020\u0007H\u0002J\u0010\u0010f\u001a\u00020\u00072\u0006\u0010g\u001a\u00020\u0006H\u0002J\b\u0010h\u001a\u00020\u0007H\u0002J\u0010\u0010i\u001a\u00020\u00062\u0006\u0010M\u001a\u00020\u0017H\u0002J\u0010\u0010j\u001a\u00020\u00062\u0006\u0010k\u001a\u00020\u001bH\u0002R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\f\u001a\n \r*\u0004\u0018\u00010\u00030\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R+\u0010\u001e\u001a\u00020\u00192\u0006\u0010\u001d\u001a\u00020\u00198F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b#\u0010$\u001a\u0004\b\u001f\u0010 \"\u0004\b!\u0010\"R+\u0010%\u001a\u00020\u00062\u0006\u0010\u001d\u001a\u00020\u00068F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b*\u0010$\u001a\u0004\b&\u0010\'\"\u0004\b(\u0010)R+\u0010+\u001a\u00020\u00192\u0006\u0010\u001d\u001a\u00020\u00198F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b-\u0010$\u001a\u0004\b+\u0010 \"\u0004\b,\u0010\"R+\u0010.\u001a\u00020\u00192\u0006\u0010\u001d\u001a\u00020\u00198F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b0\u0010$\u001a\u0004\b.\u0010 \"\u0004\b/\u0010\"R+\u00101\u001a\u00020\u00192\u0006\u0010\u001d\u001a\u00020\u00198F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b3\u0010$\u001a\u0004\b1\u0010 \"\u0004\b2\u0010\"R+\u00104\u001a\u00020\u001b2\u0006\u0010\u001d\u001a\u00020\u001b8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b9\u0010$\u001a\u0004\b5\u00106\"\u0004\b7\u00108R+\u0010:\u001a\u00020\u001b2\u0006\u0010\u001d\u001a\u00020\u001b8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b=\u0010$\u001a\u0004\b;\u00106\"\u0004\b<\u00108R+\u0010?\u001a\u00020>2\u0006\u0010\u001d\u001a\u00020>8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bD\u0010$\u001a\u0004\b@\u0010A\"\u0004\bB\u0010CR/\u0010E\u001a\u0004\u0018\u00010\u00062\b\u0010\u001d\u001a\u0004\u0018\u00010\u00068F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bH\u0010$\u001a\u0004\bF\u0010\'\"\u0004\bG\u0010)R\u0010\u0010I\u001a\u00020JX\u0082\u0004¢\u0006\u0004\n\u0002\u0010K¨\u0006l"
    }
    d2 = {
        "Lcom/example/bleconnectse/VideoMirrorController;",
        "Landroid/view/TextureView$SurfaceTextureListener;",
        "context",
        "Landroid/content/Context;",
        "logger",
        "Lkotlin/Function1;",
        "",
        "",
        "onPlaybackError",
        "Lkotlin/Function0;",
        "<init>",
        "(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V",
        "appContext",
        "kotlin.jvm.PlatformType",
        "mainHandler",
        "Landroid/os/Handler;",
        "player",
        "Landroid/media/MediaPlayer;",
        "previewView",
        "Landroid/view/TextureView;",
        "previewSurface",
        "Landroid/view/Surface;",
        "selectedUri",
        "Landroid/net/Uri;",
        "prepared",
        "",
        "lastFrameAt",
        "",
        "foregroundFrameCaptureEnabled",
        "<set-?>",
        "previewVisible",
        "getPreviewVisible",
        "()Z",
        "setPreviewVisible",
        "(Z)V",
        "previewVisible$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "mediaName",
        "getMediaName",
        "()Ljava/lang/String;",
        "setMediaName",
        "(Ljava/lang/String;)V",
        "mediaName$delegate",
        "isPrepared",
        "setPrepared",
        "isPrepared$delegate",
        "isPlaying",
        "setPlaying",
        "isPlaying$delegate",
        "isLooping",
        "setLooping",
        "isLooping$delegate",
        "positionMs",
        "getPositionMs",
        "()J",
        "setPositionMs",
        "(J)V",
        "positionMs$delegate",
        "durationMs",
        "getDurationMs",
        "setDurationMs",
        "durationMs$delegate",
        "",
        "videoAspectRatio",
        "getVideoAspectRatio",
        "()F",
        "setVideoAspectRatio",
        "(F)V",
        "videoAspectRatio$delegate",
        "errorMessage",
        "getErrorMessage",
        "setErrorMessage",
        "errorMessage$delegate",
        "framePump",
        "com/example/bleconnectse/VideoMirrorController$framePump$1",
        "Lcom/example/bleconnectse/VideoMirrorController$framePump$1;",
        "open",
        "uri",
        "attachPreview",
        "view",
        "togglePlayback",
        "updateLooping",
        "enabled",
        "enterBackground",
        "enterForeground",
        "seekBy",
        "deltaMs",
        "seekTo",
        "targetMs",
        "stop",
        "onSurfaceTextureAvailable",
        "surfaceTexture",
        "Landroid/graphics/SurfaceTexture;",
        "width",
        "",
        "height",
        "onSurfaceTextureSizeChanged",
        "onSurfaceTextureDestroyed",
        "onSurfaceTextureUpdated",
        "connectSurfaceAndPrepare",
        "preparePlayer",
        "captureCurrentFrame",
        "handlePlaybackError",
        "details",
        "releasePlayer",
        "displayNameOf",
        "formatPosition",
        "valueMs",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final appContext:Landroid/content/Context;

.field private final durationMs$delegate:Landroidx/compose/runtime/MutableState;

.field private final errorMessage$delegate:Landroidx/compose/runtime/MutableState;

.field private foregroundFrameCaptureEnabled:Z

.field private final framePump:Lcom/example/bleconnectse/VideoMirrorController$framePump$1;

.field private final isLooping$delegate:Landroidx/compose/runtime/MutableState;

.field private final isPlaying$delegate:Landroidx/compose/runtime/MutableState;

.field private final isPrepared$delegate:Landroidx/compose/runtime/MutableState;

.field private lastFrameAt:J

.field private final logger:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final mainHandler:Landroid/os/Handler;

.field private final mediaName$delegate:Landroidx/compose/runtime/MutableState;

.field private final onPlaybackError:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private player:Landroid/media/MediaPlayer;

.field private final positionMs$delegate:Landroidx/compose/runtime/MutableState;

.field private prepared:Z

.field private previewSurface:Landroid/view/Surface;

.field private previewView:Landroid/view/TextureView;

.field private final previewVisible$delegate:Landroidx/compose/runtime/MutableState;

.field private selectedUri:Landroid/net/Uri;

.field private final videoAspectRatio$delegate:Landroidx/compose/runtime/MutableState;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "logger"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onPlaybackError"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    iput-object p2, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    .line 25
    iput-object p3, p0, Lcom/example/bleconnectse/VideoMirrorController;->onPlaybackError:Lkotlin/jvm/functions/Function0;

    .line 27
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->appContext:Landroid/content/Context;

    .line 28
    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p2

    invoke-direct {p1, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->mainHandler:Landroid/os/Handler;

    const/4 p1, 0x1

    .line 36
    iput-boolean p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->foregroundFrameCaptureEnabled:Z

    const/4 p2, 0x0

    .line 38
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    const/4 p3, 0x0

    const/4 v0, 0x2

    invoke-static {p2, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewVisible$delegate:Landroidx/compose/runtime/MutableState;

    .line 40
    const-string v1, ""

    invoke-static {v1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->mediaName$delegate:Landroidx/compose/runtime/MutableState;

    .line 42
    invoke-static {p2, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->isPrepared$delegate:Landroidx/compose/runtime/MutableState;

    .line 44
    invoke-static {p2, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p2

    iput-object p2, p0, Lcom/example/bleconnectse/VideoMirrorController;->isPlaying$delegate:Landroidx/compose/runtime/MutableState;

    .line 46
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-static {p1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->isLooping$delegate:Landroidx/compose/runtime/MutableState;

    const-wide/16 p1, 0x0

    .line 48
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-static {p1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p2

    iput-object p2, p0, Lcom/example/bleconnectse/VideoMirrorController;->positionMs$delegate:Landroidx/compose/runtime/MutableState;

    .line 50
    invoke-static {p1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->durationMs$delegate:Landroidx/compose/runtime/MutableState;

    const p1, 0x3fe38e39

    .line 52
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    invoke-static {p1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->videoAspectRatio$delegate:Landroidx/compose/runtime/MutableState;

    .line 54
    invoke-static {p3, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->errorMessage$delegate:Landroidx/compose/runtime/MutableState;

    .line 57
    new-instance p1, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;-><init>(Lcom/example/bleconnectse/VideoMirrorController;)V

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->framePump:Lcom/example/bleconnectse/VideoMirrorController$framePump$1;

    return-void
.end method

.method public static final synthetic access$captureCurrentFrame(Lcom/example/bleconnectse/VideoMirrorController;)V
    .registers 1

    .line 22
    invoke-direct {p0}, Lcom/example/bleconnectse/VideoMirrorController;->captureCurrentFrame()V

    return-void
.end method

.method public static final synthetic access$getForegroundFrameCaptureEnabled$p(Lcom/example/bleconnectse/VideoMirrorController;)Z
    .registers 1

    .line 22
    iget-boolean p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->foregroundFrameCaptureEnabled:Z

    return p0
.end method

.method public static final synthetic access$getLastFrameAt$p(Lcom/example/bleconnectse/VideoMirrorController;)J
    .registers 3

    .line 22
    iget-wide v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->lastFrameAt:J

    return-wide v0
.end method

.method public static final synthetic access$getMainHandler$p(Lcom/example/bleconnectse/VideoMirrorController;)Landroid/os/Handler;
    .registers 1

    .line 22
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->mainHandler:Landroid/os/Handler;

    return-object p0
.end method

.method public static final synthetic access$getPlayer$p(Lcom/example/bleconnectse/VideoMirrorController;)Landroid/media/MediaPlayer;
    .registers 1

    .line 22
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    return-object p0
.end method

.method public static final synthetic access$getPrepared$p(Lcom/example/bleconnectse/VideoMirrorController;)Z
    .registers 1

    .line 22
    iget-boolean p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->prepared:Z

    return p0
.end method

.method public static final synthetic access$setLastFrameAt$p(Lcom/example/bleconnectse/VideoMirrorController;J)V
    .registers 3

    .line 22
    iput-wide p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->lastFrameAt:J

    return-void
.end method

.method public static final synthetic access$setPlaying(Lcom/example/bleconnectse/VideoMirrorController;Z)V
    .registers 2

    .line 22
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->setPlaying(Z)V

    return-void
.end method

.method public static final synthetic access$setPositionMs(Lcom/example/bleconnectse/VideoMirrorController;J)V
    .registers 3

    .line 22
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/VideoMirrorController;->setPositionMs(J)V

    return-void
.end method

.method private final captureCurrentFrame()V
    .registers 7

    .line 279
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewView:Landroid/view/TextureView;

    if-nez v0, :cond_6

    goto/16 :goto_aa

    .line 280
    :cond_6
    invoke-virtual {v0}, Landroid/view/TextureView;->isAvailable()Z

    move-result v1

    if-eqz v1, :cond_aa

    invoke-virtual {v0}, Landroid/view/TextureView;->getWidth()I

    move-result v1

    if-lez v1, :cond_aa

    invoke-virtual {v0}, Landroid/view/TextureView;->getHeight()I

    move-result v1

    if-gtz v1, :cond_1a

    goto/16 :goto_aa

    .line 281
    :cond_1a
    iget-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    if-nez v1, :cond_20

    goto/16 :goto_aa

    .line 282
    :cond_20
    invoke-virtual {v1}, Landroid/media/MediaPlayer;->getVideoWidth()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    const/4 v4, 0x0

    if-lez v3, :cond_33

    goto :goto_34

    :cond_33
    move-object v2, v4

    :goto_34
    if-eqz v2, :cond_3b

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    goto :goto_3f

    :cond_3b
    invoke-virtual {v0}, Landroid/view/TextureView;->getWidth()I

    move-result v2

    .line 283
    :goto_3f
    invoke-virtual {v1}, Landroid/media/MediaPlayer;->getVideoHeight()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    if-lez v3, :cond_51

    goto :goto_52

    :cond_51
    move-object v1, v4

    :goto_52
    if-eqz v1, :cond_59

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    goto :goto_5d

    :cond_59
    invoke-virtual {v0}, Landroid/view/TextureView;->getHeight()I

    move-result v1

    .line 284
    :goto_5d
    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v3

    const/high16 v5, 0x44a00000  # 1280.0f

    int-to-float v3, v3

    div-float/2addr v5, v3

    const/high16 v3, 0x3f800000  # 1.0f

    .line 285
    invoke-static {v3, v5}, Ljava/lang/Math;->min(FF)F

    move-result v3

    int-to-float v2, v2

    mul-float/2addr v2, v3

    .line 286
    invoke-static {v2}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result v2

    const/4 v5, 0x2

    invoke-static {v2, v5}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v2

    int-to-float v1, v1

    mul-float/2addr v1, v3

    .line 287
    invoke-static {v1}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result v1

    invoke-static {v1, v5}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v1

    .line 288
    :try_start_80
    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    check-cast p0, Lcom/example/bleconnectse/VideoMirrorController;

    .line 289
    invoke-virtual {v0, v2, v1}, Landroid/view/TextureView;->getBitmap(II)Landroid/graphics/Bitmap;

    move-result-object p0

    .line 288
    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_8c
    .catchall {:try_start_80 .. :try_end_8c} :catchall_8d

    goto :goto_98

    :catchall_8d
    move-exception p0

    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    .line 290
    :goto_98
    invoke-static {p0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9f

    goto :goto_a0

    :cond_9f
    move-object v4, p0

    :goto_a0
    check-cast v4, Landroid/graphics/Bitmap;

    if-nez v4, :cond_a5

    goto :goto_aa

    .line 291
    :cond_a5
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {p0, v4}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->submit(Landroid/graphics/Bitmap;)V

    :cond_aa
    :goto_aa
    return-void
.end method

.method private final connectSurfaceAndPrepare(Landroid/graphics/SurfaceTexture;)V
    .registers 3

    .line 221
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewSurface:Landroid/view/Surface;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Landroid/view/Surface;->release()V

    .line 222
    :cond_7
    new-instance v0, Landroid/view/Surface;

    invoke-direct {v0, p1}, Landroid/view/Surface;-><init>(Landroid/graphics/SurfaceTexture;)V

    iput-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewSurface:Landroid/view/Surface;

    .line 223
    iget-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    if-eqz p1, :cond_2d

    .line 225
    :try_start_12
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/VideoMirrorController;

    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewSurface:Landroid/view/Surface;

    invoke-virtual {p1, p0}, Landroid/media/MediaPlayer;->setSurface(Landroid/view/Surface;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_21
    .catchall {:try_start_12 .. :try_end_21} :catchall_22

    return-void

    :catchall_22
    move-exception p0

    sget-object p1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 228
    :cond_2d
    invoke-direct {p0}, Lcom/example/bleconnectse/VideoMirrorController;->preparePlayer()V

    return-void
.end method

.method private final displayNameOf(Landroid/net/Uri;)Ljava/lang/String;
    .registers 9

    .line 318
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->appContext:Landroid/content/Context;

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 p0, 0x1

    new-array v2, p0, [Ljava/lang/String;

    const/4 p0, 0x0

    const-string v6, "_display_name"

    aput-object v6, v2, p0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v3, 0x0

    move-object v1, p1

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0

    if-eqz p0, :cond_45

    check-cast p0, Ljava/io/Closeable;

    .line 319
    :try_start_1a
    move-object p1, p0

    check-cast p1, Landroid/database/Cursor;

    .line 320
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_37

    .line 321
    invoke-interface {p1, v6}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    if-ltz v0, :cond_37

    .line 322
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p1

    const-string v0, "getString(...)"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_33
    .catchall {:try_start_1a .. :try_end_33} :catchall_3d

    invoke-static {p0, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object p1

    .line 324
    :cond_37
    :try_start_37
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_39
    .catchall {:try_start_37 .. :try_end_39} :catchall_3d

    .line 319
    invoke-static {p0, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto :goto_45

    :catchall_3d
    move-exception v0

    move-object p1, v0

    :try_start_3f
    throw p1
    :try_end_40
    .catchall {:try_start_3f .. :try_end_40} :catchall_40

    :catchall_40
    move-exception v0

    invoke-static {p0, p1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    .line 325
    :cond_45
    :goto_45
    invoke-virtual {v1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_4e

    const-string/jumbo p0, "相册视频"

    :cond_4e
    return-object p0
.end method

.method static final enterForeground$lambda$9(Lcom/example/bleconnectse/VideoMirrorController;)V
    .registers 1

    .line 167
    invoke-direct {p0}, Lcom/example/bleconnectse/VideoMirrorController;->captureCurrentFrame()V

    return-void
.end method

.method private final formatPosition(J)Ljava/lang/String;
    .registers 7

    const-wide/16 v0, 0x0

    .line 329
    invoke-static {p1, p2, v0, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide p0

    const-wide/16 v0, 0x3e8

    div-long/2addr p0, v0

    const-wide/16 v0, 0x3c

    .line 330
    div-long v2, p0, v0

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    rem-long/2addr p0, v0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    filled-new-array {p2, p0}, [Ljava/lang/Object;

    move-result-object p0

    const/4 p1, 0x2

    invoke-static {p0, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%02d:%02d"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "format(...)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method private final handlePlaybackError(Ljava/lang/String;)V
    .registers 4

    const/4 v0, 0x0

    .line 295
    iput-boolean v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->prepared:Z

    .line 296
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/VideoMirrorController;->setPrepared(Z)V

    .line 297
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/VideoMirrorController;->setPlaying(Z)V

    .line 298
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "视频无法播放："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->setErrorMessage(Ljava/lang/String;)V

    .line 299
    iget-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getErrorMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {p1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 300
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->onPlaybackError:Lkotlin/jvm/functions/Function0;

    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method private final preparePlayer()V
    .registers 5

    .line 232
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->selectedUri:Landroid/net/Uri;

    if-nez v0, :cond_5

    goto :goto_9

    .line 233
    :cond_5
    iget-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewSurface:Landroid/view/Surface;

    if-nez v1, :cond_a

    :goto_9
    return-void

    .line 235
    :cond_a
    :try_start_a
    new-instance v2, Landroid/media/MediaPlayer;

    invoke-direct {v2}, Landroid/media/MediaPlayer;-><init>()V

    .line 236
    iput-object v2, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    .line 237
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->isLooping()Z

    move-result v3

    invoke-virtual {v2, v3}, Landroid/media/MediaPlayer;->setLooping(Z)V

    .line 238
    iget-object v3, p0, Lcom/example/bleconnectse/VideoMirrorController;->appContext:Landroid/content/Context;

    invoke-virtual {v2, v3, v0}, Landroid/media/MediaPlayer;->setDataSource(Landroid/content/Context;Landroid/net/Uri;)V

    .line 239
    invoke-virtual {v2, v1}, Landroid/media/MediaPlayer;->setSurface(Landroid/view/Surface;)V

    .line 240
    new-instance v0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda0;-><init>(Lcom/example/bleconnectse/VideoMirrorController;)V

    invoke-virtual {v2, v0}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    .line 253
    new-instance v0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/VideoMirrorController;)V

    invoke-virtual {v2, v0}, Landroid/media/MediaPlayer;->setOnVideoSizeChangedListener(Landroid/media/MediaPlayer$OnVideoSizeChangedListener;)V

    .line 258
    new-instance v0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda2;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda2;-><init>(Lcom/example/bleconnectse/VideoMirrorController;)V

    invoke-virtual {v2, v0}, Landroid/media/MediaPlayer;->setOnSeekCompleteListener(Landroid/media/MediaPlayer$OnSeekCompleteListener;)V

    .line 262
    new-instance v0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda3;-><init>(Lcom/example/bleconnectse/VideoMirrorController;)V

    invoke-virtual {v2, v0}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 268
    new-instance v0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda4;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda4;-><init>(Lcom/example/bleconnectse/VideoMirrorController;)V

    invoke-virtual {v2, v0}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    .line 272
    invoke-virtual {v2}, Landroid/media/MediaPlayer;->prepareAsync()V
    :try_end_4b
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_4b} :catch_4c

    return-void

    :catch_4c
    move-exception v0

    .line 274
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_5b

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    :cond_5b
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/VideoMirrorController;->handlePlaybackError(Ljava/lang/String;)V

    return-void
.end method

.method static final preparePlayer$lambda$12(Lcom/example/bleconnectse/VideoMirrorController;Landroid/media/MediaPlayer;)V
    .registers 7

    const/4 v0, 0x1

    .line 241
    iput-boolean v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->prepared:Z

    .line 242
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/VideoMirrorController;->setPrepared(Z)V

    .line 243
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v1

    int-to-long v1, v1

    const-wide/16 v3, 0x0

    invoke-static {v1, v2, v3, v4}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v1

    invoke-direct {p0, v1, v2}, Lcom/example/bleconnectse/VideoMirrorController;->setDurationMs(J)V

    .line 244
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->getVideoWidth()I

    move-result v1

    .line 245
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->getVideoHeight()I

    move-result v2

    if-lez v1, :cond_26

    if-lez v2, :cond_26

    int-to-float v1, v1

    int-to-float v2, v2

    div-float/2addr v1, v2

    .line 247
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/VideoMirrorController;->setVideoAspectRatio(F)V

    .line 249
    :cond_26
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->start()V

    .line 250
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/VideoMirrorController;->setPlaying(Z)V

    .line 251
    iget-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getMediaName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getDurationMs()J

    move-result-wide v1

    invoke-direct {p0, v1, v2}, Lcom/example/bleconnectse/VideoMirrorController;->formatPosition(J)Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "相册视频开始播放并投屏："

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "，时长="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-interface {p1, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method static final preparePlayer$lambda$13(Lcom/example/bleconnectse/VideoMirrorController;Landroid/media/MediaPlayer;II)V
    .registers 4

    if-lez p2, :cond_a

    if-lez p3, :cond_a

    int-to-float p1, p2

    int-to-float p2, p3

    div-float/2addr p1, p2

    .line 255
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->setVideoAspectRatio(F)V

    :cond_a
    return-void
.end method

.method static final preparePlayer$lambda$15(Lcom/example/bleconnectse/VideoMirrorController;Landroid/media/MediaPlayer;)V
    .registers 5

    .line 259
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result p1

    int-to-long v0, p1

    invoke-direct {p0, v0, v1}, Lcom/example/bleconnectse/VideoMirrorController;->setPositionMs(J)V

    .line 260
    iget-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->mainHandler:Landroid/os/Handler;

    new-instance v0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda6;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda6;-><init>(Lcom/example/bleconnectse/VideoMirrorController;)V

    const-wide/16 v1, 0x3c

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method static final preparePlayer$lambda$15$lambda$14(Lcom/example/bleconnectse/VideoMirrorController;)V
    .registers 1

    .line 260
    invoke-direct {p0}, Lcom/example/bleconnectse/VideoMirrorController;->captureCurrentFrame()V

    return-void
.end method

.method static final preparePlayer$lambda$16(Lcom/example/bleconnectse/VideoMirrorController;Landroid/media/MediaPlayer;)V
    .registers 4

    .line 263
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getDurationMs()J

    move-result-wide v0

    invoke-direct {p0, v0, v1}, Lcom/example/bleconnectse/VideoMirrorController;->setPositionMs(J)V

    const/4 p1, 0x0

    .line 264
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->setPlaying(Z)V

    .line 265
    invoke-direct {p0}, Lcom/example/bleconnectse/VideoMirrorController;->captureCurrentFrame()V

    .line 266
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    const-string/jumbo p1, "相册视频播放完成"

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method static final preparePlayer$lambda$17(Lcom/example/bleconnectse/VideoMirrorController;Landroid/media/MediaPlayer;II)Z
    .registers 5

    .line 269
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "MediaPlayer 错误 what="

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p2, " extra="

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->handlePlaybackError(Ljava/lang/String;)V

    const/4 p0, 0x1

    return p0
.end method

.method private final releasePlayer()V
    .registers 5

    const/4 v0, 0x0

    .line 304
    iput-boolean v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->prepared:Z

    .line 305
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/VideoMirrorController;->setPrepared(Z)V

    .line 306
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/VideoMirrorController;->setPlaying(Z)V

    .line 307
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    const/4 v1, 0x0

    if-eqz v0, :cond_5b

    .line 308
    :try_start_e
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p0

    check-cast v2, Lcom/example/bleconnectse/VideoMirrorController;

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1b
    .catchall {:try_start_e .. :try_end_1b} :catchall_1c

    goto :goto_26

    :catchall_1c
    move-exception v2

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 309
    :goto_26
    :try_start_26
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p0

    check-cast v2, Lcom/example/bleconnectse/VideoMirrorController;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->stop()V

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_33
    .catchall {:try_start_26 .. :try_end_33} :catchall_34

    goto :goto_3e

    :catchall_34
    move-exception v2

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 310
    :goto_3e
    :try_start_3e
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p0

    check-cast v2, Lcom/example/bleconnectse/VideoMirrorController;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_4c
    .catchall {:try_start_3e .. :try_end_4c} :catchall_4d

    goto :goto_58

    :catchall_4d
    move-exception v0

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_58
    invoke-static {v0}, Lkotlin/Result;->box-impl(Ljava/lang/Object;)Lkotlin/Result;

    .line 312
    :cond_5b
    iput-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    .line 313
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewSurface:Landroid/view/Surface;

    if-eqz v0, :cond_64

    invoke-virtual {v0}, Landroid/view/Surface;->release()V

    .line 314
    :cond_64
    iput-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewSurface:Landroid/view/Surface;

    return-void
.end method

.method private final setDurationMs(J)V
    .registers 3

    .line 50
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->durationMs$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    .line 353
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setErrorMessage(Ljava/lang/String;)V
    .registers 2

    .line 54
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->errorMessage$delegate:Landroidx/compose/runtime/MutableState;

    .line 359
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setLooping(Z)V
    .registers 2

    .line 46
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->isLooping$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 347
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setMediaName(Ljava/lang/String;)V
    .registers 2

    .line 40
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->mediaName$delegate:Landroidx/compose/runtime/MutableState;

    .line 338
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setPlaying(Z)V
    .registers 2

    .line 44
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->isPlaying$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 344
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setPositionMs(J)V
    .registers 3

    .line 48
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->positionMs$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    .line 350
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setPrepared(Z)V
    .registers 2

    .line 42
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->isPrepared$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 341
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setPreviewVisible(Z)V
    .registers 2

    .line 38
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewVisible$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 335
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setVideoAspectRatio(F)V
    .registers 2

    .line 52
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->videoAspectRatio$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    .line 356
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final attachPreview(Landroid/view/TextureView;)V
    .registers 4

    const-string/jumbo v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 98
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewView:Landroid/view/TextureView;

    if-ne v0, p1, :cond_b

    goto :goto_28

    :cond_b
    if-eqz v0, :cond_11

    const/4 v1, 0x0

    .line 99
    invoke-virtual {v0, v1}, Landroid/view/TextureView;->setSurfaceTextureListener(Landroid/view/TextureView$SurfaceTextureListener;)V

    .line 100
    :cond_11
    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewView:Landroid/view/TextureView;

    .line 101
    move-object v0, p0

    check-cast v0, Landroid/view/TextureView$SurfaceTextureListener;

    invoke-virtual {p1, v0}, Landroid/view/TextureView;->setSurfaceTextureListener(Landroid/view/TextureView$SurfaceTextureListener;)V

    .line 102
    invoke-virtual {p1}, Landroid/view/TextureView;->isAvailable()Z

    move-result v0

    if-eqz v0, :cond_28

    .line 103
    invoke-virtual {p1}, Landroid/view/TextureView;->getSurfaceTexture()Landroid/graphics/SurfaceTexture;

    move-result-object p1

    if-eqz p1, :cond_28

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->connectSurfaceAndPrepare(Landroid/graphics/SurfaceTexture;)V

    :cond_28
    :goto_28
    return-void
.end method

.method public final enterBackground(Landroid/content/Context;)V
    .registers 13

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    iget-object v3, p0, Lcom/example/bleconnectse/VideoMirrorController;->selectedUri:Landroid/net/Uri;

    if-nez v3, :cond_b

    goto/16 :goto_ec

    .line 134
    :cond_b
    iget-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    if-nez v1, :cond_11

    goto/16 :goto_ec

    .line 135
    :cond_11
    iget-boolean v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->prepared:Z

    if-eqz v0, :cond_ec

    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getPreviewVisible()Z

    move-result v0

    if-nez v0, :cond_1d

    goto/16 :goto_ec

    .line 136
    :cond_1d
    :try_start_1d
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/VideoMirrorController;

    invoke-virtual {v1}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result v0

    int-to-long v4, v0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_2f
    .catchall {:try_start_1d .. :try_end_2f} :catchall_30

    goto :goto_3b

    :catchall_30
    move-exception v0

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_3b
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getPositionMs()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4a

    move-object v0, v2

    :cond_4a
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v4

    invoke-direct {p0, v4, v5}, Lcom/example/bleconnectse/VideoMirrorController;->setPositionMs(J)V

    const/4 v10, 0x0

    .line 137
    :try_start_54
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/VideoMirrorController;

    move-object v2, v1

    .line 140
    sget-object v1, Lcom/example/bleconnectse/VideoBackgroundFrameService;->Companion:Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;

    .line 143
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getPositionMs()J

    move-result-wide v4

    .line 144
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getDurationMs()J

    move-result-wide v6
    :try_end_64
    .catchall {:try_start_54 .. :try_end_64} :catchall_a4

    .line 145
    :try_start_64
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_72
    .catchall {:try_start_64 .. :try_end_72} :catchall_73

    goto :goto_7e

    :catchall_73
    move-exception v0

    :try_start_74
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_7e
    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_89

    move-object v0, v2

    :cond_89
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    .line 146
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->isLooping()Z

    move-result v9
    :try_end_93
    .catchall {:try_start_74 .. :try_end_93} :catchall_a4

    move-object v2, p1

    .line 140
    :try_start_94
    invoke-virtual/range {v1 .. v9}, Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;->startIntent(Landroid/content/Context;Landroid/net/Uri;JJZZ)Landroid/content/Intent;

    move-result-object p1

    .line 138
    invoke-static {v2, p1}, Landroidx/core/content/ContextCompat;->startForegroundService(Landroid/content/Context;Landroid/content/Intent;)V

    .line 149
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 137
    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_a1
    .catchall {:try_start_94 .. :try_end_a1} :catchall_a2

    goto :goto_b1

    :catchall_a2
    move-exception v0

    goto :goto_a6

    :catchall_a4
    move-exception v0

    move-object v2, p1

    :goto_a6
    move-object p1, v0

    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    .line 149
    :goto_b1
    invoke-static {p1}, Lkotlin/Result;->isSuccess-impl(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_cd

    move-object v0, p1

    check-cast v0, Lkotlin/Unit;

    .line 150
    iput-boolean v10, p0, Lcom/example/bleconnectse/VideoMirrorController;->foregroundFrameCaptureEnabled:Z

    .line 151
    sget-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    invoke-virtual {v0, v2}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 152
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    const-string/jumbo v1, "视频投屏已切换为后台独立取帧"

    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 153
    :cond_cd
    invoke-static {p1}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p1

    if-eqz p1, :cond_ec

    .line 154
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "无法启动后台视频取帧："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_ec
    :goto_ec
    return-void
.end method

.method public final enterForeground(Landroid/content/Context;)V
    .registers 5

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 159
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getPreviewVisible()Z

    move-result v0

    if-eqz v0, :cond_3c

    .line 162
    sget-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    const-string/jumbo v1, "相册视频"

    invoke-virtual {v0, p1, v1}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->startIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 160
    invoke-static {p1, v0}, Landroidx/core/content/ContextCompat;->startForegroundService(Landroid/content/Context;Landroid/content/Intent;)V

    .line 164
    sget-object v0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->Companion:Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;

    invoke-virtual {v0, p1}, Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    const/4 p1, 0x1

    .line 165
    iput-boolean p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->foregroundFrameCaptureEnabled:Z

    const-wide/16 v0, 0x0

    .line 166
    iput-wide v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->lastFrameAt:J

    .line 167
    iget-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->mainHandler:Landroid/os/Handler;

    new-instance v0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda5;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda5;-><init>(Lcom/example/bleconnectse/VideoMirrorController;)V

    const-wide/16 v1, 0x50

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 168
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    const-string/jumbo p1, "视频投屏已恢复前台预览取帧"

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 170
    :cond_3c
    sget-object p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->Companion:Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    return-void
.end method

.method public final getDurationMs()J
    .registers 3

    .line 50
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->durationMs$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 352
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    return-wide v0
.end method

.method public final getErrorMessage()Ljava/lang/String;
    .registers 1

    .line 54
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->errorMessage$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 358
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public final getMediaName()Ljava/lang/String;
    .registers 1

    .line 40
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->mediaName$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 337
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public final getPositionMs()J
    .registers 3

    .line 48
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->positionMs$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 349
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    return-wide v0
.end method

.method public final getPreviewVisible()Z
    .registers 1

    .line 38
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewVisible$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 334
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final getVideoAspectRatio()F
    .registers 1

    .line 52
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->videoAspectRatio$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 355
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0
.end method

.method public final isLooping()Z
    .registers 1

    .line 46
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->isLooping$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 346
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final isPlaying()Z
    .registers 1

    .line 44
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->isPlaying$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 343
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final isPrepared()Z
    .registers 1

    .line 42
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->isPrepared$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 340
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public onSurfaceTextureAvailable(Landroid/graphics/SurfaceTexture;II)V
    .registers 4

    const-string p2, "surfaceTexture"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 205
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->connectSurfaceAndPrepare(Landroid/graphics/SurfaceTexture;)V

    return-void
.end method

.method public onSurfaceTextureDestroyed(Landroid/graphics/SurfaceTexture;)Z
    .registers 4

    const-string v0, "surfaceTexture"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    .line 211
    :try_start_6
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/VideoMirrorController;

    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    if-eqz v0, :cond_15

    invoke-virtual {v0, p1}, Landroid/media/MediaPlayer;->setSurface(Landroid/view/Surface;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_16

    :cond_15
    move-object v0, p1

    :goto_16
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_19
    .catchall {:try_start_6 .. :try_end_19} :catchall_1a

    goto :goto_24

    :catchall_1a
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 212
    :goto_24
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewSurface:Landroid/view/Surface;

    if-eqz v0, :cond_2b

    invoke-virtual {v0}, Landroid/view/Surface;->release()V

    .line 213
    :cond_2b
    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewSurface:Landroid/view/Surface;

    .line 214
    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewView:Landroid/view/TextureView;

    const/4 p0, 0x1

    return p0
.end method

.method public onSurfaceTextureSizeChanged(Landroid/graphics/SurfaceTexture;II)V
    .registers 4

    const-string p0, "surfaceTexture"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public onSurfaceTextureUpdated(Landroid/graphics/SurfaceTexture;)V
    .registers 2

    const-string p0, "surfaceTexture"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final open(Landroid/net/Uri;)V
    .registers 6

    const-string v0, "uri"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    invoke-direct {p0}, Lcom/example/bleconnectse/VideoMirrorController;->releasePlayer()V

    .line 82
    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->selectedUri:Landroid/net/Uri;

    .line 83
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->displayNameOf(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->setMediaName(Ljava/lang/String;)V

    const-wide/16 v0, 0x0

    .line 84
    invoke-direct {p0, v0, v1}, Lcom/example/bleconnectse/VideoMirrorController;->setPositionMs(J)V

    .line 85
    invoke-direct {p0, v0, v1}, Lcom/example/bleconnectse/VideoMirrorController;->setDurationMs(J)V

    const p1, 0x3fe38e39

    .line 86
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->setVideoAspectRatio(F)V

    const/4 p1, 0x0

    .line 87
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->setErrorMessage(Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 88
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/VideoMirrorController;->setPreviewVisible(Z)V

    .line 89
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getMediaName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "已选择相册视频："

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, "，准备预览并投屏"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 90
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewView:Landroid/view/TextureView;

    if-eqz v0, :cond_5d

    invoke-virtual {v0}, Landroid/view/TextureView;->isAvailable()Z

    move-result v1

    if-eqz v1, :cond_52

    move-object p1, v0

    :cond_52
    if-eqz p1, :cond_5d

    invoke-virtual {p1}, Landroid/view/TextureView;->getSurfaceTexture()Landroid/graphics/SurfaceTexture;

    move-result-object p1

    if-eqz p1, :cond_5d

    .line 91
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->connectSurfaceAndPrepare(Landroid/graphics/SurfaceTexture;)V

    .line 93
    :cond_5d
    iget-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->mainHandler:Landroid/os/Handler;

    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->framePump:Lcom/example/bleconnectse/VideoMirrorController$framePump$1;

    check-cast v0, Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 94
    iget-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController;->mainHandler:Landroid/os/Handler;

    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->framePump:Lcom/example/bleconnectse/VideoMirrorController$framePump$1;

    check-cast p0, Ljava/lang/Runnable;

    invoke-virtual {p1, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final seekBy(J)V
    .registers 5

    .line 175
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getPositionMs()J

    move-result-wide v0

    add-long/2addr v0, p1

    invoke-virtual {p0, v0, v1}, Lcom/example/bleconnectse/VideoMirrorController;->seekTo(J)V

    return-void
.end method

.method public final seekTo(J)V
    .registers 14

    .line 179
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    if-nez v0, :cond_5

    goto :goto_9

    .line 180
    :cond_5
    iget-boolean v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->prepared:Z

    if-nez v1, :cond_a

    :goto_9
    return-void

    .line 181
    :cond_a
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getDurationMs()J

    move-result-wide v1

    const-wide/16 v3, 0x0

    invoke-static {v1, v2, v3, v4}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v9

    const-wide/16 v7, 0x0

    move-wide v5, p1

    .line 182
    invoke-static/range {v5 .. v10}, Lkotlin/ranges/RangesKt;->coerceIn(JJJ)J

    move-result-wide p1

    .line 183
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/VideoMirrorController;->setPositionMs(J)V

    .line 184
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    if-lt v1, v2, :cond_29

    const/4 v1, 0x3

    .line 185
    invoke-virtual {v0, p1, p2, v1}, Landroid/media/MediaPlayer;->seekTo(JI)V

    goto :goto_2d

    :cond_29
    long-to-int v1, p1

    .line 188
    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->seekTo(I)V

    .line 190
    :goto_2d
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/VideoMirrorController;->formatPosition(J)Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string/jumbo p2, "相册视频跳转到："

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final stop()V
    .registers 5

    const/4 v0, 0x0

    .line 194
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/VideoMirrorController;->setPreviewVisible(Z)V

    .line 195
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->mainHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->framePump:Lcom/example/bleconnectse/VideoMirrorController$framePump$1;

    check-cast v1, Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 196
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewView:Landroid/view/TextureView;

    const/4 v1, 0x0

    if-eqz v0, :cond_15

    invoke-virtual {v0, v1}, Landroid/view/TextureView;->setSurfaceTextureListener(Landroid/view/TextureView$SurfaceTextureListener;)V

    .line 197
    :cond_15
    iput-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->previewView:Landroid/view/TextureView;

    .line 198
    iput-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->selectedUri:Landroid/net/Uri;

    const/4 v0, 0x1

    .line 199
    iput-boolean v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->foregroundFrameCaptureEnabled:Z

    .line 200
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->appContext:Landroid/content/Context;

    sget-object v1, Lcom/example/bleconnectse/VideoBackgroundFrameService;->Companion:Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;

    iget-object v2, p0, Lcom/example/bleconnectse/VideoMirrorController;->appContext:Landroid/content/Context;

    const-string v3, "appContext"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 201
    invoke-direct {p0}, Lcom/example/bleconnectse/VideoMirrorController;->releasePlayer()V

    return-void
.end method

.method public final togglePlayback()V
    .registers 10

    .line 108
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    if-nez v0, :cond_6

    goto/16 :goto_ac

    .line 109
    :cond_6
    iget-boolean v1, p0, Lcom/example/bleconnectse/VideoMirrorController;->prepared:Z

    if-nez v1, :cond_c

    goto/16 :goto_ac

    .line 110
    :cond_c
    :try_start_c
    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v1, p0

    check-cast v1, Lcom/example/bleconnectse/VideoMirrorController;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_1d
    .catchall {:try_start_c .. :try_end_1d} :catchall_1e

    goto :goto_29

    :catchall_1e
    move-exception v1

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    :goto_29
    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v1}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_35

    move-object v1, v3

    :cond_35
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_6c

    .line 111
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->pause()V

    .line 112
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/VideoMirrorController;->setPlaying(Z)V

    .line 113
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result v0

    int-to-long v0, v0

    invoke-direct {p0, v0, v1}, Lcom/example/bleconnectse/VideoMirrorController;->setPositionMs(J)V

    .line 114
    invoke-direct {p0}, Lcom/example/bleconnectse/VideoMirrorController;->captureCurrentFrame()V

    .line 115
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getPositionMs()J

    move-result-wide v1

    invoke-direct {p0, v1, v2}, Lcom/example/bleconnectse/VideoMirrorController;->formatPosition(J)Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "相册视频已暂停："

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_ac

    .line 117
    :cond_6c
    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getDurationMs()J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long v1, v1, v3

    if-lez v1, :cond_88

    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getPositionMs()J

    move-result-wide v1

    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getDurationMs()J

    move-result-wide v5

    const-wide/16 v7, 0xfa

    sub-long/2addr v5, v7

    cmp-long v1, v1, v5

    if-ltz v1, :cond_88

    .line 118
    invoke-virtual {p0, v3, v4}, Lcom/example/bleconnectse/VideoMirrorController;->seekTo(J)V

    .line 120
    :cond_88
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->start()V

    const/4 v0, 0x1

    .line 121
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/VideoMirrorController;->setPlaying(Z)V

    .line 122
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {p0}, Lcom/example/bleconnectse/VideoMirrorController;->getPositionMs()J

    move-result-wide v1

    invoke-direct {p0, v1, v2}, Lcom/example/bleconnectse/VideoMirrorController;->formatPosition(J)Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "相册视频继续播放："

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_ac
    return-void
.end method

.method public final updateLooping(Z)V
    .registers 3

    .line 127
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->setLooping(Z)V

    .line 128
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController;->player:Landroid/media/MediaPlayer;

    if-eqz v0, :cond_a

    invoke-virtual {v0, p1}, Landroid/media/MediaPlayer;->setLooping(Z)V

    .line 129
    :cond_a
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    if-eqz p1, :cond_12

    const-string/jumbo p1, "开启"

    goto :goto_15

    :cond_12
    const-string/jumbo p1, "关闭"

    :goto_15
    const-string/jumbo v0, "相册视频循环播放已"

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
