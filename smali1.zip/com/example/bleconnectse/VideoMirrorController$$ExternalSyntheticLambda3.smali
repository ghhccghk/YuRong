# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnCompletionListener;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/VideoMirrorController;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/VideoMirrorController;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda3;->f$0:Lcom/example/bleconnectse/VideoMirrorController;

    return-void
.end method


# virtual methods
.method public final onCompletion(Landroid/media/MediaPlayer;)V
    .registers 2

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda3;->f$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->preparePlayer$lambda$16(Lcom/example/bleconnectse/VideoMirrorController;Landroid/media/MediaPlayer;)V

    return-void
.end method
