# classes2.dex

.class final synthetic Lcom/example/bleconnectse/MainActivityKt$VideoMirrorDialog$2$1$1$1$1;
.super Lkotlin/jvm/internal/FunctionReferenceImpl;
.source "MainActivity.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/MainActivityKt;->VideoMirrorDialog(Lcom/example/bleconnectse/VideoMirrorController;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1018
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/FunctionReferenceImpl;",
        "Lkotlin/jvm/functions/Function1<",
        "Landroid/view/TextureView;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .registers 9

    const-class v3, Lcom/example/bleconnectse/VideoMirrorController;

    const-string v5, "attachPreview(Landroid/view/TextureView;)V"

    const/4 v6, 0x0

    const/4 v1, 0x1

    const-string v4, "attachPreview"

    move-object v0, p0

    move-object v2, p1

    invoke-direct/range {v0 .. v6}, Lkotlin/jvm/internal/FunctionReferenceImpl;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1073
    check-cast p1, Landroid/view/TextureView;

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/MainActivityKt$VideoMirrorDialog$2$1$1$1$1;->invoke(Landroid/view/TextureView;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public final invoke(Landroid/view/TextureView;)V
    .registers 3

    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1073
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$VideoMirrorDialog$2$1$1$1$1;->receiver:Ljava/lang/Object;

    check-cast p0, Lcom/example/bleconnectse/VideoMirrorController;

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/VideoMirrorController;->attachPreview(Landroid/view/TextureView;)V

    return-void
.end method
