# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/BleTileClient;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/BleTileClient;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda1;->f$0:Lcom/example/bleconnectse/BleTileClient;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 1

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda1;->f$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {p0}, Lcom/example/bleconnectse/BleTileClient;->$r8$lambda$QzDpTRPUPi_GkXNVEpzPHukkXdw(Lcom/example/bleconnectse/BleTileClient;)V

    return-void
.end method
