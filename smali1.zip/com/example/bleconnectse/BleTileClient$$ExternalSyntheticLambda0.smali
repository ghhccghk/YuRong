# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$1:J


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/BleTileClient;J)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda0;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iput-wide p2, p0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda0;->f$1:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda0;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iget-wide v1, p0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda0;->f$1:J

    invoke-static {v0, v1, v2}, Lcom/example/bleconnectse/BleTileClient;->pumpTransfer$lambda$16(Lcom/example/bleconnectse/BleTileClient;J)V

    return-void
.end method
