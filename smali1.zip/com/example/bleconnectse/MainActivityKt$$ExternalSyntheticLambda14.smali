# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda14;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/VideoMirrorController;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/VideoMirrorController;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda14;->f$0:Lcom/example/bleconnectse/VideoMirrorController;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 1

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda14;->f$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {p0}, Lcom/example/bleconnectse/MainActivityKt;->VideoMirrorDialog$lambda$97$lambda$96$lambda$93$lambda$92$lambda$91(Lcom/example/bleconnectse/VideoMirrorController;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
