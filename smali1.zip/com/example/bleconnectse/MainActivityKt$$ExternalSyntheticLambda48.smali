# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function1;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$2:[Lcom/example/bleconnectse/AmapNavigationView;

.field public final synthetic f$3:Z

.field public final synthetic f$4:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;[Lcom/example/bleconnectse/AmapNavigationView;ZLkotlin/jvm/functions/Function1;)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;->f$0:Lkotlin/jvm/functions/Function1;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;->f$1:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;->f$2:[Lcom/example/bleconnectse/AmapNavigationView;

    iput-boolean p4, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;->f$3:Z

    iput-object p5, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;->f$4:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;->f$0:Lkotlin/jvm/functions/Function1;

    iget-object v1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;->f$1:Landroidx/compose/runtime/MutableState;

    iget-object v2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;->f$2:[Lcom/example/bleconnectse/AmapNavigationView;

    iget-boolean v3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;->f$3:Z

    iget-object v4, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda48;->f$4:Lkotlin/jvm/functions/Function1;

    move-object v5, p1

    check-cast v5, Landroid/content/Context;

    invoke-static/range {v0 .. v5}, Lcom/example/bleconnectse/MainActivityKt;->AmapNavigationScreen$lambda$38$lambda$11$lambda$10(Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;[Lcom/example/bleconnectse/AmapNavigationView;ZLkotlin/jvm/functions/Function1;Landroid/content/Context;)Lcom/example/bleconnectse/AmapNavigationView;

    move-result-object p0

    return-object p0
.end method
