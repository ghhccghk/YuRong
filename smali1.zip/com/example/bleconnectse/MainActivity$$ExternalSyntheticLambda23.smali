# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda23;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/activity/result/ActivityResultCallback;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/MainActivity;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda23;->f$0:Lcom/example/bleconnectse/MainActivity;

    return-void
.end method


# virtual methods
.method public final onActivityResult(Ljava/lang/Object;)V
    .registers 2

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda23;->f$0:Lcom/example/bleconnectse/MainActivity;

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/MainActivity;->cameraPermissionLauncher$lambda$3(Lcom/example/bleconnectse/MainActivity;Z)V

    return-void
.end method
