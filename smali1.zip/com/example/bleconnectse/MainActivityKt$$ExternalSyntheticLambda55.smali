# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda55;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda55;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 1

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda55;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-static {p0}, Lcom/example/bleconnectse/MainActivityKt;->NetworkPanel$lambda$117$lambda$116$lambda$115$lambda$114$lambda$113(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
