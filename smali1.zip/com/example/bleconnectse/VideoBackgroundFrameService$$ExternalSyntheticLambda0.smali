# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:J

.field public final synthetic f$2:J

.field public final synthetic f$3:J

.field public final synthetic f$4:Z

.field public final synthetic f$5:Lcom/example/bleconnectse/VideoBackgroundFrameService;

.field public final synthetic f$6:Landroid/media/MediaMetadataRetriever;

.field public final synthetic f$7:I

.field public final synthetic f$8:I


# direct methods
.method public synthetic constructor <init>(ZJJJZLcom/example/bleconnectse/VideoBackgroundFrameService;Landroid/media/MediaMetadataRetriever;II)V
    .registers 13

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$0:Z

    iput-wide p2, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$1:J

    iput-wide p4, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$2:J

    iput-wide p6, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$3:J

    iput-boolean p8, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$4:Z

    iput-object p9, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$5:Lcom/example/bleconnectse/VideoBackgroundFrameService;

    iput-object p10, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$6:Landroid/media/MediaMetadataRetriever;

    iput p11, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$7:I

    iput p12, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$8:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 13

    .line 0
    iget-boolean v0, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$0:Z

    iget-wide v1, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$1:J

    iget-wide v3, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$2:J

    iget-wide v5, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$3:J

    iget-boolean v7, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$4:Z

    iget-object v8, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$5:Lcom/example/bleconnectse/VideoBackgroundFrameService;

    iget-object v9, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$6:Landroid/media/MediaMetadataRetriever;

    iget v10, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$7:I

    iget v11, p0, Lcom/example/bleconnectse/VideoBackgroundFrameService$$ExternalSyntheticLambda0;->f$8:I

    invoke-static/range {v0 .. v11}, Lcom/example/bleconnectse/VideoBackgroundFrameService;->startDecoding$lambda$3(ZJJJZLcom/example/bleconnectse/VideoBackgroundFrameService;Landroid/media/MediaMetadataRetriever;II)V

    return-void
.end method
