# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda40;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/lifecycle/LifecycleEventObserver;


# instance fields
.field public final synthetic f$0:[Lcom/example/bleconnectse/AmapNavigationView;


# direct methods
.method public synthetic constructor <init>([Lcom/example/bleconnectse/AmapNavigationView;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda40;->f$0:[Lcom/example/bleconnectse/AmapNavigationView;

    return-void
.end method


# virtual methods
.method public final onStateChanged(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 3

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda40;->f$0:[Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0, p1, p2}, Lcom/example/bleconnectse/MainActivityKt;->AmapNavigationScreen$lambda$42$lambda$41$lambda$39([Lcom/example/bleconnectse/AmapNavigationView;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V

    return-void
.end method
