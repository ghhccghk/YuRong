# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:Lcom/example/bleconnectse/P2pPeer;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda11;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda11;->f$1:Lcom/example/bleconnectse/P2pPeer;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda11;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda11;->f$1:Lcom/example/bleconnectse/P2pPeer;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->discoverPendingP2pPeer$lambda$129(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V

    return-void
.end method
