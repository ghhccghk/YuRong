# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda3;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iput-object p2, p0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda3;->f$1:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda3;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda3;->f$1:Ljava/lang/String;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/BleTileClient;->scheduleReconnect$lambda$20(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V

    return-void
.end method
