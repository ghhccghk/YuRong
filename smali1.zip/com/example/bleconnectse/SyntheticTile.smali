# classes2.dex

.class public final Lcom/example/bleconnectse/SyntheticTile;
.super Ljava/lang/Object;
.source "SyntheticTileRepository.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\t\n\u0002\b\u0011\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bJ\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0018\u001a\u00020\tHÆ\u0003J;\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\tHÆ\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÖ\u0001J\t\u0010\u001e\u001a\u00020\u001fHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013¨\u0006 "
    }
    d2 = {
        "Lcom/example/bleconnectse/SyntheticTile;",
        "",
        "tileId",
        "",
        "tileX",
        "tileY",
        "bytes",
        "",
        "crc32",
        "",
        "<init>",
        "(III[BJ)V",
        "getTileId",
        "()I",
        "getTileX",
        "getTileY",
        "getBytes",
        "()[B",
        "getCrc32",
        "()J",
        "component1",
        "component2",
        "component3",
        "component4",
        "component5",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "toString",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final bytes:[B

.field private final crc32:J

.field private final tileId:I

.field private final tileX:I

.field private final tileY:I


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(III[BJ)V
    .registers 8

    const-string v0, "bytes"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput p1, p0, Lcom/example/bleconnectse/SyntheticTile;->tileId:I

    .line 10
    iput p2, p0, Lcom/example/bleconnectse/SyntheticTile;->tileX:I

    .line 11
    iput p3, p0, Lcom/example/bleconnectse/SyntheticTile;->tileY:I

    .line 12
    iput-object p4, p0, Lcom/example/bleconnectse/SyntheticTile;->bytes:[B

    .line 13
    iput-wide p5, p0, Lcom/example/bleconnectse/SyntheticTile;->crc32:J

    return-void
.end method

.method public static synthetic copy$default(Lcom/example/bleconnectse/SyntheticTile;III[BJILjava/lang/Object;)Lcom/example/bleconnectse/SyntheticTile;
    .registers 9

    and-int/lit8 p8, p7, 0x1

    if-eqz p8, :cond_6

    iget p1, p0, Lcom/example/bleconnectse/SyntheticTile;->tileId:I

    :cond_6
    and-int/lit8 p8, p7, 0x2

    if-eqz p8, :cond_c

    iget p2, p0, Lcom/example/bleconnectse/SyntheticTile;->tileX:I

    :cond_c
    and-int/lit8 p8, p7, 0x4

    if-eqz p8, :cond_12

    iget p3, p0, Lcom/example/bleconnectse/SyntheticTile;->tileY:I

    :cond_12
    and-int/lit8 p8, p7, 0x8

    if-eqz p8, :cond_18

    iget-object p4, p0, Lcom/example/bleconnectse/SyntheticTile;->bytes:[B

    :cond_18
    and-int/lit8 p7, p7, 0x10

    if-eqz p7, :cond_1e

    iget-wide p5, p0, Lcom/example/bleconnectse/SyntheticTile;->crc32:J

    :cond_1e
    move-wide p7, p5

    move p5, p3

    move-object p6, p4

    move p3, p1

    move p4, p2

    move-object p2, p0

    invoke-virtual/range {p2 .. p8}, Lcom/example/bleconnectse/SyntheticTile;->copy(III[BJ)Lcom/example/bleconnectse/SyntheticTile;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/SyntheticTile;->tileId:I

    return p0
.end method

.method public final component2()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/SyntheticTile;->tileX:I

    return p0
.end method

.method public final component3()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/SyntheticTile;->tileY:I

    return p0
.end method

.method public final component4()[B
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticTile;->bytes:[B

    return-object p0
.end method

.method public final component5()J
    .registers 3

    iget-wide v0, p0, Lcom/example/bleconnectse/SyntheticTile;->crc32:J

    return-wide v0
.end method

.method public final copy(III[BJ)Lcom/example/bleconnectse/SyntheticTile;
    .registers 14

    const-string p0, "bytes"

    invoke-static {p4, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/example/bleconnectse/SyntheticTile;

    move v1, p1

    move v2, p2

    move v3, p3

    move-object v4, p4

    move-wide v5, p5

    invoke-direct/range {v0 .. v6}, Lcom/example/bleconnectse/SyntheticTile;-><init>(III[BJ)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/example/bleconnectse/SyntheticTile;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/example/bleconnectse/SyntheticTile;

    iget v1, p0, Lcom/example/bleconnectse/SyntheticTile;->tileId:I

    iget v3, p1, Lcom/example/bleconnectse/SyntheticTile;->tileId:I

    if-eq v1, v3, :cond_13

    return v2

    :cond_13
    iget v1, p0, Lcom/example/bleconnectse/SyntheticTile;->tileX:I

    iget v3, p1, Lcom/example/bleconnectse/SyntheticTile;->tileX:I

    if-eq v1, v3, :cond_1a

    return v2

    :cond_1a
    iget v1, p0, Lcom/example/bleconnectse/SyntheticTile;->tileY:I

    iget v3, p1, Lcom/example/bleconnectse/SyntheticTile;->tileY:I

    if-eq v1, v3, :cond_21

    return v2

    :cond_21
    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticTile;->bytes:[B

    iget-object v3, p1, Lcom/example/bleconnectse/SyntheticTile;->bytes:[B

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2c

    return v2

    :cond_2c
    iget-wide v3, p0, Lcom/example/bleconnectse/SyntheticTile;->crc32:J

    iget-wide p0, p1, Lcom/example/bleconnectse/SyntheticTile;->crc32:J

    cmp-long p0, v3, p0

    if-eqz p0, :cond_35

    return v2

    :cond_35
    return v0
.end method

.method public final getBytes()[B
    .registers 1

    .line 12
    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticTile;->bytes:[B

    return-object p0
.end method

.method public final getCrc32()J
    .registers 3

    .line 13
    iget-wide v0, p0, Lcom/example/bleconnectse/SyntheticTile;->crc32:J

    return-wide v0
.end method

.method public final getTileId()I
    .registers 1

    .line 9
    iget p0, p0, Lcom/example/bleconnectse/SyntheticTile;->tileId:I

    return p0
.end method

.method public final getTileX()I
    .registers 1

    .line 10
    iget p0, p0, Lcom/example/bleconnectse/SyntheticTile;->tileX:I

    return p0
.end method

.method public final getTileY()I
    .registers 1

    .line 11
    iget p0, p0, Lcom/example/bleconnectse/SyntheticTile;->tileY:I

    return p0
.end method

.method public hashCode()I
    .registers 4

    iget v0, p0, Lcom/example/bleconnectse/SyntheticTile;->tileId:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/SyntheticTile;->tileX:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/SyntheticTile;->tileY:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticTile;->bytes:[B

    invoke-static {v1}, Ljava/util/Arrays;->hashCode([B)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lcom/example/bleconnectse/SyntheticTile;->crc32:J

    invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 8

    iget v0, p0, Lcom/example/bleconnectse/SyntheticTile;->tileId:I

    iget v1, p0, Lcom/example/bleconnectse/SyntheticTile;->tileX:I

    iget v2, p0, Lcom/example/bleconnectse/SyntheticTile;->tileY:I

    iget-object v3, p0, Lcom/example/bleconnectse/SyntheticTile;->bytes:[B

    invoke-static {v3}, Ljava/util/Arrays;->toString([B)Ljava/lang/String;

    move-result-object v3

    iget-wide v4, p0, Lcom/example/bleconnectse/SyntheticTile;->crc32:J

    new-instance p0, Ljava/lang/StringBuilder;

    const-string v6, "SyntheticTile(tileId="

    invoke-direct {p0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ", tileX="

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ", tileY="

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ", bytes="

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ", crc32="

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ")"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
