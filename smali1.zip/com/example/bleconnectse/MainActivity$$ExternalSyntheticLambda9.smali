# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/MainActivity;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda9;->f$0:Lcom/example/bleconnectse/MainActivity;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 1

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda9;->f$0:Lcom/example/bleconnectse/MainActivity;

    invoke-static {p0}, Lcom/example/bleconnectse/MainActivity;->onCreate$lambda$55$lambda$54$lambda$51$lambda$40$lambda$39(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
