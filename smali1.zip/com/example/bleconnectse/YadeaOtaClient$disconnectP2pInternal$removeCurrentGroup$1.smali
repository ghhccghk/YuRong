# classes2.dex

.class public final Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;
.super Ljava/lang/Object;
.source "YadeaOtaClient.kt"

# interfaces
.implements Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal$removeCurrentGroup(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016J\u0010\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0006H\u0016¨\u0006\u0007"
    }
    d2 = {
        "com/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1",
        "Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;",
        "onSuccess",
        "",
        "onFailure",
        "reason",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $completed:Ljava/util/concurrent/atomic/AtomicBoolean;

.field final synthetic $generation:I

.field final synthetic $keepSelectedPeer:Z

.field final synthetic $onComplete:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic this$0:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method constructor <init>(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/atomic/AtomicBoolean;",
            "Lcom/example/bleconnectse/YadeaOtaClient;",
            "IZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$completed:Ljava/util/concurrent/atomic/AtomicBoolean;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$generation:I

    iput-boolean p4, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$keepSelectedPeer:Z

    iput-object p5, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$onComplete:Lkotlin/jvm/functions/Function0;

    .line 1786
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onFailure(I)V
    .registers 8

    .line 1792
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$completed:Ljava/util/concurrent/atomic/AtomicBoolean;

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget v2, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$generation:I

    iget-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$keepSelectedPeer:Z

    iget-object v4, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$onComplete:Lkotlin/jvm/functions/Function0;

    new-instance p0, Ljava/lang/StringBuilder;

    const-string/jumbo v5, "无活动 Group，reason="

    invoke-direct {p0, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static/range {v0 .. v5}, Lcom/example/bleconnectse/YadeaOtaClient;->access$disconnectP2pInternal$finishCleanup(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;Ljava/lang/String;)V

    return-void
.end method

.method public onSuccess()V
    .registers 7

    .line 1788
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$completed:Ljava/util/concurrent/atomic/AtomicBoolean;

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget v2, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$generation:I

    iget-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$keepSelectedPeer:Z

    iget-object v4, p0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;->$onComplete:Lkotlin/jvm/functions/Function0;

    const-string v5, "Group removed"

    invoke-static/range {v0 .. v5}, Lcom/example/bleconnectse/YadeaOtaClient;->access$disconnectP2pInternal$finishCleanup(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;Ljava/lang/String;)V

    return-void
.end method
