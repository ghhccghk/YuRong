# classes2.dex

.class public final Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$lambda$42$lambda$41$$inlined$onDispose$1;
.super Ljava/lang/Object;
.source "Effects.kt"

# interfaces
.implements Landroidx/compose/runtime/DisposableEffectResult;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/MainActivityKt;->AmapNavigationScreen(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/NavigationTransport;Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEffects.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Effects.kt\nandroidx/compose/runtime/DisposableEffectScope$onDispose$1\n+ 2 MainActivity.kt\ncom/example/bleconnectse/MainActivityKt\n*L\n1#1,603:1\n853#2,4:604\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016¨\u0006\u0004¸\u0006\u0000"
    }
    d2 = {
        "androidx/compose/runtime/DisposableEffectScope$onDispose$1",
        "Landroidx/compose/runtime/DisposableEffectResult;",
        "dispose",
        "",
        "runtime"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $lifecycleOwner$inlined:Landroidx/lifecycle/LifecycleOwner;

.field final synthetic $navigationViewHolder$inlined:[Lcom/example/bleconnectse/AmapNavigationView;

.field final synthetic $observer$inlined:Landroidx/lifecycle/LifecycleEventObserver;

.field final synthetic $onViewDisposed$inlined:Lkotlin/jvm/functions/Function1;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/LifecycleEventObserver;[Lcom/example/bleconnectse/AmapNavigationView;Lkotlin/jvm/functions/Function1;)V
    .registers 5

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$lambda$42$lambda$41$$inlined$onDispose$1;->$lifecycleOwner$inlined:Landroidx/lifecycle/LifecycleOwner;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$lambda$42$lambda$41$$inlined$onDispose$1;->$observer$inlined:Landroidx/lifecycle/LifecycleEventObserver;

    iput-object p3, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$lambda$42$lambda$41$$inlined$onDispose$1;->$navigationViewHolder$inlined:[Lcom/example/bleconnectse/AmapNavigationView;

    iput-object p4, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$lambda$42$lambda$41$$inlined$onDispose$1;->$onViewDisposed$inlined:Lkotlin/jvm/functions/Function1;

    .line 66
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public dispose()V
    .registers 4

    .line 604
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$lambda$42$lambda$41$$inlined$onDispose$1;->$lifecycleOwner$inlined:Landroidx/lifecycle/LifecycleOwner;

    invoke-interface {v0}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/Lifecycle;

    move-result-object v0

    iget-object v1, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$lambda$42$lambda$41$$inlined$onDispose$1;->$observer$inlined:Landroidx/lifecycle/LifecycleEventObserver;

    check-cast v1, Landroidx/lifecycle/LifecycleObserver;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/Lifecycle;->removeObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 605
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$lambda$42$lambda$41$$inlined$onDispose$1;->$navigationViewHolder$inlined:[Lcom/example/bleconnectse/AmapNavigationView;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    if-eqz v0, :cond_19

    iget-object v2, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$lambda$42$lambda$41$$inlined$onDispose$1;->$onViewDisposed$inlined:Lkotlin/jvm/functions/Function1;

    invoke-interface {v2, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 606
    :cond_19
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$lambda$42$lambda$41$$inlined$onDispose$1;->$navigationViewHolder$inlined:[Lcom/example/bleconnectse/AmapNavigationView;

    const/4 v0, 0x0

    aput-object v0, p0, v1

    return-void
.end method
