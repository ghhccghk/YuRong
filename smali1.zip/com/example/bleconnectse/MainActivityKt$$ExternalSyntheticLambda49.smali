# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda49;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Z


# direct methods
.method public synthetic constructor <init>(Z)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda49;->f$0:Z

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    iget-boolean p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda49;->f$0:Z

    check-cast p1, Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0, p1}, Lcom/example/bleconnectse/MainActivityKt;->AmapNavigationScreen$lambda$38$lambda$13$lambda$12(ZLcom/example/bleconnectse/AmapNavigationView;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
