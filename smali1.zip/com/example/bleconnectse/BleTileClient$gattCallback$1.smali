# classes2.dex

.class public final Lcom/example/bleconnectse/BleTileClient$gattCallback$1;
.super Landroid/bluetooth/BluetoothGattCallback;
.source "BleTileClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/BleTileClient;-><init>(Landroid/content/Context;Lcom/example/bleconnectse/SyntheticTileRepository;Lkotlin/jvm/functions/Function1;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00005\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J \u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0007H\u0016J \u0010\t\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\u0018\u0010\u000b\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J \u0010\f\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J \u0010\u000f\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\u0018\u0010\u0012\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u0011H\u0017J \u0010\u0012\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0013\u001a\u00020\u0014H\u0016¨\u0006\u0015"
    }
    d2 = {
        "com/example/bleconnectse/BleTileClient$gattCallback$1",
        "Landroid/bluetooth/BluetoothGattCallback;",
        "onConnectionStateChange",
        "",
        "gatt",
        "Landroid/bluetooth/BluetoothGatt;",
        "statusCode",
        "",
        "newState",
        "onMtuChanged",
        "mtu",
        "onServicesDiscovered",
        "onDescriptorWrite",
        "descriptor",
        "Landroid/bluetooth/BluetoothGattDescriptor;",
        "onCharacteristicWrite",
        "characteristic",
        "Landroid/bluetooth/BluetoothGattCharacteristic;",
        "onCharacteristicChanged",
        "value",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/BleTileClient;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/BleTileClient;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    .line 189
    invoke-direct {p0}, Landroid/bluetooth/BluetoothGattCallback;-><init>()V

    return-void
.end method

.method static final onCharacteristicChanged$lambda$5(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGattCharacteristic;[B)V
    .registers 4

    .line 241
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothGattCharacteristic;->getUuid()Ljava/util/UUID;

    move-result-object p1

    const-string v0, "getUuid(...)"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1, p2}, Lcom/example/bleconnectse/BleTileClient;->access$handleNotification(Lcom/example/bleconnectse/BleTileClient;Ljava/util/UUID;[B)V

    return-void
.end method

.method static final onCharacteristicChanged$lambda$6(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGattCharacteristic;[B)V
    .registers 4

    .line 249
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothGattCharacteristic;->getUuid()Ljava/util/UUID;

    move-result-object p1

    const-string v0, "getUuid(...)"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, [B

    invoke-static {p0, p1, p2}, Lcom/example/bleconnectse/BleTileClient;->access$handleNotification(Lcom/example/bleconnectse/BleTileClient;Ljava/util/UUID;[B)V

    return-void
.end method

.method static final onCharacteristicWrite$lambda$4(Landroid/bluetooth/BluetoothGattCharacteristic;Lcom/example/bleconnectse/BleTileClient;I)V
    .registers 4

    .line 228
    invoke-virtual {p0}, Landroid/bluetooth/BluetoothGattCharacteristic;->getUuid()Ljava/util/UUID;

    move-result-object p0

    .line 229
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->Companion:Lcom/example/bleconnectse/BleTileClient$Companion;

    invoke-virtual {v0}, Lcom/example/bleconnectse/BleTileClient$Companion;->getCONTROL_UUID()Ljava/util/UUID;

    move-result-object v0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_14

    invoke-static {p1, p2}, Lcom/example/bleconnectse/BleTileClient;->access$handleControlWritten(Lcom/example/bleconnectse/BleTileClient;I)V

    return-void

    .line 230
    :cond_14
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->Companion:Lcom/example/bleconnectse/BleTileClient$Companion;

    invoke-virtual {v0}, Lcom/example/bleconnectse/BleTileClient$Companion;->getDATA_UUID()Ljava/util/UUID;

    move-result-object v0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_23

    invoke-static {p1, p2}, Lcom/example/bleconnectse/BleTileClient;->access$handleDataWritten(Lcom/example/bleconnectse/BleTileClient;I)V

    :cond_23
    return-void
.end method

.method static final onConnectionStateChange$lambda$0(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;II)V
    .registers 4

    .line 191
    invoke-static {p0, p1, p2, p3}, Lcom/example/bleconnectse/BleTileClient;->access$handleConnectionState(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;II)V

    return-void
.end method

.method static final onDescriptorWrite$lambda$3(ILcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;)V
    .registers 4

    if-eqz p0, :cond_27

    .line 213
    new-instance p2, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "订阅仪表状态失败："

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string/jumbo p2, "；继续发送瓦片，但无仪表ACK"

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p1, p0}, Lcom/example/bleconnectse/BleTileClient;->access$logStatus(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V

    .line 214
    invoke-static {p1}, Lcom/example/bleconnectse/BleTileClient;->access$getDescriptorQueue$p(Lcom/example/bleconnectse/BleTileClient;)Ljava/util/ArrayDeque;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/ArrayDeque;->clear()V

    .line 215
    invoke-static {p1}, Lcom/example/bleconnectse/BleTileClient;->access$finishTransportReady(Lcom/example/bleconnectse/BleTileClient;)V

    return-void

    .line 217
    :cond_27
    invoke-static {p1, p2}, Lcom/example/bleconnectse/BleTileClient;->access$writeNextDescriptor(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;)V

    return-void
.end method

.method static final onMtuChanged$lambda$1(Lcom/example/bleconnectse/BleTileClient;IILandroid/bluetooth/BluetoothGatt;)V
    .registers 6

    if-nez p1, :cond_3

    goto :goto_5

    :cond_3
    const/16 p2, 0x17

    .line 196
    :goto_5
    invoke-static {p0, p2}, Lcom/example/bleconnectse/BleTileClient;->access$setNegotiatedMtu(Lcom/example/bleconnectse/BleTileClient;I)V

    .line 197
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getNegotiatedMtu()I

    move-result p2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "BLE MTU="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string/jumbo v0, "，status="

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->access$logStatus(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V

    .line 198
    invoke-static {p0, p3}, Lcom/example/bleconnectse/BleTileClient;->access$discoverServicesOnce(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;)V

    return-void
.end method

.method static final onServicesDiscovered$lambda$2(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;I)V
    .registers 3

    .line 203
    invoke-static {p0, p1, p2}, Lcom/example/bleconnectse/BleTileClient;->access$handleServicesDiscovered(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;I)V

    return-void
.end method


# virtual methods
.method public onCharacteristicChanged(Landroid/bluetooth/BluetoothGatt;Landroid/bluetooth/BluetoothGattCharacteristic;)V
    .registers 5
    .annotation runtime Lkotlin/Deprecated;
        message = "Used on Android 12 and lower"
    .end annotation

    const-string v0, "gatt"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "characteristic"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 240
    invoke-virtual {p2}, Landroid/bluetooth/BluetoothGattCharacteristic;->getValue()[B

    move-result-object p1

    if-eqz p1, :cond_29

    invoke-virtual {p1}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [B

    if-nez p1, :cond_19

    goto :goto_29

    .line 241
    :cond_19
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object v0

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    new-instance v1, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0, p2, p1}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda4;-><init>(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGattCharacteristic;[B)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_29
    :goto_29
    return-void
.end method

.method public onCharacteristicChanged(Landroid/bluetooth/BluetoothGatt;Landroid/bluetooth/BluetoothGattCharacteristic;[B)V
    .registers 5

    const-string v0, "gatt"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "characteristic"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string/jumbo p1, "value"

    invoke-static {p3, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 249
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {p1}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object p1

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    new-instance v0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda6;

    invoke-direct {v0, p0, p2, p3}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda6;-><init>(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGattCharacteristic;[B)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onCharacteristicWrite(Landroid/bluetooth/BluetoothGatt;Landroid/bluetooth/BluetoothGattCharacteristic;I)V
    .registers 5

    const-string v0, "gatt"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "characteristic"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 227
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {p1}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object p1

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    new-instance v0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda1;

    invoke-direct {v0, p2, p0, p3}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda1;-><init>(Landroid/bluetooth/BluetoothGattCharacteristic;Lcom/example/bleconnectse/BleTileClient;I)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onConnectionStateChange(Landroid/bluetooth/BluetoothGatt;II)V
    .registers 6

    const-string v0, "gatt"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 191
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object v0

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    new-instance v1, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;-><init>(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;II)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onDescriptorWrite(Landroid/bluetooth/BluetoothGatt;Landroid/bluetooth/BluetoothGattDescriptor;I)V
    .registers 5

    const-string v0, "gatt"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "descriptor"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 211
    iget-object p2, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {p2}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object p2

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    new-instance v0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda0;

    invoke-direct {v0, p3, p0, p1}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda0;-><init>(ILcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;)V

    invoke-virtual {p2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onMtuChanged(Landroid/bluetooth/BluetoothGatt;II)V
    .registers 6

    const-string v0, "gatt"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 195
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object v0

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    new-instance v1, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p3, p2, p1}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;-><init>(Lcom/example/bleconnectse/BleTileClient;IILandroid/bluetooth/BluetoothGatt;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onServicesDiscovered(Landroid/bluetooth/BluetoothGatt;I)V
    .registers 5

    const-string v0, "gatt"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 203
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object v0

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    new-instance v1, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0, p1, p2}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda5;-><init>(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
