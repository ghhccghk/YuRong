# classes2.dex

.class final Lcom/example/bleconnectse/NavResponse;
.super Ljava/lang/Object;
.source "YadeaOtaClient.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0012\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0015"
    }
    d2 = {
        "Lcom/example/bleconnectse/NavResponse;",
        "",
        "cmd",
        "",
        "data",
        "",
        "<init>",
        "(I[B)V",
        "getCmd",
        "()I",
        "getData",
        "()[B",
        "component1",
        "component2",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "toString",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final cmd:I

.field private final data:[B


# direct methods
.method public constructor <init>(I[B)V
    .registers 4

    const-string v0, "data"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2225
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2226
    iput p1, p0, Lcom/example/bleconnectse/NavResponse;->cmd:I

    .line 2227
    iput-object p2, p0, Lcom/example/bleconnectse/NavResponse;->data:[B

    return-void
.end method

.method public static synthetic copy$default(Lcom/example/bleconnectse/NavResponse;I[BILjava/lang/Object;)Lcom/example/bleconnectse/NavResponse;
    .registers 5

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_6

    iget p1, p0, Lcom/example/bleconnectse/NavResponse;->cmd:I

    :cond_6
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_c

    iget-object p2, p0, Lcom/example/bleconnectse/NavResponse;->data:[B

    :cond_c
    invoke-virtual {p0, p1, p2}, Lcom/example/bleconnectse/NavResponse;->copy(I[B)Lcom/example/bleconnectse/NavResponse;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/NavResponse;->cmd:I

    return p0
.end method

.method public final component2()[B
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/NavResponse;->data:[B

    return-object p0
.end method

.method public final copy(I[B)Lcom/example/bleconnectse/NavResponse;
    .registers 3

    const-string p0, "data"

    invoke-static {p2, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p0, Lcom/example/bleconnectse/NavResponse;

    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/NavResponse;-><init>(I[B)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/example/bleconnectse/NavResponse;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/example/bleconnectse/NavResponse;

    iget v1, p0, Lcom/example/bleconnectse/NavResponse;->cmd:I

    iget v3, p1, Lcom/example/bleconnectse/NavResponse;->cmd:I

    if-eq v1, v3, :cond_13

    return v2

    :cond_13
    iget-object p0, p0, Lcom/example/bleconnectse/NavResponse;->data:[B

    iget-object p1, p1, Lcom/example/bleconnectse/NavResponse;->data:[B

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1e

    return v2

    :cond_1e
    return v0
.end method

.method public final getCmd()I
    .registers 1

    .line 2226
    iget p0, p0, Lcom/example/bleconnectse/NavResponse;->cmd:I

    return p0
.end method

.method public final getData()[B
    .registers 1

    .line 2227
    iget-object p0, p0, Lcom/example/bleconnectse/NavResponse;->data:[B

    return-object p0
.end method

.method public hashCode()I
    .registers 2

    iget v0, p0, Lcom/example/bleconnectse/NavResponse;->cmd:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lcom/example/bleconnectse/NavResponse;->data:[B

    invoke-static {p0}, Ljava/util/Arrays;->hashCode([B)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    iget v0, p0, Lcom/example/bleconnectse/NavResponse;->cmd:I

    iget-object p0, p0, Lcom/example/bleconnectse/NavResponse;->data:[B

    invoke-static {p0}, Ljava/util/Arrays;->toString([B)Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "NavResponse(cmd="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", data="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ")"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
