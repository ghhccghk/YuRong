# classes2.dex

.class public final Lcom/example/bleconnectse/AmapNavigationView;
.super Landroid/widget/FrameLayout;
.source "AmapNavigationView.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;,
        Lcom/example/bleconnectse/AmapNavigationView$Guidance;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAmapNavigationView.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AmapNavigationView.kt\ncom/example/bleconnectse/AmapNavigationView\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,1189:1\n1#2:1190\n1#2:1204\n774#3:1191\n865#3,2:1192\n1617#3,9:1194\n1869#3:1203\n1870#3:1205\n1626#3:1206\n1669#3,8:1207\n*S KotlinDebug\n*F\n+ 1 AmapNavigationView.kt\ncom/example/bleconnectse/AmapNavigationView\n*L\n376#1:1204\n455#1:1191\n455#1:1192,2\n376#1:1194,9\n376#1:1203\n376#1:1205\n376#1:1206\n388#1:1207,8\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000Ñ\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\b\u0003\n\u0002\b\u0003\n\u0002\b&\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b *\u0003DGJ\b\u0007\u0018\u00002\u00020\u0001:\u0004\u0095\u0001\u0096\u0001B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005\u0012\u001a\b\u0002\u0010\b\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t\u0012\u0004\u0012\u00020\u00070\u0005¢\u0006\u0004\b\u000b\u0010\fJ\u000e\u0010L\u001a\u00020\u00072\u0006\u0010M\u001a\u00020\u0010J\u000e\u0010N\u001a\u00020\u00072\u0006\u0010O\u001a\u00020\u0006J\u000e\u0010P\u001a\u00020\u00072\u0006\u0010Q\u001a\u00020\nJ\u0016\u0010R\u001a\u00020\u00072\u0006\u0010O\u001a\u00020\u00062\u0006\u0010S\u001a\u00020\u0010J\u0006\u0010T\u001a\u00020\u0007J\u0006\u0010U\u001a\u00020\u0007J\u0006\u0010V\u001a\u00020\u0007J\u0006\u0010W\u001a\u00020\u0007J\u0006\u0010X\u001a\u00020\u0007J\b\u0010Y\u001a\u00020\u0007H\u0014J(\u0010Z\u001a\u00020\u00072\u0006\u0010[\u001a\u00020+2\u0006\u0010\\\u001a\u00020+2\u0006\u0010]\u001a\u00020+2\u0006\u0010^\u001a\u00020+H\u0014J \u0010_\u001a\u00020\u00072\u0006\u0010`\u001a\u00020#2\u0006\u0010a\u001a\u00020+2\u0006\u0010b\u001a\u00020\u0006H\u0002J\b\u0010c\u001a\u00020\u0007H\u0002J\u0010\u0010d\u001a\u00020\u00102\u0006\u0010e\u001a\u000202H\u0002J\u0010\u0010f\u001a\u00020\u00072\u0006\u0010e\u001a\u000202H\u0002J\n\u0010g\u001a\u0004\u0018\u00010-H\u0002J\n\u0010h\u001a\u0004\u0018\u00010/H\u0002J\u0018\u0010i\u001a\u00020\u00072\u0006\u0010e\u001a\u0002022\u0006\u0010j\u001a\u00020+H\u0002J\u0010\u0010k\u001a\u00020\u00072\u0006\u0010l\u001a\u000204H\u0002J\u0010\u0010m\u001a\u00020\u00072\u0006\u0010l\u001a\u000204H\u0002J(\u0010n\u001a\u00020\u00072\u0006\u0010o\u001a\u00020p2\u0006\u0010q\u001a\u00020r2\u0006\u0010[\u001a\u00020s2\u0006\u0010\\\u001a\u00020sH\u0002J(\u0010t\u001a\u00020\u00072\u0006\u0010o\u001a\u00020p2\u0006\u0010u\u001a\u00020r2\u0006\u0010[\u001a\u00020s2\u0006\u0010\\\u001a\u00020sH\u0002J(\u0010v\u001a\u00020w2\u0006\u0010x\u001a\u00020+2\u0006\u0010y\u001a\u00020+2\u0006\u0010z\u001a\u00020+2\u0006\u0010{\u001a\u00020+H\u0002J \u0010|\u001a\u00020\u00072\u0006\u0010o\u001a\u00020p2\u0006\u0010[\u001a\u00020s2\u0006\u0010\\\u001a\u00020sH\u0002J2\u0010}\u001a\u00020\u00072\u0006\u0010o\u001a\u00020p2\u0006\u0010~\u001a\u00020\u00062\u0006\u0010\u007f\u001a\u00020s2\u0007\u0010\u0080\u0001\u001a\u00020s2\u0007\u0010\u0081\u0001\u001a\u00020sH\u0002J+\u0010\u0082\u0001\u001a\u00020\u00072\u0006\u0010o\u001a\u00020p2\u0006\u0010\u007f\u001a\u00020s2\u0007\u0010\u0080\u0001\u001a\u00020s2\u0007\u0010\u0083\u0001\u001a\u00020sH\u0002J\u0012\u0010\u0084\u0001\u001a\u00020\u00072\u0007\u0010\u0085\u0001\u001a\u00020\u0006H\u0002J\u0018\u0010\u0086\u0001\u001a\u00020\u00072\r\u0010\u0087\u0001\u001a\b\u0012\u0004\u0012\u00020\n0\tH\u0002J\t\u0010\u0088\u0001\u001a\u00020\u0007H\u0002J\t\u0010\u0089\u0001\u001a\u00020\u0007H\u0002J\t\u0010\u008a\u0001\u001a\u00020\u0007H\u0002J\t\u0010\u008b\u0001\u001a\u00020\u0010H\u0002J\u0014\u0010\u008c\u0001\u001a\u0004\u0018\u00010#2\u0007\u0010\u008d\u0001\u001a\u00020\u0006H\u0002J\u0012\u0010\u008e\u0001\u001a\u00020\u00062\u0007\u0010\u008f\u0001\u001a\u00020+H\u0002J\u0012\u0010\u0090\u0001\u001a\u00020\u00062\u0007\u0010\u0091\u0001\u001a\u00020+H\u0002J\u0012\u0010\u0092\u0001\u001a\u00020\u00062\u0007\u0010\u0093\u0001\u001a\u00020+H\u0002J\u0012\u0010\u0094\u0001\u001a\u00020\u00062\u0007\u0010\u0093\u0001\u001a\u00020+H\u0002R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\b\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010 \u001a\u0004\u0018\u00010!X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\"\u001a\u0004\u0018\u00010#X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020%X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\'\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020+X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010,\u001a\u0004\u0018\u00010-X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010.\u001a\u0004\u0018\u00010/X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020+X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u000202X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00103\u001a\u0004\u0018\u000104X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u000202X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00106\u001a\u00020+X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00109\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010:\u001a\u00020+X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010<\u001a\u0004\u0018\u00010=X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010>\u001a\u0004\u0018\u00010?X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020+X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010A\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010B\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010C\u001a\u00020DX\u0082\u0004¢\u0006\u0004\n\u0002\u0010ER\u0010\u0010F\u001a\u00020GX\u0082\u0004¢\u0006\u0004\n\u0002\u0010HR\u0010\u0010I\u001a\u00020JX\u0082\u0004¢\u0006\u0004\n\u0002\u0010K¨\u0006\u0097\u0001"
    }
    d2 = {
        "Lcom/example/bleconnectse/AmapNavigationView;",
        "Landroid/widget/FrameLayout;",
        "context",
        "Landroid/content/Context;",
        "onStatusChanged",
        "Lkotlin/Function1;",
        "",
        "",
        "onSuggestionsChanged",
        "",
        "Lcom/example/bleconnectse/AmapDestinationSuggestion;",
        "<init>",
        "(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V",
        "mainHandler",
        "Landroid/os/Handler;",
        "debugCaptureProbeEnabled",
        "",
        "captureThread",
        "Landroid/os/HandlerThread;",
        "captureHandler",
        "paint",
        "Landroid/graphics/Paint;",
        "path",
        "Landroid/graphics/Path;",
        "viewOptions",
        "Lcom/amap/api/navi/AMapNaviViewOptions;",
        "naviView",
        "Lcom/amap/api/navi/AMapNaviView;",
        "map",
        "Lcom/amap/api/maps/AMap;",
        "navi",
        "Lcom/amap/api/navi/AMapNavi;",
        "destinationMarker",
        "Lcom/amap/api/maps/model/Marker;",
        "currentLocation",
        "Lcom/amap/api/maps/model/LatLng;",
        "guidance",
        "Lcom/example/bleconnectse/AmapNavigationView$Guidance;",
        "publishing",
        "closed",
        "hostResumed",
        "snapshotInFlight",
        "captureGeneration",
        "",
        "cachedMapSurface",
        "Landroid/view/SurfaceView;",
        "cachedMapTexture",
        "Landroid/view/TextureView;",
        "pixelCopyFailures",
        "pixelCopyRetryAfter",
        "",
        "captureMode",
        "Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;",
        "captureFpsWindowStartedAt",
        "capturedFramesInWindow",
        "captureProbeScheduled",
        "didCenterOnLocation",
        "routeStarting",
        "pendingNaviType",
        "pendingDestinationName",
        "geocodeSearch",
        "Lcom/amap/api/services/geocoder/GeocodeSearch;",
        "inputtips",
        "Lcom/amap/api/services/help/Inputtips;",
        "suggestionRequestSequence",
        "selectedSuggestion",
        "emulatorNavigationActive",
        "naviListener",
        "com/example/bleconnectse/AmapNavigationView$naviListener$1",
        "Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;",
        "geocodeListener",
        "com/example/bleconnectse/AmapNavigationView$geocodeListener$1",
        "Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;",
        "framePublisher",
        "com/example/bleconnectse/AmapNavigationView$framePublisher$1",
        "Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;",
        "setLocationPermissionGranted",
        "granted",
        "searchDestinationSuggestions",
        "destinationQuery",
        "selectDestinationSuggestion",
        "suggestion",
        "navigateTo",
        "simulateMovement",
        "startPublishing",
        "stopPublishing",
        "onHostResume",
        "onHostPause",
        "close",
        "onDetachedFromWindow",
        "onSizeChanged",
        "width",
        "height",
        "oldWidth",
        "oldHeight",
        "selectDestination",
        "destination",
        "naviType",
        "destinationName",
        "startGpsNavigation",
        "requestPixelCopyFrame",
        "frameStartedAt",
        "requestMapSnapshotFrame",
        "resolveMapSurfaceView",
        "resolveMapTextureView",
        "scheduleNextFrame",
        "generation",
        "recordEffectiveFrame",
        "mode",
        "updateCaptureMode",
        "drawSnapshotFrame",
        "canvas",
        "Landroid/graphics/Canvas;",
        "snapshot",
        "Landroid/graphics/Bitmap;",
        "",
        "drawCenterCrop",
        "bitmap",
        "centerCropRect",
        "Landroid/graphics/Rect;",
        "sourceWidth",
        "sourceHeight",
        "targetWidth",
        "targetHeight",
        "drawGuidance",
        "drawFittedText",
        "text",
        "x",
        "y",
        "maxWidth",
        "drawTurnArrow",
        "size",
        "updateStatus",
        "message",
        "publishSuggestions",
        "suggestions",
        "startRealLocationTracking",
        "pauseRealLocationTracking",
        "restoreRealLocationAfterEmulatorFailure",
        "hasLocationPermission",
        "parseCoordinate",
        "value",
        "routeErrorMessage",
        "errorCode",
        "formatDistance",
        "meters",
        "formatDuration",
        "seconds",
        "formatArrival",
        "CaptureMode",
        "Guidance",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private cachedMapSurface:Landroid/view/SurfaceView;

.field private cachedMapTexture:Landroid/view/TextureView;

.field private captureFpsWindowStartedAt:J

.field private volatile captureGeneration:I

.field private final captureHandler:Landroid/os/Handler;

.field private captureMode:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

.field private captureProbeScheduled:Z

.field private final captureThread:Landroid/os/HandlerThread;

.field private capturedFramesInWindow:I

.field private volatile closed:Z

.field private currentLocation:Lcom/amap/api/maps/model/LatLng;

.field private final debugCaptureProbeEnabled:Z

.field private destinationMarker:Lcom/amap/api/maps/model/Marker;

.field private didCenterOnLocation:Z

.field private emulatorNavigationActive:Z

.field private final framePublisher:Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;

.field private final geocodeListener:Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;

.field private geocodeSearch:Lcom/amap/api/services/geocoder/GeocodeSearch;

.field private volatile guidance:Lcom/example/bleconnectse/AmapNavigationView$Guidance;

.field private hostResumed:Z

.field private inputtips:Lcom/amap/api/services/help/Inputtips;

.field private final mainHandler:Landroid/os/Handler;

.field private final map:Lcom/amap/api/maps/AMap;

.field private navi:Lcom/amap/api/navi/AMapNavi;

.field private final naviListener:Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;

.field private final naviView:Lcom/amap/api/navi/AMapNaviView;

.field private final onStatusChanged:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final onSuggestionsChanged:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/AmapDestinationSuggestion;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final paint:Landroid/graphics/Paint;

.field private final path:Landroid/graphics/Path;

.field private pendingDestinationName:Ljava/lang/String;

.field private pendingNaviType:I

.field private pixelCopyFailures:I

.field private pixelCopyRetryAfter:J

.field private volatile publishing:Z

.field private routeStarting:Z

.field private selectedSuggestion:Lcom/example/bleconnectse/AmapDestinationSuggestion;

.field private snapshotInFlight:Z

.field private suggestionRequestSequence:I

.field private final viewOptions:Lcom/amap/api/navi/AMapNaviViewOptions;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V
    .registers 25
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/AmapDestinationSuggestion;",
            ">;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v0, p2

    move-object/from16 v3, p3

    const-string v4, ""

    const-string v5, "context"

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "onStatusChanged"

    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "onSuggestionsChanged"

    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 92
    invoke-direct/range {p0 .. p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 90
    iput-object v0, v1, Lcom/example/bleconnectse/AmapNavigationView;->onStatusChanged:Lkotlin/jvm/functions/Function1;

    .line 91
    iput-object v3, v1, Lcom/example/bleconnectse/AmapNavigationView;->onSuggestionsChanged:Lkotlin/jvm/functions/Function1;

    .line 112
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    invoke-direct {v0, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, v1, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    .line 114
    invoke-virtual {v2}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->flags:I

    and-int/lit8 v0, v0, 0x2

    const/4 v3, 0x1

    const/4 v5, 0x0

    .line 125
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    if-eqz v0, :cond_3d

    move v0, v3

    goto :goto_3e

    :cond_3d
    move v0, v5

    .line 114
    :goto_3e
    iput-boolean v0, v1, Lcom/example/bleconnectse/AmapNavigationView;->debugCaptureProbeEnabled:Z

    .line 115
    new-instance v0, Landroid/os/HandlerThread;

    const-string v7, "AmapMirrorCapture"

    invoke-direct {v0, v7}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    iput-object v0, v1, Lcom/example/bleconnectse/AmapNavigationView;->captureThread:Landroid/os/HandlerThread;

    .line 116
    new-instance v7, Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v7, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v7, v1, Lcom/example/bleconnectse/AmapNavigationView;->captureHandler:Landroid/os/Handler;

    .line 117
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v3}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, v1, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    .line 118
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, v1, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    .line 119
    new-instance v0, Lcom/amap/api/navi/AMapNaviViewOptions;

    invoke-direct {v0}, Lcom/amap/api/navi/AMapNaviViewOptions;-><init>()V

    .line 120
    invoke-virtual {v0, v5}, Lcom/amap/api/navi/AMapNaviViewOptions;->setLayoutVisible(Z)V

    .line 121
    invoke-virtual {v0, v3}, Lcom/amap/api/navi/AMapNaviViewOptions;->setAutoDrawRoute(Z)V

    .line 122
    invoke-virtual {v0, v3}, Lcom/amap/api/navi/AMapNaviViewOptions;->setAutoLockCar(Z)V

    .line 123
    invoke-virtual {v0, v3}, Lcom/amap/api/navi/AMapNaviViewOptions;->setTrafficLine(Z)V

    .line 124
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v0, v7}, Lcom/amap/api/navi/AMapNaviViewOptions;->setTrafficLayerEnabled(Ljava/lang/Boolean;)V

    .line 125
    invoke-virtual {v0, v6}, Lcom/amap/api/navi/AMapNaviViewOptions;->setCompassEnabled(Ljava/lang/Boolean;)V

    .line 126
    invoke-virtual {v0, v5}, Lcom/amap/api/navi/AMapNaviViewOptions;->setRouteListButtonShow(Z)V

    .line 127
    invoke-virtual {v0, v6}, Lcom/amap/api/navi/AMapNaviViewOptions;->setSettingMenuEnabled(Ljava/lang/Boolean;)V

    .line 128
    invoke-virtual {v0, v5}, Lcom/amap/api/navi/AMapNaviViewOptions;->setRealCrossDisplayShow(Z)V

    .line 129
    invoke-virtual {v0, v5}, Lcom/amap/api/navi/AMapNaviViewOptions;->setModeCrossDisplayShow(Z)V

    .line 130
    invoke-virtual {v0, v5}, Lcom/amap/api/navi/AMapNaviViewOptions;->setLaneInfoShow(Z)V

    .line 131
    invoke-virtual {v0, v3}, Lcom/amap/api/navi/AMapNaviViewOptions;->setNaviArrowVisible(Z)V

    .line 132
    invoke-virtual {v0, v5}, Lcom/amap/api/navi/AMapNaviViewOptions;->setNaviMode(I)V

    const-wide/high16 v6, 0x3fe0000000000000L  # 0.5

    .line 133
    invoke-virtual {v0, v6, v7, v6, v7}, Lcom/amap/api/navi/AMapNaviViewOptions;->setPointToCenter(DD)V

    .line 134
    invoke-virtual {v0, v5}, Lcom/amap/api/navi/AMapNaviViewOptions;->setAutoChangeZoom(Z)V

    const/16 v6, 0xf

    .line 135
    invoke-virtual {v0, v6}, Lcom/amap/api/navi/AMapNaviViewOptions;->setZoom(I)V

    .line 119
    iput-object v0, v1, Lcom/example/bleconnectse/AmapNavigationView;->viewOptions:Lcom/amap/api/navi/AMapNaviViewOptions;

    .line 137
    new-instance v7, Lcom/amap/api/navi/AMapNaviView;

    invoke-direct {v7, v2, v0}, Lcom/amap/api/navi/AMapNaviView;-><init>(Landroid/content/Context;Lcom/amap/api/navi/AMapNaviViewOptions;)V

    iput-object v7, v1, Lcom/example/bleconnectse/AmapNavigationView;->naviView:Lcom/amap/api/navi/AMapNaviView;

    .line 143
    new-instance v8, Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    const/16 v19, 0x3ff

    const/16 v20, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    invoke-direct/range {v8 .. v20}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v8, v1, Lcom/example/bleconnectse/AmapNavigationView;->guidance:Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    .line 162
    iput v3, v1, Lcom/example/bleconnectse/AmapNavigationView;->pendingNaviType:I

    .line 163
    const-string/jumbo v0, "目的地"

    iput-object v0, v1, Lcom/example/bleconnectse/AmapNavigationView;->pendingDestinationName:Ljava/lang/String;

    .line 170
    new-instance v0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;-><init>(Lcom/example/bleconnectse/AmapNavigationView;)V

    iput-object v0, v1, Lcom/example/bleconnectse/AmapNavigationView;->naviListener:Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;

    .line 266
    new-instance v8, Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;

    invoke-direct {v8, v1}, Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;-><init>(Lcom/example/bleconnectse/AmapNavigationView;)V

    iput-object v8, v1, Lcom/example/bleconnectse/AmapNavigationView;->geocodeListener:Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;

    .line 290
    new-instance v8, Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;

    invoke-direct {v8, v1}, Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;-><init>(Lcom/example/bleconnectse/AmapNavigationView;)V

    iput-object v8, v1, Lcom/example/bleconnectse/AmapNavigationView;->framePublisher:Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;

    .line 302
    move-object v8, v7

    check-cast v8, Landroid/view/View;

    .line 303
    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v10, -0x1

    invoke-direct {v9, v10, v10}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    check-cast v9, Landroid/view/ViewGroup$LayoutParams;

    .line 301
    invoke-virtual {v1, v8, v9}, Lcom/example/bleconnectse/AmapNavigationView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v8, 0x0

    .line 305
    invoke-virtual {v7, v8}, Lcom/amap/api/navi/AMapNaviView;->onCreate(Landroid/os/Bundle;)V

    .line 306
    invoke-virtual {v7, v6}, Lcom/amap/api/navi/AMapNaviView;->setLockZoom(I)V

    .line 307
    invoke-virtual {v7}, Lcom/amap/api/navi/AMapNaviView;->getMap()Lcom/amap/api/maps/AMap;

    move-result-object v6

    const-string v8, "getMap(...)"

    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v6, v1, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    const/4 v8, 0x4

    .line 308
    invoke-virtual {v6, v8}, Lcom/amap/api/maps/AMap;->setMapType(I)V

    .line 309
    invoke-virtual {v6, v3}, Lcom/amap/api/maps/AMap;->setTrafficEnabled(Z)V

    .line 310
    new-instance v8, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda3;

    invoke-direct {v8, v1}, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda3;-><init>(Lcom/example/bleconnectse/AmapNavigationView;)V

    invoke-virtual {v6, v8}, Lcom/amap/api/maps/AMap;->setOnMapLongClickListener(Lcom/amap/api/maps/AMap$OnMapLongClickListener;)V

    .line 313
    invoke-virtual {v7, v3}, Lcom/amap/api/navi/AMapNaviView;->setTrafficLine(Z)V

    .line 314
    invoke-virtual {v7, v3}, Lcom/amap/api/navi/AMapNaviView;->setShowTrafficLightView(Z)V

    .line 317
    :try_start_114
    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Lcom/amap/api/navi/AMapNavi;->getInstance(Landroid/content/Context;)Lcom/amap/api/navi/AMapNavi;

    move-result-object v3

    .line 318
    check-cast v0, Lcom/amap/api/navi/AMapNaviListener;

    invoke-virtual {v3, v0}, Lcom/amap/api/navi/AMapNavi;->addAMapNaviListener(Lcom/amap/api/navi/AMapNaviListener;)V

    .line 319
    invoke-virtual {v3, v5}, Lcom/amap/api/navi/AMapNavi;->setUseInnerVoice(Z)V

    .line 317
    iput-object v3, v1, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;
    :try_end_126
    .catchall {:try_start_114 .. :try_end_126} :catchall_127

    goto :goto_142

    :catchall_127
    move-exception v0

    .line 322
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_12f

    move-object v0, v4

    :cond_12f
    new-instance v3, Ljava/lang/StringBuilder;

    const-string/jumbo v5, "高德导航初始化异常："

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    .line 325
    :goto_142
    :try_start_142
    new-instance v0, Lcom/amap/api/services/geocoder/GeocodeSearch;

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v0, v2}, Lcom/amap/api/services/geocoder/GeocodeSearch;-><init>(Landroid/content/Context;)V

    .line 326
    iget-object v2, v1, Lcom/example/bleconnectse/AmapNavigationView;->geocodeListener:Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;

    check-cast v2, Lcom/amap/api/services/geocoder/GeocodeSearch$OnGeocodeSearchListener;

    invoke-virtual {v0, v2}, Lcom/amap/api/services/geocoder/GeocodeSearch;->setOnGeocodeSearchListener(Lcom/amap/api/services/geocoder/GeocodeSearch$OnGeocodeSearchListener;)V

    .line 325
    iput-object v0, v1, Lcom/example/bleconnectse/AmapNavigationView;->geocodeSearch:Lcom/amap/api/services/geocoder/GeocodeSearch;
    :try_end_154
    .catchall {:try_start_142 .. :try_end_154} :catchall_155

    goto :goto_171

    :catchall_155
    move-exception v0

    .line 329
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_15d

    goto :goto_15e

    :cond_15d
    move-object v4, v0

    :goto_15e
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "高德终点搜索初始化异常："

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    .line 331
    :goto_171
    invoke-virtual {v1}, Lcom/example/bleconnectse/AmapNavigationView;->onHostResume()V

    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 6

    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_9

    .line 91
    new-instance p3, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda0;

    invoke-direct {p3}, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda0;-><init>()V

    .line 88
    :cond_9
    invoke-direct {p0, p1, p2, p3}, Lcom/example/bleconnectse/AmapNavigationView;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V

    return-void
.end method

.method static final _init_$lambda$0(Ljava/util/List;)Lkotlin/Unit;
    .registers 2

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final _init_$lambda$3(Lcom/example/bleconnectse/AmapNavigationView;Lcom/amap/api/maps/model/LatLng;)V
    .registers 4

    .line 311
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/4 v0, 0x1

    const-string/jumbo v1, "地图选点"

    invoke-direct {p0, p1, v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->selectDestination(Lcom/amap/api/maps/model/LatLng;ILjava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$formatDistance(Lcom/example/bleconnectse/AmapNavigationView;I)Ljava/lang/String;
    .registers 2

    .line 88
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->formatDistance(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$getClosed$p(Lcom/example/bleconnectse/AmapNavigationView;)Z
    .registers 1

    .line 88
    iget-boolean p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    return p0
.end method

.method public static final synthetic access$getCurrentLocation$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/amap/api/maps/model/LatLng;
    .registers 1

    .line 88
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->currentLocation:Lcom/amap/api/maps/model/LatLng;

    return-object p0
.end method

.method public static final synthetic access$getDidCenterOnLocation$p(Lcom/example/bleconnectse/AmapNavigationView;)Z
    .registers 1

    .line 88
    iget-boolean p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->didCenterOnLocation:Z

    return p0
.end method

.method public static final synthetic access$getEmulatorNavigationActive$p(Lcom/example/bleconnectse/AmapNavigationView;)Z
    .registers 1

    .line 88
    iget-boolean p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->emulatorNavigationActive:Z

    return p0
.end method

.method public static final synthetic access$getGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;
    .registers 1

    .line 88
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->guidance:Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    return-object p0
.end method

.method public static final synthetic access$getMap$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/amap/api/maps/AMap;
    .registers 1

    .line 88
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    return-object p0
.end method

.method public static final synthetic access$getNavi$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/amap/api/navi/AMapNavi;
    .registers 1

    .line 88
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    return-object p0
.end method

.method public static final synthetic access$getPendingDestinationName$p(Lcom/example/bleconnectse/AmapNavigationView;)Ljava/lang/String;
    .registers 1

    .line 88
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->pendingDestinationName:Ljava/lang/String;

    return-object p0
.end method

.method public static final synthetic access$getPendingNaviType$p(Lcom/example/bleconnectse/AmapNavigationView;)I
    .registers 1

    .line 88
    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->pendingNaviType:I

    return p0
.end method

.method public static final synthetic access$getPublishing$p(Lcom/example/bleconnectse/AmapNavigationView;)Z
    .registers 1

    .line 88
    iget-boolean p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->publishing:Z

    return p0
.end method

.method public static final synthetic access$requestMapSnapshotFrame(Lcom/example/bleconnectse/AmapNavigationView;J)V
    .registers 3

    .line 88
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/AmapNavigationView;->requestMapSnapshotFrame(J)V

    return-void
.end method

.method public static final synthetic access$requestMapSnapshotFrame$deliver(Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/example/bleconnectse/AmapNavigationView;IJLandroid/graphics/Bitmap;)V
    .registers 6

    .line 88
    invoke-static/range {p0 .. p5}, Lcom/example/bleconnectse/AmapNavigationView;->requestMapSnapshotFrame$deliver(Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/example/bleconnectse/AmapNavigationView;IJLandroid/graphics/Bitmap;)V

    return-void
.end method

.method public static final synthetic access$requestPixelCopyFrame(Lcom/example/bleconnectse/AmapNavigationView;J)Z
    .registers 3

    .line 88
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/AmapNavigationView;->requestPixelCopyFrame(J)Z

    move-result p0

    return p0
.end method

.method public static final synthetic access$restoreRealLocationAfterEmulatorFailure(Lcom/example/bleconnectse/AmapNavigationView;)V
    .registers 1

    .line 88
    invoke-direct {p0}, Lcom/example/bleconnectse/AmapNavigationView;->restoreRealLocationAfterEmulatorFailure()V

    return-void
.end method

.method public static final synthetic access$routeErrorMessage(Lcom/example/bleconnectse/AmapNavigationView;I)Ljava/lang/String;
    .registers 2

    .line 88
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->routeErrorMessage(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$selectDestination(Lcom/example/bleconnectse/AmapNavigationView;Lcom/amap/api/maps/model/LatLng;ILjava/lang/String;)V
    .registers 4

    .line 88
    invoke-direct {p0, p1, p2, p3}, Lcom/example/bleconnectse/AmapNavigationView;->selectDestination(Lcom/amap/api/maps/model/LatLng;ILjava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setCurrentLocation$p(Lcom/example/bleconnectse/AmapNavigationView;Lcom/amap/api/maps/model/LatLng;)V
    .registers 2

    .line 88
    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->currentLocation:Lcom/amap/api/maps/model/LatLng;

    return-void
.end method

.method public static final synthetic access$setDidCenterOnLocation$p(Lcom/example/bleconnectse/AmapNavigationView;Z)V
    .registers 2

    .line 88
    iput-boolean p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->didCenterOnLocation:Z

    return-void
.end method

.method public static final synthetic access$setGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;Lcom/example/bleconnectse/AmapNavigationView$Guidance;)V
    .registers 2

    .line 88
    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->guidance:Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    return-void
.end method

.method public static final synthetic access$setRouteStarting$p(Lcom/example/bleconnectse/AmapNavigationView;Z)V
    .registers 2

    .line 88
    iput-boolean p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->routeStarting:Z

    return-void
.end method

.method public static final synthetic access$startGpsNavigation(Lcom/example/bleconnectse/AmapNavigationView;)V
    .registers 1

    .line 88
    invoke-direct {p0}, Lcom/example/bleconnectse/AmapNavigationView;->startGpsNavigation()V

    return-void
.end method

.method public static final synthetic access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V
    .registers 2

    .line 88
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    return-void
.end method

.method private final centerCropRect(IIII)Landroid/graphics/Rect;
    .registers 7

    int-to-float p0, p3

    int-to-float p3, p4

    div-float/2addr p0, p3

    int-to-float p3, p1

    int-to-float p4, p2

    div-float v0, p3, p4

    cmpl-float v0, v0, p0

    const/4 v1, 0x0

    if-lez v0, :cond_1c

    mul-float/2addr p4, p0

    float-to-int p0, p4

    .line 916
    invoke-static {p0, p1}, Lkotlin/ranges/RangesKt;->coerceAtMost(II)I

    move-result p0

    sub-int/2addr p1, p0

    .line 917
    div-int/lit8 p1, p1, 0x2

    .line 918
    new-instance p3, Landroid/graphics/Rect;

    add-int/2addr p0, p1

    invoke-direct {p3, p1, v1, p0, p2}, Landroid/graphics/Rect;-><init>(IIII)V

    return-object p3

    :cond_1c
    div-float/2addr p3, p0

    float-to-int p0, p3

    .line 920
    invoke-static {p0, p2}, Lkotlin/ranges/RangesKt;->coerceAtMost(II)I

    move-result p0

    sub-int/2addr p2, p0

    .line 921
    div-int/lit8 p2, p2, 0x2

    .line 922
    new-instance p3, Landroid/graphics/Rect;

    add-int/2addr p0, p2

    invoke-direct {p3, v1, p2, p1, p0}, Landroid/graphics/Rect;-><init>(IIII)V

    return-object p3
.end method

.method private final drawCenterCrop(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;FF)V
    .registers 9

    .line 902
    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    float-to-int v2, p3

    float-to-int v3, p4

    invoke-direct {p0, v0, v1, v2, v3}, Lcom/example/bleconnectse/AmapNavigationView;->centerCropRect(IIII)Landroid/graphics/Rect;

    move-result-object v0

    .line 903
    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v2, 0xff

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 904
    new-instance v1, Landroid/graphics/RectF;

    const/4 v2, 0x0

    invoke-direct {v1, v2, v2, p3, p4}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, v0, v1, p0}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    return-void
.end method

.method private final drawFittedText(Landroid/graphics/Canvas;Ljava/lang/String;FFF)V
    .registers 10

    const/4 v0, 0x0

    cmpg-float v1, p5, v0

    if-lez v1, :cond_4a

    .line 1073
    move-object v1, p2

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-nez v1, :cond_f

    return-void

    .line 1074
    :cond_f
    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, p2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v1

    cmpg-float v1, v1, p5

    if-gtz v1, :cond_1a

    goto :goto_45

    .line 1078
    :cond_1a
    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const-string/jumbo v2, "…"

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v1

    sub-float/2addr p5, v1

    invoke-static {p5, v0}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result p5

    .line 1079
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v1, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p2, v1, p5, v3}, Landroid/graphics/Paint;->breakText(Ljava/lang/String;ZF[F)I

    move-result p5

    .line 1080
    invoke-static {p2, p5}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p2

    new-instance p5, Ljava/lang/StringBuilder;

    invoke-direct {p5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 1082
    :goto_45
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, p3, p4, p0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    :cond_4a
    return-void
.end method

.method private final drawGuidance(Landroid/graphics/Canvas;FF)V
    .registers 25

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 927
    iget-object v6, v0, Lcom/example/bleconnectse/AmapNavigationView;->guidance:Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    const/high16 v2, 0x44480000  # 800.0f

    div-float v2, p2, v2

    const/high16 v3, 0x43f00000  # 480.0f

    div-float v3, p3, v3

    .line 928
    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v7

    const/high16 v2, 0x41400000  # 12.0f

    mul-float v8, v7, v2

    const/high16 v2, 0x41600000  # 14.0f

    mul-float v9, v7, v2

    const/high16 v2, 0x42ac0000  # 86.0f

    mul-float/2addr v2, v7

    sub-float v10, p2, v8

    const v3, 0x3f051eb8  # 0.52f

    mul-float v3, v3, p2

    .line 932
    invoke-static {v10, v3}, Ljava/lang/Math;->min(FF)F

    move-result v3

    const/high16 v4, 0x42b80000  # 92.0f

    mul-float v11, v7, v4

    sub-float v12, v3, v11

    .line 936
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 937
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v5, 0x17

    const/16 v13, 0x22

    const/16 v14, 0xea

    const/16 v15, 0xf

    invoke-static {v14, v15, v5, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 939
    new-instance v4, Landroid/graphics/RectF;

    add-float v13, v8, v2

    invoke-direct {v4, v8, v8, v3, v13}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 942
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    .line 938
    invoke-virtual {v1, v4, v9, v9, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 945
    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getManeuverBitmap()Landroid/graphics/Bitmap;

    move-result-object v2

    const/high16 v4, 0x41b00000  # 22.0f

    if-eqz v2, :cond_7b

    .line 946
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v15

    if-nez v15, :cond_7b

    .line 950
    new-instance v15, Landroid/graphics/RectF;

    mul-float/2addr v4, v7

    const/high16 v16, 0x41c00000  # 24.0f

    mul-float v3, v7, v16

    const/high16 v17, 0x42940000  # 74.0f

    const/high16 v18, 0x42400000  # 48.0f

    mul-float v5, v7, v17

    const/high16 v17, 0x42980000  # 76.0f

    mul-float v14, v7, v17

    invoke-direct {v15, v4, v3, v5, v14}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 951
    iget-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v4, 0x0

    .line 947
    invoke-virtual {v1, v2, v4, v15, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    goto :goto_8a

    :cond_7b
    const/high16 v16, 0x41c00000  # 24.0f

    const/high16 v17, 0x42980000  # 76.0f

    const/high16 v18, 0x42400000  # 48.0f

    mul-float v5, v7, v18

    const/high16 v2, 0x42480000  # 50.0f

    mul-float/2addr v2, v7

    mul-float/2addr v4, v7

    .line 954
    invoke-direct {v0, v1, v5, v2, v4}, Lcom/example/bleconnectse/AmapNavigationView;->drawTurnArrow(Landroid/graphics/Canvas;FFF)V

    .line 957
    :goto_8a
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 958
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v14, 0x1

    invoke-virtual {v2, v14}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 959
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v15, -0x1

    invoke-virtual {v2, v15}, Landroid/graphics/Paint;->setColor(I)V

    .line 960
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    mul-float v3, v7, v16

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 961
    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getStepDistanceM()I

    move-result v2

    if-lez v2, :cond_c6

    .line 962
    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getStepDistanceM()I

    move-result v2

    invoke-direct {v0, v2}, Lcom/example/bleconnectse/AmapNavigationView;->formatDistance(I)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " 后"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_c9

    .line 964
    :cond_c6
    const-string/jumbo v2, "前方"

    :goto_c9
    const/high16 v4, 0x42a80000  # 84.0f

    mul-float/2addr v4, v7

    mul-float v5, v7, v18

    const/high16 v16, 0x42bc0000  # 94.0f

    mul-float v16, v16, v7

    sub-float v16, v12, v16

    move/from16 v20, v16

    move/from16 v16, v3

    move v3, v4

    move v4, v5

    move/from16 v5, v20

    .line 966
    invoke-direct/range {v0 .. v5}, Lcom/example/bleconnectse/AmapNavigationView;->drawFittedText(Landroid/graphics/Canvas;Ljava/lang/String;FFF)V

    .line 973
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/high16 v2, 0x41900000  # 18.0f

    mul-float/2addr v2, v7

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 976
    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getNextRoad()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_f6

    const-string/jumbo v1, "前方道路"

    :cond_f6
    move-object v2, v1

    check-cast v2, Ljava/lang/String;

    mul-float v4, v7, v17

    move-object/from16 v1, p1

    .line 974
    invoke-direct/range {v0 .. v5}, Lcom/example/bleconnectse/AmapNavigationView;->drawFittedText(Landroid/graphics/Canvas;Ljava/lang/String;FFF)V

    .line 981
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 983
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v4, 0xd2

    const/16 v5, 0xe8

    const/16 v3, 0x5c

    const/16 v14, 0xdc

    invoke-static {v3, v4, v14, v5}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 985
    new-instance v2, Landroid/graphics/RectF;

    add-float v4, v8, v9

    add-float v5, v12, v7

    sub-float/2addr v13, v9

    invoke-direct {v2, v12, v4, v5, v13}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 991
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    .line 984
    invoke-virtual {v1, v2, v4}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 993
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v15}, Landroid/graphics/Paint;->setColor(I)V

    .line 994
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 995
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v4, 0x1

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 996
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/high16 v4, 0x41f00000  # 30.0f

    mul-float/2addr v4, v7

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 998
    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getRemainingTrafficLights()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/high16 v4, 0x40000000  # 2.0f

    div-float/2addr v11, v4

    add-float/2addr v12, v11

    const/high16 v4, 0x42540000  # 53.0f

    mul-float/2addr v4, v7

    .line 1001
    iget-object v5, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    .line 997
    invoke-virtual {v1, v2, v12, v4, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1003
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 1004
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v8}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1005
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v4, 0xbe

    const/16 v5, 0xcb

    invoke-static {v4, v5, v14}, Landroid/graphics/Color;->rgb(III)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v2, 0x429a0000  # 77.0f

    mul-float/2addr v2, v7

    .line 1010
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    .line 1006
    const-string/jumbo v5, "沿途红绿灯"

    invoke-virtual {v1, v5, v12, v2, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    const/high16 v2, 0x42a40000  # 82.0f

    mul-float/2addr v2, v7

    sub-float v4, p3, v8

    sub-float v11, v4, v2

    const v5, 0x3f0ccccd  # 0.55f

    mul-float v12, p2, v5

    .line 1017
    iget-object v5, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v13, 0xeb

    const/16 v14, 0xff

    invoke-static {v13, v14, v14, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v13

    invoke-virtual {v5, v13}, Landroid/graphics/Paint;->setColor(I)V

    .line 1019
    new-instance v5, Landroid/graphics/RectF;

    invoke-direct {v5, v8, v11, v10, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1022
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    .line 1018
    invoke-virtual {v1, v5, v9, v9, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1024
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 1025
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v5, 0x1

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 1026
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v8, 0x14

    const/16 v13, 0x1c

    const/16 v14, 0x26

    invoke-static {v8, v13, v14}, Landroid/graphics/Color;->rgb(III)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 1027
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/high16 v5, 0x42080000  # 34.0f

    mul-float v15, v7, v5

    invoke-virtual {v4, v15}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1028
    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getSpeedKph()I

    move-result v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    const/high16 v5, 0x41e00000  # 28.0f

    mul-float/2addr v5, v7

    const/high16 v19, 0x422c0000  # 43.0f

    mul-float v19, v19, v7

    add-float v8, v11, v19

    iget-object v13, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v5, v8, v13}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1029
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v8, 0x0

    invoke-virtual {v4, v8}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 1030
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v4, v9}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1031
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v9, 0x67

    const/16 v13, 0x72

    invoke-static {v3, v9, v13}, Landroid/graphics/Color;->rgb(III)I

    move-result v8

    invoke-virtual {v4, v8}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v4, 0x42280000  # 42.0f

    mul-float/2addr v4, v7

    add-float v8, v11, v4

    .line 1032
    iget-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const-string v9, "km/h"

    invoke-virtual {v1, v9, v2, v8, v3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1033
    iget-object v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/high16 v3, 0x41500000  # 13.0f

    mul-float v8, v7, v3

    invoke-virtual {v2, v8}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1036
    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getModeLabel()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getCurrentRoad()Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {v3}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_215

    const-string/jumbo v3, "等待定位"

    :cond_215
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v9, " · "

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/high16 v3, 0x42860000  # 67.0f

    mul-float/2addr v3, v7

    add-float/2addr v3, v11

    sub-float v4, v12, v4

    move v13, v4

    move v4, v3

    move v3, v5

    move v5, v13

    const/4 v13, 0x0

    .line 1034
    invoke-direct/range {v0 .. v5}, Lcom/example/bleconnectse/AmapNavigationView;->drawFittedText(Landroid/graphics/Canvas;Ljava/lang/String;FFF)V

    .line 1042
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 1043
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 1044
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v2, 0x1c

    const/16 v3, 0x14

    invoke-static {v3, v2, v14}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 1045
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/high16 v2, 0x41a00000  # 20.0f

    mul-float/2addr v2, v7

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1048
    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getRemainDistanceM()I

    move-result v1

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->formatDistance(I)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "剩余 "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/high16 v1, 0x41800000  # 16.0f

    mul-float/2addr v1, v7

    sub-float v3, v10, v1

    add-float v4, v11, v15

    sub-float/2addr v10, v12

    sub-float v5, v10, v16

    move-object/from16 v1, p1

    .line 1046
    invoke-direct/range {v0 .. v5}, Lcom/example/bleconnectse/AmapNavigationView;->drawFittedText(Landroid/graphics/Canvas;Ljava/lang/String;FFF)V

    .line 1053
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v13}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 1054
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v8}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1055
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v2, 0x72

    const/16 v4, 0x67

    const/16 v8, 0x5c

    invoke-static {v8, v4, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 1058
    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getRemainTimeS()I

    move-result v1

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->formatDuration(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getRemainTimeS()I

    move-result v2

    invoke-direct {v0, v2}, Lcom/example/bleconnectse/AmapNavigationView;->formatArrival(I)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    const-string/jumbo v6, "约 "

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " 到达"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/high16 v1, 0x42780000  # 62.0f

    mul-float/2addr v7, v1

    add-float v4, v11, v7

    move-object/from16 v1, p1

    .line 1056
    invoke-direct/range {v0 .. v5}, Lcom/example/bleconnectse/AmapNavigationView;->drawFittedText(Landroid/graphics/Canvas;Ljava/lang/String;FFF)V

    .line 1063
    iget-object v0, v0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    return-void
.end method

.method private final drawSnapshotFrame(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;FF)V
    .registers 8

    const/16 v0, 0xe9

    const/16 v1, 0xee

    const/16 v2, 0xe2

    .line 896
    invoke-static {v2, v0, v1}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->drawColor(I)V

    .line 897
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/example/bleconnectse/AmapNavigationView;->drawCenterCrop(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;FF)V

    .line 898
    invoke-direct {p0, p1, p3, p4}, Lcom/example/bleconnectse/AmapNavigationView;->drawGuidance(Landroid/graphics/Canvas;FF)V

    return-void
.end method

.method private final drawTurnArrow(Landroid/graphics/Canvas;FFF)V
    .registers 11

    .line 1086
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    .line 1087
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    const v1, 0x3f333333  # 0.7f

    mul-float/2addr v1, p4

    sub-float v1, p2, v1

    invoke-virtual {v0, v1, p3}, Landroid/graphics/Path;->moveTo(FF)V

    .line 1088
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    const v1, 0x3eb33333  # 0.35f

    mul-float/2addr v1, p4

    add-float/2addr v1, p2

    const/high16 v2, 0x3f400000  # 0.75f

    mul-float/2addr v2, p4

    sub-float v3, p3, v2

    invoke-virtual {v0, v1, v3}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1089
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    const/high16 v3, 0x3e800000  # 0.25f

    mul-float/2addr v3, p4

    sub-float v4, p3, v3

    invoke-virtual {v0, v1, v4}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1090
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    const v5, 0x3f3851ec  # 0.72f

    mul-float/2addr p4, v5

    add-float/2addr p2, p4

    invoke-virtual {v0, p2, v4}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1091
    iget-object p4, p0, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    add-float/2addr v3, p3

    invoke-virtual {p4, p2, v3}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1092
    iget-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    invoke-virtual {p2, v1, v3}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1093
    iget-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    add-float/2addr p3, v2

    invoke-virtual {p2, v1, p3}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1094
    iget-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    invoke-virtual {p2}, Landroid/graphics/Path;->close()V

    .line 1095
    iget-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    sget-object p3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1096
    iget-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    const/16 p3, 0x89

    const/16 p4, 0xff

    const/16 v0, 0x3c

    invoke-static {v0, p3, p4}, Landroid/graphics/Color;->rgb(III)I

    move-result p3

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 1097
    iget-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView;->path:Landroid/graphics/Path;

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, p0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    return-void
.end method

.method private final formatArrival(I)Ljava/lang/String;
    .registers 9

    if-gtz p1, :cond_5

    .line 1184
    const-string p0, "--:--"

    return-object p0

    .line 1185
    :cond_5
    new-instance p0, Ljava/text/SimpleDateFormat;

    const-string v0, "HH:mm"

    sget-object v1, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    invoke-direct {p0, v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 1186
    new-instance v0, Ljava/util/Date;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    int-to-long v3, p1

    const-wide/16 v5, 0x3e8

    mul-long/2addr v3, v5

    add-long/2addr v1, v3

    invoke-direct {v0, v1, v2}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {p0, v0}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "format(...)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method private final formatDistance(I)Ljava/lang/String;
    .registers 3

    if-gtz p1, :cond_5

    .line 1171
    const-string p0, "--"

    return-object p0

    :cond_5
    const/16 p0, 0x3e8

    if-ge p1, p0, :cond_1e

    .line 1172
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string/jumbo p1, "米"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1e
    const/16 v0, 0x2710

    if-ge p1, v0, :cond_43

    .line 1173
    sget-object p0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object p0, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    int-to-float p1, p1

    const/high16 v0, 0x447a0000  # 1000.0f

    div-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const/4 v0, 0x1

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    const-string v0, "%.1f公里"

    invoke-static {p0, v0, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "format(...)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0

    .line 1174
    :cond_43
    div-int/2addr p1, p0

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string/jumbo p1, "公里"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private final formatDuration(I)Ljava/lang/String;
    .registers 3

    if-gtz p1, :cond_5

    .line 1178
    const-string p0, "--"

    return-object p0

    :cond_5
    const/4 p0, 0x1

    const/16 v0, 0x3c

    .line 1179
    div-int/2addr p1, v0

    invoke-static {p0, p1}, Ljava/lang/Math;->max(II)I

    move-result p0

    if-ge p0, v0, :cond_24

    .line 1180
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string/jumbo p1, "分钟"

    :goto_1b
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_24
    div-int/lit8 p1, p0, 0x3c

    rem-int/2addr p0, v0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v0, "小时"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string/jumbo p1, "分"

    goto :goto_1b
.end method

.method private final hasLocationPermission()Z
    .registers 3

    .line 1140
    invoke-virtual {p0}, Lcom/example/bleconnectse/AmapNavigationView;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "android.permission.ACCESS_FINE_LOCATION"

    invoke-static {v0, v1}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_1b

    .line 1142
    invoke-virtual {p0}, Lcom/example/bleconnectse/AmapNavigationView;->getContext()Landroid/content/Context;

    move-result-object p0

    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    if-nez p0, :cond_19

    goto :goto_1b

    :cond_19
    const/4 p0, 0x0

    return p0

    :cond_1b
    :goto_1b
    const/4 p0, 0x1

    return p0
.end method

.method static final onSizeChanged$lambda$17(Lcom/example/bleconnectse/AmapNavigationView;)V
    .registers 3

    .line 535
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->publishing:Z

    if-nez v0, :cond_1a

    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez v0, :cond_1a

    .line 536
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 537
    invoke-direct {p0, v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->requestPixelCopyFrame(J)Z

    move-result p0

    if-nez p0, :cond_1a

    .line 538
    const-string p0, "AmapMirrorCapture"

    const-string/jumbo v0, "未发现可用的高德 PixelCopy 渲染源"

    invoke-static {p0, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1a
    return-void
.end method

.method private final parseCoordinate(Ljava/lang/String;)Lcom/amap/api/maps/model/LatLng;
    .registers 8

    .line 1146
    new-instance p0, Lkotlin/text/Regex;

    .line 1147
    const-string v0, "^\\s*(-?\\d+(?:\\.\\d+)?)\\s*[,，]\\s*(-?\\d+(?:\\.\\d+)?)\\s*$"

    .line 1146
    invoke-direct {p0, v0}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    .line 1148
    check-cast p1, Ljava/lang/CharSequence;

    invoke-virtual {p0, p1}, Lkotlin/text/Regex;->matchEntire(Ljava/lang/CharSequence;)Lkotlin/text/MatchResult;

    move-result-object p0

    const/4 p1, 0x0

    if-nez p0, :cond_11

    return-object p1

    .line 1149
    :cond_11
    invoke-interface {p0}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v0

    const/4 v1, 0x1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Lkotlin/text/StringsKt;->toDoubleOrNull(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v0

    if-eqz v0, :cond_65

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    .line 1150
    invoke-interface {p0}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x2

    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-static {p0}, Lkotlin/text/StringsKt;->toDoubleOrNull(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object p0

    if-eqz p0, :cond_65

    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v2

    const-wide v4, -0x3fa9800000000000L  # -90.0

    cmpg-double p0, v4, v0

    if-gtz p0, :cond_65

    const-wide v4, 0x4056800000000000L  # 90.0

    cmpg-double p0, v0, v4

    if-gtz p0, :cond_65

    const-wide v4, -0x3f99800000000000L  # -180.0

    cmpg-double p0, v4, v2

    if-gtz p0, :cond_65

    const-wide v4, 0x4066800000000000L  # 180.0

    cmpg-double p0, v2, v4

    if-gtz p0, :cond_65

    .line 1152
    new-instance p0, Lcom/amap/api/maps/model/LatLng;

    invoke-direct {p0, v0, v1, v2, v3}, Lcom/amap/api/maps/model/LatLng;-><init>(DD)V

    return-object p0

    :cond_65
    return-object p1
.end method

.method private final pauseRealLocationTracking()V
    .registers 2

    .line 1129
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/amap/api/navi/AMapNavi;->stopGPS()Z

    .line 1130
    :cond_7
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    invoke-virtual {v0}, Lcom/amap/api/maps/AMap;->isMyLocationEnabled()Z

    move-result v0

    if-eqz v0, :cond_15

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/amap/api/maps/AMap;->setMyLocationEnabled(Z)V

    :cond_15
    return-void
.end method

.method private final publishSuggestions(Ljava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/AmapDestinationSuggestion;",
            ">;)V"
        }
    .end annotation

    .line 1109
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_14

    .line 1110
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->onSuggestionsChanged:Lkotlin/jvm/functions/Function1;

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1112
    :cond_14
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    new-instance v1, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0, p1}, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda7;-><init>(Lcom/example/bleconnectse/AmapNavigationView;Ljava/util/List;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static final publishSuggestions$lambda$33(Lcom/example/bleconnectse/AmapNavigationView;Ljava/util/List;)V
    .registers 2

    .line 1112
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->onSuggestionsChanged:Lkotlin/jvm/functions/Function1;

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private final declared-synchronized recordEffectiveFrame(Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;)V
    .registers 9

    monitor-enter p0

    .line 869
    :try_start_1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 870
    iget-wide v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureFpsWindowStartedAt:J

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-nez v2, :cond_f

    iput-wide v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureFpsWindowStartedAt:J

    .line 871
    :cond_f
    iget v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->capturedFramesInWindow:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->capturedFramesInWindow:I

    .line 872
    iget-wide v3, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureFpsWindowStartedAt:J
    :try_end_17
    .catchall {:try_start_1 .. :try_end_17} :catchall_5a

    sub-long v3, v0, v3

    const-wide/16 v5, 0x1388

    cmp-long v5, v3, v5

    if-gez v5, :cond_21

    .line 873
    monitor-exit p0

    return-void

    :cond_21
    int-to-float v2, v2

    const/high16 v5, 0x447a0000  # 1000.0f

    mul-float/2addr v2, v5

    const-wide/16 v5, 0x1

    .line 874
    :try_start_27
    invoke-static {v3, v4, v5, v6}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v3

    long-to-float v3, v3

    div-float/2addr v2, v3

    .line 876
    const-string v3, "AmapMirrorCapture"

    .line 877
    sget-object v4, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string/jumbo v5, "有效地图帧率=%.1f fps，取帧方式=%s"

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-virtual {p1}, Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;->getLabel()Ljava/lang/String;

    move-result-object p1

    filled-new-array {v2, p1}, [Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    invoke-static {p1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    invoke-static {v4, v5, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v2, "format(...)"

    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 875
    invoke-static {v3, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 879
    iput-wide v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureFpsWindowStartedAt:J

    const/4 p1, 0x0

    .line 880
    iput p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->capturedFramesInWindow:I
    :try_end_58
    .catchall {:try_start_27 .. :try_end_58} :catchall_5a

    .line 881
    monitor-exit p0

    return-void

    :catchall_5a
    move-exception p1

    :try_start_5b
    monitor-exit p0
    :try_end_5c
    .catchall {:try_start_5b .. :try_end_5c} :catchall_5a

    throw p1
.end method

.method private final requestMapSnapshotFrame(J)V
    .registers 11

    .line 751
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->snapshotInFlight:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    .line 752
    iput-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->snapshotInFlight:Z

    .line 753
    iget v3, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    .line 754
    new-instance v2, Lkotlin/jvm/internal/Ref$BooleanRef;

    invoke-direct {v2}, Lkotlin/jvm/internal/Ref$BooleanRef;-><init>()V

    .line 787
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    .line 788
    new-instance v1, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;

    move-wide v5, p1

    move v4, v3

    move-object v3, p0

    invoke-direct/range {v1 .. v6}, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;-><init>(Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/example/bleconnectse/AmapNavigationView;IJ)V

    check-cast v1, Lcom/amap/api/maps/AMap$OnMapScreenShotListener;

    .line 797
    iget-object p0, v3, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    .line 787
    invoke-virtual {v0, v1, p0}, Lcom/amap/api/maps/AMap;->getMapScreenShot(Lcom/amap/api/maps/AMap$OnMapScreenShotListener;Landroid/os/Handler;)V

    .line 799
    iget-object p0, v3, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    new-instance v1, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;

    move v7, v4

    move-object v4, v3

    move v3, v7

    invoke-direct/range {v1 .. v6}, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda8;-><init>(Lkotlin/jvm/internal/Ref$BooleanRef;ILcom/example/bleconnectse/AmapNavigationView;J)V

    const-wide/16 p1, 0x5dc

    invoke-virtual {p0, v1, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private static final requestMapSnapshotFrame$deliver(Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/example/bleconnectse/AmapNavigationView;IJLandroid/graphics/Bitmap;)V
    .registers 9

    .line 757
    iget-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_15

    if-eqz p5, :cond_70

    .line 758
    invoke-virtual {p5}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result p0

    if-nez p0, :cond_e

    goto :goto_f

    :cond_e
    move-object p5, v1

    :goto_f
    if-eqz p5, :cond_70

    invoke-virtual {p5}, Landroid/graphics/Bitmap;->recycle()V

    return-void

    :cond_15
    const/4 v0, 0x1

    .line 761
    iput-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    const/4 p0, 0x0

    .line 762
    iput-boolean p0, p1, Lcom/example/bleconnectse/AmapNavigationView;->snapshotInFlight:Z

    .line 763
    iget-boolean p0, p1, Lcom/example/bleconnectse/AmapNavigationView;->publishing:Z

    if-eqz p0, :cond_61

    iget-boolean p0, p1, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez p0, :cond_61

    iget p0, p1, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    if-eq p2, p0, :cond_28

    goto :goto_61

    :cond_28
    if-eqz p5, :cond_58

    .line 767
    invoke-virtual {p5}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result p0

    if-nez p0, :cond_58

    const/16 p0, 0x1e0

    .line 771
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/16 v1, 0x320

    .line 768
    invoke-static {v1, p0, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p0

    const-string v0, "createBitmap(...)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 774
    new-instance v0, Landroid/graphics/Canvas;

    invoke-direct {v0, p0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/high16 v1, 0x44480000  # 800.0f

    const/high16 v2, 0x43f00000  # 480.0f

    .line 773
    invoke-direct {p1, v0, p5, v1, v2}, Lcom/example/bleconnectse/AmapNavigationView;->drawSnapshotFrame(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;FF)V

    .line 779
    invoke-virtual {p5}, Landroid/graphics/Bitmap;->recycle()V

    .line 780
    sget-object p5, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {p5, p0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->submit(Landroid/graphics/Bitmap;)V

    .line 781
    sget-object p0, Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;->MapScreenshot:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/AmapNavigationView;->recordEffectiveFrame(Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;)V

    .line 783
    :cond_58
    sget-object p0, Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;->MapScreenshot:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/AmapNavigationView;->updateCaptureMode(Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;)V

    .line 784
    invoke-direct {p1, p3, p4, p2}, Lcom/example/bleconnectse/AmapNavigationView;->scheduleNextFrame(JI)V

    return-void

    :cond_61
    :goto_61
    if-eqz p5, :cond_70

    .line 764
    invoke-virtual {p5}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result p0

    if-nez p0, :cond_6a

    goto :goto_6b

    :cond_6a
    move-object p5, v1

    :goto_6b
    if-eqz p5, :cond_70

    invoke-virtual {p5}, Landroid/graphics/Bitmap;->recycle()V

    :cond_70
    return-void
.end method

.method static final requestMapSnapshotFrame$lambda$24(Lkotlin/jvm/internal/Ref$BooleanRef;ILcom/example/bleconnectse/AmapNavigationView;J)V
    .registers 13

    .line 801
    iget-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-nez v0, :cond_18

    iget v0, p2, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    if-ne p1, v0, :cond_18

    .line 802
    const-string v0, "AmapMirrorCapture"

    const-string/jumbo v1, "高德截图等待超时，重新请求"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x0

    move-object v2, p0

    move v4, p1

    move-object v3, p2

    move-wide v5, p3

    .line 803
    invoke-static/range {v2 .. v7}, Lcom/example/bleconnectse/AmapNavigationView;->requestMapSnapshotFrame$deliver(Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/example/bleconnectse/AmapNavigationView;IJLandroid/graphics/Bitmap;)V

    :cond_18
    return-void
.end method

.method private final requestPixelCopyFrame(J)Z
    .registers 20

    move-object/from16 v2, p0

    .line 637
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    const/4 v10, 0x0

    if-ge v0, v1, :cond_a

    return v10

    .line 638
    :cond_a
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v11

    .line 639
    iget-wide v0, v2, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyRetryAfter:J

    cmp-long v0, v11, v0

    if-gez v0, :cond_15

    return v10

    .line 640
    :cond_15
    invoke-direct {v2}, Lcom/example/bleconnectse/AmapNavigationView;->resolveMapTextureView()Landroid/view/TextureView;

    move-result-object v0

    const/4 v13, 0x1

    const/4 v14, 0x0

    if-eqz v0, :cond_3e

    .line 646
    invoke-virtual {v0}, Landroid/view/TextureView;->isAvailable()Z

    move-result v1

    if-ne v1, v13, :cond_3e

    invoke-virtual {v0}, Landroid/view/TextureView;->getSurfaceTexture()Landroid/graphics/SurfaceTexture;

    move-result-object v1

    if-eqz v1, :cond_3e

    .line 647
    new-instance v1, Landroid/view/Surface;

    invoke-virtual {v0}, Landroid/view/TextureView;->getSurfaceTexture()Landroid/graphics/SurfaceTexture;

    move-result-object v3

    invoke-direct {v1, v3}, Landroid/view/Surface;-><init>(Landroid/graphics/SurfaceTexture;)V

    .line 649
    invoke-virtual {v0}, Landroid/view/TextureView;->getWidth()I

    move-result v3

    .line 650
    invoke-virtual {v0}, Landroid/view/TextureView;->getHeight()I

    move-result v0

    .line 651
    sget-object v4, Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;->TexturePixelCopy:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

    move-object v15, v1

    goto :goto_66

    .line 653
    :cond_3e
    invoke-direct {v2}, Lcom/example/bleconnectse/AmapNavigationView;->resolveMapSurfaceView()Landroid/view/SurfaceView;

    move-result-object v0

    if-nez v0, :cond_45

    return v10

    .line 655
    :cond_45
    invoke-virtual {v0}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/SurfaceHolder;->getSurface()Landroid/view/Surface;

    move-result-object v1

    const-string v3, "getSurface(...)"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 656
    invoke-virtual {v0}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/SurfaceHolder;->getSurfaceFrame()Landroid/graphics/Rect;

    move-result-object v0

    .line 657
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v3

    .line 658
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    .line 659
    sget-object v4, Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;->SurfacePixelCopy:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

    move-object v15, v1

    move-object v1, v14

    :goto_66
    move v6, v0

    move v5, v3

    .line 661
    invoke-virtual {v15}, Landroid/view/Surface;->isValid()Z

    move-result v0

    if-eqz v0, :cond_c1

    if-lez v5, :cond_c1

    if-gtz v6, :cond_73

    goto :goto_c1

    .line 671
    :cond_73
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/16 v3, 0x320

    const/16 v7, 0x1e0

    .line 668
    invoke-static {v3, v7, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v8

    const-string v0, "createBitmap(...)"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 673
    invoke-direct {v2, v5, v6, v3, v7}, Lcom/example/bleconnectse/AmapNavigationView;->centerCropRect(IIII)Landroid/graphics/Rect;

    move-result-object v0

    .line 679
    iget v3, v2, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    move-object v7, v0

    .line 681
    :try_start_89
    new-instance v0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;
    :try_end_8b
    .catchall {:try_start_89 .. :try_end_8b} :catchall_9c

    move/from16 v16, v10

    move-object v10, v7

    move-object v7, v8

    move-wide/from16 v8, p1

    :try_start_91
    invoke-direct/range {v0 .. v9}, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;-><init>(Landroid/view/Surface;Lcom/example/bleconnectse/AmapNavigationView;ILcom/example/bleconnectse/AmapNavigationView$CaptureMode;IILandroid/graphics/Bitmap;J)V

    .line 734
    iget-object v3, v2, Lcom/example/bleconnectse/AmapNavigationView;->captureHandler:Landroid/os/Handler;

    .line 681
    invoke-static {v15, v10, v7, v0, v3}, Landroid/view/PixelCopy;->request(Landroid/view/Surface;Landroid/graphics/Rect;Landroid/graphics/Bitmap;Landroid/view/PixelCopy$OnPixelCopyFinishedListener;Landroid/os/Handler;)V
    :try_end_99
    .catchall {:try_start_91 .. :try_end_99} :catchall_9a

    return v13

    :catchall_9a
    move-exception v0

    goto :goto_a0

    :catchall_9c
    move-exception v0

    move-object v7, v8

    move/from16 v16, v10

    :goto_a0
    if-eqz v1, :cond_a5

    .line 738
    invoke-virtual {v1}, Landroid/view/Surface;->release()V

    .line 739
    :cond_a5
    invoke-virtual {v7}, Landroid/graphics/Bitmap;->recycle()V

    .line 740
    iput-object v14, v2, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapSurface:Landroid/view/SurfaceView;

    .line 741
    iput-object v14, v2, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapTexture:Landroid/view/TextureView;

    const/4 v1, 0x3

    .line 742
    iput v1, v2, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyFailures:I

    const-wide/16 v3, 0x1388

    add-long/2addr v11, v3

    .line 743
    iput-wide v11, v2, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyRetryAfter:J

    .line 744
    sget-object v1, Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;->MapScreenshot:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

    invoke-direct {v2, v1}, Lcom/example/bleconnectse/AmapNavigationView;->updateCaptureMode(Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;)V

    .line 745
    const-string v1, "AmapMirrorCapture"

    const-string v2, "PixelCopy 请求异常，回退高德截图"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v16

    :cond_c1
    :goto_c1
    move/from16 v16, v10

    if-eqz v1, :cond_c8

    .line 662
    invoke-virtual {v1}, Landroid/view/Surface;->release()V

    .line 663
    :cond_c8
    iput-object v14, v2, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapSurface:Landroid/view/SurfaceView;

    .line 664
    iput-object v14, v2, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapTexture:Landroid/view/TextureView;

    return v16
.end method

.method static final requestPixelCopyFrame$lambda$21(Landroid/view/Surface;Lcom/example/bleconnectse/AmapNavigationView;ILcom/example/bleconnectse/AmapNavigationView$CaptureMode;IILandroid/graphics/Bitmap;JI)V
    .registers 10

    if-eqz p0, :cond_5

    .line 686
    invoke-virtual {p0}, Landroid/view/Surface;->release()V

    .line 687
    :cond_5
    iget-boolean p0, p1, Lcom/example/bleconnectse/AmapNavigationView;->publishing:Z

    if-eqz p0, :cond_4d

    iget-boolean p0, p1, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez p0, :cond_4d

    iget p0, p1, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    if-eq p2, p0, :cond_12

    goto :goto_4d

    :cond_12
    if-nez p9, :cond_39

    .line 698
    new-instance p0, Landroid/graphics/Canvas;

    invoke-direct {p0, p6}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/high16 p4, 0x44480000  # 800.0f

    const/high16 p5, 0x43f00000  # 480.0f

    .line 697
    invoke-direct {p1, p0, p4, p5}, Lcom/example/bleconnectse/AmapNavigationView;->drawGuidance(Landroid/graphics/Canvas;FF)V

    .line 702
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {p0, p6}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->submit(Landroid/graphics/Bitmap;)V

    .line 703
    invoke-direct {p1, p3}, Lcom/example/bleconnectse/AmapNavigationView;->recordEffectiveFrame(Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;)V

    .line 704
    iget-object p0, p1, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    move p4, p2

    move-object p2, p1

    new-instance p1, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda1;

    move p5, p4

    move-object p4, p3

    move p3, p5

    move-wide p5, p7

    invoke-direct/range {p1 .. p6}, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/AmapNavigationView;ILcom/example/bleconnectse/AmapNavigationView$CaptureMode;J)V

    invoke-virtual {p0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_39
    move p4, p2

    move-object p0, p6

    move-wide p6, p7

    move-object p2, p1

    .line 713
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->recycle()V

    .line 714
    iget-object p0, p2, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    move-object p3, p2

    new-instance p2, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda2;

    move p5, p9

    invoke-direct/range {p2 .. p7}, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda2;-><init>(Lcom/example/bleconnectse/AmapNavigationView;IIJ)V

    invoke-virtual {p0, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_4d
    :goto_4d
    move-object p2, p1

    move-object p1, p3

    move-object p0, p6

    move p3, p9

    .line 688
    iget-boolean p6, p2, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez p6, :cond_93

    iget-boolean p2, p2, Lcom/example/bleconnectse/AmapNavigationView;->debugCaptureProbeEnabled:Z

    if-eqz p2, :cond_93

    .line 691
    invoke-virtual {p1}, Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;->getLabel()Ljava/lang/String;

    move-result-object p1

    .line 692
    new-instance p2, Ljava/lang/StringBuilder;

    const-string/jumbo p6, "取帧探测结果="

    invoke-direct {p2, p6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string/jumbo p3, "，方式="

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo p2, "，源="

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo p2, "x"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 689
    const-string p2, "AmapMirrorCapture"

    invoke-static {p2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 695
    :cond_93
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->recycle()V

    return-void
.end method

.method static final requestPixelCopyFrame$lambda$21$lambda$19(Lcom/example/bleconnectse/AmapNavigationView;ILcom/example/bleconnectse/AmapNavigationView$CaptureMode;J)V
    .registers 7

    .line 705
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->publishing:Z

    if-eqz v0, :cond_19

    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez v0, :cond_19

    iget v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    if-ne p1, v0, :cond_19

    const/4 v0, 0x0

    .line 706
    iput v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyFailures:I

    const-wide/16 v0, 0x0

    .line 707
    iput-wide v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyRetryAfter:J

    .line 708
    invoke-direct {p0, p2}, Lcom/example/bleconnectse/AmapNavigationView;->updateCaptureMode(Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;)V

    .line 709
    invoke-direct {p0, p3, p4, p1}, Lcom/example/bleconnectse/AmapNavigationView;->scheduleNextFrame(JI)V

    :cond_19
    return-void
.end method

.method static final requestPixelCopyFrame$lambda$21$lambda$20(Lcom/example/bleconnectse/AmapNavigationView;IIJ)V
    .registers 9

    .line 715
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->publishing:Z

    if-eqz v0, :cond_52

    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez v0, :cond_52

    iget v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    if-ne p1, v0, :cond_52

    .line 716
    iget v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyFailures:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyFailures:I

    const/4 v1, 0x3

    if-lt v0, v1, :cond_4f

    const/4 v0, 0x0

    .line 718
    iput-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapSurface:Landroid/view/SurfaceView;

    .line 719
    iput-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapTexture:Landroid/view/TextureView;

    .line 720
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    const-wide/16 v2, 0x1388

    add-long/2addr v0, v2

    iput-wide v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyRetryAfter:J

    .line 722
    sget-object v0, Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;->MapScreenshot:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/AmapNavigationView;->updateCaptureMode(Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;)V

    .line 725
    iget v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyFailures:I

    .line 726
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "PixelCopy 连续失败 "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " 次，结果码="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string/jumbo v0, "，临时回退高德截图"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 723
    const-string v0, "AmapMirrorCapture"

    invoke-static {v0, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 729
    :cond_4f
    invoke-direct {p0, p3, p4, p1}, Lcom/example/bleconnectse/AmapNavigationView;->scheduleNextFrame(JI)V

    :cond_52
    return-void
.end method

.method private final resolveMapSurfaceView()Landroid/view/SurfaceView;
    .registers 4

    .line 811
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapSurface:Landroid/view/SurfaceView;

    if-eqz v0, :cond_19

    .line 812
    invoke-virtual {v0}, Landroid/view/SurfaceView;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_19

    invoke-virtual {v0}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/SurfaceHolder;->getSurface()Landroid/view/Surface;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Surface;->isValid()Z

    move-result v1

    if-eqz v1, :cond_19

    return-object v0

    .line 814
    :cond_19
    new-instance v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .line 815
    new-instance v1, Lkotlin/jvm/internal/Ref$LongRef;

    invoke-direct {v1}, Lkotlin/jvm/internal/Ref$LongRef;-><init>()V

    .line 830
    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->naviView:Lcom/amap/api/navi/AMapNaviView;

    check-cast v2, Landroid/view/View;

    invoke-static {v1, v0, v2}, Lcom/example/bleconnectse/AmapNavigationView;->resolveMapSurfaceView$visit(Lkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/internal/Ref$ObjectRef;Landroid/view/View;)V

    .line 831
    iget-object v0, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Landroid/view/SurfaceView;

    iput-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapSurface:Landroid/view/SurfaceView;

    return-object v0
.end method

.method private static final resolveMapSurfaceView$visit(Lkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/internal/Ref$ObjectRef;Landroid/view/View;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/Ref$LongRef;",
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Landroid/view/SurfaceView;",
            ">;",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .line 818
    instance-of v0, p2, Landroid/view/SurfaceView;

    if-eqz v0, :cond_2a

    .line 819
    move-object v0, p2

    check-cast v0, Landroid/view/SurfaceView;

    invoke-virtual {v0}, Landroid/view/SurfaceView;->getWidth()I

    move-result v1

    int-to-long v1, v1

    invoke-virtual {v0}, Landroid/view/SurfaceView;->getHeight()I

    move-result v3

    int-to-long v3, v3

    mul-long/2addr v1, v3

    .line 820
    invoke-virtual {v0}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/SurfaceHolder;->getSurface()Landroid/view/Surface;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Surface;->isValid()Z

    move-result v0

    if-eqz v0, :cond_2a

    iget-wide v3, p0, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    cmp-long v0, v1, v3

    if-lez v0, :cond_2a

    .line 821
    iput-object p2, p1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 822
    iput-wide v1, p0, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    .line 825
    :cond_2a
    instance-of v0, p2, Landroid/view/ViewGroup;

    if-eqz v0, :cond_46

    .line 826
    check-cast p2, Landroid/view/ViewGroup;

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    :goto_35
    if-ge v1, v0, :cond_46

    invoke-virtual {p2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const-string v3, "getChildAt(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1, v2}, Lcom/example/bleconnectse/AmapNavigationView;->resolveMapSurfaceView$visit(Lkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/internal/Ref$ObjectRef;Landroid/view/View;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_35

    :cond_46
    return-void
.end method

.method private final resolveMapTextureView()Landroid/view/TextureView;
    .registers 4

    .line 835
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapTexture:Landroid/view/TextureView;

    if-eqz v0, :cond_11

    .line 836
    invoke-virtual {v0}, Landroid/view/TextureView;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_11

    invoke-virtual {v0}, Landroid/view/TextureView;->isAvailable()Z

    move-result v1

    if-eqz v1, :cond_11

    return-object v0

    .line 838
    :cond_11
    new-instance v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .line 839
    new-instance v1, Lkotlin/jvm/internal/Ref$LongRef;

    invoke-direct {v1}, Lkotlin/jvm/internal/Ref$LongRef;-><init>()V

    .line 854
    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->naviView:Lcom/amap/api/navi/AMapNaviView;

    check-cast v2, Landroid/view/View;

    invoke-static {v1, v0, v2}, Lcom/example/bleconnectse/AmapNavigationView;->resolveMapTextureView$visit$28(Lkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/internal/Ref$ObjectRef;Landroid/view/View;)V

    .line 855
    iget-object v0, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Landroid/view/TextureView;

    iput-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapTexture:Landroid/view/TextureView;

    return-object v0
.end method

.method private static final resolveMapTextureView$visit$28(Lkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/internal/Ref$ObjectRef;Landroid/view/View;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/Ref$LongRef;",
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Landroid/view/TextureView;",
            ">;",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .line 842
    instance-of v0, p2, Landroid/view/TextureView;

    if-eqz v0, :cond_22

    .line 843
    move-object v0, p2

    check-cast v0, Landroid/view/TextureView;

    invoke-virtual {v0}, Landroid/view/TextureView;->getWidth()I

    move-result v1

    int-to-long v1, v1

    invoke-virtual {v0}, Landroid/view/TextureView;->getHeight()I

    move-result v3

    int-to-long v3, v3

    mul-long/2addr v1, v3

    .line 844
    invoke-virtual {v0}, Landroid/view/TextureView;->isAvailable()Z

    move-result v0

    if-eqz v0, :cond_22

    iget-wide v3, p0, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    cmp-long v0, v1, v3

    if-lez v0, :cond_22

    .line 845
    iput-object p2, p1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 846
    iput-wide v1, p0, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    .line 849
    :cond_22
    instance-of v0, p2, Landroid/view/ViewGroup;

    if-eqz v0, :cond_3e

    .line 850
    check-cast p2, Landroid/view/ViewGroup;

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    :goto_2d
    if-ge v1, v0, :cond_3e

    invoke-virtual {p2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const-string v3, "getChildAt(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1, v2}, Lcom/example/bleconnectse/AmapNavigationView;->resolveMapTextureView$visit$28(Lkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/internal/Ref$ObjectRef;Landroid/view/View;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_2d

    :cond_3e
    return-void
.end method

.method private final restoreRealLocationAfterEmulatorFailure()V
    .registers 2

    .line 1134
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->emulatorNavigationActive:Z

    if-nez v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x0

    .line 1135
    iput-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->emulatorNavigationActive:Z

    .line 1136
    invoke-direct {p0}, Lcom/example/bleconnectse/AmapNavigationView;->startRealLocationTracking()V

    return-void
.end method

.method private final routeErrorMessage(I)Ljava/lang/String;
    .registers 2

    const/4 p0, 0x2

    if-eq p1, p0, :cond_55

    const/4 p0, 0x3

    if-eq p1, p0, :cond_51

    const/4 p0, 0x6

    if-eq p1, p0, :cond_4d

    const/16 p0, 0xd

    if-eq p1, p0, :cond_49

    const/16 p0, 0x14

    if-eq p1, p0, :cond_45

    const/16 p0, 0x16

    if-eq p1, p0, :cond_41

    const/16 p0, 0x18

    if-eq p1, p0, :cond_3d

    const/16 p0, 0xa

    if-eq p1, p0, :cond_39

    const/16 p0, 0xb

    if-eq p1, p0, :cond_35

    const/16 p0, 0x10

    if-eq p1, p0, :cond_31

    const/16 p0, 0x11

    if-eq p1, p0, :cond_2d

    .line 1167
    const-string/jumbo p0, "未知错误"

    return-object p0

    .line 1163
    :cond_2d
    const-string/jumbo p0, "高德调用额度已用完"

    return-object p0

    .line 1162
    :cond_31
    const-string/jumbo p0, "高德 Key 权限不足"

    return-object p0

    .line 1160
    :cond_35
    const-string/jumbo p0, "终点附近没有可导航道路"

    return-object p0

    .line 1159
    :cond_39
    const-string/jumbo p0, "起点附近没有可导航道路"

    return-object p0

    .line 1165
    :cond_3d
    const-string/jumbo p0, "高德 Key 平台不匹配"

    return-object p0

    .line 1164
    :cond_41
    const-string/jumbo p0, "签名安全码不匹配"

    return-object p0

    .line 1166
    :cond_45
    const-string/jumbo p0, "起终点距离不符合要求"

    return-object p0

    .line 1161
    :cond_49
    const-string/jumbo p0, "高德 Key 无效"

    return-object p0

    .line 1158
    :cond_4d
    const-string/jumbo p0, "终点无效"

    return-object p0

    .line 1157
    :cond_51
    const-string/jumbo p0, "起点无效"

    return-object p0

    .line 1156
    :cond_55
    const-string/jumbo p0, "网络连接失败"

    return-object p0
.end method

.method private final scheduleNextFrame(JI)V
    .registers 6

    .line 859
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->publishing:Z

    if-eqz v0, :cond_24

    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez v0, :cond_24

    iget v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    if-eq p3, v0, :cond_d

    goto :goto_24

    .line 860
    :cond_d
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    sub-long/2addr v0, p1

    .line 861
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    .line 862
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->framePublisher:Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;

    check-cast p0, Ljava/lang/Runnable;

    const-wide/16 p2, 0x7d

    sub-long/2addr p2, v0

    const-wide/16 v0, 0x0

    .line 863
    invoke-static {p2, p3, v0, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide p2

    .line 861
    invoke-virtual {p1, p0, p2, p3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_24
    :goto_24
    return-void
.end method

.method static final searchDestinationSuggestions$lambda$11$lambda$10(Lcom/example/bleconnectse/AmapNavigationView;ILjava/util/List;I)V
    .registers 12

    .line 368
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez v0, :cond_ef

    iget v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->suggestionRequestSequence:I

    if-eq p1, v0, :cond_a

    goto/16 :goto_ef

    :cond_a
    const/16 p1, 0x3e8

    if-eq p3, p1, :cond_16

    .line 372
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->publishSuggestions(Ljava/util/List;)V

    return-void

    :cond_16
    if-nez p2, :cond_1c

    .line 375
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p2

    :cond_1c
    check-cast p2, Ljava/lang/Iterable;

    .line 1194
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    check-cast p1, Ljava/util/Collection;

    .line 1203
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_29
    :goto_29
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_a2

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    .line 1202
    check-cast p3, Lcom/amap/api/services/help/Tip;

    .line 377
    invoke-virtual {p3}, Lcom/amap/api/services/help/Tip;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    if-nez v0, :cond_3e

    move-object v0, v1

    :cond_3e
    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    .line 378
    move-object v0, v3

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v2, 0x0

    if-nez v0, :cond_53

    goto :goto_9c

    .line 379
    :cond_53
    invoke-virtual {p3}, Lcom/amap/api/services/help/Tip;->getPoint()Lcom/amap/api/services/core/LatLonPoint;

    move-result-object v0

    move-object v4, v2

    .line 380
    new-instance v2, Lcom/example/bleconnectse/AmapDestinationSuggestion;

    .line 382
    invoke-virtual {p3}, Lcom/amap/api/services/help/Tip;->getAddress()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_61

    move-object v5, v1

    :cond_61
    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v5}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    .line 383
    invoke-virtual {p3}, Lcom/amap/api/services/help/Tip;->getDistrict()Ljava/lang/String;

    move-result-object p3

    if-nez p3, :cond_72

    goto :goto_73

    :cond_72
    move-object v1, p3

    :goto_73
    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p3

    if-eqz v0, :cond_89

    .line 384
    invoke-virtual {v0}, Lcom/amap/api/services/core/LatLonPoint;->getLatitude()D

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    move-object v6, v1

    goto :goto_8a

    :cond_89
    move-object v6, v4

    :goto_8a
    if-eqz v0, :cond_96

    .line 385
    invoke-virtual {v0}, Lcom/amap/api/services/core/LatLonPoint;->getLongitude()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    move-object v7, v0

    goto :goto_97

    :cond_96
    move-object v7, v4

    :goto_97
    move-object v4, v5

    move-object v5, p3

    .line 380
    invoke-direct/range {v2 .. v7}, Lcom/example/bleconnectse/AmapDestinationSuggestion;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Double;Ljava/lang/Double;)V

    :goto_9c
    if-eqz v2, :cond_29

    .line 1202
    invoke-interface {p1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_29

    .line 1206
    :cond_a2
    check-cast p1, Ljava/util/List;

    .line 1194
    check-cast p1, Ljava/lang/Iterable;

    .line 1207
    new-instance p2, Ljava/util/HashSet;

    invoke-direct {p2}, Ljava/util/HashSet;-><init>()V

    .line 1208
    new-instance p3, Ljava/util/ArrayList;

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    .line 1209
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_b4
    :goto_b4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_e3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    .line 1210
    move-object v1, v0

    check-cast v1, Lcom/example/bleconnectse/AmapDestinationSuggestion;

    .line 390
    invoke-virtual {v1}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getName()Ljava/lang/String;

    move-result-object v2

    .line 391
    invoke-virtual {v1}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getAddress()Ljava/lang/String;

    move-result-object v3

    .line 392
    invoke-virtual {v1}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getLatitude()Ljava/lang/Double;

    move-result-object v4

    .line 393
    invoke-virtual {v1}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getLongitude()Ljava/lang/Double;

    move-result-object v1

    filled-new-array {v2, v3, v4, v1}, [Ljava/lang/Object;

    move-result-object v1

    .line 389
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    .line 1211
    invoke-virtual {p2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b4

    .line 1212
    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_b4

    .line 1214
    :cond_e3
    check-cast p3, Ljava/util/List;

    check-cast p3, Ljava/lang/Iterable;

    const/4 p1, 0x6

    .line 396
    invoke-static {p3, p1}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object p1

    .line 397
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->publishSuggestions(Ljava/util/List;)V

    :cond_ef
    :goto_ef
    return-void
.end method

.method private final selectDestination(Lcom/amap/api/maps/model/LatLng;ILjava/lang/String;)V
    .registers 24

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v5, p3

    .line 549
    invoke-direct {v0}, Lcom/example/bleconnectse/AmapNavigationView;->hasLocationPermission()Z

    move-result v3

    if-nez v3, :cond_15

    .line 550
    const-string/jumbo v1, "请先授予定位权限"

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    return-void

    .line 553
    :cond_15
    iget-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    invoke-virtual {v3}, Lcom/amap/api/maps/AMap;->getMyLocation()Landroid/location/Location;

    move-result-object v3

    if-eqz v3, :cond_2b

    .line 554
    new-instance v4, Lcom/amap/api/maps/model/LatLng;

    invoke-virtual {v3}, Landroid/location/Location;->getLatitude()D

    move-result-wide v6

    invoke-virtual {v3}, Landroid/location/Location;->getLongitude()D

    move-result-wide v8

    invoke-direct {v4, v6, v7, v8, v9}, Lcom/amap/api/maps/model/LatLng;-><init>(DD)V

    goto :goto_2d

    .line 555
    :cond_2b
    iget-object v4, v0, Lcom/example/bleconnectse/AmapNavigationView;->currentLocation:Lcom/amap/api/maps/model/LatLng;

    :goto_2d
    if-nez v4, :cond_3d

    .line 557
    const-string/jumbo v1, "正在等待 GPS 定位，请稍后再长按"

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    .line 558
    iget-object v0, v0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz v0, :cond_3c

    invoke-virtual {v0}, Lcom/amap/api/navi/AMapNavi;->startGPS()Z

    :cond_3c
    return-void

    .line 562
    :cond_3d
    iget-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->destinationMarker:Lcom/amap/api/maps/model/Marker;

    if-eqz v3, :cond_44

    invoke-virtual {v3}, Lcom/amap/api/maps/model/Marker;->remove()V

    .line 563
    :cond_44
    iget-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    .line 564
    new-instance v6, Lcom/amap/api/maps/model/MarkerOptions;

    invoke-direct {v6}, Lcom/amap/api/maps/model/MarkerOptions;-><init>()V

    .line 565
    invoke-virtual {v6, v1}, Lcom/amap/api/maps/model/MarkerOptions;->position(Lcom/amap/api/maps/model/LatLng;)Lcom/amap/api/maps/model/MarkerOptions;

    move-result-object v6

    .line 566
    invoke-virtual {v6, v5}, Lcom/amap/api/maps/model/MarkerOptions;->title(Ljava/lang/String;)Lcom/amap/api/maps/model/MarkerOptions;

    move-result-object v6

    .line 563
    invoke-virtual {v3, v6}, Lcom/amap/api/maps/AMap;->addMarker(Lcom/amap/api/maps/model/MarkerOptions;)Lcom/amap/api/maps/model/Marker;

    move-result-object v3

    iput-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->destinationMarker:Lcom/amap/api/maps/model/Marker;

    .line 568
    iget-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz v3, :cond_60

    invoke-virtual {v3}, Lcom/amap/api/navi/AMapNavi;->stopNavi()V

    :cond_60
    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-ne v2, v7, :cond_67

    move v8, v6

    goto :goto_68

    :cond_67
    move v8, v3

    .line 569
    :goto_68
    iput-boolean v8, v0, Lcom/example/bleconnectse/AmapNavigationView;->emulatorNavigationActive:Z

    if-eqz v8, :cond_70

    .line 571
    invoke-direct {v0}, Lcom/example/bleconnectse/AmapNavigationView;->pauseRealLocationTracking()V

    goto :goto_73

    .line 573
    :cond_70
    invoke-direct {v0}, Lcom/example/bleconnectse/AmapNavigationView;->startRealLocationTracking()V

    .line 575
    :goto_73
    iput v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->pendingNaviType:I

    .line 576
    iput-object v5, v0, Lcom/example/bleconnectse/AmapNavigationView;->pendingDestinationName:Ljava/lang/String;

    .line 577
    iput-boolean v6, v0, Lcom/example/bleconnectse/AmapNavigationView;->routeStarting:Z

    move v8, v3

    .line 578
    iget-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->guidance:Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    if-ne v2, v7, :cond_82

    .line 581
    const-string/jumbo v9, "高德模拟"

    goto :goto_84

    :cond_82
    const-string v9, "GPS"

    :goto_84
    move-object v12, v9

    const/16 v14, 0x2f9

    const/4 v15, 0x0

    move-object v9, v4

    const/4 v4, 0x0

    move v10, v6

    .line 578
    const-string/jumbo v6, "正在规划路线"

    move v11, v7

    const/4 v7, 0x0

    move v13, v8

    const/4 v8, 0x0

    move-object/from16 v16, v9

    const/4 v9, 0x0

    move/from16 v17, v10

    const/4 v10, 0x0

    move/from16 v18, v11

    const/4 v11, 0x0

    move/from16 v19, v13

    const/4 v13, 0x0

    move/from16 v1, v18

    invoke-static/range {v3 .. v15}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->copy$default(Lcom/example/bleconnectse/AmapNavigationView$Guidance;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;ILjava/lang/Object;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object v3

    iput-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->guidance:Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    if-ne v2, v1, :cond_ac

    .line 584
    const-string/jumbo v1, "正在规划高德模拟导航路线…"

    goto :goto_af

    .line 585
    :cond_ac
    const-string/jumbo v1, "正在规划真实 GPS 导航路线…"

    .line 583
    :goto_af
    invoke-direct {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    .line 587
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz v1, :cond_d7

    .line 588
    new-instance v2, Lcom/amap/api/navi/model/NaviPoi;

    const-string/jumbo v3, "当前位置"

    const-string v4, ""

    move-object/from16 v9, v16

    invoke-direct {v2, v3, v9, v4}, Lcom/amap/api/navi/model/NaviPoi;-><init>(Ljava/lang/String;Lcom/amap/api/maps/model/LatLng;Ljava/lang/String;)V

    .line 589
    new-instance v3, Lcom/amap/api/navi/model/NaviPoi;

    move-object/from16 v6, p1

    invoke-direct {v3, v5, v6, v4}, Lcom/amap/api/navi/model/NaviPoi;-><init>(Ljava/lang/String;Lcom/amap/api/maps/model/LatLng;Ljava/lang/String;)V

    .line 590
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v4

    const/16 v5, 0xa

    .line 587
    invoke-virtual {v1, v2, v3, v4, v5}, Lcom/amap/api/navi/AMapNavi;->calculateDriveRoute(Lcom/amap/api/navi/model/NaviPoi;Lcom/amap/api/navi/model/NaviPoi;Ljava/util/List;I)Z

    move-result v1

    const/4 v10, 0x1

    if-ne v1, v10, :cond_d7

    return-void

    :cond_d7
    const/4 v13, 0x0

    .line 594
    iput-boolean v13, v0, Lcom/example/bleconnectse/AmapNavigationView;->routeStarting:Z

    .line 595
    invoke-direct {v0}, Lcom/example/bleconnectse/AmapNavigationView;->restoreRealLocationAfterEmulatorFailure()V

    .line 596
    const-string/jumbo v1, "路线规划请求未被接受，请检查网络"

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    return-void
.end method

.method private final startGpsNavigation()V
    .registers 19

    move-object/from16 v0, p0

    .line 601
    iget-boolean v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->routeStarting:Z

    if-nez v1, :cond_7

    return-void

    :cond_7
    const/4 v1, 0x0

    .line 602
    iput-boolean v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->routeStarting:Z

    .line 603
    iget v2, v0, Lcom/example/bleconnectse/AmapNavigationView;->pendingNaviType:I

    .line 604
    iget-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz v3, :cond_15

    invoke-virtual {v3}, Lcom/amap/api/navi/AMapNavi;->getNaviPath()Lcom/amap/api/navi/model/AMapNaviPath;

    move-result-object v3

    goto :goto_16

    :cond_15
    const/4 v3, 0x0

    :goto_16
    const/4 v4, 0x2

    if-eqz v3, :cond_46

    .line 606
    iget-object v5, v0, Lcom/example/bleconnectse/AmapNavigationView;->guidance:Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    .line 607
    invoke-virtual {v3}, Lcom/amap/api/navi/model/AMapNaviPath;->getAllLength()I

    move-result v6

    invoke-static {v6, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v11

    .line 608
    invoke-virtual {v3}, Lcom/amap/api/navi/model/AMapNaviPath;->getAllTime()I

    move-result v3

    invoke-static {v3, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v12

    if-ne v2, v4, :cond_31

    .line 610
    const-string/jumbo v3, "路线已生成，开始高德模拟导航"

    goto :goto_34

    .line 612
    :cond_31
    const-string/jumbo v3, "路线已生成，开始真实 GPS 导航"

    :goto_34
    move-object v8, v3

    const/16 v16, 0x39b

    const/16 v17, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    .line 606
    invoke-static/range {v5 .. v17}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->copy$default(Lcom/example/bleconnectse/AmapNavigationView$Guidance;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;ILjava/lang/Object;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object v3

    iput-object v3, v0, Lcom/example/bleconnectse/AmapNavigationView;->guidance:Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    :cond_46
    if-ne v2, v4, :cond_55

    .line 617
    invoke-direct {v0}, Lcom/example/bleconnectse/AmapNavigationView;->pauseRealLocationTracking()V

    .line 618
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz v1, :cond_5a

    const/16 v3, 0x3c

    invoke-virtual {v1, v3}, Lcom/amap/api/navi/AMapNavi;->setEmulatorNaviSpeed(I)V

    goto :goto_5a

    .line 620
    :cond_55
    iput-boolean v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->emulatorNavigationActive:Z

    .line 621
    invoke-direct {v0}, Lcom/example/bleconnectse/AmapNavigationView;->startRealLocationTracking()V

    .line 623
    :cond_5a
    :goto_5a
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->naviView:Lcom/amap/api/navi/AMapNaviView;

    const/16 v3, 0xf

    invoke-virtual {v1, v3}, Lcom/amap/api/navi/AMapNaviView;->setLockZoom(I)V

    .line 624
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz v1, :cond_7e

    invoke-virtual {v1, v2}, Lcom/amap/api/navi/AMapNavi;->startNavi(I)Z

    move-result v1

    const/4 v3, 0x1

    if-ne v1, v3, :cond_7e

    .line 625
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView;->naviView:Lcom/amap/api/navi/AMapNaviView;

    invoke-virtual {v1}, Lcom/amap/api/navi/AMapNaviView;->recoverLockMode()V

    if-ne v2, v4, :cond_77

    .line 627
    const-string/jumbo v1, "高德模拟导航中（60 km/h）"

    goto :goto_7a

    .line 628
    :cond_77
    const-string/jumbo v1, "真实 GPS 导航中"

    .line 626
    :goto_7a
    invoke-direct {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    return-void

    .line 631
    :cond_7e
    invoke-direct {v0}, Lcom/example/bleconnectse/AmapNavigationView;->restoreRealLocationAfterEmulatorFailure()V

    .line 632
    const-string/jumbo v1, "路线已生成，但导航启动失败"

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    return-void
.end method

.method private final startRealLocationTracking()V
    .registers 5

    .line 1117
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez v0, :cond_39

    invoke-direct {p0}, Lcom/example/bleconnectse/AmapNavigationView;->hasLocationPermission()Z

    move-result v0

    if-nez v0, :cond_b

    goto :goto_39

    .line 1118
    :cond_b
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    invoke-virtual {v0}, Lcom/amap/api/maps/AMap;->isMyLocationEnabled()Z

    move-result v0

    if-nez v0, :cond_32

    .line 1119
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    new-instance v1, Lcom/amap/api/maps/model/MyLocationStyle;

    invoke-direct {v1}, Lcom/amap/api/maps/model/MyLocationStyle;-><init>()V

    const/4 v2, 0x4

    .line 1120
    invoke-virtual {v1, v2}, Lcom/amap/api/maps/model/MyLocationStyle;->myLocationType(I)Lcom/amap/api/maps/model/MyLocationStyle;

    move-result-object v1

    const-wide/16 v2, 0x3e8

    .line 1121
    invoke-virtual {v1, v2, v3}, Lcom/amap/api/maps/model/MyLocationStyle;->interval(J)Lcom/amap/api/maps/model/MyLocationStyle;

    move-result-object v1

    const/4 v2, 0x1

    .line 1122
    invoke-virtual {v1, v2}, Lcom/amap/api/maps/model/MyLocationStyle;->showMyLocation(Z)Lcom/amap/api/maps/model/MyLocationStyle;

    move-result-object v1

    .line 1119
    invoke-virtual {v0, v1}, Lcom/amap/api/maps/AMap;->setMyLocationStyle(Lcom/amap/api/maps/model/MyLocationStyle;)V

    .line 1123
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    invoke-virtual {v0, v2}, Lcom/amap/api/maps/AMap;->setMyLocationEnabled(Z)V

    .line 1125
    :cond_32
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz p0, :cond_39

    invoke-virtual {p0}, Lcom/amap/api/navi/AMapNavi;->startGPS()Z

    :cond_39
    :goto_39
    return-void
.end method

.method private final updateCaptureMode(Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;)V
    .registers 4

    .line 884
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureMode:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

    if-ne v0, p1, :cond_5

    return-void

    .line 885
    :cond_5
    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureMode:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

    .line 886
    invoke-virtual {p1}, Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;->getLabel()Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "高德投屏取帧方式="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "AmapMirrorCapture"

    invoke-static {v0, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 887
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    invoke-virtual {p1}, Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;->getLabel()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "高德投屏取帧方式："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    return-void
.end method

.method private final updateStatus(Ljava/lang/String;)V
    .registers 4

    .line 1101
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_14

    .line 1102
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->onStatusChanged:Lkotlin/jvm/functions/Function1;

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 1104
    :cond_14
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    new-instance v1, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0, p1}, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda4;-><init>(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static final updateStatus$lambda$32(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V
    .registers 3

    .line 1104
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez v0, :cond_9

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->onStatusChanged:Lkotlin/jvm/functions/Function1;

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_9
    return-void
.end method


# virtual methods
.method public final close()V
    .registers 5

    .line 499
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-eqz v0, :cond_5

    return-void

    .line 500
    :cond_5
    invoke-virtual {p0}, Lcom/example/bleconnectse/AmapNavigationView;->stopPublishing()V

    .line 501
    invoke-virtual {p0}, Lcom/example/bleconnectse/AmapNavigationView;->onHostPause()V

    const/4 v0, 0x1

    .line 502
    iput-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    .line 503
    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->destinationMarker:Lcom/amap/api/maps/model/Marker;

    if-eqz v1, :cond_15

    invoke-virtual {v1}, Lcom/amap/api/maps/model/Marker;->remove()V

    :cond_15
    const/4 v1, 0x0

    .line 504
    iput-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->destinationMarker:Lcom/amap/api/maps/model/Marker;

    .line 505
    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    invoke-virtual {v2, v1}, Lcom/amap/api/maps/AMap;->setOnMapLongClickListener(Lcom/amap/api/maps/AMap$OnMapLongClickListener;)V

    .line 506
    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz v2, :cond_24

    invoke-virtual {v2}, Lcom/amap/api/navi/AMapNavi;->stopNavi()V

    .line 507
    :cond_24
    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz v2, :cond_2b

    invoke-virtual {v2}, Lcom/amap/api/navi/AMapNavi;->stopGPS()Z

    .line 508
    :cond_2b
    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz v2, :cond_36

    iget-object v3, p0, Lcom/example/bleconnectse/AmapNavigationView;->naviListener:Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;

    check-cast v3, Lcom/amap/api/navi/AMapNaviListener;

    invoke-virtual {v2, v3}, Lcom/amap/api/navi/AMapNavi;->removeAMapNaviListener(Lcom/amap/api/navi/AMapNaviListener;)V

    .line 509
    :cond_36
    iput-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    .line 510
    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->geocodeSearch:Lcom/amap/api/services/geocoder/GeocodeSearch;

    if-eqz v2, :cond_3f

    invoke-virtual {v2, v1}, Lcom/amap/api/services/geocoder/GeocodeSearch;->setOnGeocodeSearchListener(Lcom/amap/api/services/geocoder/GeocodeSearch$OnGeocodeSearchListener;)V

    .line 511
    :cond_3f
    iput-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->geocodeSearch:Lcom/amap/api/services/geocoder/GeocodeSearch;

    .line 512
    iget v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->suggestionRequestSequence:I

    add-int/2addr v2, v0

    iput v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->suggestionRequestSequence:I

    .line 513
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->inputtips:Lcom/amap/api/services/help/Inputtips;

    if-eqz v0, :cond_4d

    invoke-virtual {v0, v1}, Lcom/amap/api/services/help/Inputtips;->setInputtipsListener(Lcom/amap/api/services/help/Inputtips$InputtipsListener;)V

    .line 514
    :cond_4d
    iput-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->inputtips:Lcom/amap/api/services/help/Inputtips;

    .line 515
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/AmapNavigationView;->publishSuggestions(Ljava/util/List;)V

    .line 516
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->naviView:Lcom/amap/api/navi/AMapNaviView;

    invoke-virtual {v0}, Lcom/amap/api/navi/AMapNaviView;->onDestroy()V

    .line 517
    iput-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapSurface:Landroid/view/SurfaceView;

    .line 518
    iput-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->cachedMapTexture:Landroid/view/TextureView;

    .line 519
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureThread:Landroid/os/HandlerThread;

    invoke-virtual {p0}, Landroid/os/HandlerThread;->quitSafely()Z

    return-void
.end method

.method public final navigateTo(Ljava/lang/String;Z)V
    .registers 12

    const-string v0, "destinationQuery"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 414
    check-cast p1, Ljava/lang/CharSequence;

    invoke-static {p1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    .line 415
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_1f

    .line 416
    const-string/jumbo p1, "请输入终点名称或完整地址"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    return-void

    .line 419
    :cond_1f
    invoke-direct {p0}, Lcom/example/bleconnectse/AmapNavigationView;->hasLocationPermission()Z

    move-result v0

    if-nez v0, :cond_2c

    .line 420
    const-string/jumbo p1, "请先授予定位权限"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    return-void

    .line 423
    :cond_2c
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->currentLocation:Lcom/amap/api/maps/model/LatLng;

    if-nez v0, :cond_46

    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    invoke-virtual {v0}, Lcom/amap/api/maps/AMap;->getMyLocation()Landroid/location/Location;

    move-result-object v0

    if-nez v0, :cond_46

    .line 424
    const-string/jumbo p1, "正在等待 GPS 定位，请稍后再试"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    .line 425
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->navi:Lcom/amap/api/navi/AMapNavi;

    if-eqz p0, :cond_45

    invoke-virtual {p0}, Lcom/amap/api/navi/AMapNavi;->startGPS()Z

    :cond_45
    return-void

    :cond_46
    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eqz p2, :cond_4c

    move p2, v0

    goto :goto_4d

    :cond_4c
    move p2, v1

    .line 428
    :goto_4d
    iput p2, p0, Lcom/example/bleconnectse/AmapNavigationView;->pendingNaviType:I

    .line 429
    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->pendingDestinationName:Ljava/lang/String;

    .line 430
    iget-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView;->selectedSuggestion:Lcom/example/bleconnectse/AmapDestinationSuggestion;

    const/4 v2, 0x0

    if-eqz p2, :cond_87

    .line 431
    invoke-virtual {p2}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_61

    goto :goto_62

    :cond_61
    move-object p2, v2

    :goto_62
    if-eqz p2, :cond_87

    .line 433
    invoke-virtual {p2}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getLatitude()Ljava/lang/Double;

    move-result-object v3

    .line 434
    invoke-virtual {p2}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getLongitude()Ljava/lang/Double;

    move-result-object v4

    if-eqz v3, :cond_87

    if-eqz v4, :cond_87

    .line 437
    new-instance p1, Lcom/amap/api/maps/model/LatLng;

    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v2

    invoke-direct {p1, v0, v1, v2, v3}, Lcom/amap/api/maps/model/LatLng;-><init>(DD)V

    .line 438
    iget v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->pendingNaviType:I

    .line 439
    invoke-virtual {p2}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getName()Ljava/lang/String;

    move-result-object p2

    .line 436
    invoke-direct {p0, p1, v0, p2}, Lcom/example/bleconnectse/AmapNavigationView;->selectDestination(Lcom/amap/api/maps/model/LatLng;ILjava/lang/String;)V

    return-void

    .line 444
    :cond_87
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->parseCoordinate(Ljava/lang/String;)Lcom/amap/api/maps/model/LatLng;

    move-result-object p2

    if-eqz p2, :cond_96

    .line 447
    iget p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->pendingNaviType:I

    .line 448
    const-string/jumbo v0, "坐标终点"

    .line 445
    invoke-direct {p0, p2, p1, v0}, Lcom/example/bleconnectse/AmapNavigationView;->selectDestination(Lcom/amap/api/maps/model/LatLng;ILjava/lang/String;)V

    return-void

    .line 452
    :cond_96
    iget-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView;->selectedSuggestion:Lcom/example/bleconnectse/AmapDestinationSuggestion;

    if-eqz p2, :cond_a5

    invoke-virtual {p2}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a5

    move-object v2, p2

    :cond_a5
    if-eqz v2, :cond_105

    const/4 p2, 0x3

    .line 454
    new-array p2, p2, [Ljava/lang/String;

    const/4 v3, 0x0

    invoke-virtual {v2}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getDistrict()Ljava/lang/String;

    move-result-object v4

    aput-object v4, p2, v3

    invoke-virtual {v2}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getAddress()Ljava/lang/String;

    move-result-object v3

    aput-object v3, p2, v1

    invoke-virtual {v2}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getName()Ljava/lang/String;

    move-result-object v1

    aput-object v1, p2, v0

    invoke-static {p2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p2

    check-cast p2, Ljava/lang/Iterable;

    .line 1191
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    check-cast v0, Ljava/util/Collection;

    .line 1192
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_ce
    :goto_ce
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_e7

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Ljava/lang/String;

    .line 455
    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_ce

    .line 1192
    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_ce

    .line 1193
    :cond_e7
    check-cast v0, Ljava/util/List;

    .line 1191
    check-cast v0, Ljava/lang/Iterable;

    .line 456
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p2

    move-object v0, p2

    check-cast v0, Ljava/lang/Iterable;

    .line 457
    const-string p2, " "

    move-object v1, p2

    check-cast v1, Ljava/lang/CharSequence;

    const/16 v7, 0x3e

    const/4 v8, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v0 .. v8}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    if-nez p2, :cond_106

    :cond_105
    move-object p2, p1

    .line 459
    :cond_106
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "正在搜索终点："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    .line 460
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->geocodeSearch:Lcom/amap/api/services/geocoder/GeocodeSearch;

    if-nez p1, :cond_124

    .line 462
    const-string/jumbo p1, "终点搜索服务尚未初始化"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->updateStatus(Ljava/lang/String;)V

    return-void

    .line 465
    :cond_124
    new-instance p0, Lcom/amap/api/services/geocoder/GeocodeQuery;

    const-string v0, ""

    invoke-direct {p0, p2, v0}, Lcom/amap/api/services/geocoder/GeocodeQuery;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Lcom/amap/api/services/geocoder/GeocodeSearch;->getFromLocationNameAsyn(Lcom/amap/api/services/geocoder/GeocodeQuery;)V

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 1

    .line 523
    invoke-virtual {p0}, Lcom/example/bleconnectse/AmapNavigationView;->stopPublishing()V

    .line 524
    invoke-super {p0}, Landroid/widget/FrameLayout;->onDetachedFromWindow()V

    return-void
.end method

.method public final onHostPause()V
    .registers 2

    .line 493
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez v0, :cond_11

    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->hostResumed:Z

    if-nez v0, :cond_9

    goto :goto_11

    :cond_9
    const/4 v0, 0x0

    .line 494
    iput-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->hostResumed:Z

    .line 495
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->naviView:Lcom/amap/api/navi/AMapNaviView;

    invoke-virtual {p0}, Lcom/amap/api/navi/AMapNaviView;->onPause()V

    :cond_11
    :goto_11
    return-void
.end method

.method public final onHostResume()V
    .registers 2

    .line 487
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-nez v0, :cond_11

    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->hostResumed:Z

    if-eqz v0, :cond_9

    goto :goto_11

    :cond_9
    const/4 v0, 0x1

    .line 488
    iput-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->hostResumed:Z

    .line 489
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->naviView:Lcom/amap/api/navi/AMapNaviView;

    invoke-virtual {p0}, Lcom/amap/api/navi/AMapNaviView;->onResume()V

    :cond_11
    :goto_11
    return-void
.end method

.method protected onSizeChanged(IIII)V
    .registers 5

    .line 528
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/FrameLayout;->onSizeChanged(IIII)V

    if-lez p1, :cond_27

    if-lez p2, :cond_27

    .line 530
    iget-object p3, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    div-int/lit8 p1, p1, 0x2

    div-int/lit8 p2, p2, 0x2

    invoke-virtual {p3, p1, p2}, Lcom/amap/api/maps/AMap;->setPointToCenter(II)V

    .line 531
    iget-boolean p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->debugCaptureProbeEnabled:Z

    if-eqz p1, :cond_27

    iget-boolean p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureProbeScheduled:Z

    if-nez p1, :cond_27

    const/4 p1, 0x1

    .line 532
    iput-boolean p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureProbeScheduled:Z

    .line 533
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    new-instance p2, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda5;

    invoke-direct {p2, p0}, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda5;-><init>(Lcom/example/bleconnectse/AmapNavigationView;)V

    const-wide/16 p3, 0x3e8

    invoke-virtual {p1, p2, p3, p4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_27
    return-void
.end method

.method public final searchDestinationSuggestions(Ljava/lang/String;)V
    .registers 10

    const-string v0, "destinationQuery"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 345
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-eqz v0, :cond_a

    return-void

    .line 346
    :cond_a
    check-cast p1, Ljava/lang/CharSequence;

    invoke-static {p1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    .line 348
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x2

    if-lt v0, v1, :cond_80

    .line 349
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->parseCoordinate(Ljava/lang/String;)Lcom/amap/api/maps/model/LatLng;

    move-result-object v0

    if-nez v0, :cond_80

    .line 350
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->selectedSuggestion:Lcom/example/bleconnectse/AmapDestinationSuggestion;

    const/4 v1, 0x0

    if-eqz v0, :cond_2b

    invoke-virtual {v0}, Lcom/example/bleconnectse/AmapDestinationSuggestion;->getName()Ljava/lang/String;

    move-result-object v0

    goto :goto_2c

    :cond_2b
    move-object v0, v1

    :goto_2c
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_33

    goto :goto_80

    .line 356
    :cond_33
    iput-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->selectedSuggestion:Lcom/example/bleconnectse/AmapDestinationSuggestion;

    .line 357
    iget v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->suggestionRequestSequence:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->suggestionRequestSequence:I

    .line 358
    new-instance v2, Lcom/amap/api/services/help/InputtipsQuery;

    const-string v3, ""

    invoke-direct {v2, p1, v3}, Lcom/amap/api/services/help/InputtipsQuery;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p1, 0x0

    .line 359
    invoke-virtual {v2, p1}, Lcom/amap/api/services/help/InputtipsQuery;->setCityLimit(Z)V

    .line 360
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->currentLocation:Lcom/amap/api/maps/model/LatLng;

    if-eqz p1, :cond_56

    .line 361
    new-instance v3, Lcom/amap/api/services/core/LatLonPoint;

    iget-wide v4, p1, Lcom/amap/api/maps/model/LatLng;->latitude:D

    iget-wide v6, p1, Lcom/amap/api/maps/model/LatLng;->longitude:D

    invoke-direct {v3, v4, v5, v6, v7}, Lcom/amap/api/services/core/LatLonPoint;-><init>(DD)V

    invoke-virtual {v2, v3}, Lcom/amap/api/services/help/InputtipsQuery;->setLocation(Lcom/amap/api/services/core/LatLonPoint;)V

    .line 365
    :cond_56
    :try_start_56
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->inputtips:Lcom/amap/api/services/help/Inputtips;

    if-eqz p1, :cond_5d

    invoke-virtual {p1, v1}, Lcom/amap/api/services/help/Inputtips;->setInputtipsListener(Lcom/amap/api/services/help/Inputtips$InputtipsListener;)V

    .line 366
    :cond_5d
    new-instance p1, Lcom/amap/api/services/help/Inputtips;

    invoke-virtual {p0}, Lcom/example/bleconnectse/AmapNavigationView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {p1, v1, v2}, Lcom/amap/api/services/help/Inputtips;-><init>(Landroid/content/Context;Lcom/amap/api/services/help/InputtipsQuery;)V

    .line 367
    new-instance v1, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda9;

    invoke-direct {v1, p0, v0}, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda9;-><init>(Lcom/example/bleconnectse/AmapNavigationView;I)V

    invoke-virtual {p1, v1}, Lcom/amap/api/services/help/Inputtips;->setInputtipsListener(Lcom/amap/api/services/help/Inputtips$InputtipsListener;)V

    .line 399
    invoke-virtual {p1}, Lcom/amap/api/services/help/Inputtips;->requestInputtipsAsyn()V

    .line 366
    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->inputtips:Lcom/amap/api/services/help/Inputtips;
    :try_end_77
    .catchall {:try_start_56 .. :try_end_77} :catchall_78

    return-void

    .line 402
    :catchall_78
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->publishSuggestions(Ljava/util/List;)V

    return-void

    .line 352
    :cond_80
    :goto_80
    iget p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->suggestionRequestSequence:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->suggestionRequestSequence:I

    .line 353
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->publishSuggestions(Ljava/util/List;)V

    return-void
.end method

.method public final selectDestinationSuggestion(Lcom/example/bleconnectse/AmapDestinationSuggestion;)V
    .registers 3

    const-string v0, "suggestion"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 407
    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->selectedSuggestion:Lcom/example/bleconnectse/AmapDestinationSuggestion;

    .line 408
    iget p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->suggestionRequestSequence:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->suggestionRequestSequence:I

    .line 409
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->inputtips:Lcom/amap/api/services/help/Inputtips;

    if-eqz p1, :cond_15

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/amap/api/services/help/Inputtips;->setInputtipsListener(Lcom/amap/api/services/help/Inputtips$InputtipsListener;)V

    .line 410
    :cond_15
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->publishSuggestions(Ljava/util/List;)V

    return-void
.end method

.method public final setLocationPermissionGranted(Z)V
    .registers 4

    .line 335
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-eqz v0, :cond_5

    goto :goto_2a

    :cond_5
    const/4 v0, 0x0

    if-eqz p1, :cond_10

    .line 336
    invoke-direct {p0}, Lcom/example/bleconnectse/AmapNavigationView;->hasLocationPermission()Z

    move-result p1

    if-eqz p1, :cond_10

    const/4 p1, 0x1

    goto :goto_11

    :cond_10
    move p1, v0

    :goto_11
    if-eqz p1, :cond_1b

    .line 337
    iget-boolean v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->emulatorNavigationActive:Z

    if-nez v1, :cond_1b

    .line 338
    invoke-direct {p0}, Lcom/example/bleconnectse/AmapNavigationView;->startRealLocationTracking()V

    return-void

    :cond_1b
    if-nez p1, :cond_2a

    .line 339
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    invoke-virtual {p1}, Lcom/amap/api/maps/AMap;->isMyLocationEnabled()Z

    move-result p1

    if-eqz p1, :cond_2a

    .line 340
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->map:Lcom/amap/api/maps/AMap;

    invoke-virtual {p0, v0}, Lcom/amap/api/maps/AMap;->setMyLocationEnabled(Z)V

    :cond_2a
    :goto_2a
    return-void
.end method

.method public final startPublishing()V
    .registers 4

    .line 469
    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->publishing:Z

    if-nez v0, :cond_25

    iget-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->closed:Z

    if-eqz v0, :cond_9

    goto :goto_25

    :cond_9
    const/4 v0, 0x1

    .line 470
    iput-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->publishing:Z

    .line 471
    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    add-int/2addr v1, v0

    iput v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    const/4 v0, 0x0

    .line 472
    iput v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyFailures:I

    const-wide/16 v1, 0x0

    .line 473
    iput-wide v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->pixelCopyRetryAfter:J

    .line 474
    iput-wide v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureFpsWindowStartedAt:J

    .line 475
    iput v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->capturedFramesInWindow:I

    .line 476
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView;->framePublisher:Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;

    check-cast p0, Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_25
    :goto_25
    return-void
.end method

.method public final stopPublishing()V
    .registers 4

    const/4 v0, 0x0

    .line 480
    iput-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->publishing:Z

    .line 481
    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->captureGeneration:I

    .line 482
    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView;->mainHandler:Landroid/os/Handler;

    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView;->framePublisher:Lcom/example/bleconnectse/AmapNavigationView$framePublisher$1;

    check-cast v2, Ljava/lang/Runnable;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 483
    iput-boolean v0, p0, Lcom/example/bleconnectse/AmapNavigationView;->snapshotInFlight:Z

    return-void
.end method
