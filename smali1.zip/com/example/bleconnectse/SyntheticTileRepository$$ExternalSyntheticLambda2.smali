# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda2;->f$0:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    iget p0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda2;->f$0:I

    check-cast p1, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    invoke-static {p0, p1}, Lcom/example/bleconnectse/SyntheticTileRepository;->clipPolygon$lambda$31(ILcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;)Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method
