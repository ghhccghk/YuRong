# classes2.dex

.class final Lcom/example/bleconnectse/OtaHttpServer;
.super Ljava/lang/Object;
.source "YadeaOtaClient.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nYadeaOtaClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 YadeaOtaClient.kt\ncom/example/bleconnectse/OtaHttpServer\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,2252:1\n1#2:2253\n1869#3,2:2254\n295#3,2:2256\n*S KotlinDebug\n*F\n+ 1 YadeaOtaClient.kt\ncom/example/bleconnectse/OtaHttpServer\n*L\n2133#1:2254,2\n2145#1:2256,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\b\u0002\u0018\u00002\u00020\u0001B9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u000b¢\u0006\u0004\b\f\u0010\rJ\u0006\u0010\u0016\u001a\u00020\tJ\u0006\u0010\u0017\u001a\u00020\tJ\b\u0010\u0018\u001a\u00020\tH\u0002J\u0010\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u001bH\u0002J\u0010\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u001fH\u0002J\u0010\u0010 \u001a\u00020\u00032\u0006\u0010!\u001a\u00020\bH\u0002J\u001a\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010\b2\u0006\u0010%\u001a\u00020\u0003H\u0002J\u0018\u0010&\u001a\u00020\t2\u0006\u0010\'\u001a\u00020(2\u0006\u0010)\u001a\u00020\u0005H\u0002J \u0010*\u001a\u00020\t2\u0006\u0010\'\u001a\u00020(2\u0006\u0010+\u001a\u00020#2\u0006\u0010)\u001a\u00020\u0005H\u0002J\u0018\u0010,\u001a\u00020\t2\u0006\u0010\'\u001a\u00020(2\u0006\u0010%\u001a\u00020\u0003H\u0002J(\u0010-\u001a\u00020\t2\u0006\u0010\'\u001a\u00020(2\u0006\u0010.\u001a\u00020\u00032\u0006\u0010/\u001a\u00020\b2\u0006\u00100\u001a\u00020\bH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u000e\u001a\u00020\u000f@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00061"
    }
    d2 = {
        "Lcom/example/bleconnectse/OtaHttpServer;",
        "",
        "port",
        "",
        "firmware",
        "",
        "logger",
        "Lkotlin/Function1;",
        "",
        "",
        "onFinish",
        "Lkotlin/Function0;",
        "<init>",
        "(I[BLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V",
        "value",
        "",
        "isRunning",
        "()Z",
        "serverSocket",
        "Ljava/net/ServerSocket;",
        "serverThread",
        "Ljava/lang/Thread;",
        "start",
        "stop",
        "serveLoop",
        "handleClient",
        "socket",
        "Ljava/net/Socket;",
        "readRequest",
        "Lcom/example/bleconnectse/HttpRequest;",
        "input",
        "Ljava/io/InputStream;",
        "finishState",
        "path",
        "parseRange",
        "Lcom/example/bleconnectse/Range;",
        "header",
        "size",
        "writeFullContent",
        "output",
        "Ljava/io/OutputStream;",
        "data",
        "writePartialContent",
        "range",
        "writeRangeNotSatisfiable",
        "writeSimple",
        "code",
        "reason",
        "body",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final firmware:[B

.field private volatile isRunning:Z

.field private final logger:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final onFinish:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final port:I

.field private serverSocket:Ljava/net/ServerSocket;

.field private serverThread:Ljava/lang/Thread;


# direct methods
.method public static synthetic $r8$lambda$dhGINebUvOTik0JhYDrXlpJg3xo(Lcom/example/bleconnectse/OtaHttpServer;)V
    .registers 1

    invoke-direct {p0}, Lcom/example/bleconnectse/OtaHttpServer;->serveLoop()V

    return-void
.end method

.method public constructor <init>(I[BLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[B",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "firmware"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "logger"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onFinish"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2043
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2044
    iput p1, p0, Lcom/example/bleconnectse/OtaHttpServer;->port:I

    .line 2045
    iput-object p2, p0, Lcom/example/bleconnectse/OtaHttpServer;->firmware:[B

    .line 2046
    iput-object p3, p0, Lcom/example/bleconnectse/OtaHttpServer;->logger:Lkotlin/jvm/functions/Function1;

    .line 2047
    iput-object p4, p0, Lcom/example/bleconnectse/OtaHttpServer;->onFinish:Lkotlin/jvm/functions/Function0;

    return-void
.end method

.method private final finishState(Ljava/lang/String;)I
    .registers 8

    const/16 p0, 0x3f

    .line 2143
    const-string v0, ""

    invoke-static {p1, p0, v0}, Lkotlin/text/StringsKt;->substringAfter(Ljava/lang/String;CLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 2144
    move-object v0, p0

    check-cast v0, Ljava/lang/CharSequence;

    const/4 p0, 0x1

    new-array v1, p0, [C

    const/4 p1, 0x0

    const/16 v2, 0x26

    aput-char v2, v1, p1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static/range {v0 .. v5}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 2256
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_21
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v1, :cond_39

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v4, v1

    check-cast v4, Ljava/lang/String;

    .line 2145
    const-string v5, "finish="

    invoke-static {v4, v5, p1, v2, v3}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_21

    goto :goto_3a

    :cond_39
    move-object v1, v3

    :goto_3a
    check-cast v1, Ljava/lang/String;

    if-eqz v1, :cond_5f

    const/16 v0, 0x3d

    .line 2146
    invoke-static {v1, v0, v3, v2, v3}, Lkotlin/text/StringsKt;->substringAfter$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_5f

    .line 2147
    invoke-static {v0}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_5f

    .line 2148
    move-object v1, v0

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    if-eqz v1, :cond_57

    if-ne v1, p0, :cond_58

    :cond_57
    move-object v3, v0

    :cond_58
    if-eqz v3, :cond_5f

    .line 2144
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0

    :cond_5f
    return p1
.end method

.method private final handleClient(Ljava/net/Socket;)V
    .registers 16

    .line 2081
    const-string v0, "Not Found"

    const-string v1, "range"

    .line 0
    const-string v2, "HTTP sent "

    const-string v3, "HTTP sent full "

    const-string v4, "HTTP "

    const-string v5, "HTTP client failed: "

    .line 2081
    check-cast p1, Ljava/io/Closeable;

    :try_start_e
    move-object v6, p1

    check-cast v6, Ljava/net/Socket;
    :try_end_11
    .catchall {:try_start_e .. :try_end_11} :catchall_15b

    const/16 v7, 0x3a98

    const/4 v8, 0x0

    .line 2083
    :try_start_14
    invoke-virtual {v6, v7}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 2084
    invoke-virtual {v6}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v7

    const-string v9, "getInputStream(...)"

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v7}, Lcom/example/bleconnectse/OtaHttpServer;->readRequest(Ljava/io/InputStream;)Lcom/example/bleconnectse/HttpRequest;

    move-result-object v7

    .line 2085
    iget-object v9, p0, Lcom/example/bleconnectse/OtaHttpServer;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v6}, Ljava/net/Socket;->getInetAddress()Ljava/net/InetAddress;

    move-result-object v10

    invoke-virtual {v10}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7}, Lcom/example/bleconnectse/HttpRequest;->getPath()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v7}, Lcom/example/bleconnectse/HttpRequest;->getHeaders()Ljava/util/Map;

    move-result-object v12

    invoke-interface {v12, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    if-nez v12, :cond_40

    const-string v12, "none"

    :cond_40
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v13, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v10, " "

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v10, " Range="

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v9, v4}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2086
    invoke-virtual {v7}, Lcom/example/bleconnectse/HttpRequest;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v9, "/icm/upgrade"

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-static {v4, v9, v10, v11, v8}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v4
    :try_end_70
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_70} :catch_12c
    .catchall {:try_start_14 .. :try_end_70} :catchall_15b

    const-string v9, "getOutputStream(...)"

    if-nez v4, :cond_84

    .line 2087
    :try_start_74
    invoke-virtual {v6}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v1

    invoke-static {v1, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v2, 0x194

    invoke-direct {p0, v1, v2, v0, v0}, Lcom/example/bleconnectse/OtaHttpServer;->writeSimple(Ljava/io/OutputStream;ILjava/lang/String;Ljava/lang/String;)V
    :try_end_80
    .catch Ljava/lang/Exception; {:try_start_74 .. :try_end_80} :catch_12c
    .catchall {:try_start_74 .. :try_end_80} :catchall_15b

    .line 2088
    invoke-static {p1, v8}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-void

    .line 2090
    :cond_84
    :try_start_84
    invoke-virtual {v7}, Lcom/example/bleconnectse/HttpRequest;->getPath()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/OtaHttpServer;->finishState(Ljava/lang/String;)I

    move-result v0

    .line 2091
    invoke-virtual {v7}, Lcom/example/bleconnectse/HttpRequest;->getHeaders()Ljava/util/Map;

    move-result-object v4

    invoke-interface {v4, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    iget-object v10, p0, Lcom/example/bleconnectse/OtaHttpServer;->firmware:[B

    array-length v10, v10

    invoke-direct {p0, v4, v10}, Lcom/example/bleconnectse/OtaHttpServer;->parseRange(Ljava/lang/String;I)Lcom/example/bleconnectse/Range;

    move-result-object v4

    .line 2092
    invoke-virtual {v4}, Lcom/example/bleconnectse/Range;->getValid()Z

    move-result v10

    if-nez v10, :cond_b4

    .line 2093
    invoke-virtual {v6}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    invoke-static {v0, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, Lcom/example/bleconnectse/OtaHttpServer;->firmware:[B

    array-length v1, v1

    invoke-direct {p0, v0, v1}, Lcom/example/bleconnectse/OtaHttpServer;->writeRangeNotSatisfiable(Ljava/io/OutputStream;I)V
    :try_end_b0
    .catch Ljava/lang/Exception; {:try_start_84 .. :try_end_b0} :catch_12c
    .catchall {:try_start_84 .. :try_end_b0} :catchall_15b

    .line 2094
    invoke-static {p1, v8}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-void

    .line 2096
    :cond_b4
    :try_start_b4
    invoke-virtual {v7}, Lcom/example/bleconnectse/HttpRequest;->getHeaders()Ljava/util/Map;

    move-result-object v7

    invoke-interface {v7, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_e6

    .line 2097
    invoke-virtual {v6}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v1

    invoke-static {v1, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, Lcom/example/bleconnectse/OtaHttpServer;->firmware:[B

    invoke-direct {p0, v1, v2}, Lcom/example/bleconnectse/OtaHttpServer;->writeFullContent(Ljava/io/OutputStream;[B)V

    .line 2098
    iget-object v1, p0, Lcom/example/bleconnectse/OtaHttpServer;->logger:Lkotlin/jvm/functions/Function1;

    iget-object v2, p0, Lcom/example/bleconnectse/OtaHttpServer;->firmware:[B

    array-length v2, v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " bytes"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_123

    .line 2100
    :cond_e6
    invoke-virtual {v6}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v1

    invoke-static {v1, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v3, p0, Lcom/example/bleconnectse/OtaHttpServer;->firmware:[B

    invoke-direct {p0, v1, v4, v3}, Lcom/example/bleconnectse/OtaHttpServer;->writePartialContent(Ljava/io/OutputStream;Lcom/example/bleconnectse/Range;[B)V

    .line 2101
    iget-object v1, p0, Lcom/example/bleconnectse/OtaHttpServer;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v4}, Lcom/example/bleconnectse/Range;->getStart()I

    move-result v3

    invoke-virtual {v4}, Lcom/example/bleconnectse/Range;->getEnd()I

    move-result v4

    iget-object v6, p0, Lcom/example/bleconnectse/OtaHttpServer;->firmware:[B

    array-length v6, v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "-"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_123
    const/4 v1, 0x1

    if-ne v0, v1, :cond_155

    .line 2103
    iget-object v0, p0, Lcom/example/bleconnectse/OtaHttpServer;->onFinish:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;
    :try_end_12b
    .catch Ljava/lang/Exception; {:try_start_b4 .. :try_end_12b} :catch_12c
    .catchall {:try_start_b4 .. :try_end_12b} :catchall_15b

    goto :goto_155

    :catch_12c
    move-exception v0

    .line 2105
    :try_start_12d
    iget-object p0, p0, Lcom/example/bleconnectse/OtaHttpServer;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2107
    :cond_155
    :goto_155
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_157
    .catchall {:try_start_12d .. :try_end_157} :catchall_15b

    .line 2081
    invoke-static {p1, v8}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-void

    :catchall_15b
    move-exception p0

    :try_start_15c
    throw p0
    :try_end_15d
    .catchall {:try_start_15c .. :try_end_15d} :catchall_15d

    :catchall_15d
    move-exception v0

    invoke-static {p1, p0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method private final parseRange(Ljava/lang/String;I)Lcom/example/bleconnectse/Range;
    .registers 13

    const/4 p0, 0x1

    const/4 v0, 0x0

    if-eqz p1, :cond_88

    const/4 v1, 0x0

    .line 2153
    const-string v2, "bytes="

    const/4 v3, 0x2

    invoke-static {p1, v2, v0, v3, v1}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10

    goto/16 :goto_88

    .line 2154
    :cond_10
    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {p1, v2}, Lkotlin/text/StringsKt;->removePrefix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    move-object v4, p1

    check-cast v4, Ljava/lang/CharSequence;

    new-array v5, p0, [Ljava/lang/String;

    const-string p1, "-"

    aput-object p1, v5, v0

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static/range {v4 .. v9}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object p1

    .line 2155
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-eq v1, v3, :cond_34

    new-instance p1, Lcom/example/bleconnectse/Range;

    sub-int/2addr p2, p0

    invoke-direct {p1, v0, p2, v0}, Lcom/example/bleconnectse/Range;-><init>(IIZ)V

    return-object p1

    .line 2156
    :cond_34
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_42

    const-string v1, "0"

    :cond_42
    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v1

    if-eqz v1, :cond_81

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    .line 2157
    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/CharSequence;

    invoke-static {p1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_60

    add-int/lit8 p1, p2, -0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    :cond_60
    check-cast p1, Ljava/lang/String;

    invoke-static {p1}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p1

    if-eqz p1, :cond_7a

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    .line 2158
    new-instance v2, Lcom/example/bleconnectse/Range;

    if-ltz v1, :cond_75

    if-lt p1, v1, :cond_75

    if-ge p1, p2, :cond_75

    goto :goto_76

    :cond_75
    move p0, v0

    :goto_76
    invoke-direct {v2, v1, p1, p0}, Lcom/example/bleconnectse/Range;-><init>(IIZ)V

    return-object v2

    .line 2157
    :cond_7a
    new-instance p1, Lcom/example/bleconnectse/Range;

    sub-int/2addr p2, p0

    invoke-direct {p1, v0, p2, v0}, Lcom/example/bleconnectse/Range;-><init>(IIZ)V

    return-object p1

    .line 2156
    :cond_81
    new-instance p1, Lcom/example/bleconnectse/Range;

    sub-int/2addr p2, p0

    invoke-direct {p1, v0, p2, v0}, Lcom/example/bleconnectse/Range;-><init>(IIZ)V

    return-object p1

    .line 2153
    :cond_88
    :goto_88
    new-instance p1, Lcom/example/bleconnectse/Range;

    sub-int/2addr p2, p0

    invoke-direct {p1, v0, p2, p0}, Lcom/example/bleconnectse/Range;-><init>(IIZ)V

    return-object p1
.end method

.method private final readRequest(Ljava/io/InputStream;)Lcom/example/bleconnectse/HttpRequest;
    .registers 11

    .line 2111
    new-instance p0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 2113
    :goto_5
    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    move-result v0

    if-ltz v0, :cond_44

    .line 2115
    invoke-virtual {p0, v0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 2116
    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    .line 2117
    array-length v1, v0

    const/4 v2, 0x4

    if-lt v1, v2, :cond_33

    add-int/lit8 v2, v1, -0x4

    .line 2119
    aget-byte v2, v0, v2

    const/16 v3, 0xd

    if-ne v2, v3, :cond_33

    add-int/lit8 v2, v1, -0x3

    .line 2120
    aget-byte v2, v0, v2

    const/16 v4, 0xa

    if-ne v2, v4, :cond_33

    add-int/lit8 v2, v1, -0x2

    .line 2121
    aget-byte v2, v0, v2

    if-ne v2, v3, :cond_33

    add-int/lit8 v1, v1, -0x1

    .line 2122
    aget-byte v0, v0, v1

    if-ne v0, v4, :cond_33

    goto :goto_44

    .line 2126
    :cond_33
    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v0

    const/16 v1, 0x4000

    if-gt v0, v1, :cond_3c

    goto :goto_5

    :cond_3c
    new-instance p0, Ljava/io/IOException;

    const-string p1, "HTTP header too large"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 2128
    :cond_44
    :goto_44
    sget-object p1, Ljava/nio/charset/StandardCharsets;->ISO_8859_1:Ljava/nio/charset/Charset;

    invoke-virtual {p1}, Ljava/nio/charset/Charset;->name()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/io/ByteArrayOutputStream;->toString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 2129
    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast p0, Ljava/lang/CharSequence;

    new-instance p1, Lkotlin/text/Regex;

    const-string v0, "\\r?\\n"

    invoke-direct {p1, v0}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {p1, p0, v0}, Lkotlin/text/Regex;->split(Ljava/lang/CharSequence;I)Ljava/util/List;

    move-result-object p0

    .line 2130
    invoke-static {p0}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    const/4 v1, 0x1

    if-eqz p1, :cond_7a

    move-object v2, p1

    check-cast v2, Ljava/lang/CharSequence;

    new-array v3, v1, [Ljava/lang/String;

    const-string p1, " "

    aput-object p1, v3, v0

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object p1

    goto :goto_7b

    :cond_7a
    const/4 p1, 0x0

    :goto_7b
    if-nez p1, :cond_81

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p1

    .line 2131
    :cond_81
    invoke-static {p1, v1}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-nez p1, :cond_8b

    const-string p1, "/"

    .line 2132
    :cond_8b
    new-instance v2, Ljava/util/LinkedHashMap;

    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v2, Ljava/util/Map;

    .line 2133
    check-cast p0, Ljava/lang/Iterable;

    invoke-static {p0, v1}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object p0

    check-cast p0, Ljava/lang/Iterable;

    .line 2254
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_9e
    :goto_9e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_f3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 2134
    move-object v3, v1

    check-cast v3, Ljava/lang/CharSequence;

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/16 v4, 0x3a

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v3 .. v8}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v3

    if-lez v3, :cond_9e

    .line 2136
    invoke-virtual {v1, v0, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const-string v5, "substring(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Ljava/lang/CharSequence;

    invoke-static {v4}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    sget-object v6, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v7, "US"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4, v6}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    const-string v6, "toLowerCase(...)"

    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    add-int/lit8 v3, v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v2, v4, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_9e

    .line 2139
    :cond_f3
    new-instance p0, Lcom/example/bleconnectse/HttpRequest;

    invoke-direct {p0, p1, v2}, Lcom/example/bleconnectse/HttpRequest;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    return-object p0
.end method

.method private final serveLoop()V
    .registers 5

    .line 2070
    :cond_0
    :goto_0
    iget-boolean v0, p0, Lcom/example/bleconnectse/OtaHttpServer;->isRunning:Z

    if-eqz v0, :cond_3e

    .line 2072
    :try_start_4
    iget-object v0, p0, Lcom/example/bleconnectse/OtaHttpServer;->serverSocket:Ljava/net/ServerSocket;

    if-eqz v0, :cond_3e

    invoke-virtual {v0}, Ljava/net/ServerSocket;->accept()Ljava/net/Socket;

    move-result-object v0

    if-nez v0, :cond_f

    goto :goto_3e

    .line 2073
    :cond_f
    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda0;

    invoke-direct {v2, p0, v0}, Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda0;-><init>(Lcom/example/bleconnectse/OtaHttpServer;Ljava/net/Socket;)V

    const-string/jumbo v0, "yadea-ota-http-client"

    invoke-direct {v1, v2, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V
    :try_end_1f
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_1f} :catch_20

    goto :goto_0

    :catch_20
    move-exception v0

    .line 2075
    iget-boolean v1, p0, Lcom/example/bleconnectse/OtaHttpServer;->isRunning:Z

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/example/bleconnectse/OtaHttpServer;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v0}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "HTTP accept failed: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_3e
    :goto_3e
    return-void
.end method

.method static final serveLoop$lambda$1(Lcom/example/bleconnectse/OtaHttpServer;Ljava/net/Socket;)V
    .registers 2

    .line 2073
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/OtaHttpServer;->handleClient(Ljava/net/Socket;)V

    return-void
.end method

.method private final writeFullContent(Ljava/io/OutputStream;[B)V
    .registers 5

    .line 2166
    array-length p0, p2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "HTTP/1.1 200 OK\r\nServer: ICM-Server/1.0\r\nConnection: close\r\nContent-Type: application/octet-stream\r\nContent-Length: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, "\r\nAccept-Range: bytes\r\n\r\n"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 2169
    sget-object v0, Ljava/nio/charset/StandardCharsets;->ISO_8859_1:Ljava/nio/charset/Charset;

    const-string v1, "ISO_8859_1"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    const-string v0, "getBytes(...)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/io/OutputStream;->write([B)V

    .line 2170
    invoke-virtual {p1, p2}, Ljava/io/OutputStream;->write([B)V

    .line 2171
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    return-void
.end method

.method private final writePartialContent(Ljava/io/OutputStream;Lcom/example/bleconnectse/Range;[B)V
    .registers 9

    .line 2175
    invoke-virtual {p2}, Lcom/example/bleconnectse/Range;->getEnd()I

    move-result p0

    invoke-virtual {p2}, Lcom/example/bleconnectse/Range;->getStart()I

    move-result v0

    sub-int/2addr p0, v0

    add-int/lit8 p0, p0, 0x1

    .line 2180
    invoke-virtual {p2}, Lcom/example/bleconnectse/Range;->getStart()I

    move-result v0

    invoke-virtual {p2}, Lcom/example/bleconnectse/Range;->getEnd()I

    move-result v1

    array-length v2, p3

    .line 2181
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "HTTP/1.1 206 Partial Content\r\nServer: ICM-Server/1.0\r\nConnection: close\r\nContent-Type: application/octet-stream\r\nContent-Range: Bytes "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, "-"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\r\nContent-Length: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\r\nAccept-Range: bytes\r\n\r\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2184
    sget-object v1, Ljava/nio/charset/StandardCharsets;->ISO_8859_1:Ljava/nio/charset/Charset;

    const-string v2, "ISO_8859_1"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const-string v1, "getBytes(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 2185
    invoke-virtual {p2}, Lcom/example/bleconnectse/Range;->getStart()I

    move-result p2

    invoke-virtual {p1, p3, p2, p0}, Ljava/io/OutputStream;->write([BII)V

    .line 2186
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    return-void
.end method

.method private final writeRangeNotSatisfiable(Ljava/io/OutputStream;I)V
    .registers 4

    .line 2193
    new-instance p0, Ljava/lang/StringBuilder;

    const-string v0, "HTTP/1.1 416 Requested Range Not Satisfiable\r\nServer: ICM-Server/1.0\r\nConnection: close\r\nContent-Range: Bytes */"

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string p2, "\r\nAccept-Range: bytes\r\n\r\n"

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 2196
    sget-object p2, Ljava/nio/charset/StandardCharsets;->ISO_8859_1:Ljava/nio/charset/Charset;

    const-string v0, "ISO_8859_1"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    const-string p2, "getBytes(...)"

    invoke-static {p0, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/io/OutputStream;->write([B)V

    .line 2197
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    return-void
.end method

.method private final writeSimple(Ljava/io/OutputStream;ILjava/lang/String;Ljava/lang/String;)V
    .registers 8

    .line 2201
    sget-object p0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    const-string v0, "UTF_8"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p4, p0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    const-string p4, "getBytes(...)"

    invoke-static {p0, p4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2206
    array-length v0, p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "HTTP/1.1 "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string v1, " "

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string p3, "\r\nServer: ICM-Server/1.0\r\nConnection: close\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string p3, "\r\n\r\n"

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 2208
    sget-object p3, Ljava/nio/charset/StandardCharsets;->ISO_8859_1:Ljava/nio/charset/Charset;

    const-string v0, "ISO_8859_1"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p2, p3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p2

    invoke-static {p2, p4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljava/io/OutputStream;->write([B)V

    .line 2209
    invoke-virtual {p1, p0}, Ljava/io/OutputStream;->write([B)V

    .line 2210
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    return-void
.end method


# virtual methods
.method public final isRunning()Z
    .registers 1

    .line 2049
    iget-boolean p0, p0, Lcom/example/bleconnectse/OtaHttpServer;->isRunning:Z

    return p0
.end method

.method public final start()V
    .registers 4

    .line 2056
    new-instance v0, Ljava/net/ServerSocket;

    iget v1, p0, Lcom/example/bleconnectse/OtaHttpServer;->port:I

    invoke-direct {v0, v1}, Ljava/net/ServerSocket;-><init>(I)V

    iput-object v0, p0, Lcom/example/bleconnectse/OtaHttpServer;->serverSocket:Ljava/net/ServerSocket;

    const/4 v0, 0x1

    .line 2057
    iput-boolean v0, p0, Lcom/example/bleconnectse/OtaHttpServer;->isRunning:Z

    .line 2058
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/OtaHttpServer;)V

    const-string/jumbo v2, "yadea-ota-http"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    iput-object v0, p0, Lcom/example/bleconnectse/OtaHttpServer;->serverThread:Ljava/lang/Thread;

    return-void
.end method

.method public final stop()V
    .registers 2

    const/4 v0, 0x0

    .line 2062
    iput-boolean v0, p0, Lcom/example/bleconnectse/OtaHttpServer;->isRunning:Z

    .line 2064
    :try_start_3
    iget-object p0, p0, Lcom/example/bleconnectse/OtaHttpServer;->serverSocket:Ljava/net/ServerSocket;

    if-eqz p0, :cond_a

    invoke-virtual {p0}, Ljava/net/ServerSocket;->close()V
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_a} :catch_a

    :catch_a
    :cond_a
    return-void
.end method
