# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/amap/api/maps/AMap$OnMapLongClickListener;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/AmapNavigationView;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/AmapNavigationView;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda3;->f$0:Lcom/example/bleconnectse/AmapNavigationView;

    return-void
.end method


# virtual methods
.method public final onMapLongClick(Lcom/amap/api/maps/model/LatLng;)V
    .registers 2

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda3;->f$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->_init_$lambda$3(Lcom/example/bleconnectse/AmapNavigationView;Lcom/amap/api/maps/model/LatLng;)V

    return-void
.end method
