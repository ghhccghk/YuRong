# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final synthetic f$1:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$2:I

.field public final synthetic f$3:Z

.field public final synthetic f$4:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;->f$0:Ljava/util/concurrent/atomic/AtomicBoolean;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;->f$1:Lcom/example/bleconnectse/YadeaOtaClient;

    iput p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;->f$2:I

    iput-boolean p4, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;->f$3:Z

    iput-object p5, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;->f$4:Lkotlin/jvm/functions/Function0;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;->f$0:Ljava/util/concurrent/atomic/AtomicBoolean;

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;->f$1:Lcom/example/bleconnectse/YadeaOtaClient;

    iget v2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;->f$2:I

    iget-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;->f$3:Z

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;->f$4:Lkotlin/jvm/functions/Function0;

    invoke-static {v0, v1, v2, v3, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal$lambda$127(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V

    return-void
.end method
