# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda51;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:[Lcom/example/bleconnectse/AmapNavigationView;

.field public final synthetic f$1:Lkotlin/jvm/functions/Function1;

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>([Lcom/example/bleconnectse/AmapNavigationView;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda51;->f$0:[Lcom/example/bleconnectse/AmapNavigationView;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda51;->f$1:Lkotlin/jvm/functions/Function1;

    iput-object p3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda51;->f$2:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda51;->f$3:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda51;->f$0:[Lcom/example/bleconnectse/AmapNavigationView;

    iget-object v1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda51;->f$1:Lkotlin/jvm/functions/Function1;

    iget-object v2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda51;->f$2:Landroidx/compose/runtime/MutableState;

    iget-object v3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda51;->f$3:Landroidx/compose/runtime/MutableState;

    move-object v4, p1

    check-cast v4, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-static/range {v0 .. v5}, Lcom/example/bleconnectse/MainActivityKt;->AmapNavigationScreen$lambda$38$lambda$35([Lcom/example/bleconnectse/AmapNavigationView;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
