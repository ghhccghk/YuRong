# classes2.dex

.class public final enum Lcom/example/bleconnectse/BleTileSource;
.super Ljava/lang/Enum;
.source "BleTileClient.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/example/bleconnectse/BleTileSource;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\t\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0019\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bj\u0002\b\fj\u0002\b\r¨\u0006\u000e"
    }
    d2 = {
        "Lcom/example/bleconnectse/BleTileSource;",
        "",
        "label",
        "",
        "wireValue",
        "",
        "<init>",
        "(Ljava/lang/String;ILjava/lang/String;I)V",
        "getLabel",
        "()Ljava/lang/String;",
        "getWireValue",
        "()I",
        "Simulated",
        "AmapTest",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/example/bleconnectse/BleTileSource;

.field public static final enum AmapTest:Lcom/example/bleconnectse/BleTileSource;

.field public static final enum Simulated:Lcom/example/bleconnectse/BleTileSource;


# instance fields
.field private final label:Ljava/lang/String;

.field private final wireValue:I


# direct methods
.method private static final synthetic $values()[Lcom/example/bleconnectse/BleTileSource;
    .registers 2

    sget-object v0, Lcom/example/bleconnectse/BleTileSource;->Simulated:Lcom/example/bleconnectse/BleTileSource;

    sget-object v1, Lcom/example/bleconnectse/BleTileSource;->AmapTest:Lcom/example/bleconnectse/BleTileSource;

    filled-new-array {v0, v1}, [Lcom/example/bleconnectse/BleTileSource;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 5

    .line 33
    new-instance v0, Lcom/example/bleconnectse/BleTileSource;

    const-string v1, "Simulated"

    const/4 v2, 0x0

    const-string/jumbo v3, "模拟瓦片"

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/example/bleconnectse/BleTileSource;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    sput-object v0, Lcom/example/bleconnectse/BleTileSource;->Simulated:Lcom/example/bleconnectse/BleTileSource;

    .line 34
    new-instance v0, Lcom/example/bleconnectse/BleTileSource;

    const-string/jumbo v1, "高德瓦片"

    const/4 v2, 0x2

    const-string v3, "AmapTest"

    invoke-direct {v0, v3, v4, v1, v2}, Lcom/example/bleconnectse/BleTileSource;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    sput-object v0, Lcom/example/bleconnectse/BleTileSource;->AmapTest:Lcom/example/bleconnectse/BleTileSource;

    invoke-static {}, Lcom/example/bleconnectse/BleTileSource;->$values()[Lcom/example/bleconnectse/BleTileSource;

    move-result-object v0

    sput-object v0, Lcom/example/bleconnectse/BleTileSource;->$VALUES:[Lcom/example/bleconnectse/BleTileSource;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/example/bleconnectse/BleTileSource;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;I)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)V"
        }
    .end annotation

    .line 32
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lcom/example/bleconnectse/BleTileSource;->label:Ljava/lang/String;

    iput p4, p0, Lcom/example/bleconnectse/BleTileSource;->wireValue:I

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/example/bleconnectse/BleTileSource;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/example/bleconnectse/BleTileSource;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/example/bleconnectse/BleTileSource;
    .registers 2

    const-class v0, Lcom/example/bleconnectse/BleTileSource;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/example/bleconnectse/BleTileSource;

    return-object p0
.end method

.method public static values()[Lcom/example/bleconnectse/BleTileSource;
    .registers 1

    sget-object v0, Lcom/example/bleconnectse/BleTileSource;->$VALUES:[Lcom/example/bleconnectse/BleTileSource;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/example/bleconnectse/BleTileSource;

    return-object v0
.end method


# virtual methods
.method public final getLabel()Ljava/lang/String;
    .registers 1

    .line 32
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileSource;->label:Ljava/lang/String;

    return-object p0
.end method

.method public final getWireValue()I
    .registers 1

    .line 32
    iget p0, p0, Lcom/example/bleconnectse/BleTileSource;->wireValue:I

    return p0
.end method
