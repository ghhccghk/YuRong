# classes2.dex

.class final Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$1$1$2$1$2$1$1;
.super Ljava/lang/Object;
.source "MainActivity.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/MainActivityKt;->CandidateListPanel(Lcom/example/bleconnectse/CandidatePanel;Lcom/example/bleconnectse/YadeaOtaClient;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

.field final synthetic $profile:Lcom/example/bleconnectse/YadeaWifiProfile;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;)V
    .registers 3

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$1$1$2$1$2$1$1;->$mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$1$1$2$1$2$1$1;->$profile:Lcom/example/bleconnectse/YadeaWifiProfile;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 1

    .line 1345
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$1$1$2$1$2$1$1;->invoke()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public final invoke()V
    .registers 3

    .line 1345
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$1$1$2$1$2$1$1;->$mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$1$1$2$1$2$1$1;->$profile:Lcom/example/bleconnectse/YadeaWifiProfile;

    const/4 v1, 0x1

    invoke-virtual {v0, p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->connectApProfile(Lcom/example/bleconnectse/YadeaWifiProfile;Z)V

    return-void
.end method
