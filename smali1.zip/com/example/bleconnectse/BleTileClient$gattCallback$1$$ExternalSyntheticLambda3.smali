# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$1:Landroid/bluetooth/BluetoothGatt;

.field public final synthetic f$2:I

.field public final synthetic f$3:I


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;II)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iput-object p2, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;->f$1:Landroid/bluetooth/BluetoothGatt;

    iput p3, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;->f$2:I

    iput p4, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;->f$3:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;->f$1:Landroid/bluetooth/BluetoothGatt;

    iget v2, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;->f$2:I

    iget p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda3;->f$3:I

    invoke-static {v0, v1, v2, p0}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->onConnectionStateChange$lambda$0(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;II)V

    return-void
.end method
