# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda38;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/CandidatePanel;

.field public final synthetic f$1:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$2:I


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/CandidatePanel;Lcom/example/bleconnectse/YadeaOtaClient;I)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda38;->f$0:Lcom/example/bleconnectse/CandidatePanel;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda38;->f$1:Lcom/example/bleconnectse/YadeaOtaClient;

    iput p3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda38;->f$2:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda38;->f$0:Lcom/example/bleconnectse/CandidatePanel;

    iget-object v1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda38;->f$1:Lcom/example/bleconnectse/YadeaOtaClient;

    iget p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda38;->f$2:I

    check-cast p1, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {v0, v1, p0, p1, p2}, Lcom/example/bleconnectse/MainActivityKt;->CandidateListPanel$lambda$129(Lcom/example/bleconnectse/CandidatePanel;Lcom/example/bleconnectse/YadeaOtaClient;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
