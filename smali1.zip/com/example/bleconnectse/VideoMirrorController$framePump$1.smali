# classes2.dex

.class public final Lcom/example/bleconnectse/VideoMirrorController$framePump$1;
.super Ljava/lang/Object;
.source "VideoMirrorController.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/VideoMirrorController;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nVideoMirrorController.kt\nKotlin\n*S Kotlin\n*F\n+ 1 VideoMirrorController.kt\ncom/example/bleconnectse/VideoMirrorController$framePump$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,333:1\n1#2:334\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016¨\u0006\u0004"
    }
    d2 = {
        "com/example/bleconnectse/VideoMirrorController$framePump$1",
        "Ljava/lang/Runnable;",
        "run",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/VideoMirrorController;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/VideoMirrorController;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    .line 57
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 8

    .line 59
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {v0}, Lcom/example/bleconnectse/VideoMirrorController;->access$getPlayer$p(Lcom/example/bleconnectse/VideoMirrorController;)Landroid/media/MediaPlayer;

    move-result-object v0

    .line 60
    iget-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {v1}, Lcom/example/bleconnectse/VideoMirrorController;->access$getPrepared$p(Lcom/example/bleconnectse/VideoMirrorController;)Z

    move-result v1

    if-eqz v1, :cond_a4

    if-eqz v0, :cond_a4

    .line 61
    iget-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    :try_start_12
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p0

    check-cast v2, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result v2

    int-to-long v2, v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2
    :try_end_24
    .catchall {:try_start_12 .. :try_end_24} :catchall_25

    goto :goto_30

    :catchall_25
    move-exception v2

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 62
    :goto_30
    iget-object v3, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-virtual {v3}, Lcom/example/bleconnectse/VideoMirrorController;->getPositionMs()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-static {v2}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_41

    move-object v2, v3

    :cond_41
    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    .line 61
    invoke-static {v1, v2, v3}, Lcom/example/bleconnectse/VideoMirrorController;->access$setPositionMs(Lcom/example/bleconnectse/VideoMirrorController;J)V

    .line 63
    :try_start_4a
    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v1, p0

    check-cast v1, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_5b
    .catchall {:try_start_4a .. :try_end_5b} :catchall_5c

    goto :goto_67

    :catchall_5c
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_67
    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_73

    move-object v0, v1

    :cond_73
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 64
    iget-object v1, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {v1, v0}, Lcom/example/bleconnectse/VideoMirrorController;->access$setPlaying(Lcom/example/bleconnectse/VideoMirrorController;Z)V

    .line 65
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    .line 67
    iget-object v3, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {v3}, Lcom/example/bleconnectse/VideoMirrorController;->access$getForegroundFrameCaptureEnabled$p(Lcom/example/bleconnectse/VideoMirrorController;)Z

    move-result v3

    if-eqz v3, :cond_a4

    if-eqz v0, :cond_a4

    .line 68
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {v0}, Lcom/example/bleconnectse/VideoMirrorController;->access$getLastFrameAt$p(Lcom/example/bleconnectse/VideoMirrorController;)J

    move-result-wide v3

    sub-long v3, v1, v3

    const-wide/16 v5, 0x64

    cmp-long v0, v3, v5

    if-ltz v0, :cond_a4

    .line 70
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {v0, v1, v2}, Lcom/example/bleconnectse/VideoMirrorController;->access$setLastFrameAt$p(Lcom/example/bleconnectse/VideoMirrorController;J)V

    .line 71
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {v0}, Lcom/example/bleconnectse/VideoMirrorController;->access$captureCurrentFrame(Lcom/example/bleconnectse/VideoMirrorController;)V

    .line 74
    :cond_a4
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-virtual {v0}, Lcom/example/bleconnectse/VideoMirrorController;->getPreviewVisible()Z

    move-result v0

    if-eqz v0, :cond_b9

    .line 75
    iget-object v0, p0, Lcom/example/bleconnectse/VideoMirrorController$framePump$1;->this$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {v0}, Lcom/example/bleconnectse/VideoMirrorController;->access$getMainHandler$p(Lcom/example/bleconnectse/VideoMirrorController;)Landroid/os/Handler;

    move-result-object v0

    check-cast p0, Ljava/lang/Runnable;

    const-wide/16 v1, 0x32

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_b9
    return-void
.end method
