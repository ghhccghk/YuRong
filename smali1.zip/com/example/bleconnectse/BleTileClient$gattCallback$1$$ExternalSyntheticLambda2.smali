# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$1:I

.field public final synthetic f$2:I

.field public final synthetic f$3:Landroid/bluetooth/BluetoothGatt;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/BleTileClient;IILandroid/bluetooth/BluetoothGatt;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iput p2, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;->f$1:I

    iput p3, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;->f$2:I

    iput-object p4, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;->f$3:Landroid/bluetooth/BluetoothGatt;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iget v1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;->f$1:I

    iget v2, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;->f$2:I

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda2;->f$3:Landroid/bluetooth/BluetoothGatt;

    invoke-static {v0, v1, v2, p0}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->onMtuChanged$lambda$1(Lcom/example/bleconnectse/BleTileClient;IILandroid/bluetooth/BluetoothGatt;)V

    return-void
.end method
