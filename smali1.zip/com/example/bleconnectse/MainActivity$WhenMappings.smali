# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivity$WhenMappings;
.super Ljava/lang/Object;
.source "MainActivity.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/bleconnectse/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1019
    name = "WhenMappings"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    invoke-static {}, Lcom/example/bleconnectse/PendingBleEntry;->values()[Lcom/example/bleconnectse/PendingBleEntry;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_7
    sget-object v1, Lcom/example/bleconnectse/PendingBleEntry;->Simulated:Lcom/example/bleconnectse/PendingBleEntry;

    invoke-virtual {v1}, Lcom/example/bleconnectse/PendingBleEntry;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_10} :catch_10

    :catch_10
    :try_start_10
    sget-object v1, Lcom/example/bleconnectse/PendingBleEntry;->Amap:Lcom/example/bleconnectse/PendingBleEntry;

    invoke-virtual {v1}, Lcom/example/bleconnectse/PendingBleEntry;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_19
    .catch Ljava/lang/NoSuchFieldError; {:try_start_10 .. :try_end_19} :catch_19

    :catch_19
    sput-object v0, Lcom/example/bleconnectse/MainActivity$WhenMappings;->$EnumSwitchMapping$0:[I

    return-void
.end method
