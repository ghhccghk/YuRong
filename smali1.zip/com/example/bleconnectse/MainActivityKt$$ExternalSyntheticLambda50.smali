# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$1:Z

.field public final synthetic f$2:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$3:Lcom/example/bleconnectse/NavigationTransport;

.field public final synthetic f$4:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$5:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$6:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Lcom/example/bleconnectse/NavigationTransport;Lcom/example/bleconnectse/BleTileClient;Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V
    .registers 8

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$0:Lkotlin/jvm/functions/Function0;

    iput-boolean p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$1:Z

    iput-object p3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$2:Lkotlin/jvm/functions/Function0;

    iput-object p4, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$3:Lcom/example/bleconnectse/NavigationTransport;

    iput-object p5, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$4:Lcom/example/bleconnectse/BleTileClient;

    iput-object p6, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$5:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p7, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$6:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$0:Lkotlin/jvm/functions/Function0;

    iget-boolean v1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$1:Z

    iget-object v2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$2:Lkotlin/jvm/functions/Function0;

    iget-object v3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$3:Lcom/example/bleconnectse/NavigationTransport;

    iget-object v4, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$4:Lcom/example/bleconnectse/BleTileClient;

    iget-object v5, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$5:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v6, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda50;->f$6:Ljava/lang/String;

    move-object v7, p1

    check-cast v7, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v8

    invoke-static/range {v0 .. v8}, Lcom/example/bleconnectse/MainActivityKt;->AmapNavigationScreen$lambda$38$lambda$18(Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Lcom/example/bleconnectse/NavigationTransport;Lcom/example/bleconnectse/BleTileClient;Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
