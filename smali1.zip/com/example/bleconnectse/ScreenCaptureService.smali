# classes2.dex

.class public final Lcom/example/bleconnectse/ScreenCaptureService;
.super Landroid/app/Service;
.source "ScreenCaptureService.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/ScreenCaptureService$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nScreenCaptureService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ScreenCaptureService.kt\ncom/example/bleconnectse/ScreenCaptureService\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,187:1\n1#2:188\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\b\b\u0007\u0018\u0000 \u001e2\u00020\u0001:\u0001\u001eB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0014\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016J\"\u0010\u0012\u001a\u00020\u00132\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u0013H\u0016J\u0012\u0010\u0016\u001a\u00020\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u0011H\u0016J\b\u0010\u0019\u001a\u00020\u0017H\u0016J\b\u0010\u001a\u001a\u00020\u0017H\u0002J\u0018\u0010\u001b\u001a\u00020\u00172\u0006\u0010\u001c\u001a\u00020\u00132\u0006\u0010\u001d\u001a\u00020\u0011H\u0002R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001f"
    }
    d2 = {
        "Lcom/example/bleconnectse/ScreenCaptureService;",
        "Landroid/app/Service;",
        "<init>",
        "()V",
        "projection",
        "Landroid/media/projection/MediaProjection;",
        "virtualDisplay",
        "Landroid/hardware/display/VirtualDisplay;",
        "imageReader",
        "Landroid/media/ImageReader;",
        "lastFrameAt",
        "",
        "stopping",
        "",
        "onBind",
        "Landroid/os/IBinder;",
        "intent",
        "Landroid/content/Intent;",
        "onStartCommand",
        "",
        "flags",
        "startId",
        "onTaskRemoved",
        "",
        "rootIntent",
        "onDestroy",
        "startAsForeground",
        "startCapture",
        "resultCode",
        "resultData",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field private static final ACTION_STOP:Ljava/lang/String; = "com.example.bleconnectse.STOP_SCREEN_CAPTURE"

.field private static final CHANNEL_ID:Ljava/lang/String; = "screen_mirror"

.field public static final Companion:Lcom/example/bleconnectse/ScreenCaptureService$Companion;

.field private static final EXTRA_RESULT_CODE:Ljava/lang/String; = "result_code"

.field private static final EXTRA_RESULT_DATA:Ljava/lang/String; = "result_data"

.field private static final NOTIFICATION_ID:I = 0x3ea


# instance fields
.field private imageReader:Landroid/media/ImageReader;

.field private lastFrameAt:J

.field private projection:Landroid/media/projection/MediaProjection;

.field private volatile stopping:Z

.field private virtualDisplay:Landroid/hardware/display/VirtualDisplay;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/example/bleconnectse/ScreenCaptureService$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/ScreenCaptureService$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/example/bleconnectse/ScreenCaptureService;->Companion:Lcom/example/bleconnectse/ScreenCaptureService$Companion;

    const/16 v0, 0x8

    sput v0, Lcom/example/bleconnectse/ScreenCaptureService;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 23
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static final synthetic access$getStopping$p(Lcom/example/bleconnectse/ScreenCaptureService;)Z
    .registers 1

    .line 23
    iget-boolean p0, p0, Lcom/example/bleconnectse/ScreenCaptureService;->stopping:Z

    return p0
.end method

.method private final startAsForeground()V
    .registers 6

    .line 67
    const-class v0, Landroid/app/NotificationManager;

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/ScreenCaptureService;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 68
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    const-string v3, "screen_mirror"

    if-lt v1, v2, :cond_1e

    .line 70
    new-instance v1, Landroid/app/NotificationChannel;

    .line 72
    const-string/jumbo v2, "手机屏幕投屏"

    check-cast v2, Ljava/lang/CharSequence;

    const/4 v4, 0x2

    .line 70
    invoke-direct {v1, v3, v2, v4}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 69
    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 77
    :cond_1e
    new-instance v0, Landroidx/core/app/NotificationCompat$Builder;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-direct {v0, v1, v3}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v1, 0x1080037

    .line 78
    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->setSmallIcon(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    .line 79
    const-string/jumbo v1, "正在投屏手机屏幕"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    .line 80
    const-string/jumbo v1, "画面正在发送到仪表"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->setContentText(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    const/4 v1, 0x1

    .line 81
    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->setOngoing(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    .line 82
    invoke-virtual {v0}, Landroidx/core/app/NotificationCompat$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    const-string v1, "build(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 84
    check-cast p0, Landroid/app/Service;

    .line 87
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1d

    if-lt v1, v2, :cond_58

    const/16 v1, 0x20

    goto :goto_59

    :cond_58
    const/4 v1, 0x0

    :goto_59
    const/16 v2, 0x3ea

    .line 83
    invoke-static {p0, v2, v0, v1}, Landroidx/core/app/ServiceCompat;->startForeground(Landroid/app/Service;ILandroid/app/Notification;I)V

    return-void
.end method

.method private final startCapture(ILandroid/content/Intent;)V
    .registers 13

    .line 99
    iget-object v0, p0, Lcom/example/bleconnectse/ScreenCaptureService;->projection:Landroid/media/projection/MediaProjection;

    if-eqz v0, :cond_5

    return-void

    .line 98
    :cond_5
    const-string v0, "media_projection"

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/ScreenCaptureService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.media.projection.MediaProjectionManager"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/media/projection/MediaProjectionManager;

    .line 99
    invoke-virtual {v0, p1, p2}, Landroid/media/projection/MediaProjectionManager;->getMediaProjection(ILandroid/content/Intent;)Landroid/media/projection/MediaProjection;

    move-result-object v1

    if-nez v1, :cond_1f

    move-object p1, p0

    check-cast p1, Lcom/example/bleconnectse/ScreenCaptureService;

    .line 100
    invoke-virtual {p0}, Lcom/example/bleconnectse/ScreenCaptureService;->stopSelf()V

    return-void

    .line 103
    :cond_1f
    new-instance p1, Lcom/example/bleconnectse/ScreenCaptureService$startCapture$1;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/ScreenCaptureService$startCapture$1;-><init>(Lcom/example/bleconnectse/ScreenCaptureService;)V

    check-cast p1, Landroid/media/projection/MediaProjection$Callback;

    const/4 p2, 0x0

    invoke-virtual {v1, p1, p2}, Landroid/media/projection/MediaProjection;->registerCallback(Landroid/media/projection/MediaProjection$Callback;Landroid/os/Handler;)V

    .line 108
    iput-object v1, p0, Lcom/example/bleconnectse/ScreenCaptureService;->projection:Landroid/media/projection/MediaProjection;

    .line 110
    invoke-virtual {p0}, Lcom/example/bleconnectse/ScreenCaptureService;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    .line 111
    iget v0, p1, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v2, p1, Landroid/util/DisplayMetrics;->heightPixels:I

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-float v0, v0

    const/high16 v2, 0x44a00000  # 1280.0f

    div-float/2addr v2, v0

    const/high16 v0, 0x3f800000  # 1.0f

    invoke-static {v0, v2}, Ljava/lang/Math;->min(FF)F

    move-result v0

    .line 112
    iget v2, p1, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v2, v2

    mul-float/2addr v2, v0

    invoke-static {v2}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result v2

    const/4 v3, 0x2

    invoke-static {v2, v3}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v2

    .line 113
    iget v4, p1, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v4, v4

    mul-float/2addr v4, v0

    invoke-static {v4}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result v0

    invoke-static {v0, v3}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v4

    const/4 v0, 0x1

    .line 114
    invoke-static {v2, v4, v0, v3}, Landroid/media/ImageReader;->newInstance(IIII)Landroid/media/ImageReader;

    move-result-object v0

    const-string v3, "newInstance(...)"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 115
    new-instance v3, Lcom/example/bleconnectse/ScreenCaptureService$$ExternalSyntheticLambda0;

    invoke-direct {v3, p0}, Lcom/example/bleconnectse/ScreenCaptureService$$ExternalSyntheticLambda0;-><init>(Lcom/example/bleconnectse/ScreenCaptureService;)V

    invoke-virtual {v0, v3, p2}, Landroid/media/ImageReader;->setOnImageAvailableListener(Landroid/media/ImageReader$OnImageAvailableListener;Landroid/os/Handler;)V

    .line 147
    iput-object v0, p0, Lcom/example/bleconnectse/ScreenCaptureService;->imageReader:Landroid/media/ImageReader;

    .line 152
    iget v5, p1, Landroid/util/DisplayMetrics;->densityDpi:I

    .line 154
    invoke-virtual {v0}, Landroid/media/ImageReader;->getSurface()Landroid/view/Surface;

    move-result-object v7

    const/4 v8, 0x0

    const/4 v9, 0x0

    move v3, v2

    .line 148
    const-string v2, "ScreenMirror"

    const/16 v6, 0x10

    invoke-virtual/range {v1 .. v9}, Landroid/media/projection/MediaProjection;->createVirtualDisplay(Ljava/lang/String;IIIILandroid/view/Surface;Landroid/hardware/display/VirtualDisplay$Callback;Landroid/os/Handler;)Landroid/hardware/display/VirtualDisplay;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/ScreenCaptureService;->virtualDisplay:Landroid/hardware/display/VirtualDisplay;

    return-void
.end method

.method static final startCapture$lambda$2(Lcom/example/bleconnectse/ScreenCaptureService;Landroid/media/ImageReader;)V
    .registers 8

    .line 116
    invoke-virtual {p1}, Landroid/media/ImageReader;->acquireLatestImage()Landroid/media/Image;

    move-result-object p1

    if-nez p1, :cond_7

    return-void

    .line 118
    :cond_7
    :try_start_7
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 119
    iget-wide v2, p0, Lcom/example/bleconnectse/ScreenCaptureService;->lastFrameAt:J

    sub-long v2, v0, v2

    const-wide/16 v4, 0x64

    cmp-long v2, v2, v4

    if-ltz v2, :cond_65

    .line 120
    iput-wide v0, p0, Lcom/example/bleconnectse/ScreenCaptureService;->lastFrameAt:J

    .line 121
    invoke-virtual {p1}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object p0

    const/4 v0, 0x0

    aget-object p0, p0, v0

    .line 122
    invoke-virtual {p0}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v1

    invoke-virtual {p0}, Landroid/media/Image$Plane;->getPixelStride()I

    move-result v2

    div-int/2addr v1, v2

    .line 125
    invoke-virtual {p1}, Landroid/media/Image;->getHeight()I

    move-result v2

    .line 126
    sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 123
    invoke-static {v1, v2, v3}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v2

    const-string v3, "createBitmap(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 128
    invoke-virtual {p0}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    .line 129
    invoke-virtual {p0}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object p0

    check-cast p0, Ljava/nio/Buffer;

    invoke-virtual {v2, p0}, Landroid/graphics/Bitmap;->copyPixelsFromBuffer(Ljava/nio/Buffer;)V

    .line 130
    invoke-virtual {p1}, Landroid/media/Image;->getWidth()I

    move-result p0

    if-ne v1, p0, :cond_4d

    goto :goto_60

    .line 137
    :cond_4d
    invoke-virtual {p1}, Landroid/media/Image;->getWidth()I

    move-result p0

    .line 138
    invoke-virtual {p1}, Landroid/media/Image;->getHeight()I

    move-result v1

    .line 133
    invoke-static {v2, v0, v0, p0, v1}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIII)Landroid/graphics/Bitmap;

    move-result-object p0

    .line 139
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    .line 132
    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v2, p0

    .line 141
    :goto_60
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {p0, v2}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->submit(Landroid/graphics/Bitmap;)V
    :try_end_65
    .catchall {:try_start_7 .. :try_end_65} :catchall_69

    .line 144
    :cond_65
    invoke-virtual {p1}, Landroid/media/Image;->close()V

    return-void

    :catchall_69
    move-exception p0

    invoke-virtual {p1}, Landroid/media/Image;->close()V

    throw p0
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 2

    const/4 p0, 0x0

    return-object p0
.end method

.method public onDestroy()V
    .registers 3

    const/4 v0, 0x1

    .line 55
    iput-boolean v0, p0, Lcom/example/bleconnectse/ScreenCaptureService;->stopping:Z

    .line 56
    iget-object v0, p0, Lcom/example/bleconnectse/ScreenCaptureService;->imageReader:Landroid/media/ImageReader;

    const/4 v1, 0x0

    if-eqz v0, :cond_b

    invoke-virtual {v0, v1, v1}, Landroid/media/ImageReader;->setOnImageAvailableListener(Landroid/media/ImageReader$OnImageAvailableListener;Landroid/os/Handler;)V

    .line 57
    :cond_b
    iget-object v0, p0, Lcom/example/bleconnectse/ScreenCaptureService;->virtualDisplay:Landroid/hardware/display/VirtualDisplay;

    if-eqz v0, :cond_12

    invoke-virtual {v0}, Landroid/hardware/display/VirtualDisplay;->release()V

    .line 58
    :cond_12
    iget-object v0, p0, Lcom/example/bleconnectse/ScreenCaptureService;->imageReader:Landroid/media/ImageReader;

    if-eqz v0, :cond_19

    invoke-virtual {v0}, Landroid/media/ImageReader;->close()V

    .line 59
    :cond_19
    iget-object v0, p0, Lcom/example/bleconnectse/ScreenCaptureService;->projection:Landroid/media/projection/MediaProjection;

    if-eqz v0, :cond_20

    invoke-virtual {v0}, Landroid/media/projection/MediaProjection;->stop()V

    .line 60
    :cond_20
    iput-object v1, p0, Lcom/example/bleconnectse/ScreenCaptureService;->virtualDisplay:Landroid/hardware/display/VirtualDisplay;

    .line 61
    iput-object v1, p0, Lcom/example/bleconnectse/ScreenCaptureService;->imageReader:Landroid/media/ImageReader;

    .line 62
    iput-object v1, p0, Lcom/example/bleconnectse/ScreenCaptureService;->projection:Landroid/media/projection/MediaProjection;

    .line 63
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 6

    const/4 p2, 0x0

    if-eqz p1, :cond_8

    .line 33
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p3

    goto :goto_9

    :cond_8
    move-object p3, p2

    :goto_9
    const-string v0, "com.example.bleconnectse.STOP_SCREEN_CAPTURE"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    const/4 v0, 0x2

    if-eqz p3, :cond_16

    .line 34
    invoke-virtual {p0}, Lcom/example/bleconnectse/ScreenCaptureService;->stopSelf()V

    return v0

    .line 37
    :cond_16
    invoke-direct {p0}, Lcom/example/bleconnectse/ScreenCaptureService;->startAsForeground()V

    const/4 p3, 0x0

    if-eqz p1, :cond_22

    .line 38
    const-string v1, "result_code"

    invoke-virtual {p1, v1, p3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p3

    :cond_22
    if-eqz p1, :cond_2a

    .line 40
    const-string p2, "result_data"

    invoke-static {p1, p2}, Lcom/example/bleconnectse/ScreenCaptureServiceKt;->access$intentExtra(Landroid/content/Intent;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p2

    :cond_2a
    const/4 p1, -0x1

    if-ne p3, p1, :cond_34

    if-nez p2, :cond_30

    goto :goto_34

    .line 45
    :cond_30
    invoke-direct {p0, p3, p2}, Lcom/example/bleconnectse/ScreenCaptureService;->startCapture(ILandroid/content/Intent;)V

    return v0

    .line 42
    :cond_34
    :goto_34
    invoke-virtual {p0}, Lcom/example/bleconnectse/ScreenCaptureService;->stopSelf()V

    return v0
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .registers 2

    .line 50
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    .line 51
    sget-object p1, Lcom/example/bleconnectse/MirrorTaskCleanup;->INSTANCE:Lcom/example/bleconnectse/MirrorTaskCleanup;

    check-cast p0, Landroid/content/Context;

    invoke-virtual {p1, p0}, Lcom/example/bleconnectse/MirrorTaskCleanup;->stopAll(Landroid/content/Context;)V

    return-void
.end method
