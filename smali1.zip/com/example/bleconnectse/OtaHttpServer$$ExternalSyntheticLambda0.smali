# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/OtaHttpServer;

.field public final synthetic f$1:Ljava/net/Socket;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/OtaHttpServer;Ljava/net/Socket;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda0;->f$0:Lcom/example/bleconnectse/OtaHttpServer;

    iput-object p2, p0, Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda0;->f$1:Ljava/net/Socket;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda0;->f$0:Lcom/example/bleconnectse/OtaHttpServer;

    iget-object p0, p0, Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda0;->f$1:Ljava/net/Socket;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/OtaHttpServer;->serveLoop$lambda$1(Lcom/example/bleconnectse/OtaHttpServer;Ljava/net/Socket;)V

    return-void
.end method
