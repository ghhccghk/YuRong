# classes2.dex

.class public final Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$6;
.super Ljava/lang/Object;
.source "LazyDsl.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/MainActivityKt;->CandidateListPanel(Lcom/example/bleconnectse/CandidatePanel;Lcom/example/bleconnectse/YadeaOtaClient;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function1<",
        "Ljava/lang/Integer;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLazyDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt$items$2\n*L\n1#1,523:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $items:Ljava/util/List;

.field final synthetic $key:Lkotlin/jvm/functions/Function1;


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V
    .registers 3

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$6;->$key:Lkotlin/jvm/functions/Function1;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$6;->$items:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(I)Ljava/lang/Object;
    .registers 3

    .line 176
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$6;->$key:Lkotlin/jvm/functions/Function1;

    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$6;->$items:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    invoke-interface {v0, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 174
    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$6;->invoke(I)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
