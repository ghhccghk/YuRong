# classes2.dex

.class public final Lcom/example/bleconnectse/BleTileClient$Companion;
.super Ljava/lang/Object;
.source "BleTileClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/bleconnectse/BleTileClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0007R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0007R\u0011\u0010\f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u0007R\u0011\u0010\u000e\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0007R\u000e\u0010\u0010\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0012X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0012X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001cX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001cX\u0082T¢\u0006\u0002\n\u0000¨\u0006\u001f"
    }
    d2 = {
        "Lcom/example/bleconnectse/BleTileClient$Companion;",
        "",
        "<init>",
        "()V",
        "SERVICE_UUID",
        "Ljava/util/UUID;",
        "getSERVICE_UUID",
        "()Ljava/util/UUID;",
        "CONTROL_UUID",
        "getCONTROL_UUID",
        "DATA_UUID",
        "getDATA_UUID",
        "STATUS_UUID",
        "getSTATUS_UUID",
        "RESULT_UUID",
        "getRESULT_UUID",
        "CLIENT_CONFIG_UUID",
        "REQUESTED_MTU",
        "",
        "TRANSPORT_HEADER_SIZE",
        "SCAN_TIMEOUT_MS",
        "",
        "DATA_PACKET_PACING_MS",
        "DATA_WRITE_RETRY_MS",
        "DATA_WRITE_STALL_MS",
        "RECONNECT_DELAY_MS",
        "MAX_DATA_WRITE_RETRIES",
        "PREFERRED_DEVICE",
        "",
        "PREFERENCES",
        "LOG_TAG",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 49
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final getCONTROL_UUID()Ljava/util/UUID;
    .registers 1

    .line 51
    invoke-static {}, Lcom/example/bleconnectse/BleTileClient;->access$getCONTROL_UUID$cp()Ljava/util/UUID;

    move-result-object p0

    return-object p0
.end method

.method public final getDATA_UUID()Ljava/util/UUID;
    .registers 1

    .line 52
    invoke-static {}, Lcom/example/bleconnectse/BleTileClient;->access$getDATA_UUID$cp()Ljava/util/UUID;

    move-result-object p0

    return-object p0
.end method

.method public final getRESULT_UUID()Ljava/util/UUID;
    .registers 1

    .line 54
    invoke-static {}, Lcom/example/bleconnectse/BleTileClient;->access$getRESULT_UUID$cp()Ljava/util/UUID;

    move-result-object p0

    return-object p0
.end method

.method public final getSERVICE_UUID()Ljava/util/UUID;
    .registers 1

    .line 50
    invoke-static {}, Lcom/example/bleconnectse/BleTileClient;->access$getSERVICE_UUID$cp()Ljava/util/UUID;

    move-result-object p0

    return-object p0
.end method

.method public final getSTATUS_UUID()Ljava/util/UUID;
    .registers 1

    .line 53
    invoke-static {}, Lcom/example/bleconnectse/BleTileClient;->access$getSTATUS_UUID$cp()Ljava/util/UUID;

    move-result-object p0

    return-object p0
.end method
