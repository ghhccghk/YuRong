# classes.dex

.class public final Lcom/example/bleconnectse/CameraMirrorController;
.super Ljava/lang/Object;
.source "CameraMirrorController.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCameraMirrorController.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CameraMirrorController.kt\ncom/example/bleconnectse/CameraMirrorController\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,110:1\n1#2:111\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B+\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\u0004\b\n\u0010\u000bJ\b\u0010\u0014\u001a\u00020\tH\u0007J\u0006\u0010\u0015\u001a\u00020\tJ\u0006\u0010\u0016\u001a\u00020\tJ\u0010\u0010\u0017\u001a\u00020\t2\u0006\u0010\u0018\u001a\u00020\u0019H\u0002J\f\u0010\u001a\u001a\u00020\u001b*\u00020\u0019H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001c"
    }
    d2 = {
        "Lcom/example/bleconnectse/CameraMirrorController;",
        "",
        "context",
        "Landroid/content/Context;",
        "lifecycleOwner",
        "Landroidx/lifecycle/LifecycleOwner;",
        "logger",
        "Lkotlin/Function1;",
        "",
        "",
        "<init>",
        "(Landroid/content/Context;Landroidx/lifecycle/LifecycleOwner;Lkotlin/jvm/functions/Function1;)V",
        "analyzerExecutor",
        "Ljava/util/concurrent/ExecutorService;",
        "cameraProvider",
        "Landroidx/camera/lifecycle/ProcessCameraProvider;",
        "running",
        "",
        "lastFrameAt",
        "",
        "start",
        "stop",
        "close",
        "analyze",
        "image",
        "Landroidx/camera/core/ImageProxy;",
        "toRgbaBitmap",
        "Landroid/graphics/Bitmap;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final analyzerExecutor:Ljava/util/concurrent/ExecutorService;

.field private cameraProvider:Landroidx/camera/lifecycle/ProcessCameraProvider;

.field private final context:Landroid/content/Context;

.field private lastFrameAt:J

.field private final lifecycleOwner:Landroidx/lifecycle/LifecycleOwner;

.field private final logger:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private running:Z


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/lifecycle/LifecycleOwner;Lkotlin/jvm/functions/Function1;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroidx/lifecycle/LifecycleOwner;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "lifecycleOwner"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "logger"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    iput-object p1, p0, Lcom/example/bleconnectse/CameraMirrorController;->context:Landroid/content/Context;

    .line 19
    iput-object p2, p0, Lcom/example/bleconnectse/CameraMirrorController;->lifecycleOwner:Landroidx/lifecycle/LifecycleOwner;

    .line 20
    iput-object p3, p0, Lcom/example/bleconnectse/CameraMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    .line 22
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    const-string p2, "newSingleThreadExecutor(...)"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lcom/example/bleconnectse/CameraMirrorController;->analyzerExecutor:Ljava/util/concurrent/ExecutorService;

    return-void
.end method

.method private final analyze(Landroidx/camera/core/ImageProxy;)V
    .registers 9

    const-string/jumbo v0, "摄像头帧转换失败："

    .line 73
    :try_start_3
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    .line 74
    iget-boolean v3, p0, Lcom/example/bleconnectse/CameraMirrorController;->running:Z

    if-eqz v3, :cond_25

    iget-wide v3, p0, Lcom/example/bleconnectse/CameraMirrorController;->lastFrameAt:J

    sub-long v3, v1, v3

    const-wide/16 v5, 0x64

    cmp-long v3, v3, v5

    if-gez v3, :cond_16

    goto :goto_25

    .line 75
    :cond_16
    iput-wide v1, p0, Lcom/example/bleconnectse/CameraMirrorController;->lastFrameAt:J

    .line 76
    sget-object v1, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/CameraMirrorController;->toRgbaBitmap(Landroidx/camera/core/ImageProxy;)Landroid/graphics/Bitmap;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->submit(Landroid/graphics/Bitmap;)V
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_21} :catch_2b
    .catchall {:try_start_3 .. :try_end_21} :catchall_29

    .line 80
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->close()V

    return-void

    :cond_25
    :goto_25
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->close()V

    return-void

    :catchall_29
    move-exception p0

    goto :goto_46

    :catch_2b
    move-exception v1

    .line 78
    :try_start_2c
    iget-object p0, p0, Lcom/example/bleconnectse/CameraMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_42
    .catchall {:try_start_2c .. :try_end_42} :catchall_29

    .line 80
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->close()V

    return-void

    :goto_46
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->close()V

    throw p0
.end method

.method static final start$lambda$1(Lcom/example/bleconnectse/CameraMirrorController;Lcom/google/common/util/concurrent/ListenableFuture;)V
    .registers 7

    .line 33
    iget-boolean v0, p0, Lcom/example/bleconnectse/CameraMirrorController;->running:Z

    if-nez v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x0

    .line 35
    :try_start_6
    invoke-interface {p1}, Lcom/google/common/util/concurrent/ListenableFuture;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/camera/lifecycle/ProcessCameraProvider;

    .line 36
    new-instance v1, Landroidx/camera/core/ImageAnalysis$Builder;

    invoke-direct {v1}, Landroidx/camera/core/ImageAnalysis$Builder;-><init>()V

    .line 37
    new-instance v2, Landroid/util/Size;

    const/16 v3, 0x500

    const/16 v4, 0x2d0

    invoke-direct {v2, v3, v4}, Landroid/util/Size;-><init>(II)V

    invoke-virtual {v1, v2}, Landroidx/camera/core/ImageAnalysis$Builder;->setTargetResolution(Landroid/util/Size;)Landroidx/camera/core/ImageAnalysis$Builder;

    move-result-object v1

    .line 38
    invoke-virtual {v1, v0}, Landroidx/camera/core/ImageAnalysis$Builder;->setBackpressureStrategy(I)Landroidx/camera/core/ImageAnalysis$Builder;

    move-result-object v1

    const/4 v2, 0x2

    .line 39
    invoke-virtual {v1, v2}, Landroidx/camera/core/ImageAnalysis$Builder;->setOutputImageFormat(I)Landroidx/camera/core/ImageAnalysis$Builder;

    move-result-object v1

    .line 40
    invoke-virtual {v1}, Landroidx/camera/core/ImageAnalysis$Builder;->build()Landroidx/camera/core/ImageAnalysis;

    move-result-object v1

    const-string v2, "build(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    iget-object v2, p0, Lcom/example/bleconnectse/CameraMirrorController;->analyzerExecutor:Ljava/util/concurrent/ExecutorService;

    check-cast v2, Ljava/util/concurrent/Executor;

    new-instance v3, Lcom/example/bleconnectse/CameraMirrorController$$ExternalSyntheticLambda0;

    invoke-direct {v3, p0}, Lcom/example/bleconnectse/CameraMirrorController$$ExternalSyntheticLambda0;-><init>(Lcom/example/bleconnectse/CameraMirrorController;)V

    invoke-virtual {v1, v2, v3}, Landroidx/camera/core/ImageAnalysis;->setAnalyzer(Ljava/util/concurrent/Executor;Landroidx/camera/core/ImageAnalysis$Analyzer;)V

    .line 44
    invoke-virtual {p1}, Landroidx/camera/lifecycle/ProcessCameraProvider;->unbindAll()V

    .line 46
    iget-object v2, p0, Lcom/example/bleconnectse/CameraMirrorController;->lifecycleOwner:Landroidx/lifecycle/LifecycleOwner;

    .line 47
    sget-object v3, Landroidx/camera/core/CameraSelector;->DEFAULT_BACK_CAMERA:Landroidx/camera/core/CameraSelector;

    const-string v4, "DEFAULT_BACK_CAMERA"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x1

    .line 48
    new-array v4, v4, [Landroidx/camera/core/UseCase;

    aput-object v1, v4, v0

    .line 45
    invoke-virtual {p1, v2, v3, v4}, Landroidx/camera/lifecycle/ProcessCameraProvider;->bindToLifecycle(Landroidx/lifecycle/LifecycleOwner;Landroidx/camera/core/CameraSelector;[Landroidx/camera/core/UseCase;)Landroidx/camera/core/Camera;

    .line 50
    iput-object p1, p0, Lcom/example/bleconnectse/CameraMirrorController;->cameraProvider:Landroidx/camera/lifecycle/ProcessCameraProvider;

    .line 51
    iget-object p1, p0, Lcom/example/bleconnectse/CameraMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    const-string/jumbo v1, "摄像头取帧已启动"

    invoke-interface {p1, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5a
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_5a} :catch_5b

    return-void

    :catch_5b
    move-exception p1

    .line 53
    iput-boolean v0, p0, Lcom/example/bleconnectse/CameraMirrorController;->running:Z

    .line 54
    iget-object p0, p0, Lcom/example/bleconnectse/CameraMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "摄像头启动失败："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method static final start$lambda$1$lambda$0(Lcom/example/bleconnectse/CameraMirrorController;Landroidx/camera/core/ImageProxy;)V
    .registers 3

    const-string v0, "image"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/CameraMirrorController;->analyze(Landroidx/camera/core/ImageProxy;)V

    return-void
.end method

.method private final toRgbaBitmap(Landroidx/camera/core/ImageProxy;)Landroid/graphics/Bitmap;
    .registers 13

    .line 85
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->getPlanes()[Landroidx/camera/core/ImageProxy$PlaneProxy;

    move-result-object p0

    const/4 v0, 0x0

    aget-object p0, p0, v0

    .line 86
    invoke-interface {p0}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getPixelStride()I

    move-result v1

    .line 87
    invoke-interface {p0}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getRowStride()I

    move-result v2

    .line 88
    div-int/2addr v2, v1

    .line 89
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->getHeight()I

    move-result v1

    sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v2, v1, v3}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    const-string v3, "createBitmap(...)"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    invoke-interface {p0}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    .line 91
    invoke-interface {p0}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object p0

    check-cast p0, Ljava/nio/Buffer;

    invoke-virtual {v1, p0}, Landroid/graphics/Bitmap;->copyPixelsFromBuffer(Ljava/nio/Buffer;)V

    .line 92
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->getWidth()I

    move-result p0

    if-ne v2, p0, :cond_37

    move-object v4, v1

    goto :goto_4a

    .line 95
    :cond_37
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->getWidth()I

    move-result p0

    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->getHeight()I

    move-result v2

    invoke-static {v1, v0, v0, p0, v2}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIII)Landroid/graphics/Bitmap;

    move-result-object p0

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 94
    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v4, p0

    .line 97
    :goto_4a
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->getImageInfo()Landroidx/camera/core/ImageInfo;

    move-result-object p0

    invoke-interface {p0}, Landroidx/camera/core/ImageInfo;->getRotationDegrees()I

    move-result p0

    if-nez p0, :cond_55

    return-object v4

    .line 103
    :cond_55
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v7

    .line 104
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v8

    .line 105
    new-instance v9, Landroid/graphics/Matrix;

    invoke-direct {v9}, Landroid/graphics/Matrix;-><init>()V

    int-to-float p0, p0

    invoke-virtual {v9, p0}, Landroid/graphics/Matrix;->postRotate(F)Z

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    const/4 v10, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    .line 99
    invoke-static/range {v4 .. v10}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;

    move-result-object p0

    invoke-static {p0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 107
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->recycle()V

    return-object p0
.end method


# virtual methods
.method public final close()V
    .registers 1

    .line 67
    invoke-virtual {p0}, Lcom/example/bleconnectse/CameraMirrorController;->stop()V

    .line 68
    iget-object p0, p0, Lcom/example/bleconnectse/CameraMirrorController;->analyzerExecutor:Ljava/util/concurrent/ExecutorService;

    invoke-interface {p0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    return-void
.end method

.method public final start()V
    .registers 3

    .line 29
    iget-boolean v0, p0, Lcom/example/bleconnectse/CameraMirrorController;->running:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    .line 30
    iput-boolean v0, p0, Lcom/example/bleconnectse/CameraMirrorController;->running:Z

    .line 31
    sget-object v0, Landroidx/camera/lifecycle/ProcessCameraProvider;->Companion:Landroidx/camera/lifecycle/ProcessCameraProvider$Companion;

    iget-object v1, p0, Lcom/example/bleconnectse/CameraMirrorController;->context:Landroid/content/Context;

    invoke-virtual {v0, v1}, Landroidx/camera/lifecycle/ProcessCameraProvider$Companion;->getInstance(Landroid/content/Context;)Lcom/google/common/util/concurrent/ListenableFuture;

    move-result-object v0

    .line 32
    new-instance v1, Lcom/example/bleconnectse/CameraMirrorController$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, v0}, Lcom/example/bleconnectse/CameraMirrorController$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/CameraMirrorController;Lcom/google/common/util/concurrent/ListenableFuture;)V

    .line 56
    iget-object p0, p0, Lcom/example/bleconnectse/CameraMirrorController;->context:Landroid/content/Context;

    invoke-static {p0}, Landroidx/core/content/ContextCompat;->getMainExecutor(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    move-result-object p0

    .line 32
    invoke-interface {v0, v1, p0}, Lcom/google/common/util/concurrent/ListenableFuture;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method public final stop()V
    .registers 2

    const/4 v0, 0x0

    .line 60
    iput-boolean v0, p0, Lcom/example/bleconnectse/CameraMirrorController;->running:Z

    .line 61
    iget-object v0, p0, Lcom/example/bleconnectse/CameraMirrorController;->cameraProvider:Landroidx/camera/lifecycle/ProcessCameraProvider;

    if-eqz v0, :cond_a

    invoke-virtual {v0}, Landroidx/camera/lifecycle/ProcessCameraProvider;->unbindAll()V

    :cond_a
    const/4 v0, 0x0

    .line 62
    iput-object v0, p0, Lcom/example/bleconnectse/CameraMirrorController;->cameraProvider:Landroidx/camera/lifecycle/ProcessCameraProvider;

    .line 63
    iget-object p0, p0, Lcom/example/bleconnectse/CameraMirrorController;->logger:Lkotlin/jvm/functions/Function1;

    const-string/jumbo v0, "摄像头取帧已停止"

    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
