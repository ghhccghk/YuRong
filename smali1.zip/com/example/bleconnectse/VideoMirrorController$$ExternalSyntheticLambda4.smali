# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnErrorListener;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/VideoMirrorController;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/VideoMirrorController;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda4;->f$0:Lcom/example/bleconnectse/VideoMirrorController;

    return-void
.end method


# virtual methods
.method public final onError(Landroid/media/MediaPlayer;II)Z
    .registers 4

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda4;->f$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {p0, p1, p2, p3}, Lcom/example/bleconnectse/VideoMirrorController;->preparePlayer$lambda$17(Lcom/example/bleconnectse/VideoMirrorController;Landroid/media/MediaPlayer;II)Z

    move-result p0

    return p0
.end method
