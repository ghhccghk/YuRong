# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda24;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:[Lcom/example/bleconnectse/SimulatedNavigationView;

.field public final synthetic f$1:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>([Lcom/example/bleconnectse/SimulatedNavigationView;Lkotlin/jvm/functions/Function1;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda24;->f$0:[Lcom/example/bleconnectse/SimulatedNavigationView;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda24;->f$1:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda24;->f$0:[Lcom/example/bleconnectse/SimulatedNavigationView;

    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda24;->f$1:Lkotlin/jvm/functions/Function1;

    check-cast p1, Landroid/content/Context;

    invoke-static {v0, p0, p1}, Lcom/example/bleconnectse/MainActivityKt;->SimulatedNavigationScreen$lambda$54$lambda$47$lambda$46([Lcom/example/bleconnectse/SimulatedNavigationView;Lkotlin/jvm/functions/Function1;Landroid/content/Context;)Lcom/example/bleconnectse/SimulatedNavigationView;

    move-result-object p0

    return-object p0
.end method
