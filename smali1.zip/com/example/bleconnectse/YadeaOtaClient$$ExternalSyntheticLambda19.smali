# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:Lkotlin/jvm/internal/Ref$IntRef;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/internal/Ref$IntRef;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda19;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda19;->f$1:Lkotlin/jvm/internal/Ref$IntRef;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda19;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda19;->f$1:Lkotlin/jvm/internal/Ref$IntRef;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->startMirror$lambda$70$lambda$61$lambda$60$lambda$59(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/internal/Ref$IntRef;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
