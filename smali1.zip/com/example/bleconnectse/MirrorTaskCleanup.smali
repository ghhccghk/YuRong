# classes2.dex

.class public final Lcom/example/bleconnectse/MirrorTaskCleanup;
.super Ljava/lang/Object;
.source "MirrorTaskCleanup.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÁ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"
    }
    d2 = {
        "Lcom/example/bleconnectse/MirrorTaskCleanup;",
        "",
        "<init>",
        "()V",
        "stopAll",
        "",
        "context",
        "Landroid/content/Context;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/example/bleconnectse/MirrorTaskCleanup;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/example/bleconnectse/MirrorTaskCleanup;

    invoke-direct {v0}, Lcom/example/bleconnectse/MirrorTaskCleanup;-><init>()V

    sput-object v0, Lcom/example/bleconnectse/MirrorTaskCleanup;->INSTANCE:Lcom/example/bleconnectse/MirrorTaskCleanup;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final stopAll(Landroid/content/Context;)V
    .registers 2

    const-string p0, "context"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    sget-object p0, Lcom/example/bleconnectse/AppConnectionSession;->INSTANCE:Lcom/example/bleconnectse/AppConnectionSession;

    invoke-virtual {p0}, Lcom/example/bleconnectse/AppConnectionSession;->stopMirrorIfPresent()V

    .line 9
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {p0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    .line 10
    sget-object p0, Lcom/example/bleconnectse/VideoBackgroundFrameService;->Companion:Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 11
    sget-object p0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 12
    sget-object p0, Lcom/example/bleconnectse/ScreenCaptureService;->Companion:Lcom/example/bleconnectse/ScreenCaptureService$Companion;

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/ScreenCaptureService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    return-void
.end method
