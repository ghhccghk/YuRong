# classes2.dex

.class final Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;
.super Ljava/lang/Object;
.source "InstrumentWallpaperClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/bleconnectse/InstrumentWallpaperClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "DisplayConfig"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\'\u0010\u000f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0014\u001a\u00020\u0015HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\t¨\u0006\u0016"
    }
    d2 = {
        "Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;",
        "",
        "width",
        "",
        "height",
        "type",
        "<init>",
        "(III)V",
        "getWidth",
        "()I",
        "getHeight",
        "getType",
        "component1",
        "component2",
        "component3",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "toString",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final height:I

.field private final type:I

.field private final width:I


# direct methods
.method public constructor <init>(III)V
    .registers 4

    .line 245
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->width:I

    iput p2, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->height:I

    iput p3, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->type:I

    return-void
.end method

.method public static synthetic copy$default(Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;IIIILjava/lang/Object;)Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget p1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->width:I

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget p2, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->height:I

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    iget p3, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->type:I

    :cond_12
    invoke-virtual {p0, p1, p2, p3}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->copy(III)Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->width:I

    return p0
.end method

.method public final component2()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->height:I

    return p0
.end method

.method public final component3()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->type:I

    return p0
.end method

.method public final copy(III)Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;
    .registers 4

    new-instance p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;

    invoke-direct {p0, p1, p2, p3}, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;-><init>(III)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;

    iget v1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->width:I

    iget v3, p1, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->width:I

    if-eq v1, v3, :cond_13

    return v2

    :cond_13
    iget v1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->height:I

    iget v3, p1, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->height:I

    if-eq v1, v3, :cond_1a

    return v2

    :cond_1a
    iget p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->type:I

    iget p1, p1, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->type:I

    if-eq p0, p1, :cond_21

    return v2

    :cond_21
    return v0
.end method

.method public final getHeight()I
    .registers 1

    .line 245
    iget p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->height:I

    return p0
.end method

.method public final getType()I
    .registers 1

    .line 245
    iget p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->type:I

    return p0
.end method

.method public final getWidth()I
    .registers 1

    .line 245
    iget p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->width:I

    return p0
.end method

.method public hashCode()I
    .registers 3

    iget v0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->width:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->height:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->type:I

    invoke-static {p0}, Ljava/lang/Integer;->hashCode(I)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 5

    iget v0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->width:I

    iget v1, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->height:I

    iget p0, p0, Lcom/example/bleconnectse/InstrumentWallpaperClient$DisplayConfig;->type:I

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "DisplayConfig(width="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", height="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", type="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ")"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
