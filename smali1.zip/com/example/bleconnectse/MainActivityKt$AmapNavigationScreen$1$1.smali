# classes2.dex

.class final Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "MainActivity.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/MainActivityKt;->AmapNavigationScreen(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/NavigationTransport;Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.example.bleconnectse.MainActivityKt$AmapNavigationScreen$1$1"
    f = "MainActivity.kt"
    i = {}
    l = {
        0x286
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $destinationText$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $navigationViewHolder:[Lcom/example/bleconnectse/AmapNavigationView;

.field final synthetic $privacyAgreed:Z

.field label:I


# direct methods
.method constructor <init>(Z[Lcom/example/bleconnectse/AmapNavigationView;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z[",
            "Lcom/example/bleconnectse/AmapNavigationView;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;",
            ">;)V"
        }
    .end annotation

    iput-boolean p1, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->$privacyAgreed:Z

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->$navigationViewHolder:[Lcom/example/bleconnectse/AmapNavigationView;

    iput-object p3, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->$destinationText$delegate:Landroidx/compose/runtime/MutableState;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance p1, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;

    iget-boolean v0, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->$privacyAgreed:Z

    iget-object v1, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->$navigationViewHolder:[Lcom/example/bleconnectse/AmapNavigationView;

    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->$destinationText$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {p1, v0, v1, p0, p2}, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;-><init>(Z[Lcom/example/bleconnectse/AmapNavigationView;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    check-cast p1, Lkotlin/coroutines/Continuation;

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object p0

    check-cast p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 644
    iget v1, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->label:I

    const/4 v2, 0x1

    if-eqz v1, :cond_17

    if-ne v1, v2, :cond_f

    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    goto :goto_2f

    :cond_f
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_17
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 645
    iget-boolean p1, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->$privacyAgreed:Z

    if-nez p1, :cond_21

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0

    .line 646
    :cond_21
    move-object p1, p0

    check-cast p1, Lkotlin/coroutines/Continuation;

    iput v2, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->label:I

    const-wide/16 v1, 0x12c

    invoke-static {v1, v2, p1}, Lkotlinx/coroutines/DelayKt;->delay(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_2f

    return-object v0

    .line 647
    :cond_2f
    :goto_2f
    iget-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->$navigationViewHolder:[Lcom/example/bleconnectse/AmapNavigationView;

    const/4 v0, 0x0

    aget-object p1, p1, v0

    if-eqz p1, :cond_3f

    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$AmapNavigationScreen$1$1;->$destinationText$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p0}, Lcom/example/bleconnectse/MainActivityKt;->access$AmapNavigationScreen$lambda$2(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Lcom/example/bleconnectse/AmapNavigationView;->searchDestinationSuggestions(Ljava/lang/String;)V

    .line 648
    :cond_3f
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method
