# classes2.dex

.class public final Lcom/example/bleconnectse/MediaMirrorKeepAliveService;
.super Landroid/app/Service;
.source "MediaMirrorKeepAliveService.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 \u000f2\u00020\u0001:\u0001\u000fB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0014\u0010\u0004\u001a\u0004\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0016J\"\u0010\b\u001a\u00020\t2\b\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\tH\u0016J\u0012\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0007H\u0016¨\u0006\u0010"
    }
    d2 = {
        "Lcom/example/bleconnectse/MediaMirrorKeepAliveService;",
        "Landroid/app/Service;",
        "<init>",
        "()V",
        "onBind",
        "Landroid/os/IBinder;",
        "intent",
        "Landroid/content/Intent;",
        "onStartCommand",
        "",
        "flags",
        "startId",
        "onTaskRemoved",
        "",
        "rootIntent",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field private static final ACTION_STOP:Ljava/lang/String; = "com.example.bleconnectse.STOP_MEDIA_MIRROR_KEEPALIVE"

.field private static final CHANNEL_ID:Ljava/lang/String; = "media_mirror"

.field public static final Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

.field private static final EXTRA_LABEL:Ljava/lang/String; = "label"

.field private static final NOTIFICATION_ID:I = 0x3ec


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    const/16 v0, 0x8

    sput v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 14
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 2

    const/4 p0, 0x0

    return-object p0
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 7

    if-eqz p1, :cond_7

    .line 18
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    goto :goto_8

    :cond_7
    const/4 p2, 0x0

    :goto_8
    const-string p3, "com.example.bleconnectse.STOP_MEDIA_MIRROR_KEEPALIVE"

    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    const/4 p3, 0x2

    if-eqz p2, :cond_15

    .line 19
    invoke-virtual {p0}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->stopSelf()V

    return p3

    :cond_15
    if-eqz p1, :cond_1f

    .line 22
    const-string p2, "label"

    invoke-virtual {p1, p2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_22

    :cond_1f
    const-string/jumbo p1, "相册媒体"

    .line 23
    :cond_22
    const-class p2, Landroid/app/NotificationManager;

    invoke-virtual {p0, p2}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/app/NotificationManager;

    .line 24
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    const-string v2, "media_mirror"

    if-lt v0, v1, :cond_3f

    .line 26
    new-instance v0, Landroid/app/NotificationChannel;

    const-string/jumbo v1, "相册投屏"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-direct {v0, v2, v1, p3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 25
    invoke-virtual {p2, v0}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 29
    :cond_3f
    new-instance p2, Landroidx/core/app/NotificationCompat$Builder;

    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    invoke-direct {p2, v0, v2}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v0, 0x108003f

    .line 30
    invoke-virtual {p2, v0}, Landroidx/core/app/NotificationCompat$Builder;->setSmallIcon(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object p2

    .line 31
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "正在投屏"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    check-cast p1, Ljava/lang/CharSequence;

    invoke-virtual {p2, p1}, Landroidx/core/app/NotificationCompat$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object p1

    .line 32
    const-string/jumbo p2, "退到后台后仍会继续发送画面"

    check-cast p2, Ljava/lang/CharSequence;

    invoke-virtual {p1, p2}, Landroidx/core/app/NotificationCompat$Builder;->setContentText(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object p1

    const/4 p2, 0x1

    .line 33
    invoke-virtual {p1, p2}, Landroidx/core/app/NotificationCompat$Builder;->setOngoing(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object p1

    .line 34
    invoke-virtual {p1}, Landroidx/core/app/NotificationCompat$Builder;->build()Landroid/app/Notification;

    move-result-object p1

    const-string p2, "build(...)"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    check-cast p0, Landroid/app/Service;

    .line 39
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1d

    if-lt p2, v0, :cond_86

    const/16 p2, 0x10

    goto :goto_87

    :cond_86
    const/4 p2, 0x0

    :goto_87
    const/16 v0, 0x3ec

    .line 35
    invoke-static {p0, v0, p1, p2}, Landroidx/core/app/ServiceCompat;->startForeground(Landroid/app/Service;ILandroid/app/Notification;I)V

    return p3
.end method

.method public onTaskRemoved(Landroid/content/Intent;)V
    .registers 2

    .line 47
    invoke-super {p0, p1}, Landroid/app/Service;->onTaskRemoved(Landroid/content/Intent;)V

    .line 48
    sget-object p1, Lcom/example/bleconnectse/MirrorTaskCleanup;->INSTANCE:Lcom/example/bleconnectse/MirrorTaskCleanup;

    check-cast p0, Landroid/content/Context;

    invoke-virtual {p1, p0}, Lcom/example/bleconnectse/MirrorTaskCleanup;->stopAll(Landroid/content/Context;)V

    return-void
.end method
