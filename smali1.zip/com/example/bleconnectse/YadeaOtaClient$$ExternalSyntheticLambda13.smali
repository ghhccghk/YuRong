# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/net/wifi/p2p/WifiP2pManager$ChannelListener;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda13;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    return-void
.end method


# virtual methods
.method public final onChannelDisconnected()V
    .registers 1

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda13;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->ensureP2pChannel$lambda$124(Lcom/example/bleconnectse/YadeaOtaClient;)V

    return-void
.end method
