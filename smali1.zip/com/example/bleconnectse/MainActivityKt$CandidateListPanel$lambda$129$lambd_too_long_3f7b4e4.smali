# classes2.dex

.class public final Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$8;
.super Ljava/lang/Object;
.source "LazyDsl.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/MainActivityKt;->CandidateListPanel(Lcom/example/bleconnectse/CandidatePanel;Lcom/example/bleconnectse/YadeaOtaClient;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function4<",
        "Landroidx/compose/foundation/lazy/LazyItemScope;",
        "Ljava/lang/Integer;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLazyDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt$items$4\n+ 2 MainActivity.kt\ncom/example/bleconnectse/MainActivityKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,523:1\n1355#2,3:524\n1359#2:533\n1128#3,6:527\n*S KotlinDebug\n*F\n+ 1 MainActivity.kt\ncom/example/bleconnectse/MainActivityKt\n*L\n1357#1:527,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $items:Ljava/util/List;

.field final synthetic $mirrorClient$inlined:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 3

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$8;->$items:Ljava/util/List;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$8;->$mirrorClient$inlined:Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 178
    check-cast p1, Landroidx/compose/foundation/lazy/LazyItemScope;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    move-result p2

    check-cast p3, Landroidx/compose/runtime/Composer;

    check-cast p4, Ljava/lang/Number;

    invoke-virtual {p4}, Ljava/lang/Number;->intValue()I

    move-result p4

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$8;->invoke(Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public final invoke(Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)V
    .registers 8

    const-string v0, "CN(it)178@8834L22:LazyDsl.kt#428nma"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p4, 0x6

    if-nez v0, :cond_14

    invoke-interface {p3, p1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_11

    const/4 p1, 0x4

    goto :goto_12

    :cond_11
    const/4 p1, 0x2

    :goto_12
    or-int/2addr p1, p4

    goto :goto_15

    :cond_14
    move p1, p4

    :goto_15
    and-int/lit8 p4, p4, 0x30

    if-nez p4, :cond_25

    invoke-interface {p3, p2}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result p4

    if-eqz p4, :cond_22

    const/16 p4, 0x20

    goto :goto_24

    :cond_22
    const/16 p4, 0x10

    :goto_24
    or-int/2addr p1, p4

    :cond_25
    and-int/lit16 p4, p1, 0x93

    const/16 v0, 0x92

    const/4 v1, 0x0

    if-eq p4, v0, :cond_2e

    const/4 p4, 0x1

    goto :goto_2f

    :cond_2e
    move p4, v1

    :goto_2f
    and-int/lit8 v0, p1, 0x1

    invoke-interface {p3, p4, v0}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result p4

    if-eqz p4, :cond_9c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p4

    if-eqz p4, :cond_46

    const/4 p4, -0x1

    const-string v0, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)"

    const v2, 0x2fd4df92

    invoke-static {v2, p1, p4, v0}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 179
    :cond_46
    iget-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$8;->$items:Ljava/util/List;

    invoke-interface {p1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/example/bleconnectse/P2pPeer;

    const p2, -0x84aa58

    .line 524
    invoke-interface {p3, p2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string p2, "CN(peer)*1356@55387L56,1354@55280L197:MainActivity.kt#p15tle"

    invoke-static {p3, p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const p2, -0x6b5f1172

    .line 525
    const-string p4, "CC(remember):MainActivity.kt#9igjgp"

    .line 526
    invoke-static {p3, p2, p4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    iget-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$8;->$mirrorClient$inlined:Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-interface {p3, p2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result p2

    invoke-interface {p3, p1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result p4

    or-int/2addr p2, p4

    .line 527
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object p4

    if-nez p2, :cond_7a

    .line 528
    sget-object p2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {p2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object p2

    if-ne p4, p2, :cond_87

    .line 526
    :cond_7a
    new-instance p2, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$1$1$2$1$4$1$1;

    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$8;->$mirrorClient$inlined:Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-direct {p2, p0, p1}, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$1$1$2$1$4$1$1;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V

    move-object p4, p2

    check-cast p4, Lkotlin/jvm/functions/Function0;

    .line 530
    invoke-interface {p3, p4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 526
    :cond_87
    check-cast p4, Lkotlin/jvm/functions/Function0;

    invoke-static {p3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 524
    invoke-static {p1, p4, p3, v1}, Lcom/example/bleconnectse/MainActivityKt;->access$P2pPeerRow(Lcom/example/bleconnectse/P2pPeer;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 179
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_9b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_9b
    return-void

    .line 178
    :cond_9c
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    return-void
.end method
