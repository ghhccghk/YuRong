# classes2.dex

.class public final Lcom/example/bleconnectse/TimelineRecorder;
.super Ljava/lang/Object;
.source "TimelineRecorder.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eJ\u000e\u0010\u000f\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0010"
    }
    d2 = {
        "Lcom/example/bleconnectse/TimelineRecorder;",
        "",
        "<init>",
        "()V",
        "zeroAtMs",
        "",
        "entries",
        "Landroidx/compose/runtime/snapshots/SnapshotStateList;",
        "Lcom/example/bleconnectse/TimelineEntry;",
        "getEntries",
        "()Landroidx/compose/runtime/snapshots/SnapshotStateList;",
        "reset",
        "",
        "message",
        "",
        "mark",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

.field private static final entries:Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "Lcom/example/bleconnectse/TimelineEntry;",
            ">;"
        }
    .end annotation
.end field

.field private static zeroAtMs:J


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/example/bleconnectse/TimelineRecorder;

    invoke-direct {v0}, Lcom/example/bleconnectse/TimelineRecorder;-><init>()V

    sput-object v0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    .line 16
    invoke-static {}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateListOf()Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-result-object v0

    sput-object v0, Lcom/example/bleconnectse/TimelineRecorder;->entries:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    const/16 v0, 0x8

    sput v0, Lcom/example/bleconnectse/TimelineRecorder;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final getEntries()Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "Lcom/example/bleconnectse/TimelineEntry;",
            ">;"
        }
    .end annotation

    .line 16
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->entries:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    return-object p0
.end method

.method public final mark(Ljava/lang/String;)V
    .registers 8

    const-string v0, "message"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    sget-wide v0, Lcom/example/bleconnectse/TimelineRecorder;->zeroAtMs:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-nez v0, :cond_11

    .line 26
    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/TimelineRecorder;->reset(Ljava/lang/String;)V

    return-void

    .line 29
    :cond_11
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->entries:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-object v0, p0

    check-cast v0, Ljava/util/Collection;

    new-instance v1, Lcom/example/bleconnectse/TimelineEntry;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    sget-wide v4, Lcom/example/bleconnectse/TimelineRecorder;->zeroAtMs:J

    sub-long/2addr v2, v4

    invoke-direct {v1, v2, v3, p1}, Lcom/example/bleconnectse/TimelineEntry;-><init>(JLjava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 30
    invoke-virtual {p0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->size()I

    move-result p1

    const/16 v0, 0xc8

    if-le p1, v0, :cond_36

    .line 31
    invoke-virtual {p0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->size()I

    move-result p1

    sub-int/2addr p1, v0

    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->removeRange(II)V

    :cond_36
    return-void
.end method

.method public final reset(Ljava/lang/String;)V
    .registers 5

    const-string p0, "message"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sput-wide v0, Lcom/example/bleconnectse/TimelineRecorder;->zeroAtMs:J

    .line 20
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->entries:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    invoke-virtual {p0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    .line 21
    check-cast p0, Ljava/util/Collection;

    new-instance v0, Lcom/example/bleconnectse/TimelineEntry;

    const-wide/16 v1, 0x0

    invoke-direct {v0, v1, v2, p1}, Lcom/example/bleconnectse/TimelineEntry;-><init>(JLjava/lang/String;)V

    invoke-interface {p0, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    return-void
.end method
