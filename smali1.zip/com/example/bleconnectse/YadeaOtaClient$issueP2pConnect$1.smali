# classes2.dex

.class public final Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;
.super Ljava/lang/Object;
.source "YadeaOtaClient.kt"

# interfaces
.implements Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/YadeaOtaClient;->issueP2pConnect(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Lcom/example/bleconnectse/P2pPeer;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nYadeaOtaClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 YadeaOtaClient.kt\ncom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,2252:1\n1#2:2253\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016J\u0010\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0006H\u0016¨\u0006\u0007"
    }
    d2 = {
        "com/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1",
        "Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;",
        "onSuccess",
        "",
        "onFailure",
        "reason",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $peer:Lcom/example/bleconnectse/P2pPeer;

.field final synthetic this$0:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/P2pPeer;Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 3

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;->$peer:Lcom/example/bleconnectse/P2pPeer;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    .line 1856
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onFailure(I)V
    .registers 4

    .line 1863
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setPendingP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V

    .line 1864
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-static {v0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setSelectedP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V

    .line 1865
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setP2pPeerVerified$p(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 1866
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "P2P 连接失败："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    return-void
.end method

.method public onSuccess()V
    .registers 5

    .line 1858
    sget-object v0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;->$peer:Lcom/example/bleconnectse/P2pPeer;

    invoke-virtual {v1}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;->$peer:Lcom/example/bleconnectse/P2pPeer;

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_16

    invoke-virtual {v2}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v1

    :cond_16
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "P2P 连接请求已发出："

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 1859
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    const-string v0, "P2P 连接请求已发出，等待目标身份校验"

    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    return-void
.end method
