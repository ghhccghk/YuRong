# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda60;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/CandidatePanel;

.field public final synthetic f$1:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/CandidatePanel;Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda60;->f$0:Lcom/example/bleconnectse/CandidatePanel;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda60;->f$1:Lcom/example/bleconnectse/YadeaOtaClient;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda60;->f$0:Lcom/example/bleconnectse/CandidatePanel;

    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda60;->f$1:Lcom/example/bleconnectse/YadeaOtaClient;

    check-cast p1, Landroidx/compose/foundation/lazy/LazyItemScope;

    check-cast p2, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-static {v0, p0, p1, p2, p3}, Lcom/example/bleconnectse/MainActivityKt;->MirrorNavScreen$lambda$105$lambda$104$lambda$101(Lcom/example/bleconnectse/CandidatePanel;Lcom/example/bleconnectse/YadeaOtaClient;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
