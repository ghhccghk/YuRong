# classes2.dex

.class public final Lcom/example/bleconnectse/JieliRleEncoder;
.super Ljava/lang/Object;
.source "JieliRleEncoder.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nJieliRleEncoder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JieliRleEncoder.kt\ncom/example/bleconnectse/JieliRleEncoder\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,49:1\n12637#2,2:50\n1#3:52\n*S KotlinDebug\n*F\n+ 1 JieliRleEncoder.kt\ncom/example/bleconnectse/JieliRleEncoder\n*L\n18#1:50,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0000\bÁ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\n"
    }
    d2 = {
        "Lcom/example/bleconnectse/JieliRleEncoder;",
        "",
        "<init>",
        "()V",
        "OPTIONS_JSON",
        "",
        "encode",
        "",
        "bitmap",
        "Landroid/graphics/Bitmap;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x0

.field public static final INSTANCE:Lcom/example/bleconnectse/JieliRleEncoder;

.field private static final OPTIONS_JSON:Ljava/lang/String; = "{\"lvgl\":{\"version\":\"LVGL8\"},\"compress\":{\"type\":\"RLE\"},\"image\":{\"format\":\"INDEXED_8BIT\"},\"options\":{\"block\":\"BLOCK_256x1\",\"clut_format\":\"ARGB8565\",\"yuv_format\":\"YUYV\"}}"


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/example/bleconnectse/JieliRleEncoder;

    invoke-direct {v0}, Lcom/example/bleconnectse/JieliRleEncoder;-><init>()V

    sput-object v0, Lcom/example/bleconnectse/JieliRleEncoder;->INSTANCE:Lcom/example/bleconnectse/JieliRleEncoder;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final encode(Landroid/graphics/Bitmap;)[B
    .registers 12

    const-string p0, "bitmap"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    sget-object p0, Landroid/os/Build;->SUPPORTED_ABIS:[Ljava/lang/String;

    const-string v0, "SUPPORTED_ABIS"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, [Ljava/lang/Object;

    .line 50
    array-length v1, p0

    const/4 v2, 0x0

    :goto_10
    if-ge v2, v1, :cond_ce

    aget-object v3, p0, v2

    check-cast v3, Ljava/lang/String;

    .line 18
    const-string v4, "arm64-v8a"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_ca

    .line 21
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    move-result-object p0

    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    if-ne p0, v0, :cond_bd

    .line 24
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getByteCount()I

    move-result p0

    invoke-static {p0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object p0

    move-object v0, p0

    check-cast v0, Ljava/nio/Buffer;

    invoke-virtual {p1, v0}, Landroid/graphics/Bitmap;->copyPixelsToBuffer(Ljava/nio/Buffer;)V

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v2

    .line 25
    const-string p0, "jl_compress_"

    const-string v0, ".zip"

    invoke-static {p0, v0}, Ljava/io/File;->createTempFile(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    .line 28
    :try_start_40
    new-instance v0, Lcom/jieli/lib/uiresconv/UiResConverter;

    invoke-direct {v0}, Lcom/jieli/lib/uiresconv/UiResConverter;-><init>()V

    move-object v7, v0

    check-cast v7, Ljava/lang/AutoCloseable;
    :try_end_48
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_40 .. :try_end_48} :catch_97
    .catchall {:try_start_40 .. :try_end_48} :catchall_94

    :try_start_48
    move-object v1, v7

    check-cast v1, Lcom/jieli/lib/uiresconv/UiResConverter;

    .line 31
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    .line 32
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    .line 33
    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5

    .line 34
    const-string/jumbo v6, "{\"lvgl\":{\"version\":\"LVGL8\"},\"compress\":{\"type\":\"RLE\"},\"image\":{\"format\":\"INDEXED_8BIT\"},\"options\":{\"block\":\"BLOCK_256x1\",\"clut_format\":\"ARGB8565\",\"yuv_format\":\"YUYV\"}}"

    .line 29
    invoke-virtual/range {v1 .. v6}, Lcom/jieli/lib/uiresconv/UiResConverter;->compressResource([BIILjava/lang/String;Ljava/lang/String;)Z

    move-result p1
    :try_end_5e
    .catchall {:try_start_48 .. :try_end_5e} :catchall_8c

    const/4 v0, 0x0

    .line 28
    :try_start_5f
    invoke-static {v7, v0}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V
    :try_end_62
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_5f .. :try_end_62} :catch_97
    .catchall {:try_start_5f .. :try_end_62} :catchall_94

    if-eqz p1, :cond_7f

    .line 40
    :try_start_64
    invoke-virtual {p0}, Ljava/io/File;->isFile()Z

    move-result p1

    if-eqz p1, :cond_7f

    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long p1, v0, v2

    if-lez p1, :cond_7f

    .line 43
    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {p0}, Lkotlin/io/FilesKt;->readBytes(Ljava/io/File;)[B

    move-result-object p1
    :try_end_7b
    .catchall {:try_start_64 .. :try_end_7b} :catchall_94

    .line 45
    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    return-object p1

    .line 41
    :cond_7f
    :try_start_7f
    const-string/jumbo p1, "杰理 RLE 转换失败"

    .line 40
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_8c
    .catchall {:try_start_7f .. :try_end_8c} :catchall_94

    :catchall_8c
    move-exception v0

    move-object p1, v0

    .line 28
    :try_start_8e
    throw p1
    :try_end_8f
    .catchall {:try_start_8e .. :try_end_8f} :catchall_8f

    :catchall_8f
    move-exception v0

    :try_start_90
    invoke-static {v7, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw v0
    :try_end_94
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_90 .. :try_end_94} :catch_97
    .catchall {:try_start_90 .. :try_end_94} :catchall_94

    :catchall_94
    move-exception v0

    move-object p1, v0

    goto :goto_b9

    :catch_97
    move-exception v0

    move-object p1, v0

    .line 38
    :try_start_99
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {p1}, Ljava/lang/UnsatisfiedLinkError;->getMessage()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "无法加载 libjl_uiresconv.so："

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    check-cast p1, Ljava/lang/Throwable;

    invoke-direct {v0, v1, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
    :try_end_b9
    .catchall {:try_start_99 .. :try_end_b9} :catchall_94

    .line 45
    :goto_b9
    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    throw p1

    .line 21
    :cond_bd
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string/jumbo p1, "杰理 RLE 输入必须是 ARGB_8888"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_ca
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_10

    .line 19
    :cond_ce
    sget-object p0, Landroid/os/Build;->SUPPORTED_ABIS:[Ljava/lang/String;

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v1, p0

    check-cast v1, [Ljava/lang/Object;

    const/16 v8, 0x3f

    const/4 v9, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v1 .. v9}, Lkotlin/collections/ArraysKt;->joinToString$default([Ljava/lang/Object;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "杰理 RLE 转换库仅包含 arm64-v8a，当前设备 ABI="

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 18
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
