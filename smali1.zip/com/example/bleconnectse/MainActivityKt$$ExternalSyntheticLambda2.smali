# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/BleTileClient;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/BleTileClient;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda2;->f$0:Lcom/example/bleconnectse/BleTileClient;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 1

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda2;->f$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {p0}, Lcom/example/bleconnectse/MainActivityKt;->BleTileOverlay$lambda$70$lambda$69$lambda$58$lambda$57(Lcom/example/bleconnectse/BleTileClient;)F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    return-object p0
.end method
