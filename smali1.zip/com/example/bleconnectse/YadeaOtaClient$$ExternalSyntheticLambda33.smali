# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:I

.field public final synthetic f$2:I

.field public final synthetic f$3:[B


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;II[B)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;->f$1:I

    iput p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;->f$2:I

    iput-object p4, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;->f$3:[B

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;->f$1:I

    iget v2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;->f$2:I

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;->f$3:[B

    invoke-static {v0, v1, v2, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->sendImagePackets$lambda$106(Lcom/example/bleconnectse/YadeaOtaClient;II[B)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
