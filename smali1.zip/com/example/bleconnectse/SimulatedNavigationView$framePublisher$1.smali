# classes2.dex

.class public final Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;
.super Ljava/lang/Object;
.source "SimulatedNavigationView.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/SimulatedNavigationView;-><init>(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016¨\u0006\u0004"
    }
    d2 = {
        "com/example/bleconnectse/SimulatedNavigationView$framePublisher$1",
        "Ljava/lang/Runnable;",
        "run",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/SimulatedNavigationView;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/SimulatedNavigationView;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;->this$0:Lcom/example/bleconnectse/SimulatedNavigationView;

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    .line 46
    iget-object v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;->this$0:Lcom/example/bleconnectse/SimulatedNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/SimulatedNavigationView;->access$getPublishing$p(Lcom/example/bleconnectse/SimulatedNavigationView;)Z

    move-result v0

    if-nez v0, :cond_9

    return-void

    .line 47
    :cond_9
    iget-object v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;->this$0:Lcom/example/bleconnectse/SimulatedNavigationView;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-static {v0, v1, v2}, Lcom/example/bleconnectse/SimulatedNavigationView;->access$updateAnimation(Lcom/example/bleconnectse/SimulatedNavigationView;J)V

    const/16 v0, 0x2d0

    .line 51
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/16 v2, 0x500

    .line 48
    invoke-static {v2, v0, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    const-string v1, "createBitmap(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    iget-object v1, p0, Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;->this$0:Lcom/example/bleconnectse/SimulatedNavigationView;

    .line 54
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/high16 v3, 0x44a00000  # 1280.0f

    const/high16 v4, 0x44340000  # 720.0f

    .line 53
    invoke-static {v1, v2, v3, v4}, Lcom/example/bleconnectse/SimulatedNavigationView;->access$drawNavigation(Lcom/example/bleconnectse/SimulatedNavigationView;Landroid/graphics/Canvas;FF)V

    .line 58
    sget-object v1, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v1, v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->submit(Landroid/graphics/Bitmap;)V

    .line 59
    iget-object v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;->this$0:Lcom/example/bleconnectse/SimulatedNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/SimulatedNavigationView;->access$getFrameHandler$p(Lcom/example/bleconnectse/SimulatedNavigationView;)Landroid/os/Handler;

    move-result-object v0

    check-cast p0, Ljava/lang/Runnable;

    const-wide/16 v1, 0x64

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
