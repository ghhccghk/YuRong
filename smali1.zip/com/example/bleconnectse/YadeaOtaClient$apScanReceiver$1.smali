# classes2.dex

.class public final Lcom/example/bleconnectse/YadeaOtaClient$apScanReceiver$1;
.super Landroid/content/BroadcastReceiver;
.source "YadeaOtaClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/YadeaOtaClient;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001d\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u001c\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0016¨\u0006\b"
    }
    d2 = {
        "com/example/bleconnectse/YadeaOtaClient$apScanReceiver$1",
        "Landroid/content/BroadcastReceiver;",
        "onReceive",
        "",
        "ctx",
        "Landroid/content/Context;",
        "intent",
        "Landroid/content/Intent;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$apScanReceiver$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    .line 189
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 4

    if-eqz p2, :cond_7

    .line 191
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    goto :goto_8

    :cond_7
    const/4 p1, 0x0

    :goto_8
    const-string v0, "android.net.wifi.SCAN_RESULTS"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_11

    return-void

    .line 192
    :cond_11
    const-string p1, "resultsUpdated"

    const/4 v0, 0x0

    invoke-virtual {p2, p1, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    .line 193
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$apScanReceiver$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-static {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$handleApScanResults(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    return-void
.end method
