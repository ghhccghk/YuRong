# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:J


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;J)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-wide p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;->f$1:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-wide v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;->f$1:J

    invoke-static {v0, v1, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->startMirror$lambda$70$lambda$69(Lcom/example/bleconnectse/YadeaOtaClient;J)V

    return-void
.end method
