# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda41;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/example/bleconnectse/YadeaWifiProfile;

    invoke-static {p1}, Lcom/example/bleconnectse/YadeaOtaClient;->handleApScanResults$lambda$83(Lcom/example/bleconnectse/YadeaWifiProfile;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method
