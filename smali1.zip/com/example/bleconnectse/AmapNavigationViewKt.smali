# classes2.dex

.class public final Lcom/example/bleconnectse/AmapNavigationViewKt;
.super Ljava/lang/Object;
.source "AmapNavigationView.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0018\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0005\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\b\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\t\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\n\u001a\u00020\u000bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\f"
    }
    d2 = {
        "AMAP_FRAME_WIDTH",
        "",
        "AMAP_FRAME_HEIGHT",
        "AMAP_FRAME_INTERVAL_MS",
        "",
        "AMAP_NAV_LOCK_ZOOM",
        "PIXEL_COPY_FAILURE_LIMIT",
        "PIXEL_COPY_RETRY_DELAY_MS",
        "AMAP_SCREENSHOT_TIMEOUT_MS",
        "CAPTURE_FPS_LOG_WINDOW_MS",
        "AMAP_CAPTURE_TAG",
        "",
        "app"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final AMAP_CAPTURE_TAG:Ljava/lang/String; = "AmapMirrorCapture"

.field private static final AMAP_FRAME_HEIGHT:I = 0x1e0

.field private static final AMAP_FRAME_INTERVAL_MS:J = 0x7dL

.field private static final AMAP_FRAME_WIDTH:I = 0x320

.field private static final AMAP_NAV_LOCK_ZOOM:I = 0xf

.field private static final AMAP_SCREENSHOT_TIMEOUT_MS:J = 0x5dcL

.field private static final CAPTURE_FPS_LOG_WINDOW_MS:J = 0x1388L

.field private static final PIXEL_COPY_FAILURE_LIMIT:I = 0x3

.field private static final PIXEL_COPY_RETRY_DELAY_MS:J = 0x1388L
