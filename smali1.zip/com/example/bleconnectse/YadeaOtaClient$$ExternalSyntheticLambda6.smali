# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:Landroid/net/Uri;

.field public final synthetic f$2:Lcom/example/bleconnectse/OtaNetworkMode;

.field public final synthetic f$3:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Uri;Lcom/example/bleconnectse/OtaNetworkMode;Ljava/lang/String;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;->f$1:Landroid/net/Uri;

    iput-object p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;->f$2:Lcom/example/bleconnectse/OtaNetworkMode;

    iput-object p4, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;->f$3:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;->f$1:Landroid/net/Uri;

    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;->f$2:Lcom/example/bleconnectse/OtaNetworkMode;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;->f$3:Ljava/lang/String;

    invoke-static {v0, v1, v2, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->startInstrumentWallpaper$lambda$44(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Uri;Lcom/example/bleconnectse/OtaNetworkMode;Ljava/lang/String;)V

    return-void
.end method
