# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/VideoMirrorController;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/VideoMirrorController;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda5;->f$0:Lcom/example/bleconnectse/VideoMirrorController;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 1

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/VideoMirrorController$$ExternalSyntheticLambda5;->f$0:Lcom/example/bleconnectse/VideoMirrorController;

    invoke-static {p0}, Lcom/example/bleconnectse/VideoMirrorController;->enterForeground$lambda$9(Lcom/example/bleconnectse/VideoMirrorController;)V

    return-void
.end method
