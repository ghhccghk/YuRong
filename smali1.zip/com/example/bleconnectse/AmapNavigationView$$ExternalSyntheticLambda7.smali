# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/AmapNavigationView;

.field public final synthetic f$1:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/AmapNavigationView;Ljava/util/List;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda7;->f$0:Lcom/example/bleconnectse/AmapNavigationView;

    iput-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda7;->f$1:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda7;->f$0:Lcom/example/bleconnectse/AmapNavigationView;

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda7;->f$1:Ljava/util/List;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/AmapNavigationView;->publishSuggestions$lambda$33(Lcom/example/bleconnectse/AmapNavigationView;Ljava/util/List;)V

    return-void
.end method
