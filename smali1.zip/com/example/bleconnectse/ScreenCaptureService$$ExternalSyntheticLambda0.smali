# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/ScreenCaptureService$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/ImageReader$OnImageAvailableListener;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/ScreenCaptureService;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/ScreenCaptureService;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/ScreenCaptureService$$ExternalSyntheticLambda0;->f$0:Lcom/example/bleconnectse/ScreenCaptureService;

    return-void
.end method


# virtual methods
.method public final onImageAvailable(Landroid/media/ImageReader;)V
    .registers 2

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/ScreenCaptureService$$ExternalSyntheticLambda0;->f$0:Lcom/example/bleconnectse/ScreenCaptureService;

    invoke-static {p0, p1}, Lcom/example/bleconnectse/ScreenCaptureService;->startCapture$lambda$2(Lcom/example/bleconnectse/ScreenCaptureService;Landroid/media/ImageReader;)V

    return-void
.end method
