# classes2.dex

.class final Lcom/example/bleconnectse/AmapNavigationView$Guidance;
.super Ljava/lang/Object;
.source "AmapNavigationView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/bleconnectse/AmapNavigationView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Guidance"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u001b\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001Bm\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007\u0012\b\b\u0002\u0010\t\u001a\u00020\u0007\u0012\b\b\u0002\u0010\n\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0007\u0012\b\b\u0002\u0010\f\u001a\u00020\u0003\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u000e¢\u0006\u0004\b\u000f\u0010\u0010J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0007HÆ\u0003J\t\u0010\"\u001a\u00020\u0007HÆ\u0003J\t\u0010#\u001a\u00020\u0007HÆ\u0003J\t\u0010$\u001a\u00020\u0007HÆ\u0003J\t\u0010%\u001a\u00020\u0007HÆ\u0003J\t\u0010&\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\'\u001a\u0004\u0018\u00010\u000eHÆ\u0003Jo\u0010(\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\u00072\b\b\u0002\u0010\n\u001a\u00020\u00072\b\b\u0002\u0010\u000b\u001a\u00020\u00072\b\b\u0002\u0010\f\u001a\u00020\u00032\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u000eHÆ\u0001J\u0013\u0010)\u001a\u00020*2\b\u0010+\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010,\u001a\u00020\u0007HÖ\u0001J\t\u0010-\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0016R\u0011\u0010\t\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0016R\u0011\u0010\n\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0016R\u0011\u0010\u000b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0016R\u0011\u0010\f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0012R\u0013\u0010\r\u001a\u0004\u0018\u00010\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001d¨\u0006."
    }
    d2 = {
        "Lcom/example/bleconnectse/AmapNavigationView$Guidance;",
        "",
        "currentRoad",
        "",
        "nextRoad",
        "instruction",
        "speedKph",
        "",
        "stepDistanceM",
        "remainDistanceM",
        "remainTimeS",
        "remainingTrafficLights",
        "modeLabel",
        "maneuverBitmap",
        "Landroid/graphics/Bitmap;",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;)V",
        "getCurrentRoad",
        "()Ljava/lang/String;",
        "getNextRoad",
        "getInstruction",
        "getSpeedKph",
        "()I",
        "getStepDistanceM",
        "getRemainDistanceM",
        "getRemainTimeS",
        "getRemainingTrafficLights",
        "getModeLabel",
        "getManeuverBitmap",
        "()Landroid/graphics/Bitmap;",
        "component1",
        "component2",
        "component3",
        "component4",
        "component5",
        "component6",
        "component7",
        "component8",
        "component9",
        "component10",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "toString",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final currentRoad:Ljava/lang/String;

.field private final instruction:Ljava/lang/String;

.field private final maneuverBitmap:Landroid/graphics/Bitmap;

.field private final modeLabel:Ljava/lang/String;

.field private final nextRoad:Ljava/lang/String;

.field private final remainDistanceM:I

.field private final remainTimeS:I

.field private final remainingTrafficLights:I

.field private final speedKph:I

.field private final stepDistanceM:I


# direct methods
.method public constructor <init>()V
    .registers 14

    const/16 v11, 0x3ff

    const/4 v12, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v12}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;)V
    .registers 12

    const-string v0, "currentRoad"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "nextRoad"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "instruction"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "modeLabel"

    invoke-static {p9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 99
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 100
    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->currentRoad:Ljava/lang/String;

    .line 101
    iput-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->nextRoad:Ljava/lang/String;

    .line 102
    iput-object p3, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->instruction:Ljava/lang/String;

    .line 103
    iput p4, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->speedKph:I

    .line 104
    iput p5, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->stepDistanceM:I

    .line 105
    iput p6, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainDistanceM:I

    .line 106
    iput p7, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainTimeS:I

    .line 107
    iput p8, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainingTrafficLights:I

    .line 108
    iput-object p9, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->modeLabel:Ljava/lang/String;

    .line 109
    iput-object p10, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->maneuverBitmap:Landroid/graphics/Bitmap;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 14

    and-int/lit8 p12, p11, 0x1

    if-eqz p12, :cond_6

    .line 100
    const-string p1, ""

    :cond_6
    and-int/lit8 p12, p11, 0x2

    if-eqz p12, :cond_d

    .line 101
    const-string/jumbo p2, "等待路线"

    :cond_d
    and-int/lit8 p12, p11, 0x4

    if-eqz p12, :cond_14

    .line 102
    const-string/jumbo p3, "长按地图选择目的地"

    :cond_14
    and-int/lit8 p12, p11, 0x8

    const/4 v0, 0x0

    if-eqz p12, :cond_1a

    move p4, v0

    :cond_1a
    and-int/lit8 p12, p11, 0x10

    if-eqz p12, :cond_1f

    move p5, v0

    :cond_1f
    and-int/lit8 p12, p11, 0x20

    if-eqz p12, :cond_24

    move p6, v0

    :cond_24
    and-int/lit8 p12, p11, 0x40

    if-eqz p12, :cond_29

    move p7, v0

    :cond_29
    and-int/lit16 p12, p11, 0x80

    if-eqz p12, :cond_2e

    move p8, v0

    :cond_2e
    and-int/lit16 p12, p11, 0x100

    if-eqz p12, :cond_34

    .line 108
    const-string p9, "GPS"

    :cond_34
    and-int/lit16 p11, p11, 0x200

    if-eqz p11, :cond_39

    const/4 p10, 0x0

    :cond_39
    move-object p11, p9

    move-object p12, p10

    move p9, p7

    move p10, p8

    move p7, p5

    move p8, p6

    move-object p5, p3

    move p6, p4

    move-object p3, p1

    move-object p4, p2

    move-object p2, p0

    .line 99
    invoke-direct/range {p2 .. p12}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;)V

    return-void
.end method

.method public static synthetic copy$default(Lcom/example/bleconnectse/AmapNavigationView$Guidance;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;ILjava/lang/Object;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;
    .registers 13

    and-int/lit8 p12, p11, 0x1

    if-eqz p12, :cond_6

    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->currentRoad:Ljava/lang/String;

    :cond_6
    and-int/lit8 p12, p11, 0x2

    if-eqz p12, :cond_c

    iget-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->nextRoad:Ljava/lang/String;

    :cond_c
    and-int/lit8 p12, p11, 0x4

    if-eqz p12, :cond_12

    iget-object p3, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->instruction:Ljava/lang/String;

    :cond_12
    and-int/lit8 p12, p11, 0x8

    if-eqz p12, :cond_18

    iget p4, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->speedKph:I

    :cond_18
    and-int/lit8 p12, p11, 0x10

    if-eqz p12, :cond_1e

    iget p5, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->stepDistanceM:I

    :cond_1e
    and-int/lit8 p12, p11, 0x20

    if-eqz p12, :cond_24

    iget p6, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainDistanceM:I

    :cond_24
    and-int/lit8 p12, p11, 0x40

    if-eqz p12, :cond_2a

    iget p7, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainTimeS:I

    :cond_2a
    and-int/lit16 p12, p11, 0x80

    if-eqz p12, :cond_30

    iget p8, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainingTrafficLights:I

    :cond_30
    and-int/lit16 p12, p11, 0x100

    if-eqz p12, :cond_36

    iget-object p9, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->modeLabel:Ljava/lang/String;

    :cond_36
    and-int/lit16 p11, p11, 0x200

    if-eqz p11, :cond_3c

    iget-object p10, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->maneuverBitmap:Landroid/graphics/Bitmap;

    :cond_3c
    move-object p11, p9

    move-object p12, p10

    move p9, p7

    move p10, p8

    move p7, p5

    move p8, p6

    move-object p5, p3

    move p6, p4

    move-object p3, p1

    move-object p4, p2

    move-object p2, p0

    invoke-virtual/range {p2 .. p12}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->currentRoad:Ljava/lang/String;

    return-object p0
.end method

.method public final component10()Landroid/graphics/Bitmap;
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->maneuverBitmap:Landroid/graphics/Bitmap;

    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->nextRoad:Ljava/lang/String;

    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->instruction:Ljava/lang/String;

    return-object p0
.end method

.method public final component4()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->speedKph:I

    return p0
.end method

.method public final component5()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->stepDistanceM:I

    return p0
.end method

.method public final component6()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainDistanceM:I

    return p0
.end method

.method public final component7()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainTimeS:I

    return p0
.end method

.method public final component8()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainingTrafficLights:I

    return p0
.end method

.method public final component9()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->modeLabel:Ljava/lang/String;

    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;
    .registers 22

    const-string p0, "currentRoad"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "nextRoad"

    invoke-static {p2, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "instruction"

    invoke-static {p3, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "modeLabel"

    move-object/from16 v9, p9

    invoke-static {v9, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move/from16 v7, p7

    move/from16 v8, p8

    move-object/from16 v10, p10

    invoke-direct/range {v0 .. v10}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->currentRoad:Ljava/lang/String;

    iget-object v3, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->currentRoad:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->nextRoad:Ljava/lang/String;

    iget-object v3, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->nextRoad:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    return v2

    :cond_22
    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->instruction:Ljava/lang/String;

    iget-object v3, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->instruction:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2d

    return v2

    :cond_2d
    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->speedKph:I

    iget v3, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->speedKph:I

    if-eq v1, v3, :cond_34

    return v2

    :cond_34
    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->stepDistanceM:I

    iget v3, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->stepDistanceM:I

    if-eq v1, v3, :cond_3b

    return v2

    :cond_3b
    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainDistanceM:I

    iget v3, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainDistanceM:I

    if-eq v1, v3, :cond_42

    return v2

    :cond_42
    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainTimeS:I

    iget v3, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainTimeS:I

    if-eq v1, v3, :cond_49

    return v2

    :cond_49
    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainingTrafficLights:I

    iget v3, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainingTrafficLights:I

    if-eq v1, v3, :cond_50

    return v2

    :cond_50
    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->modeLabel:Ljava/lang/String;

    iget-object v3, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->modeLabel:Ljava/lang/String;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5b

    return v2

    :cond_5b
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->maneuverBitmap:Landroid/graphics/Bitmap;

    iget-object p1, p1, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->maneuverBitmap:Landroid/graphics/Bitmap;

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_66

    return v2

    :cond_66
    return v0
.end method

.method public final getCurrentRoad()Ljava/lang/String;
    .registers 1

    .line 100
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->currentRoad:Ljava/lang/String;

    return-object p0
.end method

.method public final getInstruction()Ljava/lang/String;
    .registers 1

    .line 102
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->instruction:Ljava/lang/String;

    return-object p0
.end method

.method public final getManeuverBitmap()Landroid/graphics/Bitmap;
    .registers 1

    .line 109
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->maneuverBitmap:Landroid/graphics/Bitmap;

    return-object p0
.end method

.method public final getModeLabel()Ljava/lang/String;
    .registers 1

    .line 108
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->modeLabel:Ljava/lang/String;

    return-object p0
.end method

.method public final getNextRoad()Ljava/lang/String;
    .registers 1

    .line 101
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->nextRoad:Ljava/lang/String;

    return-object p0
.end method

.method public final getRemainDistanceM()I
    .registers 1

    .line 105
    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainDistanceM:I

    return p0
.end method

.method public final getRemainTimeS()I
    .registers 1

    .line 106
    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainTimeS:I

    return p0
.end method

.method public final getRemainingTrafficLights()I
    .registers 1

    .line 107
    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainingTrafficLights:I

    return p0
.end method

.method public final getSpeedKph()I
    .registers 1

    .line 103
    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->speedKph:I

    return p0
.end method

.method public final getStepDistanceM()I
    .registers 1

    .line 104
    iget p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->stepDistanceM:I

    return p0
.end method

.method public hashCode()I
    .registers 3

    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->currentRoad:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->nextRoad:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->instruction:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->speedKph:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->stepDistanceM:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainDistanceM:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainTimeS:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainingTrafficLights:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->modeLabel:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->maneuverBitmap:Landroid/graphics/Bitmap;

    if-nez p0, :cond_56

    const/4 p0, 0x0

    goto :goto_5a

    :cond_56
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->hashCode()I

    move-result p0

    :goto_5a
    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 12

    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->currentRoad:Ljava/lang/String;

    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->nextRoad:Ljava/lang/String;

    iget-object v2, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->instruction:Ljava/lang/String;

    iget v3, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->speedKph:I

    iget v4, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->stepDistanceM:I

    iget v5, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainDistanceM:I

    iget v6, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainTimeS:I

    iget v7, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->remainingTrafficLights:I

    iget-object v8, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->modeLabel:Ljava/lang/String;

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->maneuverBitmap:Landroid/graphics/Bitmap;

    new-instance v9, Ljava/lang/StringBuilder;

    const-string v10, "Guidance(currentRoad="

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v9, ", nextRoad="

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", instruction="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", speedKph="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", stepDistanceM="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", remainDistanceM="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", remainTimeS="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", remainingTrafficLights="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", modeLabel="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", maneuverBitmap="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ")"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
