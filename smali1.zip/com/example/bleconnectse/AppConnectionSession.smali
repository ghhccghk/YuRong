# classes2.dex

.class public final Lcom/example/bleconnectse/AppConnectionSession;
.super Ljava/lang/Object;
.source "AppConnectionSession.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAppConnectionSession.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AppConnectionSession.kt\ncom/example/bleconnectse/AppConnectionSession\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,23:1\n1#2:24\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0002\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\"\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\f0\nJ\u0006\u0010\r\u001a\u00020\fR\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u000e"
    }
    d2 = {
        "Lcom/example/bleconnectse/AppConnectionSession;",
        "",
        "<init>",
        "()V",
        "client",
        "Lcom/example/bleconnectse/YadeaOtaClient;",
        "obtain",
        "context",
        "Landroid/content/Context;",
        "logger",
        "Lkotlin/Function1;",
        "",
        "",
        "stopMirrorIfPresent",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/example/bleconnectse/AppConnectionSession;

.field private static volatile client:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/example/bleconnectse/AppConnectionSession;

    invoke-direct {v0}, Lcom/example/bleconnectse/AppConnectionSession;-><init>()V

    sput-object v0, Lcom/example/bleconnectse/AppConnectionSession;->INSTANCE:Lcom/example/bleconnectse/AppConnectionSession;

    const/16 v0, 0x8

    sput v0, Lcom/example/bleconnectse/AppConnectionSession;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final obtain(Landroid/content/Context;Lkotlin/jvm/functions/Function1;)Lcom/example/bleconnectse/YadeaOtaClient;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)",
            "Lcom/example/bleconnectse/YadeaOtaClient;"
        }
    .end annotation

    .line 10
    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "logger"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, Lcom/example/bleconnectse/AppConnectionSession;->client:Lcom/example/bleconnectse/YadeaOtaClient;

    if-eqz v0, :cond_f

    return-object v0

    .line 11
    :cond_f
    monitor-enter p0

    .line 12
    :try_start_10
    sget-object v0, Lcom/example/bleconnectse/AppConnectionSession;->client:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez v0, :cond_22

    .line 13
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    .line 14
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v0, p1, p2}, Lcom/example/bleconnectse/YadeaOtaClient;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;)V

    sput-object v0, Lcom/example/bleconnectse/AppConnectionSession;->client:Lcom/example/bleconnectse/YadeaOtaClient;
    :try_end_22
    .catchall {:try_start_10 .. :try_end_22} :catchall_24

    .line 11
    :cond_22
    monitor-exit p0

    return-object v0

    :catchall_24
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final stopMirrorIfPresent()V
    .registers 1

    .line 20
    sget-object p0, Lcom/example/bleconnectse/AppConnectionSession;->client:Lcom/example/bleconnectse/YadeaOtaClient;

    if-eqz p0, :cond_7

    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->stopMirrorDemo()V

    :cond_7
    return-void
.end method
