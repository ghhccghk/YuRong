# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/PixelCopy$OnPixelCopyFinishedListener;


# instance fields
.field public final synthetic f$0:Landroid/view/Surface;

.field public final synthetic f$1:Lcom/example/bleconnectse/AmapNavigationView;

.field public final synthetic f$2:I

.field public final synthetic f$3:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

.field public final synthetic f$4:I

.field public final synthetic f$5:I

.field public final synthetic f$6:Landroid/graphics/Bitmap;

.field public final synthetic f$7:J


# direct methods
.method public synthetic constructor <init>(Landroid/view/Surface;Lcom/example/bleconnectse/AmapNavigationView;ILcom/example/bleconnectse/AmapNavigationView$CaptureMode;IILandroid/graphics/Bitmap;J)V
    .registers 10

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$0:Landroid/view/Surface;

    iput-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$1:Lcom/example/bleconnectse/AmapNavigationView;

    iput p3, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$2:I

    iput-object p4, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$3:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

    iput p5, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$4:I

    iput p6, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$5:I

    iput-object p7, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$6:Landroid/graphics/Bitmap;

    iput-wide p8, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$7:J

    return-void
.end method


# virtual methods
.method public final onPixelCopyFinished(I)V
    .registers 12

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$0:Landroid/view/Surface;

    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$1:Lcom/example/bleconnectse/AmapNavigationView;

    iget v2, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$2:I

    iget-object v3, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$3:Lcom/example/bleconnectse/AmapNavigationView$CaptureMode;

    iget v4, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$4:I

    iget v5, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$5:I

    iget-object v6, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$6:Landroid/graphics/Bitmap;

    iget-wide v7, p0, Lcom/example/bleconnectse/AmapNavigationView$$ExternalSyntheticLambda6;->f$7:J

    move v9, p1

    invoke-static/range {v0 .. v9}, Lcom/example/bleconnectse/AmapNavigationView;->requestPixelCopyFrame$lambda$21(Landroid/view/Surface;Lcom/example/bleconnectse/AmapNavigationView;ILcom/example/bleconnectse/AmapNavigationView$CaptureMode;IILandroid/graphics/Bitmap;JI)V

    return-void
.end method
