# classes2.dex

.class public final Lcom/example/bleconnectse/YadeaOtaClient$discoverPendingP2pPeer$2;
.super Ljava/lang/Object;
.source "YadeaOtaClient.kt"

# interfaces
.implements Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/YadeaOtaClient;->discoverPendingP2pPeer(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016J\u0010\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0006H\u0016¨\u0006\u0007"
    }
    d2 = {
        "com/example/bleconnectse/YadeaOtaClient$discoverPendingP2pPeer$2",
        "Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;",
        "onSuccess",
        "",
        "onFailure",
        "reason",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$discoverPendingP2pPeer$2;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    .line 1827
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onFailure(I)V
    .registers 4

    .line 1833
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$discoverPendingP2pPeer$2;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setPendingP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V

    .line 1834
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$discoverPendingP2pPeer$2;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "切车 P2P 搜索失败："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    return-void
.end method

.method public onSuccess()V
    .registers 2

    .line 1829
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$discoverPendingP2pPeer$2;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    const-string/jumbo v0, "切车 P2P 搜索已开始"

    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    return-void
.end method
