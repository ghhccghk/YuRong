# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:Ljava/util/List;

.field public final synthetic f$10:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$11:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$12:Z

.field public final synthetic f$13:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$14:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$15:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$16:Landroidx/compose/ui/Modifier;

.field public final synthetic f$17:I

.field public final synthetic f$18:I

.field public final synthetic f$19:I

.field public final synthetic f$2:Z

.field public final synthetic f$3:Lcom/example/bleconnectse/CandidatePanel;

.field public final synthetic f$4:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$5:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$6:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$7:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$8:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$9:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/util/List;ZLcom/example/bleconnectse/CandidatePanel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;III)V
    .registers 21

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$1:Ljava/util/List;

    iput-boolean p3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$2:Z

    iput-object p4, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$3:Lcom/example/bleconnectse/CandidatePanel;

    iput-object p5, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$4:Lkotlin/jvm/functions/Function0;

    iput-object p6, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$5:Lkotlin/jvm/functions/Function0;

    iput-object p7, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$6:Lkotlin/jvm/functions/Function0;

    iput-object p8, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$7:Lkotlin/jvm/functions/Function0;

    iput-object p9, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$8:Lkotlin/jvm/functions/Function0;

    iput-object p10, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$9:Lkotlin/jvm/functions/Function0;

    iput-object p11, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$10:Lkotlin/jvm/functions/Function0;

    iput-object p12, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$11:Lkotlin/jvm/functions/Function0;

    iput-boolean p13, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$12:Z

    iput-object p14, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$13:Lkotlin/jvm/functions/Function0;

    iput-object p15, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$14:Lkotlin/jvm/functions/Function0;

    move-object/from16 p1, p16

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$15:Lkotlin/jvm/functions/Function0;

    move-object/from16 p1, p17

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$16:Landroidx/compose/ui/Modifier;

    move/from16 p1, p18

    iput p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$17:I

    move/from16 p1, p19

    iput p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$18:I

    move/from16 p1, p20

    iput p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$19:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 26

    .line 0
    move-object/from16 v0, p0

    iget-object v1, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v2, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$1:Ljava/util/List;

    iget-boolean v3, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$2:Z

    iget-object v4, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$3:Lcom/example/bleconnectse/CandidatePanel;

    iget-object v5, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$4:Lkotlin/jvm/functions/Function0;

    iget-object v6, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$5:Lkotlin/jvm/functions/Function0;

    iget-object v7, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$6:Lkotlin/jvm/functions/Function0;

    iget-object v8, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$7:Lkotlin/jvm/functions/Function0;

    iget-object v9, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$8:Lkotlin/jvm/functions/Function0;

    iget-object v10, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$9:Lkotlin/jvm/functions/Function0;

    iget-object v11, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$10:Lkotlin/jvm/functions/Function0;

    iget-object v12, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$11:Lkotlin/jvm/functions/Function0;

    iget-boolean v13, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$12:Z

    iget-object v14, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$13:Lkotlin/jvm/functions/Function0;

    iget-object v15, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$14:Lkotlin/jvm/functions/Function0;

    move-object/from16 v16, v1

    iget-object v1, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$15:Lkotlin/jvm/functions/Function0;

    move-object/from16 v17, v1

    iget-object v1, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$16:Landroidx/compose/ui/Modifier;

    move-object/from16 v18, v1

    iget v1, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$17:I

    move/from16 v19, v1

    iget v1, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$18:I

    iget v0, v0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda7;->f$19:I

    move-object/from16 v21, p1

    check-cast v21, Landroidx/compose/runtime/Composer;

    move-object/from16 v20, p2

    check-cast v20, Ljava/lang/Integer;

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Integer;->intValue()I

    move-result v22

    move/from16 v20, v19

    move/from16 v19, v1

    move-object/from16 v1, v16

    move-object/from16 v16, v17

    move-object/from16 v17, v18

    move/from16 v18, v20

    move/from16 v20, v0

    invoke-static/range {v1 .. v22}, Lcom/example/bleconnectse/MainActivityKt;->MirrorNavScreen$lambda$106(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/util/List;ZLcom/example/bleconnectse/CandidatePanel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;IIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method
