# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/net/wifi/p2p/WifiP2pManager$ConnectionInfoListener;


# instance fields
.field public final synthetic f$0:Landroid/net/wifi/p2p/WifiP2pManager;

.field public final synthetic f$1:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

.field public final synthetic f$2:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method public synthetic constructor <init>(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda5;->f$0:Landroid/net/wifi/p2p/WifiP2pManager;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda5;->f$1:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    iput-object p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda5;->f$2:Lcom/example/bleconnectse/YadeaOtaClient;

    return-void
.end method


# virtual methods
.method public final onConnectionInfoAvailable(Landroid/net/wifi/p2p/WifiP2pInfo;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda5;->f$0:Landroid/net/wifi/p2p/WifiP2pManager;

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda5;->f$1:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda5;->f$2:Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-static {v0, v1, p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->onReceive$lambda$12(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/wifi/p2p/WifiP2pInfo;)V

    return-void
.end method
