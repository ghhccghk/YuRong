# classes2.dex

.class public final Lcom/example/bleconnectse/VideoBackgroundFrameServiceKt;
.super Ljava/lang/Object;
.source "VideoBackgroundFrameService.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u001a\u0013\u0010\u0000\u001a\u00020\u0001*\u0004\u0018\u00010\u0001H\u0002¢\u0006\u0002\u0010\u0002\u001a\u0013\u0010\u0003\u001a\u00020\u0004*\u0004\u0018\u00010\u0004H\u0002¢\u0006\u0002\u0010\u0005\u001a\u0016\u0010\u0006\u001a\u0004\u0018\u00010\u0007*\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0002¨\u0006\u000b"
    }
    d2 = {
        "orEmptyDuration",
        "",
        "(Ljava/lang/Long;)J",
        "orEmptyDimension",
        "",
        "(Ljava/lang/Integer;)I",
        "uriExtra",
        "Landroid/net/Uri;",
        "Landroid/content/Intent;",
        "name",
        "",
        "app"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final synthetic access$orEmptyDimension(Ljava/lang/Integer;)I
    .registers 1

    .line 1
    invoke-static {p0}, Lcom/example/bleconnectse/VideoBackgroundFrameServiceKt;->orEmptyDimension(Ljava/lang/Integer;)I

    move-result p0

    return p0
.end method

.method public static final synthetic access$orEmptyDuration(Ljava/lang/Long;)J
    .registers 3

    .line 1
    invoke-static {p0}, Lcom/example/bleconnectse/VideoBackgroundFrameServiceKt;->orEmptyDuration(Ljava/lang/Long;)J

    move-result-wide v0

    return-wide v0
.end method

.method public static final synthetic access$uriExtra(Landroid/content/Intent;Ljava/lang/String;)Landroid/net/Uri;
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lcom/example/bleconnectse/VideoBackgroundFrameServiceKt;->uriExtra(Landroid/content/Intent;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    return-object p0
.end method

.method private static final orEmptyDimension(Ljava/lang/Integer;)I
    .registers 2

    const/4 v0, 0x0

    if-eqz p0, :cond_c

    .line 195
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-static {p0, v0}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result p0

    return p0

    :cond_c
    return v0
.end method

.method private static final orEmptyDuration(Ljava/lang/Long;)J
    .registers 5

    const-wide/16 v0, 0x0

    if-eqz p0, :cond_c

    .line 194
    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-static {v2, v3, v0, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v0

    :cond_c
    return-wide v0
.end method

.method private static final uriExtra(Landroid/content/Intent;Ljava/lang/String;)Landroid/net/Uri;
    .registers 4

    .line 198
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    if-lt v0, v1, :cond_f

    .line 199
    const-class v0, Landroid/net/Uri;

    invoke-virtual {p0, p1, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/net/Uri;

    return-object p0

    .line 202
    :cond_f
    invoke-virtual {p0, p1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p0

    check-cast p0, Landroid/net/Uri;

    return-object p0
.end method
