# classes2.dex

.class public final Lcom/example/bleconnectse/SyntheticTileRepository;
.super Ljava/lang/Object;
.source "SyntheticTileRepository.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;,
        Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;,
        Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;,
        Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSyntheticTileRepository.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SyntheticTileRepository.kt\ncom/example/bleconnectse/SyntheticTileRepository\n+ 2 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,320:1\n382#2,7:321\n382#2,7:415\n1617#3,9:328\n1869#3:337\n1870#3:339\n1626#3:340\n1617#3,9:341\n1869#3:350\n1563#3:351\n1634#3,3:352\n1870#3:356\n1626#3:357\n774#3:358\n865#3,2:359\n1563#3:361\n1634#3,3:362\n1869#3,2:365\n1869#3,2:367\n1869#3,2:369\n1788#3,4:371\n1788#3,4:375\n1788#3,4:379\n1869#3:383\n1869#3,2:384\n1870#3:386\n1056#3:387\n1869#3:388\n1869#3,2:389\n1870#3:391\n1869#3,2:392\n1869#3:395\n295#3,2:396\n1869#3,2:398\n1870#3:400\n1563#3:401\n1634#3,3:402\n1563#3:405\n1634#3,3:406\n1869#3,2:409\n1563#3:411\n1634#3,3:412\n1#4:338\n1#4:355\n1#4:394\n*S KotlinDebug\n*F\n+ 1 SyntheticTileRepository.kt\ncom/example/bleconnectse/SyntheticTileRepository\n*L\n47#1:321,7\n93#1:415,7\n68#1:328,9\n68#1:337\n68#1:339\n68#1:340\n77#1:341,9\n77#1:350\n81#1:351\n81#1:352,3\n77#1:356\n77#1:357\n86#1:358\n86#1:359,2\n87#1:361\n87#1:362,3\n101#1:365,2\n102#1:367,2\n103#1:369,2\n105#1:371,4\n106#1:375,4\n107#1:379,4\n128#1:383\n136#1:384,2\n128#1:386\n141#1:387\n141#1:388\n145#1:389,2\n141#1:391\n150#1:392,2\n180#1:395\n181#1:396,2\n185#1:398,2\n180#1:400\n258#1:401\n258#1:402,3\n263#1:405\n263#1:406,3\n277#1:409,2\n303#1:411\n303#1:412,3\n68#1:338\n77#1:355\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0006\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0007\u0018\u00002\u00020\u0001:\u00044567B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\b\u001a\u0004\u0018\u00010\u00072\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0006J\u001c\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00070\f2\u0006\u0010\r\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\u0006J\u0018\u0010\u000f\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0006H\u0002J.\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00110\f2\u0006\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00062\u0006\u0010\u0014\u001a\u00020\u00062\u0006\u0010\u0015\u001a\u00020\u0006H\u0002JF\u0010\u0016\u001a\u0010\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u0018\u0018\u00010\u00172\u0006\u0010\u0019\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u00182\u0006\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00062\u0006\u0010\u0014\u001a\u00020\u00062\u0006\u0010\u0015\u001a\u00020\u0006H\u0002J<\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u00180\f2\f\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u00180\f2\u0006\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00062\u0006\u0010\u0014\u001a\u00020\u00062\u0006\u0010\u0015\u001a\u00020\u0006H\u0002JJ\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u001e0\f2\f\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u001e0\f2\u0012\u0010 \u001a\u000e\u0012\u0004\u0012\u00020\u001e\u0012\u0004\u0012\u00020\"0!2\u0018\u0010#\u001a\u0014\u0012\u0004\u0012\u00020\u001e\u0012\u0004\u0012\u00020\u001e\u0012\u0004\u0012\u00020\u001e0$H\u0002J \u0010%\u001a\u00020\u001e2\u0006\u0010&\u001a\u00020\u001e2\u0006\u0010\'\u001a\u00020\u001e2\u0006\u0010(\u001a\u00020)H\u0002J \u0010*\u001a\u00020\u001e2\u0006\u0010&\u001a\u00020\u001e2\u0006\u0010\'\u001a\u00020\u001e2\u0006\u0010+\u001a\u00020)H\u0002J$\u0010,\u001a\b\u0012\u0004\u0012\u00020\u00180\f2\f\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u00180\f2\u0006\u0010-\u001a\u00020\u0006H\u0002J\u001c\u0010.\u001a\u00020\u0018*\u00020\u00182\u0006\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u0006H\u0002J\u0014\u0010/\u001a\u000200*\u0002012\u0006\u00102\u001a\u00020\u0006H\u0002J\u0014\u00103\u001a\u000200*\u0002012\u0006\u00102\u001a\u00020\u0006H\u0002R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u00068"
    }
    d2 = {
        "Lcom/example/bleconnectse/SyntheticTileRepository;",
        "",
        "<init>",
        "()V",
        "cache",
        "",
        "",
        "Lcom/example/bleconnectse/SyntheticTile;",
        "tile",
        "tileX",
        "tileY",
        "neighborhood",
        "",
        "centerTileX",
        "centerTileY",
        "encodeTile",
        "buildTileRoads",
        "Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;",
        "left",
        "top",
        "right",
        "bottom",
        "clipSegment",
        "Lkotlin/Pair;",
        "Lcom/example/bleconnectse/SyntheticPoint;",
        "from",
        "to",
        "clipPolygon",
        "points",
        "clipEdge",
        "Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;",
        "input",
        "inside",
        "Lkotlin/Function1;",
        "",
        "intersection",
        "Lkotlin/Function2;",
        "intersectVertical",
        "a",
        "b",
        "x",
        "",
        "intersectHorizontal",
        "y",
        "simplify",
        "maximum",
        "toLocal",
        "writeUInt16Le",
        "",
        "Ljava/io/ByteArrayOutputStream;",
        "value",
        "writeInt16Le",
        "TileRoad",
        "TileArea",
        "TileJunction",
        "DoublePoint",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final cache:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lcom/example/bleconnectse/SyntheticTile;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 37
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v0, Ljava/util/Map;

    iput-object v0, p0, Lcom/example/bleconnectse/SyntheticTileRepository;->cache:Ljava/util/Map;

    return-void
.end method

.method private final buildTileRoads(IIII)Ljava/util/List;
    .registers 25
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IIII)",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;",
            ">;"
        }
    .end annotation

    move/from16 v3, p1

    move/from16 v4, p2

    .line 172
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v7, v0

    check-cast v7, Ljava/util/List;

    .line 173
    sget-object v0, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticMapData;->getRoads()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    new-instance v8, Lcom/example/bleconnectse/SyntheticRoad;

    .line 174
    sget-object v1, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticMapData;->getNavigationRoute()Ljava/util/List;

    move-result-object v9

    .line 175
    sget-object v10, Lcom/example/bleconnectse/SyntheticRoadClass;->Navigation:Lcom/example/bleconnectse/SyntheticRoadClass;

    .line 176
    sget-object v11, Lcom/example/bleconnectse/SyntheticTraffic;->Clear:Lcom/example/bleconnectse/SyntheticTraffic;

    .line 177
    const-string v12, ""

    .line 178
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v13

    .line 173
    invoke-direct/range {v8 .. v13}, Lcom/example/bleconnectse/SyntheticRoad;-><init>(Ljava/util/List;Lcom/example/bleconnectse/SyntheticRoadClass;Lcom/example/bleconnectse/SyntheticTraffic;Ljava/lang/String;Ljava/util/List;)V

    invoke-static {v0, v8}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    .line 180
    check-cast v0, Ljava/lang/Iterable;

    .line 395
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_33
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_108

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lcom/example/bleconnectse/SyntheticRoad;

    .line 181
    invoke-virtual {v9}, Lcom/example/bleconnectse/SyntheticRoad;->getLabelPositions()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 396
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_4a
    :goto_4a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_6f

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Lcom/example/bleconnectse/SyntheticPoint;

    .line 182
    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v5

    move/from16 v6, p3

    if-gt v3, v5, :cond_6c

    if-gt v5, v6, :cond_6c

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v2

    if-gt v4, v2, :cond_6c

    move/from16 v5, p4

    if-gt v2, v5, :cond_4a

    goto :goto_74

    :cond_6c
    move/from16 v5, p4

    goto :goto_4a

    :cond_6f
    move/from16 v6, p3

    move/from16 v5, p4

    const/4 v1, 0x0

    .line 181
    :goto_74
    move-object v11, v1

    check-cast v11, Lcom/example/bleconnectse/SyntheticPoint;

    .line 185
    invoke-virtual {v9}, Lcom/example/bleconnectse/SyntheticRoad;->getPoints()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->zipWithNext(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 398
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    const/4 v13, 0x0

    move v14, v13

    :goto_89
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_104

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkotlin/Pair;

    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lcom/example/bleconnectse/SyntheticPoint;

    move v0, v6

    move v6, v5

    move v5, v0

    move-object/from16 v0, p0

    .line 186
    invoke-direct/range {v0 .. v6}, Lcom/example/bleconnectse/SyntheticTileRepository;->clipSegment(Lcom/example/bleconnectse/SyntheticPoint;Lcom/example/bleconnectse/SyntheticPoint;IIII)Lkotlin/Pair;

    move-result-object v1

    if-nez v1, :cond_ae

    goto :goto_ff

    :cond_ae
    if-nez v14, :cond_ba

    if-eqz v11, :cond_ba

    .line 189
    invoke-direct {v0, v11, v3, v4}, Lcom/example/bleconnectse/SyntheticTileRepository;->toLocal(Lcom/example/bleconnectse/SyntheticPoint;II)Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v5

    move-object/from16 v19, v5

    const/4 v5, 0x1

    goto :goto_bd

    :cond_ba
    move v5, v14

    const/16 v19, 0x0

    .line 193
    :goto_bd
    move-object v6, v7

    check-cast v6, Ljava/util/Collection;

    new-instance v14, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;

    .line 194
    invoke-virtual {v9}, Lcom/example/bleconnectse/SyntheticRoad;->getRoadClass()Lcom/example/bleconnectse/SyntheticRoadClass;

    move-result-object v15

    .line 195
    invoke-virtual {v9}, Lcom/example/bleconnectse/SyntheticRoad;->getTraffic()Lcom/example/bleconnectse/SyntheticTraffic;

    move-result-object v16

    const/16 v17, 0x1

    const/4 v2, 0x2

    .line 197
    new-array v2, v2, [Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v18

    move-object/from16 v10, v18

    check-cast v10, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v0, v10, v3, v4}, Lcom/example/bleconnectse/SyntheticTileRepository;->toLocal(Lcom/example/bleconnectse/SyntheticPoint;II)Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v10

    aput-object v10, v2, v13

    .line 198
    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-direct {v0, v1, v3, v4}, Lcom/example/bleconnectse/SyntheticTileRepository;->toLocal(Lcom/example/bleconnectse/SyntheticPoint;II)Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v1

    aput-object v1, v2, v17

    .line 196
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v17

    if-eqz v19, :cond_f4

    .line 200
    invoke-virtual {v9}, Lcom/example/bleconnectse/SyntheticRoad;->getName()Ljava/lang/String;

    move-result-object v1

    goto :goto_f6

    :cond_f4
    const-string v1, ""

    :goto_f6
    move-object/from16 v18, v1

    .line 193
    invoke-direct/range {v14 .. v19}, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;-><init>(Lcom/example/bleconnectse/SyntheticRoadClass;Lcom/example/bleconnectse/SyntheticTraffic;Ljava/util/List;Ljava/lang/String;Lcom/example/bleconnectse/SyntheticPoint;)V

    invoke-interface {v6, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move v14, v5

    :goto_ff
    move/from16 v6, p3

    move/from16 v5, p4

    goto :goto_89

    :cond_104
    move-object/from16 v0, p0

    goto/16 :goto_33

    :cond_108
    return-object v7
.end method

.method private final clipEdge(Ljava/util/List;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;)Ljava/util/List;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;",
            "-",
            "Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;",
            "Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;",
            ">;"
        }
    .end annotation

    .line 273
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_b

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p0

    return-object p0

    .line 274
    :cond_b
    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    check-cast p0, Ljava/util/List;

    .line 275
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    .line 276
    invoke-interface {p2, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    .line 277
    check-cast p1, Ljava/lang/Iterable;

    .line 409
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_26
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_60

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    .line 278
    invoke-interface {p2, v2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_51

    if-nez v1, :cond_4a

    .line 280
    move-object v1, p0

    check-cast v1, Ljava/util/Collection;

    invoke-interface {p3, v0, v2}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-interface {v1, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 281
    :cond_4a
    move-object v0, p0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_5d

    :cond_51
    if-eqz v1, :cond_5d

    .line 283
    move-object v1, p0

    check-cast v1, Ljava/util/Collection;

    invoke-interface {p3, v0, v2}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-interface {v1, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_5d
    :goto_5d
    move-object v0, v2

    move v1, v3

    goto :goto_26

    :cond_60
    return-object p0
.end method

.method private final clipPolygon(Ljava/util/List;IIII)Ljava/util/List;
    .registers 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;IIII)",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;"
        }
    .end annotation

    .line 257
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x3

    if-ge v0, v1, :cond_c

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p0

    return-object p0

    .line 258
    :cond_c
    check-cast p1, Ljava/lang/Iterable;

    .line 401
    new-instance v0, Ljava/util/ArrayList;

    const/16 v1, 0xa

    invoke-static {p1, v1}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v2

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v0, Ljava/util/Collection;

    .line 402
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1f
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3e

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .line 403
    check-cast v2, Lcom/example/bleconnectse/SyntheticPoint;

    .line 258
    new-instance v3, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v4

    int-to-double v4, v4

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v2

    int-to-double v6, v2

    invoke-direct {v3, v4, v5, v6, v7}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;-><init>(DD)V

    .line 403
    invoke-interface {v0, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1f

    .line 404
    :cond_3e
    check-cast v0, Ljava/util/List;

    .line 259
    new-instance p1, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda0;

    invoke-direct {p1, p2}, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda0;-><init>(I)V

    new-instance v2, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0, p2}, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/SyntheticTileRepository;I)V

    invoke-direct {p0, v0, p1, v2}, Lcom/example/bleconnectse/SyntheticTileRepository;->clipEdge(Ljava/util/List;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;)Ljava/util/List;

    move-result-object p1

    .line 260
    new-instance p2, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda2;

    invoke-direct {p2, p4}, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda2;-><init>(I)V

    new-instance v0, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0, p4}, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda3;-><init>(Lcom/example/bleconnectse/SyntheticTileRepository;I)V

    invoke-direct {p0, p1, p2, v0}, Lcom/example/bleconnectse/SyntheticTileRepository;->clipEdge(Ljava/util/List;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;)Ljava/util/List;

    move-result-object p1

    .line 261
    new-instance p2, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda4;

    invoke-direct {p2, p3}, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda4;-><init>(I)V

    new-instance p4, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda5;

    invoke-direct {p4, p0, p3}, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda5;-><init>(Lcom/example/bleconnectse/SyntheticTileRepository;I)V

    invoke-direct {p0, p1, p2, p4}, Lcom/example/bleconnectse/SyntheticTileRepository;->clipEdge(Ljava/util/List;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;)Ljava/util/List;

    move-result-object p1

    .line 262
    new-instance p2, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda6;

    invoke-direct {p2, p5}, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda6;-><init>(I)V

    new-instance p3, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda7;

    invoke-direct {p3, p0, p5}, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda7;-><init>(Lcom/example/bleconnectse/SyntheticTileRepository;I)V

    invoke-direct {p0, p1, p2, p3}, Lcom/example/bleconnectse/SyntheticTileRepository;->clipEdge(Ljava/util/List;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;)Ljava/util/List;

    move-result-object p0

    .line 263
    check-cast p0, Ljava/lang/Iterable;

    .line 405
    new-instance p1, Ljava/util/ArrayList;

    invoke-static {p0, v1}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result p2

    invoke-direct {p1, p2}, Ljava/util/ArrayList;-><init>(I)V

    check-cast p1, Ljava/util/Collection;

    .line 406
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_89
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_ae

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    .line 407
    check-cast p2, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    .line 263
    new-instance p3, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide p4

    invoke-static {p4, p5}, Lkotlin/math/MathKt;->roundToInt(D)I

    move-result p4

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide v0

    invoke-static {v0, v1}, Lkotlin/math/MathKt;->roundToInt(D)I

    move-result p2

    invoke-direct {p3, p4, p2}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 407
    invoke-interface {p1, p3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_89

    .line 408
    :cond_ae
    check-cast p1, Ljava/util/List;

    .line 405
    check-cast p1, Ljava/lang/Iterable;

    .line 263
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method static final clipPolygon$lambda$29(ILcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;)Z
    .registers 4

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 259
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide v0

    int-to-double p0, p0

    cmpl-double p0, v0, p0

    if-ltz p0, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    const/4 p0, 0x0

    return p0
.end method

.method static final clipPolygon$lambda$30(Lcom/example/bleconnectse/SyntheticTileRepository;ILcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;
    .registers 6

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    int-to-double v0, p1

    .line 259
    invoke-direct {p0, p2, p3, v0, v1}, Lcom/example/bleconnectse/SyntheticTileRepository;->intersectVertical(Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;D)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    move-result-object p0

    return-object p0
.end method

.method static final clipPolygon$lambda$31(ILcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;)Z
    .registers 4

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 260
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide v0

    int-to-double p0, p0

    cmpg-double p0, v0, p0

    if-gtz p0, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    const/4 p0, 0x0

    return p0
.end method

.method static final clipPolygon$lambda$32(Lcom/example/bleconnectse/SyntheticTileRepository;ILcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;
    .registers 6

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    int-to-double v0, p1

    .line 260
    invoke-direct {p0, p2, p3, v0, v1}, Lcom/example/bleconnectse/SyntheticTileRepository;->intersectVertical(Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;D)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    move-result-object p0

    return-object p0
.end method

.method static final clipPolygon$lambda$33(ILcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;)Z
    .registers 4

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 261
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide v0

    int-to-double p0, p0

    cmpl-double p0, v0, p0

    if-ltz p0, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    const/4 p0, 0x0

    return p0
.end method

.method static final clipPolygon$lambda$34(Lcom/example/bleconnectse/SyntheticTileRepository;ILcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;
    .registers 6

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    int-to-double v0, p1

    .line 261
    invoke-direct {p0, p2, p3, v0, v1}, Lcom/example/bleconnectse/SyntheticTileRepository;->intersectHorizontal(Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;D)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    move-result-object p0

    return-object p0
.end method

.method static final clipPolygon$lambda$35(ILcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;)Z
    .registers 4

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 262
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide v0

    int-to-double p0, p0

    cmpg-double p0, v0, p0

    if-gtz p0, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    const/4 p0, 0x0

    return p0
.end method

.method static final clipPolygon$lambda$36(Lcom/example/bleconnectse/SyntheticTileRepository;ILcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;
    .registers 6

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    int-to-double v0, p1

    .line 262
    invoke-direct {p0, p2, p3, v0, v1}, Lcom/example/bleconnectse/SyntheticTileRepository;->intersectHorizontal(Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;D)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    move-result-object p0

    return-object p0
.end method

.method private final clipSegment(Lcom/example/bleconnectse/SyntheticPoint;Lcom/example/bleconnectse/SyntheticPoint;IIII)Lkotlin/Pair;
    .registers 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            "IIII)",
            "Lkotlin/Pair<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;"
        }
    .end annotation

    .line 218
    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v0

    invoke-virtual/range {p1 .. p1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v1

    sub-int/2addr v0, v1

    int-to-double v0, v0

    .line 219
    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v2

    invoke-virtual/range {p1 .. p1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v3

    sub-int/2addr v2, v3

    int-to-double v2, v2

    neg-double v4, v0

    neg-double v6, v2

    const/4 v8, 0x4

    .line 220
    new-array v9, v8, [D

    const/4 v10, 0x0

    aput-wide v4, v9, v10

    const/4 v4, 0x1

    aput-wide v0, v9, v4

    const/4 v5, 0x2

    aput-wide v6, v9, v5

    const/4 v6, 0x3

    aput-wide v2, v9, v6

    .line 222
    invoke-virtual/range {p1 .. p1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v7

    sub-int v7, v7, p3

    int-to-double v11, v7

    .line 223
    invoke-virtual/range {p1 .. p1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v7

    sub-int v7, p5, v7

    int-to-double v13, v7

    .line 224
    invoke-virtual/range {p1 .. p1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v7

    sub-int v7, v7, p4

    move/from16 p0, v4

    move/from16 p2, v5

    int-to-double v4, v7

    .line 225
    invoke-virtual/range {p1 .. p1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v7

    sub-int v7, p6, v7

    move v15, v6

    int-to-double v6, v7

    move/from16 v16, v10

    new-array v10, v8, [D

    aput-wide v11, v10, v16

    aput-wide v13, v10, p0

    aput-wide v4, v10, p2

    aput-wide v6, v10, v15

    const-wide/16 v4, 0x0

    const-wide/high16 v6, 0x3ff0000000000000L  # 1.0

    move-wide v12, v4

    move/from16 v11, v16

    :goto_59
    if-ge v11, v8, :cond_8c

    .line 228
    aget-wide v14, v9, v11

    cmpg-double v16, v14, v4

    const/16 v17, 0x0

    if-nez v16, :cond_6a

    .line 229
    aget-wide v14, v10, v11

    cmpg-double v14, v14, v4

    if-gez v14, :cond_89

    return-object v17

    .line 232
    :cond_6a
    aget-wide v18, v10, v11

    div-double v18, v18, v14

    cmpg-double v14, v14, v4

    if-gez v14, :cond_7e

    cmpl-double v14, v18, v6

    if-lez v14, :cond_77

    return-object v17

    :cond_77
    cmpl-double v14, v18, v12

    if-lez v14, :cond_89

    move-wide/from16 v12, v18

    goto :goto_89

    :cond_7e
    cmpg-double v14, v18, v12

    if-gez v14, :cond_83

    return-object v17

    :cond_83
    cmpg-double v14, v18, v6

    if-gez v14, :cond_89

    move-wide/from16 v6, v18

    :cond_89
    :goto_89
    add-int/lit8 v11, v11, 0x1

    goto :goto_59

    .line 241
    :cond_8c
    new-instance v4, Lcom/example/bleconnectse/SyntheticPoint;

    .line 242
    invoke-virtual/range {p1 .. p1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v5

    int-to-double v8, v5

    mul-double v10, v12, v0

    add-double/2addr v8, v10

    invoke-static {v8, v9}, Lkotlin/math/MathKt;->roundToInt(D)I

    move-result v5

    .line 243
    invoke-virtual/range {p1 .. p1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v8

    int-to-double v8, v8

    mul-double/2addr v12, v2

    add-double/2addr v8, v12

    invoke-static {v8, v9}, Lkotlin/math/MathKt;->roundToInt(D)I

    move-result v8

    .line 241
    invoke-direct {v4, v5, v8}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 244
    new-instance v5, Lcom/example/bleconnectse/SyntheticPoint;

    .line 245
    invoke-virtual/range {p1 .. p1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v8

    int-to-double v8, v8

    mul-double/2addr v0, v6

    add-double/2addr v8, v0

    invoke-static {v8, v9}, Lkotlin/math/MathKt;->roundToInt(D)I

    move-result v0

    .line 246
    invoke-virtual/range {p1 .. p1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v1

    int-to-double v8, v1

    mul-double/2addr v6, v2

    add-double/2addr v8, v6

    invoke-static {v8, v9}, Lkotlin/math/MathKt;->roundToInt(D)I

    move-result v1

    .line 244
    invoke-direct {v5, v0, v1}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    .line 241
    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    return-object v0
.end method

.method private final encodeTile(II)Lcom/example/bleconnectse/SyntheticTile;
    .registers 24

    move-object/from16 v0, p0

    move/from16 v6, p1

    move/from16 v7, p2

    mul-int/lit16 v2, v6, 0x320

    mul-int/lit16 v3, v7, 0x1e0

    add-int/lit16 v4, v2, 0x320

    add-int/lit16 v5, v3, 0x1e0

    .line 76
    invoke-direct {v0, v2, v3, v4, v5}, Lcom/example/bleconnectse/SyntheticTileRepository;->buildTileRoads(IIII)Ljava/util/List;

    move-result-object v8

    .line 77
    sget-object v1, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticMapData;->getAreas()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .line 341
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    check-cast v9, Ljava/util/Collection;

    .line 350
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_25
    :goto_25
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/16 v11, 0xa

    if-eqz v1, :cond_86

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    .line 349
    move-object v12, v1

    check-cast v12, Lcom/example/bleconnectse/SyntheticArea;

    .line 78
    invoke-virtual {v12}, Lcom/example/bleconnectse/SyntheticArea;->getPoints()Ljava/util/List;

    move-result-object v1

    invoke-direct/range {v0 .. v5}, Lcom/example/bleconnectse/SyntheticTileRepository;->clipPolygon(Ljava/util/List;IIII)Ljava/util/List;

    move-result-object v1

    .line 79
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v13

    const/4 v14, 0x3

    if-ge v13, v14, :cond_45

    const/4 v1, 0x0

    goto :goto_80

    .line 80
    :cond_45
    invoke-virtual {v12}, Lcom/example/bleconnectse/SyntheticArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object v13

    const/16 v14, 0x10

    .line 81
    invoke-direct {v0, v1, v14}, Lcom/example/bleconnectse/SyntheticTileRepository;->simplify(Ljava/util/List;I)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .line 351
    new-instance v14, Ljava/util/ArrayList;

    invoke-static {v1, v11}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v11

    invoke-direct {v14, v11}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v14, Ljava/util/Collection;

    .line 352
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_60
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_74

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .line 353
    check-cast v11, Lcom/example/bleconnectse/SyntheticPoint;

    .line 81
    invoke-direct {v0, v11, v2, v3}, Lcom/example/bleconnectse/SyntheticTileRepository;->toLocal(Lcom/example/bleconnectse/SyntheticPoint;II)Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v11

    .line 353
    invoke-interface {v14, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_60

    .line 354
    :cond_74
    check-cast v14, Ljava/util/List;

    .line 82
    invoke-virtual {v12}, Lcom/example/bleconnectse/SyntheticArea;->getName()Ljava/lang/String;

    move-result-object v1

    .line 79
    new-instance v11, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;

    invoke-direct {v11, v13, v14, v1}, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;-><init>(Lcom/example/bleconnectse/SyntheticAreaType;Ljava/util/List;Ljava/lang/String;)V

    move-object v1, v11

    :goto_80
    if-eqz v1, :cond_25

    .line 349
    invoke-interface {v9, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_25

    .line 357
    :cond_86
    check-cast v9, Ljava/util/List;

    .line 85
    sget-object v1, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticMapData;->getJunctions()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .line 358
    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    check-cast v10, Ljava/util/Collection;

    .line 359
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_9b
    :goto_9b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_c4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    move-object v13, v12

    check-cast v13, Lcom/example/bleconnectse/SyntheticJunction;

    .line 86
    invoke-virtual {v13}, Lcom/example/bleconnectse/SyntheticJunction;->getPosition()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v14

    invoke-virtual {v14}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v14

    if-gt v2, v14, :cond_9b

    if-gt v14, v4, :cond_9b

    invoke-virtual {v13}, Lcom/example/bleconnectse/SyntheticJunction;->getPosition()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v13

    invoke-virtual {v13}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v13

    if-gt v3, v13, :cond_9b

    if-gt v13, v5, :cond_9b

    .line 359
    invoke-interface {v10, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_9b

    .line 360
    :cond_c4
    check-cast v10, Ljava/util/List;

    .line 358
    check-cast v10, Ljava/lang/Iterable;

    .line 361
    new-instance v1, Ljava/util/ArrayList;

    invoke-static {v10, v11}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v1, Ljava/util/Collection;

    .line 362
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_d7
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_f8

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .line 363
    check-cast v5, Lcom/example/bleconnectse/SyntheticJunction;

    .line 87
    new-instance v10, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;

    invoke-virtual {v5}, Lcom/example/bleconnectse/SyntheticJunction;->getPosition()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v11

    invoke-direct {v0, v11, v2, v3}, Lcom/example/bleconnectse/SyntheticTileRepository;->toLocal(Lcom/example/bleconnectse/SyntheticPoint;II)Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v11

    invoke-virtual {v5}, Lcom/example/bleconnectse/SyntheticJunction;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v10, v11, v5}, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;-><init>(Lcom/example/bleconnectse/SyntheticPoint;Ljava/lang/String;)V

    .line 363
    invoke-interface {v1, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_d7

    .line 364
    :cond_f8
    check-cast v1, Ljava/util/List;

    .line 89
    new-instance v4, Ljava/util/LinkedHashMap;

    invoke-direct {v4}, Ljava/util/LinkedHashMap;-><init>()V

    .line 90
    new-instance v5, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v5}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 101
    move-object v10, v8

    check-cast v10, Ljava/lang/Iterable;

    .line 365
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_10b
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_11f

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;

    .line 101
    invoke-virtual {v12}, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;->getName()Ljava/lang/String;

    move-result-object v12

    invoke-static {v4, v5, v12}, Lcom/example/bleconnectse/SyntheticTileRepository;->encodeTile$stringOffset(Ljava/util/LinkedHashMap;Ljava/io/ByteArrayOutputStream;Ljava/lang/String;)I

    goto :goto_10b

    .line 102
    :cond_11f
    check-cast v9, Ljava/lang/Iterable;

    .line 367
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_125
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_139

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;

    .line 102
    invoke-virtual {v12}, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;->getName()Ljava/lang/String;

    move-result-object v12

    invoke-static {v4, v5, v12}, Lcom/example/bleconnectse/SyntheticTileRepository;->encodeTile$stringOffset(Ljava/util/LinkedHashMap;Ljava/io/ByteArrayOutputStream;Ljava/lang/String;)I

    goto :goto_125

    .line 103
    :cond_139
    move-object v11, v1

    check-cast v11, Ljava/lang/Iterable;

    .line 369
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_140
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_154

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;

    .line 103
    invoke-virtual {v13}, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->getName()Ljava/lang/String;

    move-result-object v13

    invoke-static {v4, v5, v13}, Lcom/example/bleconnectse/SyntheticTileRepository;->encodeTile$stringOffset(Ljava/util/LinkedHashMap;Ljava/io/ByteArrayOutputStream;Ljava/lang/String;)I

    goto :goto_140

    .line 104
    :cond_154
    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v12

    .line 371
    instance-of v13, v9, Ljava/util/Collection;

    if-eqz v13, :cond_169

    move-object v15, v9

    check-cast v15, Ljava/util/Collection;

    invoke-interface {v15}, Ljava/util/Collection;->isEmpty()Z

    move-result v15

    if-eqz v15, :cond_169

    const/4 v14, 0x0

    :goto_166
    move-object/from16 v17, v1

    goto :goto_192

    .line 373
    :cond_169
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    const/16 v16, 0x0

    :goto_16f
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_18f

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;

    .line 105
    invoke-virtual/range {v17 .. v17}, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object v14

    move-object/from16 v17, v1

    sget-object v1, Lcom/example/bleconnectse/SyntheticAreaType;->Building:Lcom/example/bleconnectse/SyntheticAreaType;

    if-ne v14, v1, :cond_18c

    add-int/lit8 v16, v16, 0x1

    if-gez v16, :cond_18c

    .line 373
    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    :cond_18c
    move-object/from16 v1, v17

    goto :goto_16f

    :cond_18f
    move/from16 v14, v16

    goto :goto_166

    :goto_192
    if-eqz v13, :cond_1a1

    .line 375
    move-object v1, v9

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1a1

    const/4 v15, 0x0

    :cond_19e
    move-object/from16 v16, v8

    goto :goto_1ca

    .line 377
    :cond_1a1
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v15, 0x0

    :goto_1a6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_19e

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;

    move-object/from16 v18, v1

    .line 106
    invoke-virtual/range {v16 .. v16}, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object v1

    move-object/from16 v16, v8

    sget-object v8, Lcom/example/bleconnectse/SyntheticAreaType;->Park:Lcom/example/bleconnectse/SyntheticAreaType;

    if-ne v1, v8, :cond_1c5

    add-int/lit8 v15, v15, 0x1

    if-gez v15, :cond_1c5

    .line 377
    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    :cond_1c5
    move-object/from16 v8, v16

    move-object/from16 v1, v18

    goto :goto_1a6

    :goto_1ca
    if-eqz v13, :cond_1d7

    .line 379
    move-object v1, v9

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1d7

    const/4 v8, 0x0

    goto :goto_1fc

    .line 381
    :cond_1d7
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v8, 0x0

    :goto_1dc
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_1fc

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;

    .line 107
    invoke-virtual {v13}, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object v13

    move-object/from16 v18, v1

    sget-object v1, Lcom/example/bleconnectse/SyntheticAreaType;->Water:Lcom/example/bleconnectse/SyntheticAreaType;

    if-ne v13, v1, :cond_1f9

    add-int/lit8 v8, v8, 0x1

    if-gez v8, :cond_1f9

    .line 381
    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    :cond_1f9
    move-object/from16 v1, v18

    goto :goto_1dc

    .line 109
    :cond_1fc
    :goto_1fc
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v13, 0x4

    .line 110
    new-array v13, v13, [B

    fill-array-data v13, :array_3d4

    invoke-virtual {v1, v13}, Ljava/io/ByteArrayOutputStream;->write([B)V

    const/4 v13, 0x1

    .line 111
    invoke-virtual {v1, v13}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 112
    invoke-virtual {v1, v6}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 113
    invoke-virtual {v1, v7}, Ljava/io/ByteArrayOutputStream;->write(I)V

    const/4 v13, 0x0

    .line 114
    invoke-virtual {v1, v13}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 115
    invoke-direct {v0, v1, v2}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 116
    invoke-direct {v0, v1, v3}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    const/16 v2, 0x320

    .line 117
    invoke-direct {v0, v1, v2}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    const/16 v2, 0x1e0

    .line 118
    invoke-direct {v0, v1, v2}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 119
    invoke-interface/range {v16 .. v16}, Ljava/util/List;->size()I

    move-result v2

    invoke-direct {v0, v1, v2}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 120
    invoke-direct {v0, v1, v14}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 121
    invoke-direct {v0, v1, v15}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 122
    invoke-direct {v0, v1, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 123
    invoke-interface/range {v17 .. v17}, Ljava/util/List;->size()I

    move-result v2

    invoke-direct {v0, v1, v2}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 124
    array-length v2, v12

    invoke-direct {v0, v1, v2}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    const/16 v2, 0x1900

    .line 125
    invoke-direct {v0, v1, v2}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    const/16 v2, 0x960

    .line 126
    invoke-direct {v0, v1, v2}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 383
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_251
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2d8

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;

    .line 129
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;->getRoadClass()Lcom/example/bleconnectse/SyntheticRoadClass;

    move-result-object v8

    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticRoadClass;->getWireValue()I

    move-result v8

    invoke-virtual {v1, v8}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 130
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;->getTraffic()Lcom/example/bleconnectse/SyntheticTraffic;

    move-result-object v8

    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticTraffic;->getWireValue()I

    move-result v8

    invoke-virtual {v1, v8}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 131
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;->getPoints()Ljava/util/List;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    invoke-virtual {v1, v8}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 132
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;->getLabel()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v8

    if-eqz v8, :cond_286

    const/4 v8, 0x1

    goto :goto_287

    :cond_286
    move v8, v13

    :goto_287
    invoke-virtual {v1, v8}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 133
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;->getLabel()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v8

    if-eqz v8, :cond_295

    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v8

    goto :goto_296

    :cond_295
    move v8, v13

    :goto_296
    invoke-direct {v0, v1, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 134
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;->getLabel()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v8

    if-eqz v8, :cond_2a4

    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v8

    goto :goto_2a5

    :cond_2a4
    move v8, v13

    :goto_2a5
    invoke-direct {v0, v1, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 135
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;->getName()Ljava/lang/String;

    move-result-object v8

    invoke-static {v4, v5, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->encodeTile$stringOffset(Ljava/util/LinkedHashMap;Ljava/io/ByteArrayOutputStream;Ljava/lang/String;)I

    move-result v8

    invoke-direct {v0, v1, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 136
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileRoad;->getPoints()Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .line 384
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_2bd
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_251

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/example/bleconnectse/SyntheticPoint;

    .line 137
    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v10

    invoke-direct {v0, v1, v10}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 138
    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v8

    invoke-direct {v0, v1, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    goto :goto_2bd

    .line 387
    :cond_2d8
    new-instance v2, Lcom/example/bleconnectse/SyntheticTileRepository$encodeTile$$inlined$sortedBy$1;

    invoke-direct {v2}, Lcom/example/bleconnectse/SyntheticTileRepository$encodeTile$$inlined$sortedBy$1;-><init>()V

    check-cast v2, Ljava/util/Comparator;

    invoke-static {v9, v2}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .line 388
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2e9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_33b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;

    .line 142
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object v8

    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticAreaType;->getWireValue()I

    move-result v8

    invoke-virtual {v1, v8}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 143
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;->getPoints()Ljava/util/List;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    invoke-virtual {v1, v8}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 144
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;->getName()Ljava/lang/String;

    move-result-object v8

    invoke-static {v4, v5, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->encodeTile$stringOffset(Ljava/util/LinkedHashMap;Ljava/io/ByteArrayOutputStream;Ljava/lang/String;)I

    move-result v8

    invoke-direct {v0, v1, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 145
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileArea;->getPoints()Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .line 389
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_320
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_2e9

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/example/bleconnectse/SyntheticPoint;

    .line 146
    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v9

    invoke-direct {v0, v1, v9}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 147
    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v8

    invoke-direct {v0, v1, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    goto :goto_320

    .line 392
    :cond_33b
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_33f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_36d

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;

    .line 151
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->getPoint()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v8

    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v8

    invoke-direct {v0, v1, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 152
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->getPoint()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v8

    invoke-virtual {v8}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v8

    invoke-direct {v0, v1, v8}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    .line 153
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v5, v3}, Lcom/example/bleconnectse/SyntheticTileRepository;->encodeTile$stringOffset(Ljava/util/LinkedHashMap;Ljava/io/ByteArrayOutputStream;Ljava/lang/String;)I

    move-result v3

    invoke-direct {v0, v1, v3}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    goto :goto_33f

    .line 155
    :cond_36d
    invoke-virtual {v1, v12}, Ljava/io/ByteArrayOutputStream;->write([B)V

    .line 157
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v4

    .line 158
    array-length v0, v4

    const v1, 0xffff

    if-gt v0, v1, :cond_39d

    .line 161
    new-instance v0, Ljava/util/zip/CRC32;

    invoke-direct {v0}, Ljava/util/zip/CRC32;-><init>()V

    invoke-virtual {v0, v4}, Ljava/util/zip/CRC32;->update([B)V

    invoke-virtual {v0}, Ljava/util/zip/CRC32;->getValue()J

    move-result-wide v0

    move-wide v1, v0

    .line 162
    new-instance v0, Lcom/example/bleconnectse/SyntheticTile;

    .line 163
    sget-object v3, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v3, v6, v7}, Lcom/example/bleconnectse/SyntheticMapData;->tileId(II)I

    move-result v3

    .line 166
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-wide/from16 v19, v1

    move v2, v6

    move-wide/from16 v5, v19

    move v1, v3

    move v3, v7

    .line 162
    invoke-direct/range {v0 .. v6}, Lcom/example/bleconnectse/SyntheticTile;-><init>(III[BJ)V

    return-object v0

    :cond_39d
    move v2, v6

    move v3, v7

    .line 159
    array-length v0, v4

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v4, "Tile "

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ","

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " is too large for VTL1: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " bytes"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 158
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    nop

    :array_3d4
    .array-data 1
        0x56t
        0x54t
        0x4ct
        0x31t
    .end array-data
.end method

.method private static final encodeTile$stringOffset(Ljava/util/LinkedHashMap;Ljava/io/ByteArrayOutputStream;Ljava/lang/String;)I
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;",
            "Ljava/io/ByteArrayOutputStream;",
            "Ljava/lang/String;",
            ")I"
        }
    .end annotation

    .line 92
    move-object v0, p2

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_d

    const p0, 0xffff

    return p0

    .line 93
    :cond_d
    check-cast p0, Ljava/util/Map;

    .line 415
    invoke-interface {p0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_32

    .line 94
    invoke-virtual {p1}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v0

    .line 95
    sget-object v1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p2, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    const-string v2, "getBytes(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v1}, Ljava/io/ByteArrayOutputStream;->write([B)V

    const/4 v1, 0x0

    .line 96
    invoke-virtual {p1, v1}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 97
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    .line 418
    invoke-interface {p0, p2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 416
    :cond_32
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result p0

    return p0
.end method

.method private final intersectHorizontal(Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;D)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;
    .registers 11

    .line 297
    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide v0

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide v2

    cmpg-double p0, v0, v2

    if-nez p0, :cond_f

    const-wide/16 v0, 0x0

    goto :goto_1f

    :cond_f
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide v0

    sub-double v0, p3, v0

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide v2

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide v4

    sub-double/2addr v2, v4

    div-double/2addr v0, v2

    .line 298
    :goto_1f
    new-instance p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide v2

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide v4

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide p1

    sub-double/2addr v4, p1

    mul-double/2addr v4, v0

    add-double/2addr v2, v4

    invoke-direct {p0, v2, v3, p3, p4}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;-><init>(DD)V

    return-object p0
.end method

.method private final intersectVertical(Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;D)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;
    .registers 11

    .line 292
    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide v0

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide v2

    cmpg-double p0, v0, v2

    if-nez p0, :cond_f

    const-wide/16 v0, 0x0

    goto :goto_1f

    :cond_f
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide v0

    sub-double v0, p3, v0

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide v2

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getX()D

    move-result-wide v4

    sub-double/2addr v2, v4

    div-double/2addr v0, v2

    .line 293
    :goto_1f
    new-instance p0, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide v2

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide v4

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;->getY()D

    move-result-wide p1

    sub-double/2addr v4, p1

    mul-double/2addr v4, v0

    add-double/2addr v2, v4

    invoke-direct {p0, p3, p4, v2, v3}, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;-><init>(DD)V

    return-object p0
.end method

.method private final simplify(Ljava/util/List;I)Ljava/util/List;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;I)",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;"
        }
    .end annotation

    .line 302
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    if-gt p0, p2, :cond_7

    return-object p1

    :cond_7
    const/4 p0, 0x0

    .line 303
    invoke-static {p0, p2}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object p0

    check-cast p0, Ljava/lang/Iterable;

    .line 411
    new-instance v0, Ljava/util/ArrayList;

    const/16 v1, 0xa

    invoke-static {p0, v1}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v0, Ljava/util/Collection;

    .line 412
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1f
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3c

    move-object v1, p0

    check-cast v1, Lkotlin/collections/IntIterator;

    invoke-virtual {v1}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v1

    .line 304
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    mul-int/2addr v1, v2

    div-int/2addr v1, p2

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/example/bleconnectse/SyntheticPoint;

    .line 413
    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1f

    .line 414
    :cond_3c
    check-cast v0, Ljava/util/List;

    return-object v0
.end method

.method private final toLocal(Lcom/example/bleconnectse/SyntheticPoint;II)Lcom/example/bleconnectse/SyntheticPoint;
    .registers 5

    .line 309
    new-instance p0, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v0

    sub-int/2addr v0, p2

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result p1

    sub-int/2addr p1, p3

    invoke-direct {p0, v0, p1}, Lcom/example/bleconnectse/SyntheticPoint;-><init>(II)V

    return-object p0
.end method

.method private final writeInt16Le(Ljava/io/ByteArrayOutputStream;I)V
    .registers 4

    const v0, 0xffff

    and-int/2addr p2, v0

    .line 317
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/SyntheticTileRepository;->writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V

    return-void
.end method

.method private final writeUInt16Le(Ljava/io/ByteArrayOutputStream;I)V
    .registers 3

    and-int/lit16 p0, p2, 0xff

    .line 312
    invoke-virtual {p1, p0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    ushr-int/lit8 p0, p2, 0x8

    and-int/lit16 p0, p0, 0xff

    .line 313
    invoke-virtual {p1, p0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    return-void
.end method


# virtual methods
.method public final neighborhood(II)Ljava/util/List;
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticTile;",
            ">;"
        }
    .end annotation

    .line 52
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    check-cast v0, Ljava/util/List;

    add-int/lit8 v1, p2, -0x1

    add-int/lit8 v2, p2, 0x1

    if-gt v1, v2, :cond_3a

    :goto_d
    add-int/lit8 v3, p1, -0x1

    add-int/lit8 v4, p1, 0x1

    if-gt v3, v4, :cond_35

    :goto_13
    if-ltz v3, :cond_30

    const/16 v5, 0x8

    if-ge v3, v5, :cond_30

    if-ltz v1, :cond_30

    const/4 v5, 0x5

    if-ge v1, v5, :cond_30

    .line 58
    move-object v5, v0

    check-cast v5, Ljava/util/Collection;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v6, v7}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_30
    if-eq v3, v4, :cond_35

    add-int/lit8 v3, v3, 0x1

    goto :goto_13

    :cond_35
    if-eq v1, v2, :cond_3a

    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    .line 62
    :cond_3a
    check-cast v0, Ljava/lang/Iterable;

    .line 64
    new-instance v1, Lcom/example/bleconnectse/SyntheticTileRepository$neighborhood$$inlined$compareBy$1;

    invoke-direct {v1, p1, p2}, Lcom/example/bleconnectse/SyntheticTileRepository$neighborhood$$inlined$compareBy$1;-><init>(II)V

    check-cast v1, Ljava/util/Comparator;

    .line 66
    new-instance p1, Lcom/example/bleconnectse/SyntheticTileRepository$neighborhood$$inlined$thenBy$1;

    invoke-direct {p1, v1}, Lcom/example/bleconnectse/SyntheticTileRepository$neighborhood$$inlined$thenBy$1;-><init>(Ljava/util/Comparator;)V

    check-cast p1, Ljava/util/Comparator;

    new-instance p2, Lcom/example/bleconnectse/SyntheticTileRepository$neighborhood$$inlined$thenBy$2;

    invoke-direct {p2, p1}, Lcom/example/bleconnectse/SyntheticTileRepository$neighborhood$$inlined$thenBy$2;-><init>(Ljava/util/Comparator;)V

    check-cast p2, Ljava/util/Comparator;

    .line 63
    invoke-static {v0, p2}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    .line 328
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    check-cast p2, Ljava/util/Collection;

    .line 337
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_62
    :goto_62
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_8c

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    .line 336
    check-cast v0, Lkotlin/Pair;

    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .line 68
    invoke-virtual {p0, v1, v0}, Lcom/example/bleconnectse/SyntheticTileRepository;->tile(II)Lcom/example/bleconnectse/SyntheticTile;

    move-result-object v0

    if-eqz v0, :cond_62

    .line 336
    invoke-interface {p2, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_62

    .line 340
    :cond_8c
    check-cast p2, Ljava/util/List;

    return-object p2
.end method

.method public final tile(II)Lcom/example/bleconnectse/SyntheticTile;
    .registers 7

    if-ltz p1, :cond_2e

    const/16 v0, 0x8

    if-ge p1, v0, :cond_2e

    if-ltz p2, :cond_2e

    const/4 v0, 0x5

    if-ge p2, v0, :cond_2e

    .line 45
    sget-object v0, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v0, p1, p2}, Lcom/example/bleconnectse/SyntheticMapData;->tileId(II)I

    move-result v0

    .line 46
    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticTileRepository;->cache:Ljava/util/Map;

    monitor-enter v1

    .line 47
    :try_start_14
    iget-object v2, p0, Lcom/example/bleconnectse/SyntheticTileRepository;->cache:Ljava/util/Map;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    .line 321
    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    if-nez v3, :cond_27

    .line 47
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/SyntheticTileRepository;->encodeTile(II)Lcom/example/bleconnectse/SyntheticTile;

    move-result-object v3

    .line 324
    invoke-interface {v2, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 322
    :cond_27
    check-cast v3, Lcom/example/bleconnectse/SyntheticTile;
    :try_end_29
    .catchall {:try_start_14 .. :try_end_29} :catchall_2b

    .line 46
    monitor-exit v1

    return-object v3

    :catchall_2b
    move-exception p0

    monitor-exit v1

    throw p0

    :cond_2e
    const/4 p0, 0x0

    return-object p0
.end method
