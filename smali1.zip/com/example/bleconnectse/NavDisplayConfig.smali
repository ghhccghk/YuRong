# classes2.dex

.class final Lcom/example/bleconnectse/NavDisplayConfig;
.super Ljava/lang/Object;
.source "YadeaOtaClient.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0013\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J;\u0010\u0015\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0016\u001a\u00020\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÖ\u0001J\t\u0010\u001a\u001a\u00020\u001bHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000bR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000b¨\u0006\u001c"
    }
    d2 = {
        "Lcom/example/bleconnectse/NavDisplayConfig;",
        "",
        "width",
        "",
        "height",
        "imageFormat",
        "capabilities",
        "maxFps",
        "<init>",
        "(IIIII)V",
        "getWidth",
        "()I",
        "getHeight",
        "getImageFormat",
        "getCapabilities",
        "getMaxFps",
        "component1",
        "component2",
        "component3",
        "component4",
        "component5",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "toString",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final capabilities:I

.field private final height:I

.field private final imageFormat:I

.field private final maxFps:I

.field private final width:I


# direct methods
.method public constructor <init>(IIIII)V
    .registers 6

    .line 2230
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2231
    iput p1, p0, Lcom/example/bleconnectse/NavDisplayConfig;->width:I

    .line 2232
    iput p2, p0, Lcom/example/bleconnectse/NavDisplayConfig;->height:I

    .line 2233
    iput p3, p0, Lcom/example/bleconnectse/NavDisplayConfig;->imageFormat:I

    .line 2234
    iput p4, p0, Lcom/example/bleconnectse/NavDisplayConfig;->capabilities:I

    .line 2235
    iput p5, p0, Lcom/example/bleconnectse/NavDisplayConfig;->maxFps:I

    return-void
.end method

.method public static synthetic copy$default(Lcom/example/bleconnectse/NavDisplayConfig;IIIIIILjava/lang/Object;)Lcom/example/bleconnectse/NavDisplayConfig;
    .registers 8

    and-int/lit8 p7, p6, 0x1

    if-eqz p7, :cond_6

    iget p1, p0, Lcom/example/bleconnectse/NavDisplayConfig;->width:I

    :cond_6
    and-int/lit8 p7, p6, 0x2

    if-eqz p7, :cond_c

    iget p2, p0, Lcom/example/bleconnectse/NavDisplayConfig;->height:I

    :cond_c
    and-int/lit8 p7, p6, 0x4

    if-eqz p7, :cond_12

    iget p3, p0, Lcom/example/bleconnectse/NavDisplayConfig;->imageFormat:I

    :cond_12
    and-int/lit8 p7, p6, 0x8

    if-eqz p7, :cond_18

    iget p4, p0, Lcom/example/bleconnectse/NavDisplayConfig;->capabilities:I

    :cond_18
    and-int/lit8 p6, p6, 0x10

    if-eqz p6, :cond_1e

    iget p5, p0, Lcom/example/bleconnectse/NavDisplayConfig;->maxFps:I

    :cond_1e
    move p6, p4

    move p7, p5

    move p4, p2

    move p5, p3

    move-object p2, p0

    move p3, p1

    invoke-virtual/range {p2 .. p7}, Lcom/example/bleconnectse/NavDisplayConfig;->copy(IIIII)Lcom/example/bleconnectse/NavDisplayConfig;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->width:I

    return p0
.end method

.method public final component2()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->height:I

    return p0
.end method

.method public final component3()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->imageFormat:I

    return p0
.end method

.method public final component4()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->capabilities:I

    return p0
.end method

.method public final component5()I
    .registers 1

    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->maxFps:I

    return p0
.end method

.method public final copy(IIIII)Lcom/example/bleconnectse/NavDisplayConfig;
    .registers 6

    new-instance p0, Lcom/example/bleconnectse/NavDisplayConfig;

    invoke-direct/range {p0 .. p5}, Lcom/example/bleconnectse/NavDisplayConfig;-><init>(IIIII)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/example/bleconnectse/NavDisplayConfig;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/example/bleconnectse/NavDisplayConfig;

    iget v1, p0, Lcom/example/bleconnectse/NavDisplayConfig;->width:I

    iget v3, p1, Lcom/example/bleconnectse/NavDisplayConfig;->width:I

    if-eq v1, v3, :cond_13

    return v2

    :cond_13
    iget v1, p0, Lcom/example/bleconnectse/NavDisplayConfig;->height:I

    iget v3, p1, Lcom/example/bleconnectse/NavDisplayConfig;->height:I

    if-eq v1, v3, :cond_1a

    return v2

    :cond_1a
    iget v1, p0, Lcom/example/bleconnectse/NavDisplayConfig;->imageFormat:I

    iget v3, p1, Lcom/example/bleconnectse/NavDisplayConfig;->imageFormat:I

    if-eq v1, v3, :cond_21

    return v2

    :cond_21
    iget v1, p0, Lcom/example/bleconnectse/NavDisplayConfig;->capabilities:I

    iget v3, p1, Lcom/example/bleconnectse/NavDisplayConfig;->capabilities:I

    if-eq v1, v3, :cond_28

    return v2

    :cond_28
    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->maxFps:I

    iget p1, p1, Lcom/example/bleconnectse/NavDisplayConfig;->maxFps:I

    if-eq p0, p1, :cond_2f

    return v2

    :cond_2f
    return v0
.end method

.method public final getCapabilities()I
    .registers 1

    .line 2234
    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->capabilities:I

    return p0
.end method

.method public final getHeight()I
    .registers 1

    .line 2232
    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->height:I

    return p0
.end method

.method public final getImageFormat()I
    .registers 1

    .line 2233
    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->imageFormat:I

    return p0
.end method

.method public final getMaxFps()I
    .registers 1

    .line 2235
    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->maxFps:I

    return p0
.end method

.method public final getWidth()I
    .registers 1

    .line 2231
    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->width:I

    return p0
.end method

.method public hashCode()I
    .registers 3

    iget v0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->width:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/NavDisplayConfig;->height:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/NavDisplayConfig;->imageFormat:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/example/bleconnectse/NavDisplayConfig;->capabilities:I

    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->maxFps:I

    invoke-static {p0}, Ljava/lang/Integer;->hashCode(I)I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 7

    iget v0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->width:I

    iget v1, p0, Lcom/example/bleconnectse/NavDisplayConfig;->height:I

    iget v2, p0, Lcom/example/bleconnectse/NavDisplayConfig;->imageFormat:I

    iget v3, p0, Lcom/example/bleconnectse/NavDisplayConfig;->capabilities:I

    iget p0, p0, Lcom/example/bleconnectse/NavDisplayConfig;->maxFps:I

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "NavDisplayConfig(width="

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, ", height="

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", imageFormat="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", capabilities="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", maxFps="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ")"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
