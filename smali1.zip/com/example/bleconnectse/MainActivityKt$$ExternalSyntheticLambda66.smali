# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda66;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/P2pPeer;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/P2pPeer;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda66;->f$0:Lcom/example/bleconnectse/P2pPeer;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda66;->f$0:Lcom/example/bleconnectse/P2pPeer;

    check-cast p1, Landroidx/compose/foundation/layout/ColumnScope;

    check-cast p2, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-static {p0, p1, p2, p3}, Lcom/example/bleconnectse/MainActivityKt;->P2pPeerRow$lambda$150(Lcom/example/bleconnectse/P2pPeer;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
