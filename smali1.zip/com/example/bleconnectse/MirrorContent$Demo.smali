# classes2.dex

.class public final Lcom/example/bleconnectse/MirrorContent$Demo;
.super Ljava/lang/Object;
.source "YadeaOtaClient.kt"

# interfaces
.implements Lcom/example/bleconnectse/MirrorContent;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/bleconnectse/MirrorContent;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Demo"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"
    }
    d2 = {
        "Lcom/example/bleconnectse/MirrorContent$Demo;",
        "Lcom/example/bleconnectse/MirrorContent;",
        "<init>",
        "()V",
        "equals",
        "",
        "other",
        "",
        "hashCode",
        "",
        "toString",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/example/bleconnectse/MirrorContent$Demo;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/example/bleconnectse/MirrorContent$Demo;

    invoke-direct {v0}, Lcom/example/bleconnectse/MirrorContent$Demo;-><init>()V

    sput-object v0, Lcom/example/bleconnectse/MirrorContent$Demo;->INSTANCE:Lcom/example/bleconnectse/MirrorContent$Demo;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 2239
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 3

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of p0, p1, Lcom/example/bleconnectse/MirrorContent$Demo;

    if-nez p0, :cond_a

    const/4 p0, 0x0

    return p0

    :cond_a
    check-cast p1, Lcom/example/bleconnectse/MirrorContent$Demo;

    return v0
.end method

.method public hashCode()I
    .registers 1

    const p0, 0x6fe0c933

    return p0
.end method

.method public toString()Ljava/lang/String;
    .registers 1

    const-string p0, "Demo"

    return-object p0
.end method
