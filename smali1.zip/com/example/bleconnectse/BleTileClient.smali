# classes2.dex

.class public final Lcom/example/bleconnectse/BleTileClient;
.super Ljava/lang/Object;
.source "BleTileClient.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/BleTileClient$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nBleTileClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BleTileClient.kt\ncom/example/bleconnectse/BleTileClient\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,858:1\n85#2:859\n117#2,2:860\n85#2:862\n117#2,2:863\n85#2:865\n117#2,2:866\n85#2:868\n117#2,2:869\n85#2:871\n117#2,2:872\n85#2:874\n117#2,2:875\n85#2:877\n117#2,2:878\n85#2:880\n117#2,2:881\n85#2:883\n117#2,2:884\n85#2:886\n117#2,2:887\n295#3,2:889\n360#3,7:892\n1021#3,2:899\n1869#3,2:901\n1634#3,3:903\n774#3:906\n865#3,2:907\n1869#3,2:909\n1#4:891\n*S KotlinDebug\n*F\n+ 1 BleTileClient.kt\ncom/example/bleconnectse/BleTileClient\n*L\n82#1:859\n82#1:860,2\n84#1:862\n84#1:863,2\n86#1:865\n86#1:866,2\n88#1:868\n88#1:869,2\n90#1:871\n90#1:872,2\n92#1:874\n92#1:875,2\n94#1:877\n94#1:878,2\n96#1:880\n96#1:881,2\n98#1:883\n98#1:884,2\n100#1:886\n100#1:887,2\n315#1:889,2\n370#1:892,7\n372#1:899,2\n451#1:901,2\n555#1:903,3\n569#1:906\n569#1:907,2\n587#1:909,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000Ó\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010#\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0014\n\u0002\u0010\u0007\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\"\n\u0002\b\n\n\u0002\b\u0003\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\b\u0003\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0019\n\u0002\u0018\u0002\n\u0002\b\u0013*\u0007\u007f\u0082\u0001\u0087\u0001\u008a\u0001\b\u0007\u0018\u0000 Ã\u00012\u00020\u0001:\u0002Ã\u0001B+\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\u0004\b\n\u0010\u000bJ\u0011\u0010\u008c\u0001\u001a\u00020\t2\u0006\u0010_\u001a\u00020`H\u0007J\u0012\u0010\u008d\u0001\u001a\u00020\t2\u0007\u0010\u008e\u0001\u001a\u00020\bH\u0007J\u0012\u0010\u008f\u0001\u001a\u00020\t2\u0007\u0010\u008e\u0001\u001a\u00020\bH\u0003J\u0007\u0010\u0090\u0001\u001a\u00020\tJ\u0019\u0010\u0091\u0001\u001a\u00020\t2\u0007\u0010\u0092\u0001\u001a\u00020\u001d2\u0007\u0010\u0093\u0001\u001a\u00020\u001dJ\u0007\u0010\u0094\u0001\u001a\u00020\tJ\u0013\u0010\u0095\u0001\u001a\u00020\t2\b\u0010\u0096\u0001\u001a\u00030\u0097\u0001H\u0003J$\u0010\u0098\u0001\u001a\u00020\t2\u0007\u0010\u0099\u0001\u001a\u00020b2\u0007\u0010\u009a\u0001\u001a\u00020\u001d2\u0007\u0010\u009b\u0001\u001a\u00020\u001dH\u0003J\u0012\u0010\u009c\u0001\u001a\u00020\t2\u0007\u0010\u0099\u0001\u001a\u00020bH\u0003J\u001b\u0010\u009d\u0001\u001a\u00020\t2\u0007\u0010\u0099\u0001\u001a\u00020b2\u0007\u0010\u009a\u0001\u001a\u00020\u001dH\u0002J\u001b\u0010\u009e\u0001\u001a\u00020\t2\u0007\u0010\u0099\u0001\u001a\u00020b2\u0007\u0010\u009f\u0001\u001a\u00020dH\u0003J\u0012\u0010\u00a0\u0001\u001a\u00020\t2\u0007\u0010\u0099\u0001\u001a\u00020bH\u0003J\u0012\u0010¡\u0001\u001a\u00020\t2\u0007\u0010\u0099\u0001\u001a\u00020bH\u0003J\u0012\u0010¢\u0001\u001a\u00020\t2\u0007\u0010\u009a\u0001\u001a\u00020\u001dH\u0002J\t\u0010£\u0001\u001a\u00020\tH\u0002J\u001b\u0010¤\u0001\u001a\u00020\t2\u0007\u0010¥\u0001\u001a\u00020\u001d2\u0007\u0010¦\u0001\u001a\u00020\u001dH\u0002J$\u0010¤\u0001\u001a\u00020\t2\u0007\u0010¥\u0001\u001a\u00020\u001d2\u0007\u0010¦\u0001\u001a\u00020\u001d2\u0007\u0010§\u0001\u001a\u000200H\u0002J\t\u0010¨\u0001\u001a\u00020\tH\u0002J\u0012\u0010©\u0001\u001a\u00020\t2\u0007\u0010\u009a\u0001\u001a\u00020\u001dH\u0002J\u0012\u0010ª\u0001\u001a\u00020\t2\u0007\u0010«\u0001\u001a\u00020LH\u0002J\t\u0010¬\u0001\u001a\u00020\tH\u0002J\u0012\u0010\u00ad\u0001\u001a\u00020\t2\u0007\u0010®\u0001\u001a\u00020\bH\u0002J\u001c\u0010¯\u0001\u001a\u00020\t2\b\u0010°\u0001\u001a\u00030±\u00012\u0007\u0010²\u0001\u001a\u00020\"H\u0002J\u0012\u0010³\u0001\u001a\u00020\t2\u0007\u0010²\u0001\u001a\u00020\"H\u0002J\t\u0010´\u0001\u001a\u00020\tH\u0003J\u0012\u0010µ\u0001\u001a\u00020\t2\u0007\u0010®\u0001\u001a\u00020\bH\u0002J\u0012\u0010¶\u0001\u001a\u00020\t2\u0007\u0010·\u0001\u001a\u00020\bH\u0002J-\u0010¸\u0001\u001a\u0002002\u0007\u0010\u0099\u0001\u001a\u00020b2\u0007\u0010\u009f\u0001\u001a\u00020d2\u0007\u0010²\u0001\u001a\u00020\"2\u0007\u0010¹\u0001\u001a\u00020\u001dH\u0003J\t\u0010º\u0001\u001a\u00020\tH\u0003J\u0012\u0010»\u0001\u001a\u00020\t2\u0007\u0010¼\u0001\u001a\u000200H\u0003J\u0012\u0010½\u0001\u001a\u00020\t2\u0007\u0010·\u0001\u001a\u00020\bH\u0002J$\u0010¾\u0001\u001a\u00020\t2\u0007\u0010¿\u0001\u001a\u00020\"2\u0007\u0010À\u0001\u001a\u00020\u001d2\u0007\u0010²\u0001\u001a\u00020\u001dH\u0002J$\u0010Á\u0001\u001a\u00020\t2\u0007\u0010¿\u0001\u001a\u00020\"2\u0007\u0010À\u0001\u001a\u00020\u001d2\u0007\u0010²\u0001\u001a\u00020LH\u0002J\u001a\u0010Â\u0001\u001a\u00020\u001d2\u0006\u0010_\u001a\u00020\"2\u0007\u0010À\u0001\u001a\u00020\u001dH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\f\u001a\n \r*\u0004\u0018\u00010\u00030\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0010\u001a\n \r*\u0004\u0018\u00010\u00110\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0012\u001a\u0004\u0018\u00010\u00138BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R\u0016\u0010\u0016\u001a\n \r*\u0004\u0018\u00010\u00170\u0017X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u001a0\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001cX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001cX\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\u001f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020!\u0012\u0004\u0012\u00020\"0 0\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010#\u001a\b\u0012\u0004\u0012\u00020%0$¢\u0006\b\n\u0000\u001a\u0004\b&\u0010\'R+\u0010)\u001a\u00020\b2\u0006\u0010(\u001a\u00020\b8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b.\u0010/\u001a\u0004\b*\u0010+\"\u0004\b,\u0010-R+\u00101\u001a\u0002002\u0006\u0010(\u001a\u0002008F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b6\u0010/\u001a\u0004\b2\u00103\"\u0004\b4\u00105R+\u00107\u001a\u0002002\u0006\u0010(\u001a\u0002008F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b:\u0010/\u001a\u0004\b8\u00103\"\u0004\b9\u00105R+\u0010;\u001a\u00020\b2\u0006\u0010(\u001a\u00020\b8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b>\u0010/\u001a\u0004\b<\u0010+\"\u0004\b=\u0010-R+\u0010?\u001a\u00020\u001d2\u0006\u0010(\u001a\u00020\u001d8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bD\u0010/\u001a\u0004\b@\u0010A\"\u0004\bB\u0010CR+\u0010F\u001a\u00020E2\u0006\u0010(\u001a\u00020E8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bK\u0010/\u001a\u0004\bG\u0010H\"\u0004\bI\u0010JR+\u0010M\u001a\u00020L2\u0006\u0010(\u001a\u00020L8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bR\u0010/\u001a\u0004\bN\u0010O\"\u0004\bP\u0010QR+\u0010S\u001a\u00020\u001d2\u0006\u0010(\u001a\u00020\u001d8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bV\u0010/\u001a\u0004\bT\u0010A\"\u0004\bU\u0010CR+\u0010W\u001a\u00020\u001d2\u0006\u0010(\u001a\u00020\u001d8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bZ\u0010/\u001a\u0004\bX\u0010A\"\u0004\bY\u0010CR+\u0010[\u001a\u00020\u001d2\u0006\u0010(\u001a\u00020\u001d8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b^\u0010/\u001a\u0004\b\\\u0010A\"\u0004\b]\u0010CR\u000e\u0010_\u001a\u00020`X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010a\u001a\u0004\u0018\u00010bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010c\u001a\u0004\u0018\u00010dX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010e\u001a\u0004\u0018\u00010dX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010f\u001a\u0004\u0018\u00010\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010g\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010h\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010i\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010j\u001a\u000200X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010k\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010l\u001a\u00020LX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010m\u001a\u00020LX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010n\u001a\u000200X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010o\u001a\u000200X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010p\u001a\u000200X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010q\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010r\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010s\u001a\b\u0012\u0004\u0012\u00020\u001d0tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010u\u001a\u000200X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010v\u001a\u00020LX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010w\u001a\u00020LX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010x\u001a\u00020LX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010y\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010z\u001a\u000200X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010{\u001a\u000200X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010|\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010}\u001a\u000200X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010~\u001a\u00020\u007fX\u0082\u0004¢\u0006\u0005\n\u0003\u0010\u0080\u0001R\u0013\u0010\u0081\u0001\u001a\u00030\u0082\u0001X\u0082\u0004¢\u0006\u0005\n\u0003\u0010\u0083\u0001R\u0010\u0010\u0084\u0001\u001a\u00030\u0085\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u0013\u0010\u0086\u0001\u001a\u00030\u0087\u0001X\u0082\u0004¢\u0006\u0005\n\u0003\u0010\u0088\u0001R\u0013\u0010\u0089\u0001\u001a\u00030\u008a\u0001X\u0082\u0004¢\u0006\u0005\n\u0003\u0010\u008b\u0001¨\u0006Ä\u0001"
    }
    d2 = {
        "Lcom/example/bleconnectse/BleTileClient;",
        "",
        "context",
        "Landroid/content/Context;",
        "repository",
        "Lcom/example/bleconnectse/SyntheticTileRepository;",
        "logger",
        "Lkotlin/Function1;",
        "",
        "",
        "<init>",
        "(Landroid/content/Context;Lcom/example/bleconnectse/SyntheticTileRepository;Lkotlin/jvm/functions/Function1;)V",
        "appContext",
        "kotlin.jvm.PlatformType",
        "mainHandler",
        "Landroid/os/Handler;",
        "bluetoothManager",
        "Landroid/bluetooth/BluetoothManager;",
        "bluetoothAdapter",
        "Landroid/bluetooth/BluetoothAdapter;",
        "getBluetoothAdapter",
        "()Landroid/bluetooth/BluetoothAdapter;",
        "preferences",
        "Landroid/content/SharedPreferences;",
        "transferQueue",
        "Ljava/util/ArrayDeque;",
        "Lcom/example/bleconnectse/SyntheticTile;",
        "queuedTileIds",
        "",
        "",
        "sentTileIds",
        "descriptorQueue",
        "Lkotlin/Pair;",
        "Landroid/bluetooth/BluetoothGattDescriptor;",
        "",
        "candidates",
        "Landroidx/compose/runtime/snapshots/SnapshotStateList;",
        "Lcom/example/bleconnectse/BleTileDevice;",
        "getCandidates",
        "()Landroidx/compose/runtime/snapshots/SnapshotStateList;",
        "<set-?>",
        "status",
        "getStatus",
        "()Ljava/lang/String;",
        "setStatus",
        "(Ljava/lang/String;)V",
        "status$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "",
        "scanning",
        "getScanning",
        "()Z",
        "setScanning",
        "(Z)V",
        "scanning$delegate",
        "connected",
        "getConnected",
        "setConnected",
        "connected$delegate",
        "connectedName",
        "getConnectedName",
        "setConnectedName",
        "connectedName$delegate",
        "negotiatedMtu",
        "getNegotiatedMtu",
        "()I",
        "setNegotiatedMtu",
        "(I)V",
        "negotiatedMtu$delegate",
        "",
        "progress",
        "getProgress",
        "()F",
        "setProgress",
        "(F)V",
        "progress$delegate",
        "",
        "speedBytesPerSecond",
        "getSpeedBytesPerSecond",
        "()J",
        "setSpeedBytesPerSecond",
        "(J)V",
        "speedBytesPerSecond$delegate",
        "queuedTileCount",
        "getQueuedTileCount",
        "setQueuedTileCount",
        "queuedTileCount$delegate",
        "sentTileCount",
        "getSentTileCount",
        "setSentTileCount",
        "sentTileCount$delegate",
        "acknowledgedTileCount",
        "getAcknowledgedTileCount",
        "setAcknowledgedTileCount",
        "acknowledgedTileCount$delegate",
        "source",
        "Lcom/example/bleconnectse/BleTileSource;",
        "bluetoothGatt",
        "Landroid/bluetooth/BluetoothGatt;",
        "controlCharacteristic",
        "Landroid/bluetooth/BluetoothGattCharacteristic;",
        "dataCharacteristic",
        "activeTile",
        "activeOffset",
        "activeSequence",
        "pendingPayloadSize",
        "writeInFlight",
        "writeRetries",
        "bytesSentTotal",
        "speedWindowBytes",
        "serviceDiscoveryStarted",
        "transportReady",
        "closed",
        "desiredCenterTileX",
        "desiredCenterTileY",
        "neighborhoodTileIds",
        "",
        "instrumentControlsDemand",
        "dataWriteGeneration",
        "dataWriteStartedAtMs",
        "lastTransferProgressAtMs",
        "desiredDeviceAddress",
        "keepConnectionAlive",
        "reconnectScheduled",
        "reconnectAttempts",
        "connecting",
        "transferWatchdog",
        "com/example/bleconnectse/BleTileClient$transferWatchdog$1",
        "Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;",
        "speedTicker",
        "com/example/bleconnectse/BleTileClient$speedTicker$1",
        "Lcom/example/bleconnectse/BleTileClient$speedTicker$1;",
        "scanTimeout",
        "Ljava/lang/Runnable;",
        "scanCallback",
        "com/example/bleconnectse/BleTileClient$scanCallback$1",
        "Lcom/example/bleconnectse/BleTileClient$scanCallback$1;",
        "gattCallback",
        "com/example/bleconnectse/BleTileClient$gattCallback$1",
        "Lcom/example/bleconnectse/BleTileClient$gattCallback$1;",
        "startScan",
        "connect",
        "address",
        "connectInternal",
        "disconnect",
        "updateVehicleTile",
        "tileX",
        "tileY",
        "close",
        "acceptScanResult",
        "result",
        "Landroid/bluetooth/le/ScanResult;",
        "handleConnectionState",
        "gatt",
        "statusCode",
        "newState",
        "discoverServicesOnce",
        "handleServicesDiscovered",
        "enableLocalNotification",
        "characteristic",
        "writeNextDescriptor",
        "writeControlPacket",
        "handleControlWritten",
        "finishTransportReady",
        "enqueueNeighborhood",
        "centerTileX",
        "centerTileY",
        "forceRefresh",
        "pumpTransfer",
        "handleDataWritten",
        "handleNoResponsePacketSubmitted",
        "generation",
        "completeCurrentPacket",
        "retryOrFailCurrentPacket",
        "reason",
        "handleNotification",
        "uuid",
        "Ljava/util/UUID;",
        "value",
        "handleTileResult",
        "recoverGattConnection",
        "scheduleReconnect",
        "failTransport",
        "message",
        "writeCharacteristic",
        "writeType",
        "stopScanInternal",
        "disconnectInternal",
        "updateStatus",
        "logStatus",
        "writeUInt16Le",
        "target",
        "offset",
        "writeUInt32Le",
        "readUInt16Le",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field private static final CLIENT_CONFIG_UUID:Ljava/util/UUID;

.field private static final CONTROL_UUID:Ljava/util/UUID;

.field public static final Companion:Lcom/example/bleconnectse/BleTileClient$Companion;

.field private static final DATA_PACKET_PACING_MS:J = 0x12L

.field private static final DATA_UUID:Ljava/util/UUID;

.field private static final DATA_WRITE_RETRY_MS:J = 0x28L

.field private static final DATA_WRITE_STALL_MS:J = 0x5dcL

.field private static final LOG_TAG:Ljava/lang/String; = "BleTileClient"

.field private static final MAX_DATA_WRITE_RETRIES:I = 0x14

.field private static final PREFERENCES:Ljava/lang/String; = "ble_tile_transport"

.field private static final PREFERRED_DEVICE:Ljava/lang/String; = "ble_tile_device"

.field private static final RECONNECT_DELAY_MS:J = 0x3e8L

.field private static final REQUESTED_MTU:I = 0x205

.field private static final RESULT_UUID:Ljava/util/UUID;

.field private static final SCAN_TIMEOUT_MS:J = 0x2710L

.field private static final SERVICE_UUID:Ljava/util/UUID;

.field private static final STATUS_UUID:Ljava/util/UUID;

.field private static final TRANSPORT_HEADER_SIZE:I = 0xa


# instance fields
.field private final acknowledgedTileCount$delegate:Landroidx/compose/runtime/MutableState;

.field private activeOffset:I

.field private activeSequence:I

.field private activeTile:Lcom/example/bleconnectse/SyntheticTile;

.field private final appContext:Landroid/content/Context;

.field private bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

.field private final bluetoothManager:Landroid/bluetooth/BluetoothManager;

.field private bytesSentTotal:J

.field private final candidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "Lcom/example/bleconnectse/BleTileDevice;",
            ">;"
        }
    .end annotation
.end field

.field private closed:Z

.field private final connected$delegate:Landroidx/compose/runtime/MutableState;

.field private final connectedName$delegate:Landroidx/compose/runtime/MutableState;

.field private connecting:Z

.field private controlCharacteristic:Landroid/bluetooth/BluetoothGattCharacteristic;

.field private dataCharacteristic:Landroid/bluetooth/BluetoothGattCharacteristic;

.field private dataWriteGeneration:J

.field private dataWriteStartedAtMs:J

.field private final descriptorQueue:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "Lkotlin/Pair<",
            "Landroid/bluetooth/BluetoothGattDescriptor;",
            "[B>;>;"
        }
    .end annotation
.end field

.field private desiredCenterTileX:I

.field private desiredCenterTileY:I

.field private desiredDeviceAddress:Ljava/lang/String;

.field private final gattCallback:Lcom/example/bleconnectse/BleTileClient$gattCallback$1;

.field private instrumentControlsDemand:Z

.field private keepConnectionAlive:Z

.field private lastTransferProgressAtMs:J

.field private final logger:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final mainHandler:Landroid/os/Handler;

.field private final negotiatedMtu$delegate:Landroidx/compose/runtime/MutableState;

.field private neighborhoodTileIds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private pendingPayloadSize:I

.field private final preferences:Landroid/content/SharedPreferences;

.field private final progress$delegate:Landroidx/compose/runtime/MutableState;

.field private final queuedTileCount$delegate:Landroidx/compose/runtime/MutableState;

.field private final queuedTileIds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private reconnectAttempts:I

.field private reconnectScheduled:Z

.field private final repository:Lcom/example/bleconnectse/SyntheticTileRepository;

.field private final scanCallback:Lcom/example/bleconnectse/BleTileClient$scanCallback$1;

.field private final scanTimeout:Ljava/lang/Runnable;

.field private final scanning$delegate:Landroidx/compose/runtime/MutableState;

.field private final sentTileCount$delegate:Landroidx/compose/runtime/MutableState;

.field private final sentTileIds:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private serviceDiscoveryStarted:Z

.field private source:Lcom/example/bleconnectse/BleTileSource;

.field private final speedBytesPerSecond$delegate:Landroidx/compose/runtime/MutableState;

.field private final speedTicker:Lcom/example/bleconnectse/BleTileClient$speedTicker$1;

.field private speedWindowBytes:J

.field private final status$delegate:Landroidx/compose/runtime/MutableState;

.field private final transferQueue:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "Lcom/example/bleconnectse/SyntheticTile;",
            ">;"
        }
    .end annotation
.end field

.field private final transferWatchdog:Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;

.field private transportReady:Z

.field private writeInFlight:Z

.field private writeRetries:I


# direct methods
.method public static synthetic $r8$lambda$QzDpTRPUPi_GkXNVEpzPHukkXdw(Lcom/example/bleconnectse/BleTileClient;)V
    .registers 1

    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->pumpTransfer()V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/example/bleconnectse/BleTileClient$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/BleTileClient$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/example/bleconnectse/BleTileClient;->Companion:Lcom/example/bleconnectse/BleTileClient$Companion;

    const/16 v0, 0x8

    sput v0, Lcom/example/bleconnectse/BleTileClient;->$stable:I

    .line 50
    const-string v0, "7e400001-b5a3-f393-e0a9-e50e24dcca9e"

    invoke-static {v0}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v0

    const-string v1, "fromString(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lcom/example/bleconnectse/BleTileClient;->SERVICE_UUID:Ljava/util/UUID;

    .line 51
    const-string v0, "7e400002-b5a3-f393-e0a9-e50e24dcca9e"

    invoke-static {v0}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lcom/example/bleconnectse/BleTileClient;->CONTROL_UUID:Ljava/util/UUID;

    .line 52
    const-string v0, "7e400003-b5a3-f393-e0a9-e50e24dcca9e"

    invoke-static {v0}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lcom/example/bleconnectse/BleTileClient;->DATA_UUID:Ljava/util/UUID;

    .line 53
    const-string v0, "7e400004-b5a3-f393-e0a9-e50e24dcca9e"

    invoke-static {v0}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lcom/example/bleconnectse/BleTileClient;->STATUS_UUID:Ljava/util/UUID;

    .line 54
    const-string v0, "7e400005-b5a3-f393-e0a9-e50e24dcca9e"

    invoke-static {v0}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lcom/example/bleconnectse/BleTileClient;->RESULT_UUID:Ljava/util/UUID;

    .line 56
    const-string v0, "00002902-0000-1000-8000-00805f9b34fb"

    invoke-static {v0}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sput-object v0, Lcom/example/bleconnectse/BleTileClient;->CLIENT_CONFIG_UUID:Ljava/util/UUID;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/example/bleconnectse/SyntheticTileRepository;Lkotlin/jvm/functions/Function1;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/example/bleconnectse/SyntheticTileRepository;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "repository"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "logger"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    iput-object p2, p0, Lcom/example/bleconnectse/BleTileClient;->repository:Lcom/example/bleconnectse/SyntheticTileRepository;

    .line 47
    iput-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->logger:Lkotlin/jvm/functions/Function1;

    .line 71
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->appContext:Landroid/content/Context;

    .line 72
    new-instance p2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p3

    invoke-direct {p2, p3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p2, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    .line 73
    const-class p3, Landroid/bluetooth/BluetoothManager;

    invoke-virtual {p1, p3}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroid/bluetooth/BluetoothManager;

    iput-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothManager:Landroid/bluetooth/BluetoothManager;

    .line 75
    const-string p3, "ble_tile_transport"

    const/4 v0, 0x0

    .line 84
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    .line 96
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    .line 75
    invoke-virtual {p1, p3, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->preferences:Landroid/content/SharedPreferences;

    .line 76
    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    .line 77
    new-instance p1, Ljava/util/LinkedHashSet;

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    check-cast p1, Ljava/util/Set;

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileIds:Ljava/util/Set;

    .line 78
    new-instance p1, Ljava/util/LinkedHashSet;

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    check-cast p1, Ljava/util/Set;

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileIds:Ljava/util/Set;

    .line 79
    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->descriptorQueue:Ljava/util/ArrayDeque;

    .line 81
    invoke-static {}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateListOf()Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->candidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 82
    const-string p1, "BLE瓦片空闲"

    const/4 p3, 0x0

    const/4 v0, 0x2

    invoke-static {p1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->status$delegate:Landroidx/compose/runtime/MutableState;

    .line 84
    invoke-static {v1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->scanning$delegate:Landroidx/compose/runtime/MutableState;

    .line 86
    invoke-static {v1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->connected$delegate:Landroidx/compose/runtime/MutableState;

    .line 88
    const-string p1, ""

    invoke-static {p1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->connectedName$delegate:Landroidx/compose/runtime/MutableState;

    const/16 p1, 0x17

    .line 90
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->negotiatedMtu$delegate:Landroidx/compose/runtime/MutableState;

    const/4 p1, 0x0

    .line 92
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    invoke-static {p1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->progress$delegate:Landroidx/compose/runtime/MutableState;

    const-wide/16 v3, 0x0

    .line 94
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-static {p1, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->speedBytesPerSecond$delegate:Landroidx/compose/runtime/MutableState;

    .line 96
    invoke-static {v2, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileCount$delegate:Landroidx/compose/runtime/MutableState;

    .line 98
    invoke-static {v2, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileCount$delegate:Landroidx/compose/runtime/MutableState;

    .line 100
    invoke-static {v2, p3, v0, p3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->acknowledgedTileCount$delegate:Landroidx/compose/runtime/MutableState;

    .line 103
    sget-object p1, Lcom/example/bleconnectse/BleTileSource;->Simulated:Lcom/example/bleconnectse/BleTileSource;

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->source:Lcom/example/bleconnectse/BleTileSource;

    .line 120
    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->neighborhoodTileIds:Ljava/util/Set;

    .line 131
    new-instance p1, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;-><init>(Lcom/example/bleconnectse/BleTileClient;)V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->transferWatchdog:Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;

    .line 153
    new-instance p3, Lcom/example/bleconnectse/BleTileClient$speedTicker$1;

    invoke-direct {p3, p0}, Lcom/example/bleconnectse/BleTileClient$speedTicker$1;-><init>(Lcom/example/bleconnectse/BleTileClient;)V

    iput-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->speedTicker:Lcom/example/bleconnectse/BleTileClient$speedTicker$1;

    .line 161
    new-instance v0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda2;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda2;-><init>(Lcom/example/bleconnectse/BleTileClient;)V

    iput-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->scanTimeout:Ljava/lang/Runnable;

    .line 171
    new-instance v0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;-><init>(Lcom/example/bleconnectse/BleTileClient;)V

    iput-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->scanCallback:Lcom/example/bleconnectse/BleTileClient$scanCallback$1;

    .line 189
    new-instance v0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;-><init>(Lcom/example/bleconnectse/BleTileClient;)V

    iput-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->gattCallback:Lcom/example/bleconnectse/BleTileClient$gattCallback$1;

    .line 254
    check-cast p3, Ljava/lang/Runnable;

    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 255
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->lastTransferProgressAtMs:J

    .line 256
    check-cast p1, Ljava/lang/Runnable;

    invoke-virtual {p2, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private final acceptScanResult(Landroid/bluetooth/le/ScanResult;)V
    .registers 8

    .line 367
    invoke-virtual {p1}, Landroid/bluetooth/le/ScanResult;->getDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v0

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_c

    goto/16 :goto_c2

    .line 368
    :cond_c
    invoke-virtual {p1}, Landroid/bluetooth/le/ScanResult;->getScanRecord()Landroid/bluetooth/le/ScanRecord;

    move-result-object v1

    const/4 v2, 0x0

    if-eqz v1, :cond_18

    invoke-virtual {v1}, Landroid/bluetooth/le/ScanRecord;->getDeviceName()Ljava/lang/String;

    move-result-object v1

    goto :goto_19

    :cond_18
    move-object v1, v2

    :goto_19
    if-nez v1, :cond_1d

    const-string v1, ""

    :cond_1d
    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_27

    const-string v1, "BLE瓦片仪表"

    :cond_27
    check-cast v1, Ljava/lang/String;

    .line 369
    new-instance v3, Lcom/example/bleconnectse/BleTileDevice;

    invoke-virtual {p1}, Landroid/bluetooth/le/ScanResult;->getRssi()I

    move-result p1

    invoke-direct {v3, v0, v1, p1}, Lcom/example/bleconnectse/BleTileDevice;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 370
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->candidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    check-cast p1, Ljava/util/List;

    .line 893
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v1, 0x0

    :goto_3b
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v5, 0x1

    if-eqz v4, :cond_56

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .line 894
    check-cast v4, Lcom/example/bleconnectse/BleTileDevice;

    .line 370
    invoke-virtual {v4}, Lcom/example/bleconnectse/BleTileDevice;->getAddress()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v0, v5}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v4

    if-eqz v4, :cond_53

    goto :goto_57

    :cond_53
    add-int/lit8 v1, v1, 0x1

    goto :goto_3b

    :cond_56
    const/4 v1, -0x1

    .line 371
    :goto_57
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->candidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    if-ltz v1, :cond_5f

    invoke-virtual {p1, v1, v3}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    goto :goto_64

    :cond_5f
    check-cast p1, Ljava/util/Collection;

    invoke-interface {p1, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 372
    :goto_64
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->candidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    check-cast p1, Ljava/util/List;

    .line 899
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-le v1, v5, :cond_78

    new-instance v1, Lcom/example/bleconnectse/BleTileClient$acceptScanResult$$inlined$sortByDescending$1;

    invoke-direct {v1}, Lcom/example/bleconnectse/BleTileClient$acceptScanResult$$inlined$sortByDescending$1;-><init>()V

    check-cast v1, Ljava/util/Comparator;

    invoke-static {p1, v1}, Lkotlin/collections/CollectionsKt;->sortWith(Ljava/util/List;Ljava/util/Comparator;)V

    .line 373
    :cond_78
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->candidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    invoke-virtual {p1}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->size()I

    move-result p1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "发现 "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v1, " 个瓦片仪表，请核对地址后连接"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 375
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->preferences:Landroid/content/SharedPreferences;

    const-string v1, "ble_tile_device"

    invoke-interface {p1, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 376
    invoke-static {p1, v0, v5}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_c2

    .line 377
    new-instance p1, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "发现上次已确认仪表："

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v1, "，自动连接"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    .line 378
    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->connect(Ljava/lang/String;)V

    :cond_c2
    :goto_c2
    return-void
.end method

.method public static final synthetic access$acceptScanResult(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/le/ScanResult;)V
    .registers 2

    .line 44
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->acceptScanResult(Landroid/bluetooth/le/ScanResult;)V

    return-void
.end method

.method public static final synthetic access$discoverServicesOnce(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;)V
    .registers 2

    .line 44
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->discoverServicesOnce(Landroid/bluetooth/BluetoothGatt;)V

    return-void
.end method

.method public static final synthetic access$finishTransportReady(Lcom/example/bleconnectse/BleTileClient;)V
    .registers 1

    .line 44
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->finishTransportReady()V

    return-void
.end method

.method public static final synthetic access$getActiveTile$p(Lcom/example/bleconnectse/BleTileClient;)Lcom/example/bleconnectse/SyntheticTile;
    .registers 1

    .line 44
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    return-object p0
.end method

.method public static final synthetic access$getCONTROL_UUID$cp()Ljava/util/UUID;
    .registers 1

    .line 44
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->CONTROL_UUID:Ljava/util/UUID;

    return-object v0
.end method

.method public static final synthetic access$getClosed$p(Lcom/example/bleconnectse/BleTileClient;)Z
    .registers 1

    .line 44
    iget-boolean p0, p0, Lcom/example/bleconnectse/BleTileClient;->closed:Z

    return p0
.end method

.method public static final synthetic access$getDATA_UUID$cp()Ljava/util/UUID;
    .registers 1

    .line 44
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->DATA_UUID:Ljava/util/UUID;

    return-object v0
.end method

.method public static final synthetic access$getDataWriteGeneration$p(Lcom/example/bleconnectse/BleTileClient;)J
    .registers 3

    .line 44
    iget-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    return-wide v0
.end method

.method public static final synthetic access$getDataWriteStartedAtMs$p(Lcom/example/bleconnectse/BleTileClient;)J
    .registers 3

    .line 44
    iget-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteStartedAtMs:J

    return-wide v0
.end method

.method public static final synthetic access$getDescriptorQueue$p(Lcom/example/bleconnectse/BleTileClient;)Ljava/util/ArrayDeque;
    .registers 1

    .line 44
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->descriptorQueue:Ljava/util/ArrayDeque;

    return-object p0
.end method

.method public static final synthetic access$getLastTransferProgressAtMs$p(Lcom/example/bleconnectse/BleTileClient;)J
    .registers 3

    .line 44
    iget-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->lastTransferProgressAtMs:J

    return-wide v0
.end method

.method public static final synthetic access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;
    .registers 1

    .line 44
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    return-object p0
.end method

.method public static final synthetic access$getRESULT_UUID$cp()Ljava/util/UUID;
    .registers 1

    .line 44
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->RESULT_UUID:Ljava/util/UUID;

    return-object v0
.end method

.method public static final synthetic access$getSERVICE_UUID$cp()Ljava/util/UUID;
    .registers 1

    .line 44
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->SERVICE_UUID:Ljava/util/UUID;

    return-object v0
.end method

.method public static final synthetic access$getSTATUS_UUID$cp()Ljava/util/UUID;
    .registers 1

    .line 44
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->STATUS_UUID:Ljava/util/UUID;

    return-object v0
.end method

.method public static final synthetic access$getSpeedWindowBytes$p(Lcom/example/bleconnectse/BleTileClient;)J
    .registers 3

    .line 44
    iget-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->speedWindowBytes:J

    return-wide v0
.end method

.method public static final synthetic access$getTransferQueue$p(Lcom/example/bleconnectse/BleTileClient;)Ljava/util/ArrayDeque;
    .registers 1

    .line 44
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    return-object p0
.end method

.method public static final synthetic access$getTransportReady$p(Lcom/example/bleconnectse/BleTileClient;)Z
    .registers 1

    .line 44
    iget-boolean p0, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    return p0
.end method

.method public static final synthetic access$getWriteInFlight$p(Lcom/example/bleconnectse/BleTileClient;)Z
    .registers 1

    .line 44
    iget-boolean p0, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    return p0
.end method

.method public static final synthetic access$handleConnectionState(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;II)V
    .registers 4

    .line 44
    invoke-direct {p0, p1, p2, p3}, Lcom/example/bleconnectse/BleTileClient;->handleConnectionState(Landroid/bluetooth/BluetoothGatt;II)V

    return-void
.end method

.method public static final synthetic access$handleControlWritten(Lcom/example/bleconnectse/BleTileClient;I)V
    .registers 2

    .line 44
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->handleControlWritten(I)V

    return-void
.end method

.method public static final synthetic access$handleDataWritten(Lcom/example/bleconnectse/BleTileClient;I)V
    .registers 2

    .line 44
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->handleDataWritten(I)V

    return-void
.end method

.method public static final synthetic access$handleNotification(Lcom/example/bleconnectse/BleTileClient;Ljava/util/UUID;[B)V
    .registers 3

    .line 44
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/BleTileClient;->handleNotification(Ljava/util/UUID;[B)V

    return-void
.end method

.method public static final synthetic access$handleServicesDiscovered(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;I)V
    .registers 3

    .line 44
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/BleTileClient;->handleServicesDiscovered(Landroid/bluetooth/BluetoothGatt;I)V

    return-void
.end method

.method public static final synthetic access$logStatus(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V
    .registers 2

    .line 44
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$pumpTransfer(Lcom/example/bleconnectse/BleTileClient;)V
    .registers 1

    .line 44
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->pumpTransfer()V

    return-void
.end method

.method public static final synthetic access$retryOrFailCurrentPacket(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V
    .registers 2

    .line 44
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->retryOrFailCurrentPacket(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setDataWriteGeneration$p(Lcom/example/bleconnectse/BleTileClient;J)V
    .registers 3

    .line 44
    iput-wide p1, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    return-void
.end method

.method public static final synthetic access$setNegotiatedMtu(Lcom/example/bleconnectse/BleTileClient;I)V
    .registers 2

    .line 44
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setNegotiatedMtu(I)V

    return-void
.end method

.method public static final synthetic access$setScanning(Lcom/example/bleconnectse/BleTileClient;Z)V
    .registers 2

    .line 44
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setScanning(Z)V

    return-void
.end method

.method public static final synthetic access$setSpeedBytesPerSecond(Lcom/example/bleconnectse/BleTileClient;J)V
    .registers 3

    .line 44
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/BleTileClient;->setSpeedBytesPerSecond(J)V

    return-void
.end method

.method public static final synthetic access$setSpeedWindowBytes$p(Lcom/example/bleconnectse/BleTileClient;J)V
    .registers 3

    .line 44
    iput-wide p1, p0, Lcom/example/bleconnectse/BleTileClient;->speedWindowBytes:J

    return-void
.end method

.method public static final synthetic access$setStatus(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V
    .registers 2

    .line 44
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setWriteInFlight$p(Lcom/example/bleconnectse/BleTileClient;Z)V
    .registers 2

    .line 44
    iput-boolean p1, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    return-void
.end method

.method public static final synthetic access$writeNextDescriptor(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;)V
    .registers 2

    .line 44
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->writeNextDescriptor(Landroid/bluetooth/BluetoothGatt;)V

    return-void
.end method

.method private final completeCurrentPacket()V
    .registers 10

    const/4 v0, 0x0

    .line 660
    iput v0, p0, Lcom/example/bleconnectse/BleTileClient;->writeRetries:I

    .line 661
    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    if-nez v1, :cond_8

    return-void

    .line 662
    :cond_8
    iget v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeOffset:I

    iget v3, p0, Lcom/example/bleconnectse/BleTileClient;->pendingPayloadSize:I

    add-int/2addr v2, v3

    iput v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeOffset:I

    .line 663
    iget v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeSequence:I

    const/4 v4, 0x1

    add-int/2addr v2, v4

    iput v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeSequence:I

    .line 664
    iget-wide v5, p0, Lcom/example/bleconnectse/BleTileClient;->bytesSentTotal:J

    int-to-long v7, v3

    add-long/2addr v5, v7

    iput-wide v5, p0, Lcom/example/bleconnectse/BleTileClient;->bytesSentTotal:J

    .line 665
    iget-wide v5, p0, Lcom/example/bleconnectse/BleTileClient;->speedWindowBytes:J

    int-to-long v2, v3

    add-long/2addr v5, v2

    iput-wide v5, p0, Lcom/example/bleconnectse/BleTileClient;->speedWindowBytes:J

    .line 666
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/example/bleconnectse/BleTileClient;->lastTransferProgressAtMs:J

    .line 667
    iget v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeOffset:I

    int-to-float v2, v2

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticTile;->getBytes()[B

    move-result-object v3

    array-length v3, v3

    invoke-static {v3, v4}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v2, v3

    invoke-direct {p0, v2}, Lcom/example/bleconnectse/BleTileClient;->setProgress(F)V

    .line 668
    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticTile;->getTileX()I

    move-result v2

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticTile;->getTileY()I

    move-result v3

    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getProgress()F

    move-result v5

    const/high16 v6, 0x42c80000  # 100.0f

    mul-float/2addr v5, v6

    invoke-static {v5}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result v5

    new-instance v6, Ljava/lang/StringBuilder;

    const-string/jumbo v7, "发送瓦片 "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v6, ","

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "："

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "%"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 669
    iget v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeOffset:I

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticTile;->getBytes()[B

    move-result-object v3

    array-length v3, v3

    if-lt v2, v3, :cond_ef

    .line 670
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileIds:Ljava/util/Set;

    check-cast v2, Ljava/util/Collection;

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 671
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileIds:Ljava/util/Set;

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v2

    invoke-direct {p0, v2}, Lcom/example/bleconnectse/BleTileClient;->setSentTileCount(I)V

    .line 673
    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v2

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticTile;->getBytes()[B

    move-result-object v3

    array-length v3, v3

    .line 674
    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticTile;->getCrc32()J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const-string v5, "CRC32=%08X"

    invoke-static {v5, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v5, "format(...)"

    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "BLE瓦片已发送：id="

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, " "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "B "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 672
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    const/4 v1, 0x0

    .line 676
    iput-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    .line 677
    iput v0, p0, Lcom/example/bleconnectse/BleTileClient;->activeOffset:I

    .line 678
    iput v0, p0, Lcom/example/bleconnectse/BleTileClient;->activeSequence:I

    const/4 v1, 0x0

    .line 679
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/BleTileClient;->setProgress(F)V

    .line 681
    :cond_ef
    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->size()I

    move-result v1

    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    if-eqz v2, :cond_fa

    move v0, v4

    :cond_fa
    add-int/2addr v1, v0

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/BleTileClient;->setQueuedTileCount(I)V

    .line 682
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->pumpTransfer()V

    return-void
.end method

.method private final connectInternal(Ljava/lang/String;)V
    .registers 9

    .line 311
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->closed:Z

    if-nez v0, :cond_e7

    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getConnected()Z

    move-result v0

    if-nez v0, :cond_e7

    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->connecting:Z

    if-eqz v0, :cond_10

    goto/16 :goto_e7

    .line 312
    :cond_10
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->getBluetoothAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    if-nez v0, :cond_18

    goto/16 :goto_e7

    .line 313
    :cond_18
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->stopScanInternal()V

    const/4 v1, 0x0

    .line 314
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/BleTileClient;->disconnectInternal(Z)V

    .line 315
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->candidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    check-cast v2, Ljava/lang/Iterable;

    .line 889
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_27
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_41

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    move-object v6, v3

    check-cast v6, Lcom/example/bleconnectse/BleTileDevice;

    .line 315
    invoke-virtual {v6}, Lcom/example/bleconnectse/BleTileDevice;->getAddress()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, p1, v4}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v6

    if-eqz v6, :cond_27

    goto :goto_42

    :cond_41
    move-object v3, v5

    :goto_42
    check-cast v3, Lcom/example/bleconnectse/BleTileDevice;

    .line 316
    :try_start_44
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p0

    check-cast v2, Lcom/example/bleconnectse/BleTileClient;

    invoke-virtual {v0, p1}, Landroid/bluetooth/BluetoothAdapter;->getRemoteDevice(Ljava/lang/String;)Landroid/bluetooth/BluetoothDevice;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_51
    .catchall {:try_start_44 .. :try_end_51} :catchall_52

    goto :goto_5d

    :catchall_52
    move-exception v0

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_5d
    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_64

    goto :goto_65

    :cond_64
    move-object v5, v0

    :goto_65
    check-cast v5, Landroid/bluetooth/BluetoothDevice;

    if-nez v5, :cond_7d

    .line 318
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "无效BLE地址："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    return-void

    :cond_7d
    if-eqz v3, :cond_92

    .line 321
    invoke-virtual {v3}, Lcom/example/bleconnectse/BleTileDevice;->getName()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_92

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_8e

    move-object v0, p1

    :cond_8e
    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_93

    :cond_92
    move-object v0, p1

    :cond_93
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setConnectedName(Ljava/lang/String;)V

    .line 322
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getConnectedName()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "正在连接 "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v2, "…"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 323
    iput-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->serviceDiscoveryStarted:Z

    .line 324
    iput-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    .line 325
    iput-boolean v4, p0, Lcom/example/bleconnectse/BleTileClient;->connecting:Z

    .line 327
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->appContext:Landroid/content/Context;

    .line 329
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->gattCallback:Lcom/example/bleconnectse/BleTileClient$gattCallback$1;

    check-cast v2, Landroid/bluetooth/BluetoothGattCallback;

    const/4 v3, 0x2

    .line 326
    invoke-virtual {v5, v0, v1, v2, v3}, Landroid/bluetooth/BluetoothDevice;->connectGatt(Landroid/content/Context;ZLandroid/bluetooth/BluetoothGattCallback;I)Landroid/bluetooth/BluetoothGatt;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    .line 332
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getConnectedName()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "BLE连接请求："

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    :cond_e7
    :goto_e7
    return-void
.end method

.method private final disconnectInternal(Z)V
    .registers 7

    const/4 v0, 0x0

    .line 808
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    .line 809
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setConnected(Z)V

    .line 810
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->connecting:Z

    .line 811
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    .line 812
    iget-wide v1, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    const-wide/16 v3, 0x1

    add-long/2addr v1, v3

    iput-wide v1, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    .line 813
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->serviceDiscoveryStarted:Z

    const/4 v1, 0x0

    .line 814
    iput-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->controlCharacteristic:Landroid/bluetooth/BluetoothGattCharacteristic;

    .line 815
    iput-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->dataCharacteristic:Landroid/bluetooth/BluetoothGattCharacteristic;

    .line 816
    iput-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    .line 817
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    .line 818
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileIds:Ljava/util/Set;

    invoke-interface {v2}, Ljava/util/Set;->clear()V

    .line 819
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileIds:Ljava/util/Set;

    invoke-interface {v2}, Ljava/util/Set;->clear()V

    .line 820
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->descriptorQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    .line 821
    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object v2

    iput-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->neighborhoodTileIds:Ljava/util/Set;

    .line 822
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setQueuedTileCount(I)V

    .line 823
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setSentTileCount(I)V

    .line 824
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setAcknowledgedTileCount(I)V

    const/4 v2, 0x0

    .line 825
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/BleTileClient;->setProgress(F)V

    const-wide/16 v2, 0x0

    .line 826
    invoke-direct {p0, v2, v3}, Lcom/example/bleconnectse/BleTileClient;->setSpeedBytesPerSecond(J)V

    .line 827
    iput-wide v2, p0, Lcom/example/bleconnectse/BleTileClient;->speedWindowBytes:J

    .line 828
    iput-wide v2, p0, Lcom/example/bleconnectse/BleTileClient;->bytesSentTotal:J

    .line 829
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->instrumentControlsDemand:Z

    .line 830
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    if-eqz v0, :cond_85

    .line 831
    :try_start_50
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p0

    check-cast v2, Lcom/example/bleconnectse/BleTileClient;

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothGatt;->disconnect()V

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5d
    .catchall {:try_start_50 .. :try_end_5d} :catchall_5e

    goto :goto_68

    :catchall_5e
    move-exception v2

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 832
    :goto_68
    :try_start_68
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p0

    check-cast v2, Lcom/example/bleconnectse/BleTileClient;

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothGatt;->close()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_76
    .catchall {:try_start_68 .. :try_end_76} :catchall_77

    goto :goto_82

    :catchall_77
    move-exception v0

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_82
    invoke-static {v0}, Lkotlin/Result;->box-impl(Ljava/lang/Object;)Lkotlin/Result;

    .line 834
    :cond_85
    iput-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    if-eqz p1, :cond_8e

    .line 835
    const-string p1, "BLE瓦片已停止"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    :cond_8e
    return-void
.end method

.method private final discoverServicesOnce(Landroid/bluetooth/BluetoothGatt;)V
    .registers 3

    .line 426
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->serviceDiscoveryStarted:Z

    if-nez v0, :cond_24

    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getConnected()Z

    move-result v0

    if-eqz v0, :cond_24

    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    if-eq p1, v0, :cond_f

    goto :goto_24

    :cond_f
    const/4 v0, 0x1

    .line 427
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->serviceDiscoveryStarted:Z

    .line 428
    const-string/jumbo v0, "正在发现BLE瓦片服务…"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 429
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothGatt;->discoverServices()Z

    move-result p1

    if-nez p1, :cond_24

    const-string/jumbo p1, "无法启动BLE服务发现"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->failTransport(Ljava/lang/String;)V

    :cond_24
    :goto_24
    return-void
.end method

.method private final enableLocalNotification(Landroid/bluetooth/BluetoothGatt;Landroid/bluetooth/BluetoothGattCharacteristic;)V
    .registers 4

    const/4 v0, 0x1

    .line 472
    invoke-virtual {p1, p2, v0}, Landroid/bluetooth/BluetoothGatt;->setCharacteristicNotification(Landroid/bluetooth/BluetoothGattCharacteristic;Z)Z

    move-result p1

    if-nez p1, :cond_1e

    .line 473
    invoke-virtual {p2}, Landroid/bluetooth/BluetoothGattCharacteristic;->getUuid()Ljava/util/UUID;

    move-result-object p1

    new-instance p2, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "本地通知启用失败："

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    :cond_1e
    return-void
.end method

.method private final enqueueNeighborhood(II)V
    .registers 4

    const/4 v0, 0x0

    .line 546
    invoke-direct {p0, p1, p2, v0}, Lcom/example/bleconnectse/BleTileClient;->enqueueNeighborhood(IIZ)V

    return-void
.end method

.method private final enqueueNeighborhood(IIZ)V
    .registers 11

    .line 554
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->repository:Lcom/example/bleconnectse/SyntheticTileRepository;

    invoke-virtual {v0, p1, p2}, Lcom/example/bleconnectse/SyntheticTileRepository;->neighborhood(II)Ljava/util/List;

    move-result-object v0

    .line 555
    check-cast v0, Ljava/lang/Iterable;

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    check-cast v1, Ljava/util/Set;

    check-cast v1, Ljava/util/Collection;

    .line 903
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_15
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2d

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .line 904
    check-cast v3, Lcom/example/bleconnectse/SyntheticTile;

    .line 555
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    .line 904
    invoke-interface {v1, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_15

    .line 555
    :cond_2d
    check-cast v1, Ljava/util/Set;

    if-eqz p3, :cond_4b

    .line 556
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->neighborhoodTileIds:Ljava/util/Set;

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4b

    .line 557
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    if-nez v2, :cond_47

    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_4b

    .line 562
    :cond_47
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->pumpTransfer()V

    return-void

    :cond_4b
    if-nez p3, :cond_59

    .line 565
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->neighborhoodTileIds:Ljava/util/Set;

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_59

    .line 566
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->pumpTransfer()V

    return-void

    .line 569
    :cond_59
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    check-cast v2, Ljava/lang/Iterable;

    .line 906
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .line 907
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_68
    :goto_68
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_87

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v5, v4

    check-cast v5, Lcom/example/bleconnectse/SyntheticTile;

    .line 569
    invoke-virtual {v5}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v1, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_68

    .line 907
    invoke-interface {v3, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_68

    .line 908
    :cond_87
    check-cast v3, Ljava/util/List;

    .line 570
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    if-nez p3, :cond_97

    .line 571
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    check-cast v3, Ljava/util/Collection;

    invoke-virtual {v2, v3}, Ljava/util/ArrayDeque;->addAll(Ljava/util/Collection;)Z

    .line 572
    :cond_97
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileIds:Ljava/util/Set;

    move-object v3, v1

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v2, v3}, Ljava/util/Set;->retainAll(Ljava/util/Collection;)Z

    .line 573
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileIds:Ljava/util/Set;

    invoke-interface {v2, v3}, Ljava/util/Set;->retainAll(Ljava/util/Collection;)Z

    const/4 v2, 0x0

    if-eqz p3, :cond_e2

    .line 575
    iget-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileIds:Ljava/util/Set;

    invoke-interface {p3}, Ljava/util/Set;->clear()V

    .line 576
    iget-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileIds:Ljava/util/Set;

    invoke-interface {p3, v3}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z

    .line 577
    iget-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    if-eqz p3, :cond_c5

    .line 578
    iget-wide v3, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    const-wide/16 v5, 0x1

    add-long/2addr v3, v5

    iput-wide v3, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    .line 579
    iput-boolean v2, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    const/4 p3, 0x0

    .line 580
    iput-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    .line 581
    iput v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeOffset:I

    .line 582
    iput v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeSequence:I

    .line 584
    :cond_c5
    new-instance p3, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "仪表请求完整刷新3×3区域："

    invoke-direct {p3, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p3, ","

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    .line 586
    :cond_e2
    iput-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->neighborhoodTileIds:Ljava/util/Set;

    .line 909
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_e8
    :goto_e8
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_12b

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/example/bleconnectse/SyntheticTile;

    .line 588
    iget-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileIds:Ljava/util/Set;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p3, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_e8

    iget-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileIds:Ljava/util/Set;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p3, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_e8

    .line 589
    iget-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    check-cast p3, Ljava/util/Collection;

    invoke-interface {p3, p2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 590
    iget-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileIds:Ljava/util/Set;

    check-cast p3, Ljava/util/Collection;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result p2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-interface {p3, p2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_e8

    .line 593
    :cond_12b
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    invoke-virtual {p1}, Ljava/util/ArrayDeque;->size()I

    move-result p1

    iget-object p2, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    if-eqz p2, :cond_136

    const/4 v2, 0x1

    :cond_136
    add-int/2addr p1, v2

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setQueuedTileCount(I)V

    .line 594
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->pumpTransfer()V

    return-void
.end method

.method private final failTransport(Ljava/lang/String;)V
    .registers 3

    const/4 v0, 0x0

    .line 776
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    .line 777
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 778
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    return-void
.end method

.method private final finishTransportReady()V
    .registers 3

    .line 539
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    .line 540
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    .line 541
    const-string v0, "BLE瓦片通道就绪，正在发送车辆周围瓦片"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 542
    iget v0, p0, Lcom/example/bleconnectse/BleTileClient;->desiredCenterTileX:I

    iget v1, p0, Lcom/example/bleconnectse/BleTileClient;->desiredCenterTileY:I

    invoke-direct {p0, v0, v1}, Lcom/example/bleconnectse/BleTileClient;->enqueueNeighborhood(II)V

    return-void
.end method

.method private final getBluetoothAdapter()Landroid/bluetooth/BluetoothAdapter;
    .registers 1

    .line 74
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothManager:Landroid/bluetooth/BluetoothManager;

    if-eqz p0, :cond_9

    invoke-virtual {p0}, Landroid/bluetooth/BluetoothManager;->getAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object p0

    return-object p0

    :cond_9
    const/4 p0, 0x0

    return-object p0
.end method

.method private final handleConnectionState(Landroid/bluetooth/BluetoothGatt;II)V
    .registers 6

    .line 384
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    if-eq p1, v0, :cond_8

    .line 385
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothGatt;->close()V

    return-void

    :cond_8
    const/4 v0, 0x2

    const/4 v1, 0x0

    if-ne p3, v0, :cond_51

    if-nez p2, :cond_51

    .line 389
    iput-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->connecting:Z

    const/4 p2, 0x1

    .line 390
    invoke-direct {p0, p2}, Lcom/example/bleconnectse/BleTileClient;->setConnected(Z)V

    .line 391
    iput v1, p0, Lcom/example/bleconnectse/BleTileClient;->reconnectAttempts:I

    .line 392
    iput-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->reconnectScheduled:Z

    .line 393
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->lastTransferProgressAtMs:J

    .line 394
    const-string p3, "BLE已连接，正在协商传输参数"

    invoke-direct {p0, p3}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 395
    invoke-virtual {p1, p2}, Landroid/bluetooth/BluetoothGatt;->requestConnectionPriority(I)Z

    move-result p2

    if-nez p2, :cond_2e

    .line 398
    const-string p2, "BLE高连接优先级请求未接受，继续使用默认参数"

    invoke-direct {p0, p2}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    :cond_2e
    const/16 p2, 0x205

    .line 399
    invoke-virtual {p1, p2}, Landroid/bluetooth/BluetoothGatt;->requestMtu(I)Z

    move-result p2

    if-nez p2, :cond_44

    .line 401
    const-string p2, "BLE MTU请求未接受，继续使用默认MTU 23"

    invoke-direct {p0, p2}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    const/16 p2, 0x17

    .line 402
    invoke-direct {p0, p2}, Lcom/example/bleconnectse/BleTileClient;->setNegotiatedMtu(I)V

    .line 403
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->discoverServicesOnce(Landroid/bluetooth/BluetoothGatt;)V

    return-void

    .line 405
    :cond_44
    iget-object p2, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    new-instance p3, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda4;

    invoke-direct {p3, p0, p1}, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda4;-><init>(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;)V

    const-wide/16 p0, 0x5dc

    invoke-virtual {p2, p3, p0, p1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_51
    if-nez p3, :cond_97

    .line 408
    iput-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->connecting:Z

    .line 409
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/BleTileClient;->setConnected(Z)V

    .line 410
    iput-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    .line 411
    iput-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    if-nez p2, :cond_61

    .line 413
    const-string p3, "BLE已断开"

    goto :goto_70

    .line 415
    :cond_61
    new-instance p3, Ljava/lang/StringBuilder;

    const-string v0, "BLE连接断开：状态"

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    .line 412
    :goto_70
    invoke-direct {p0, p3}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 417
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getStatus()Ljava/lang/String;

    move-result-object p3

    invoke-direct {p0, p3}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    .line 418
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothGatt;->close()V

    .line 419
    iget-object p3, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    if-ne p1, p3, :cond_84

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    .line 420
    :cond_84
    new-instance p1, Ljava/lang/StringBuilder;

    const-string/jumbo p3, "连接状态="

    invoke-direct {p1, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->scheduleReconnect(Ljava/lang/String;)V

    :cond_97
    return-void
.end method

.method static final handleConnectionState$lambda$7(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;)V
    .registers 2

    .line 405
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->discoverServicesOnce(Landroid/bluetooth/BluetoothGatt;)V

    return-void
.end method

.method private final handleControlWritten(I)V
    .registers 4

    if-eqz p1, :cond_16

    .line 523
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "仪表拒绝BLE瓦片模式："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->failTransport(Ljava/lang/String;)V

    return-void

    .line 526
    :cond_16
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    if-eqz p1, :cond_35

    invoke-virtual {p1}, Landroid/bluetooth/BluetoothGatt;->getDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object p1

    if-eqz p1, :cond_35

    invoke-virtual {p1}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_35

    .line 527
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "ble_tile_device"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 529
    :cond_35
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    if-nez p1, :cond_3a

    return-void

    .line 530
    :cond_3a
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->descriptorQueue:Ljava/util/ArrayDeque;

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_4d

    .line 531
    const-string v0, "BLE瓦片协议已启动，正在订阅仪表校验状态"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 532
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->writeNextDescriptor(Landroid/bluetooth/BluetoothGatt;)V

    return-void

    .line 534
    :cond_4d
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->finishTransportReady()V

    return-void
.end method

.method private final handleDataWritten(I)V
    .registers 2

    return-void
.end method

.method private final handleNoResponsePacketSubmitted(J)V
    .registers 5

    .line 654
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    if-eqz v0, :cond_15

    iget-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    cmp-long p1, p1, v0

    if-nez p1, :cond_15

    iget-boolean p1, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    if-nez p1, :cond_f

    goto :goto_15

    :cond_f
    const/4 p1, 0x0

    .line 655
    iput-boolean p1, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    .line 656
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->completeCurrentPacket()V

    :cond_15
    :goto_15
    return-void
.end method

.method private final handleNotification(Ljava/util/UUID;[B)V
    .registers 6

    .line 699
    array-length v0, p2

    const/4 v1, 0x2

    if-lt v0, v1, :cond_5f

    const/4 v0, 0x0

    aget-byte v0, p2, v0

    const/4 v2, 0x1

    if-eq v0, v2, :cond_b

    goto :goto_5f

    .line 701
    :cond_b
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->STATUS_UUID:Ljava/util/UUID;

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54

    .line 702
    aget-byte p1, p2, v2

    const/16 v0, 0x10

    if-ne p1, v0, :cond_5f

    array-length p1, p2

    const/4 v0, 0x4

    if-lt p1, v0, :cond_5f

    .line 703
    aget-byte p1, p2, v1

    and-int/lit16 p1, p1, 0xff

    const/4 v0, 0x3

    .line 704
    aget-byte p2, p2, v0

    and-int/lit16 p2, p2, 0xff

    .line 705
    iput-boolean v2, p0, Lcom/example/bleconnectse/BleTileClient;->instrumentControlsDemand:Z

    .line 706
    iput p1, p0, Lcom/example/bleconnectse/BleTileClient;->desiredCenterTileX:I

    .line 707
    iput p2, p0, Lcom/example/bleconnectse/BleTileClient;->desiredCenterTileY:I

    .line 708
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "仪表请求前方瓦片 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ","

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "，检查3×3缓存"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 712
    invoke-direct {p0, p1, p2, v2}, Lcom/example/bleconnectse/BleTileClient;->enqueueNeighborhood(IIZ)V

    return-void

    .line 716
    :cond_54
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->RESULT_UUID:Ljava/util/UUID;

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5f

    invoke-direct {p0, p2}, Lcom/example/bleconnectse/BleTileClient;->handleTileResult([B)V

    :cond_5f
    :goto_5f
    return-void
.end method

.method private final handleServicesDiscovered(Landroid/bluetooth/BluetoothGatt;I)V
    .registers 9

    if-eqz p2, :cond_15

    .line 434
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "BLE服务发现失败："

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->failTransport(Ljava/lang/String;)V

    return-void

    .line 437
    :cond_15
    sget-object p2, Lcom/example/bleconnectse/BleTileClient;->SERVICE_UUID:Ljava/util/UUID;

    invoke-virtual {p1, p2}, Landroid/bluetooth/BluetoothGatt;->getService(Ljava/util/UUID;)Landroid/bluetooth/BluetoothGattService;

    move-result-object p2

    if-nez p2, :cond_27

    move-object p1, p0

    check-cast p1, Lcom/example/bleconnectse/BleTileClient;

    .line 438
    const-string/jumbo p1, "仪表未提供BLE瓦片服务；请等待ESP32端升级"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->failTransport(Ljava/lang/String;)V

    return-void

    .line 441
    :cond_27
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->CONTROL_UUID:Ljava/util/UUID;

    invoke-virtual {p2, v0}, Landroid/bluetooth/BluetoothGattService;->getCharacteristic(Ljava/util/UUID;)Landroid/bluetooth/BluetoothGattCharacteristic;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->controlCharacteristic:Landroid/bluetooth/BluetoothGattCharacteristic;

    .line 442
    sget-object v0, Lcom/example/bleconnectse/BleTileClient;->DATA_UUID:Ljava/util/UUID;

    invoke-virtual {p2, v0}, Landroid/bluetooth/BluetoothGattService;->getCharacteristic(Ljava/util/UUID;)Landroid/bluetooth/BluetoothGattCharacteristic;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->dataCharacteristic:Landroid/bluetooth/BluetoothGattCharacteristic;

    .line 443
    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->controlCharacteristic:Landroid/bluetooth/BluetoothGattCharacteristic;

    if-eqz v1, :cond_9c

    if-nez v0, :cond_3e

    goto :goto_9c

    .line 447
    :cond_3e
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->descriptorQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    const/4 v0, 0x2

    .line 449
    new-array v0, v0, [Landroid/bluetooth/BluetoothGattCharacteristic;

    sget-object v1, Lcom/example/bleconnectse/BleTileClient;->STATUS_UUID:Ljava/util/UUID;

    invoke-virtual {p2, v1}, Landroid/bluetooth/BluetoothGattService;->getCharacteristic(Ljava/util/UUID;)Landroid/bluetooth/BluetoothGattCharacteristic;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    .line 450
    sget-object v1, Lcom/example/bleconnectse/BleTileClient;->RESULT_UUID:Ljava/util/UUID;

    invoke-virtual {p2, v1}, Landroid/bluetooth/BluetoothGattService;->getCharacteristic(Ljava/util/UUID;)Landroid/bluetooth/BluetoothGattCharacteristic;

    move-result-object p2

    const/4 v1, 0x1

    aput-object p2, v0, v1

    .line 448
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p2

    check-cast p2, Ljava/lang/Iterable;

    .line 901
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_62
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_98

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/bluetooth/BluetoothGattCharacteristic;

    .line 452
    sget-object v3, Lcom/example/bleconnectse/BleTileClient;->CLIENT_CONFIG_UUID:Ljava/util/UUID;

    invoke-virtual {v0, v3}, Landroid/bluetooth/BluetoothGattCharacteristic;->getDescriptor(Ljava/util/UUID;)Landroid/bluetooth/BluetoothGattDescriptor;

    move-result-object v3

    if-nez v3, :cond_77

    goto :goto_62

    .line 453
    :cond_77
    invoke-virtual {v0}, Landroid/bluetooth/BluetoothGattCharacteristic;->getProperties()I

    move-result v4

    and-int/lit8 v4, v4, 0x20

    if-eqz v4, :cond_81

    move v4, v1

    goto :goto_82

    :cond_81
    move v4, v2

    .line 454
    :goto_82
    iget-object v5, p0, Lcom/example/bleconnectse/BleTileClient;->descriptorQueue:Ljava/util/ArrayDeque;

    check-cast v5, Ljava/util/Collection;

    if-eqz v4, :cond_8b

    .line 455
    sget-object v4, Landroid/bluetooth/BluetoothGattDescriptor;->ENABLE_INDICATION_VALUE:[B

    goto :goto_8d

    .line 457
    :cond_8b
    sget-object v4, Landroid/bluetooth/BluetoothGattDescriptor;->ENABLE_NOTIFICATION_VALUE:[B

    .line 454
    :goto_8d
    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    invoke-interface {v5, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 459
    invoke-direct {p0, p1, v0}, Lcom/example/bleconnectse/BleTileClient;->enableLocalNotification(Landroid/bluetooth/BluetoothGatt;Landroid/bluetooth/BluetoothGattCharacteristic;)V

    goto :goto_62

    .line 464
    :cond_98
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->writeControlPacket(Landroid/bluetooth/BluetoothGatt;)V

    return-void

    .line 444
    :cond_9c
    :goto_9c
    const-string p1, "BLE瓦片服务缺少控制或数据特征"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->failTransport(Ljava/lang/String;)V

    return-void
.end method

.method private final handleTileResult([B)V
    .registers 6

    .line 721
    array-length v0, p1

    const/4 v1, 0x4

    if-ge v0, v1, :cond_5

    goto :goto_17

    :cond_5
    const/4 v0, 0x1

    .line 722
    aget-byte v1, p1, v0

    and-int/lit16 v1, v1, 0xff

    const/4 v2, 0x2

    .line 723
    invoke-direct {p0, p1, v2}, Lcom/example/bleconnectse/BleTileClient;->readUInt16Le([BI)I

    move-result p1

    const/16 v2, 0x20

    if-eq v1, v2, :cond_93

    const/16 v0, 0x21

    if-eq v1, v0, :cond_18

    :goto_17
    return-void

    .line 728
    :cond_18
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    if-eqz v0, :cond_33

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v0

    if-ne v0, p1, :cond_33

    .line 729
    iget-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    const/4 v0, 0x0

    .line 730
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    const/4 v1, 0x0

    .line 731
    iput-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    .line 732
    iput v0, p0, Lcom/example/bleconnectse/BleTileClient;->activeOffset:I

    .line 733
    iput v0, p0, Lcom/example/bleconnectse/BleTileClient;->activeSequence:I

    .line 735
    :cond_33
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileIds:Ljava/util/Set;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 736
    rem-int/lit8 v0, p1, 0x8

    .line 737
    div-int/lit8 v1, p1, 0x8

    .line 738
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->repository:Lcom/example/bleconnectse/SyntheticTileRepository;

    invoke-virtual {v2, v0, v1}, Lcom/example/bleconnectse/SyntheticTileRepository;->tile(II)Lcom/example/bleconnectse/SyntheticTile;

    move-result-object v0

    if-eqz v0, :cond_6c

    .line 739
    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileIds:Ljava/util/Set;

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6c

    .line 740
    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v1, v0}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    .line 741
    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileIds:Ljava/util/Set;

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v1, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 744
    :cond_6c
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "仪表校验失败：瓦片"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v0, "，准备重发"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 745
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    new-instance v0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/BleTileClient;)V

    const-wide/16 v1, 0x28

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 725
    :cond_93
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getAcknowledgedTileCount()I

    move-result v1

    add-int/2addr v1, v0

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/BleTileClient;->setAcknowledgedTileCount(I)V

    .line 726
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getAcknowledgedTileCount()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "仪表校验成功：瓦片"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v1, "，共确认"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v0, "块"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    return-void
.end method

.method private final logStatus(Ljava/lang/String;)V
    .registers 3

    .line 839
    const-string v0, "BleTileClient"

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 840
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->logger:Lkotlin/jvm/functions/Function1;

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private final pumpTransfer()V
    .registers 12

    .line 598
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    if-eqz v0, :cond_d6

    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    if-eqz v0, :cond_a

    goto/16 :goto_d6

    .line 599
    :cond_a
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    if-nez v0, :cond_10

    goto/16 :goto_d6

    .line 600
    :cond_10
    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->dataCharacteristic:Landroid/bluetooth/BluetoothGattCharacteristic;

    if-nez v1, :cond_16

    goto/16 :goto_d6

    .line 601
    :cond_16
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v2, :cond_58

    .line 602
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_26

    const/4 v2, 0x0

    goto :goto_2e

    :cond_26
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/example/bleconnectse/SyntheticTile;

    :goto_2e
    iput-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    if-eqz v2, :cond_3f

    .line 603
    iget-object v5, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileIds:Ljava/util/Set;

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v5, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 604
    :cond_3f
    iput v4, p0, Lcom/example/bleconnectse/BleTileClient;->activeOffset:I

    .line 605
    iput v4, p0, Lcom/example/bleconnectse/BleTileClient;->activeSequence:I

    const/4 v2, 0x0

    .line 606
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/BleTileClient;->setProgress(F)V

    .line 607
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->transferQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->size()I

    move-result v2

    iget-object v5, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    if-eqz v5, :cond_53

    move v5, v3

    goto :goto_54

    :cond_53
    move v5, v4

    :goto_54
    add-int/2addr v2, v5

    invoke-direct {p0, v2}, Lcom/example/bleconnectse/BleTileClient;->setQueuedTileCount(I)V

    .line 609
    :cond_58
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->activeTile:Lcom/example/bleconnectse/SyntheticTile;

    if-nez v2, :cond_65

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/BleTileClient;

    .line 610
    const-string v0, "BLE瓦片发送完成，等待仪表校验"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    return-void

    .line 613
    :cond_65
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getNegotiatedMtu()I

    move-result v5

    add-int/lit8 v5, v5, -0xd

    invoke-static {v5, v3}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v5

    .line 614
    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticTile;->getBytes()[B

    move-result-object v6

    array-length v6, v6

    iget v7, p0, Lcom/example/bleconnectse/BleTileClient;->activeOffset:I

    sub-int/2addr v6, v7

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v5

    add-int/lit8 v6, v5, 0xa

    .line 615
    new-array v6, v6, [B

    .line 616
    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticTile;->getTileId()I

    move-result v7

    invoke-direct {p0, v6, v4, v7}, Lcom/example/bleconnectse/BleTileClient;->writeUInt16Le([BII)V

    const/4 v7, 0x2

    .line 617
    iget v8, p0, Lcom/example/bleconnectse/BleTileClient;->activeSequence:I

    invoke-direct {p0, v6, v7, v8}, Lcom/example/bleconnectse/BleTileClient;->writeUInt16Le([BII)V

    .line 618
    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticTile;->getBytes()[B

    move-result-object v7

    array-length v7, v7

    const/4 v8, 0x4

    invoke-direct {p0, v6, v8, v7}, Lcom/example/bleconnectse/BleTileClient;->writeUInt16Le([BII)V

    const/4 v7, 0x6

    .line 619
    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticTile;->getCrc32()J

    move-result-wide v8

    invoke-direct {p0, v6, v7, v8, v9}, Lcom/example/bleconnectse/BleTileClient;->writeUInt32Le([BIJ)V

    .line 620
    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticTile;->getBytes()[B

    move-result-object v2

    .line 623
    iget v7, p0, Lcom/example/bleconnectse/BleTileClient;->activeOffset:I

    add-int v8, v7, v5

    const/16 v9, 0xa

    .line 620
    invoke-static {v2, v6, v9, v7, v8}, Lkotlin/collections/ArraysKt;->copyInto([B[BIII)[B

    .line 626
    iput v5, p0, Lcom/example/bleconnectse/BleTileClient;->pendingPayloadSize:I

    .line 627
    iput-boolean v3, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    .line 628
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7

    iput-wide v7, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteStartedAtMs:J

    .line 629
    iget-wide v7, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    const-wide/16 v9, 0x1

    add-long/2addr v7, v9

    iput-wide v7, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    .line 635
    invoke-direct {p0, v0, v1, v6, v3}, Lcom/example/bleconnectse/BleTileClient;->writeCharacteristic(Landroid/bluetooth/BluetoothGatt;Landroid/bluetooth/BluetoothGattCharacteristic;[BI)Z

    move-result v0

    if-nez v0, :cond_ca

    .line 636
    iput-boolean v4, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    .line 637
    const-string/jumbo v0, "手机BLE写队列忙"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->retryOrFailCurrentPacket(Ljava/lang/String;)V

    return-void

    .line 639
    :cond_ca
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    new-instance v1, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, v7, v8}, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda0;-><init>(Lcom/example/bleconnectse/BleTileClient;J)V

    const-wide/16 v2, 0x12

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_d6
    :goto_d6
    return-void
.end method

.method static final pumpTransfer$lambda$16(Lcom/example/bleconnectse/BleTileClient;J)V
    .registers 3

    .line 640
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/BleTileClient;->handleNoResponsePacketSubmitted(J)V

    return-void
.end method

.method private final readUInt16Le([BI)I
    .registers 3

    .line 855
    aget-byte p0, p1, p2

    and-int/lit16 p0, p0, 0xff

    add-int/lit8 p2, p2, 0x1

    .line 856
    aget-byte p1, p1, p2

    and-int/lit16 p1, p1, 0xff

    shl-int/lit8 p1, p1, 0x8

    or-int/2addr p0, p1

    return p0
.end method

.method private final recoverGattConnection()V
    .registers 5

    const/4 v0, 0x0

    .line 751
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    .line 752
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setConnected(Z)V

    .line 753
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->connecting:Z

    .line 754
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->writeInFlight:Z

    .line 755
    iget-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lcom/example/bleconnectse/BleTileClient;->dataWriteGeneration:J

    .line 756
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->bluetoothGatt:Landroid/bluetooth/BluetoothGatt;

    if-eqz v0, :cond_32

    :try_start_15
    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v1, p0

    check-cast v1, Lcom/example/bleconnectse/BleTileClient;

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothGatt;->disconnect()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_23
    .catchall {:try_start_15 .. :try_end_23} :catchall_24

    goto :goto_2f

    :catchall_24
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_2f
    invoke-static {v0}, Lkotlin/Result;->box-impl(Ljava/lang/Object;)Lkotlin/Result;

    .line 757
    :cond_32
    const-string/jumbo v0, "传输看门狗"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->scheduleReconnect(Ljava/lang/String;)V

    return-void
.end method

.method private final retryOrFailCurrentPacket(Ljava/lang/String;)V
    .registers 5

    .line 686
    iget v0, p0, Lcom/example/bleconnectse/BleTileClient;->writeRetries:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/example/bleconnectse/BleTileClient;->writeRetries:I

    const/16 v1, 0x14

    if-gt v0, v1, :cond_38

    .line 688
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v1, "，重试"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, "/20"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 689
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    new-instance v0, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/BleTileClient;)V

    const-wide/16 v1, 0x28

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_38
    const/4 v0, 0x0

    .line 691
    iput v0, p0, Lcom/example/bleconnectse/BleTileClient;->writeRetries:I

    .line 692
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v0, "，BLE栈持续无响应，正在自动恢复连接"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 693
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getStatus()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    .line 694
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->recoverGattConnection()V

    return-void
.end method

.method static final scanTimeout$lambda$0(Lcom/example/bleconnectse/BleTileClient;)V
    .registers 2

    .line 162
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getScanning()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    .line 163
    :cond_7
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->stopScanInternal()V

    .line 164
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->candidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    invoke-virtual {v0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_16

    .line 165
    const-string/jumbo v0, "未发现BLE瓦片仪表；当前ESP固件尚未提供该服务"

    goto :goto_19

    .line 167
    :cond_16
    const-string/jumbo v0, "扫描完成，请选择准确的仪表设备"

    .line 164
    :goto_19
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    return-void
.end method

.method private final scheduleReconnect(Ljava/lang/String;)V
    .registers 7

    .line 761
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->desiredDeviceAddress:Ljava/lang/String;

    if-nez v0, :cond_5

    goto :goto_50

    .line 762
    :cond_5
    iget-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->keepConnectionAlive:Z

    if-eqz v1, :cond_50

    iget-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->closed:Z

    if-nez v1, :cond_50

    iget-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->reconnectScheduled:Z

    if-eqz v1, :cond_12

    goto :goto_50

    :cond_12
    const/4 v1, 0x1

    .line 763
    iput-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->reconnectScheduled:Z

    .line 764
    iget v2, p0, Lcom/example/bleconnectse/BleTileClient;->reconnectAttempts:I

    add-int/2addr v2, v1

    iput v2, p0, Lcom/example/bleconnectse/BleTileClient;->reconnectAttempts:I

    const/4 v1, 0x5

    .line 765
    invoke-static {v2, v1}, Lkotlin/ranges/RangesKt;->coerceAtMost(II)I

    move-result v1

    int-to-long v1, v1

    const-wide/16 v3, 0x3e8

    mul-long/2addr v1, v3

    .line 766
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "BLE链路需要恢复："

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v3, "，"

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v3, "ms后重连"

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    .line 767
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    new-instance v3, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda3;

    invoke-direct {v3, p0, v0}, Lcom/example/bleconnectse/BleTileClient$$ExternalSyntheticLambda3;-><init>(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V

    invoke-virtual {p1, v3, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_50
    :goto_50
    return-void
.end method

.method static final scheduleReconnect$lambda$20(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V
    .registers 3

    const/4 v0, 0x0

    .line 768
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->reconnectScheduled:Z

    .line 769
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->closed:Z

    if-nez v0, :cond_14

    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->keepConnectionAlive:Z

    if-eqz v0, :cond_14

    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getConnected()Z

    move-result v0

    if-nez v0, :cond_14

    .line 770
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->connectInternal(Ljava/lang/String;)V

    :cond_14
    return-void
.end method

.method private final setAcknowledgedTileCount(I)V
    .registers 2

    .line 100
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->acknowledgedTileCount$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    .line 887
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setConnected(Z)V
    .registers 2

    .line 86
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->connected$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 866
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setConnectedName(Ljava/lang/String;)V
    .registers 2

    .line 88
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->connectedName$delegate:Landroidx/compose/runtime/MutableState;

    .line 869
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setNegotiatedMtu(I)V
    .registers 2

    .line 90
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->negotiatedMtu$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    .line 872
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setProgress(F)V
    .registers 2

    .line 92
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->progress$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    .line 875
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setQueuedTileCount(I)V
    .registers 2

    .line 96
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileCount$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    .line 881
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setScanning(Z)V
    .registers 2

    .line 84
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->scanning$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 863
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setSentTileCount(I)V
    .registers 2

    .line 98
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileCount$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    .line 884
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setSpeedBytesPerSecond(J)V
    .registers 3

    .line 94
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->speedBytesPerSecond$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    .line 878
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setStatus(Ljava/lang/String;)V
    .registers 2

    .line 82
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->status$delegate:Landroidx/compose/runtime/MutableState;

    .line 860
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final stopScanInternal()V
    .registers 3

    .line 800
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getScanning()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    .line 801
    :cond_7
    :try_start_7
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/BleTileClient;

    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->getBluetoothAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    if-eqz v0, :cond_22

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothAdapter;->getBluetoothLeScanner()Landroid/bluetooth/le/BluetoothLeScanner;

    move-result-object v0

    if-eqz v0, :cond_22

    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->scanCallback:Lcom/example/bleconnectse/BleTileClient$scanCallback$1;

    check-cast v1, Landroid/bluetooth/le/ScanCallback;

    invoke-virtual {v0, v1}, Landroid/bluetooth/le/BluetoothLeScanner;->stopScan(Landroid/bluetooth/le/ScanCallback;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_23

    :cond_22
    const/4 v0, 0x0

    :goto_23
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_26
    .catchall {:try_start_7 .. :try_end_26} :catchall_27

    goto :goto_31

    :catchall_27
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_31
    const/4 v0, 0x0

    .line 802
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->setScanning(Z)V

    .line 803
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->scanTimeout:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    return-void
.end method

.method private final writeCharacteristic(Landroid/bluetooth/BluetoothGatt;Landroid/bluetooth/BluetoothGattCharacteristic;[BI)Z
    .registers 6

    .line 787
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x21

    if-lt p0, v0, :cond_10

    .line 788
    invoke-virtual {p1, p2, p3, p4}, Landroid/bluetooth/BluetoothGatt;->writeCharacteristic(Landroid/bluetooth/BluetoothGattCharacteristic;[BI)I

    move-result p0

    if-nez p0, :cond_e

    const/4 p0, 0x1

    return p0

    :cond_e
    const/4 p0, 0x0

    return p0

    .line 791
    :cond_10
    invoke-virtual {p2, p4}, Landroid/bluetooth/BluetoothGattCharacteristic;->setWriteType(I)V

    .line 793
    invoke-virtual {p2, p3}, Landroid/bluetooth/BluetoothGattCharacteristic;->setValue([B)Z

    .line 795
    invoke-virtual {p1, p2}, Landroid/bluetooth/BluetoothGatt;->writeCharacteristic(Landroid/bluetooth/BluetoothGattCharacteristic;)Z

    move-result p0

    return p0
.end method

.method private final writeControlPacket(Landroid/bluetooth/BluetoothGatt;)V
    .registers 7

    .line 502
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->controlCharacteristic:Landroid/bluetooth/BluetoothGattCharacteristic;

    if-nez v0, :cond_5

    goto :goto_45

    :cond_5
    const/16 v1, 0xc

    .line 503
    new-array v1, v1, [B

    const/4 v2, 0x0

    const/16 v3, 0x42

    .line 504
    aput-byte v3, v1, v2

    const/16 v2, 0x4d

    const/4 v3, 0x1

    .line 505
    aput-byte v2, v1, v3

    const/4 v2, 0x2

    .line 506
    aput-byte v3, v1, v2

    .line 507
    iget-object v3, p0, Lcom/example/bleconnectse/BleTileClient;->source:Lcom/example/bleconnectse/BleTileSource;

    invoke-virtual {v3}, Lcom/example/bleconnectse/BleTileSource;->getWireValue()I

    move-result v3

    int-to-byte v3, v3

    const/4 v4, 0x3

    aput-byte v3, v1, v4

    const/4 v3, 0x4

    const/16 v4, 0x1900

    .line 508
    invoke-direct {p0, v1, v3, v4}, Lcom/example/bleconnectse/BleTileClient;->writeUInt16Le([BII)V

    const/4 v3, 0x6

    const/16 v4, 0x960

    .line 509
    invoke-direct {p0, v1, v3, v4}, Lcom/example/bleconnectse/BleTileClient;->writeUInt16Le([BII)V

    const/16 v3, 0x8

    const/16 v4, 0x320

    .line 510
    invoke-direct {p0, v1, v3, v4}, Lcom/example/bleconnectse/BleTileClient;->writeUInt16Le([BII)V

    const/16 v3, 0xa

    const/16 v4, 0x1e0

    .line 511
    invoke-direct {p0, v1, v3, v4}, Lcom/example/bleconnectse/BleTileClient;->writeUInt16Le([BII)V

    .line 512
    invoke-direct {p0, p1, v0, v1, v2}, Lcom/example/bleconnectse/BleTileClient;->writeCharacteristic(Landroid/bluetooth/BluetoothGatt;Landroid/bluetooth/BluetoothGattCharacteristic;[BI)Z

    move-result p1

    if-nez p1, :cond_45

    .line 518
    const-string p1, "BLE瓦片模式启动命令发送失败"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->failTransport(Ljava/lang/String;)V

    :cond_45
    :goto_45
    return-void
.end method

.method private final writeNextDescriptor(Landroid/bluetooth/BluetoothGatt;)V
    .registers 6

    .line 479
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->descriptorQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 v0, 0x0

    goto :goto_12

    :cond_a
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->descriptorQueue:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkotlin/Pair;

    :goto_12
    if-nez v0, :cond_18

    .line 481
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->finishTransportReady()V

    return-void

    .line 484
    :cond_18
    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/bluetooth/BluetoothGattDescriptor;

    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    .line 485
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x21

    if-lt v2, v3, :cond_34

    .line 486
    invoke-virtual {p1, v1, v0}, Landroid/bluetooth/BluetoothGatt;->writeDescriptor(Landroid/bluetooth/BluetoothGattDescriptor;[B)I

    move-result p1

    if-nez p1, :cond_32

    const/4 p1, 0x1

    goto :goto_3b

    :cond_32
    const/4 p1, 0x0

    goto :goto_3b

    .line 489
    :cond_34
    invoke-virtual {v1, v0}, Landroid/bluetooth/BluetoothGattDescriptor;->setValue([B)Z

    .line 491
    invoke-virtual {p1, v1}, Landroid/bluetooth/BluetoothGatt;->writeDescriptor(Landroid/bluetooth/BluetoothGattDescriptor;)Z

    move-result p1

    :goto_3b
    if-nez p1, :cond_67

    .line 494
    invoke-virtual {v1}, Landroid/bluetooth/BluetoothGattDescriptor;->getCharacteristic()Landroid/bluetooth/BluetoothGattCharacteristic;

    move-result-object p1

    invoke-virtual {p1}, Landroid/bluetooth/BluetoothGattCharacteristic;->getUuid()Ljava/util/UUID;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "无法订阅仪表状态："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v0, "；继续无ACK传输"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    .line 495
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->descriptorQueue:Ljava/util/ArrayDeque;

    invoke-virtual {p1}, Ljava/util/ArrayDeque;->clear()V

    .line 496
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->finishTransportReady()V

    :cond_67
    return-void
.end method

.method private final writeUInt16Le([BII)V
    .registers 4

    and-int/lit16 p0, p3, 0xff

    int-to-byte p0, p0

    .line 844
    aput-byte p0, p1, p2

    add-int/lit8 p2, p2, 0x1

    ushr-int/lit8 p0, p3, 0x8

    and-int/lit16 p0, p0, 0xff

    int-to-byte p0, p0

    .line 845
    aput-byte p0, p1, p2

    return-void
.end method

.method private final writeUInt32Le([BIJ)V
    .registers 10

    const/4 p0, 0x0

    :goto_1
    const/4 v0, 0x4

    if-ge p0, v0, :cond_14

    add-int v0, p2, p0

    mul-int/lit8 v1, p0, 0x8

    ushr-long v1, p3, v1

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    long-to-int v1, v1

    int-to-byte v1, v1

    .line 850
    aput-byte v1, p1, v0

    add-int/lit8 p0, p0, 0x1

    goto :goto_1

    :cond_14
    return-void
.end method


# virtual methods
.method public final close()V
    .registers 4

    .line 356
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->closed:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    .line 357
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->closed:Z

    const/4 v0, 0x0

    .line 358
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->keepConnectionAlive:Z

    const/4 v1, 0x0

    .line 359
    iput-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->desiredDeviceAddress:Ljava/lang/String;

    .line 360
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    invoke-virtual {v2, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 361
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->stopScanInternal()V

    .line 362
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->disconnectInternal(Z)V

    return-void
.end method

.method public final connect(Ljava/lang/String;)V
    .registers 4

    const-string v0, "address"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 297
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->closed:Z

    if-eqz v0, :cond_a

    goto :goto_1d

    .line 298
    :cond_a
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getConnected()Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_15

    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->connecting:Z

    if-eqz v0, :cond_1e

    .line 299
    :cond_15
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->desiredDeviceAddress:Ljava/lang/String;

    invoke-static {v0, p1, v1}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1e

    :goto_1d
    return-void

    .line 303
    :cond_1e
    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->desiredDeviceAddress:Ljava/lang/String;

    .line 304
    iput-boolean v1, p0, Lcom/example/bleconnectse/BleTileClient;->keepConnectionAlive:Z

    const/4 v0, 0x0

    .line 305
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->reconnectScheduled:Z

    .line 306
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->connectInternal(Ljava/lang/String;)V

    return-void
.end method

.method public final disconnect()V
    .registers 3

    const/4 v0, 0x0

    .line 336
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->keepConnectionAlive:Z

    const/4 v1, 0x0

    .line 337
    iput-object v1, p0, Lcom/example/bleconnectse/BleTileClient;->desiredDeviceAddress:Ljava/lang/String;

    .line 338
    iput-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->reconnectScheduled:Z

    .line 339
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->stopScanInternal()V

    const/4 v0, 0x1

    .line 340
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->disconnectInternal(Z)V

    return-void
.end method

.method public final getAcknowledgedTileCount()I
    .registers 1

    .line 100
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->acknowledgedTileCount$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 886
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    return p0
.end method

.method public final getCandidates()Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "Lcom/example/bleconnectse/BleTileDevice;",
            ">;"
        }
    .end annotation

    .line 81
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->candidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    return-object p0
.end method

.method public final getConnected()Z
    .registers 1

    .line 86
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->connected$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 865
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final getConnectedName()Ljava/lang/String;
    .registers 1

    .line 88
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->connectedName$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 868
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public final getNegotiatedMtu()I
    .registers 1

    .line 90
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->negotiatedMtu$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 871
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    return p0
.end method

.method public final getProgress()F
    .registers 1

    .line 92
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->progress$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 874
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    return p0
.end method

.method public final getQueuedTileCount()I
    .registers 1

    .line 96
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->queuedTileCount$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 880
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    return p0
.end method

.method public final getScanning()Z
    .registers 1

    .line 84
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->scanning$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 862
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final getSentTileCount()I
    .registers 1

    .line 98
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->sentTileCount$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 883
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    return p0
.end method

.method public final getSpeedBytesPerSecond()J
    .registers 3

    .line 94
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->speedBytesPerSecond$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 877
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    return-wide v0
.end method

.method public final getStatus()Ljava/lang/String;
    .registers 1

    .line 82
    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient;->status$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 859
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public final startScan(Lcom/example/bleconnectse/BleTileSource;)V
    .registers 7

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 261
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->closed:Z

    if-eqz v0, :cond_a

    return-void

    .line 262
    :cond_a
    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->source:Lcom/example/bleconnectse/BleTileSource;

    const/4 p1, 0x0

    .line 263
    iput-boolean p1, p0, Lcom/example/bleconnectse/BleTileClient;->keepConnectionAlive:Z

    const/4 v0, 0x0

    .line 264
    iput-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->desiredDeviceAddress:Ljava/lang/String;

    .line 265
    iput-boolean p1, p0, Lcom/example/bleconnectse/BleTileClient;->reconnectScheduled:Z

    .line 266
    iput p1, p0, Lcom/example/bleconnectse/BleTileClient;->desiredCenterTileX:I

    .line 267
    iput p1, p0, Lcom/example/bleconnectse/BleTileClient;->desiredCenterTileY:I

    .line 268
    iput-boolean p1, p0, Lcom/example/bleconnectse/BleTileClient;->instrumentControlsDemand:Z

    .line 269
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->disconnectInternal(Z)V

    .line 270
    invoke-direct {p0}, Lcom/example/bleconnectse/BleTileClient;->getBluetoothAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object p1

    if-eqz p1, :cond_27

    .line 271
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothAdapter;->getBluetoothLeScanner()Landroid/bluetooth/le/BluetoothLeScanner;

    move-result-object v0

    :cond_27
    if-eqz p1, :cond_98

    .line 272
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothAdapter;->isEnabled()Z

    move-result p1

    if-nez p1, :cond_30

    goto :goto_98

    :cond_30
    if-nez v0, :cond_39

    .line 277
    const-string/jumbo p1, "当前手机不支持BLE扫描"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    return-void

    .line 280
    :cond_39
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->candidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    invoke-virtual {p1}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    const/4 p1, 0x1

    .line 281
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setScanning(Z)V

    .line 282
    const-string/jumbo p1, "正在扫描BLE瓦片仪表…"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    .line 283
    new-instance p1, Landroid/bluetooth/le/ScanFilter$Builder;

    invoke-direct {p1}, Landroid/bluetooth/le/ScanFilter$Builder;-><init>()V

    .line 284
    new-instance v1, Landroid/os/ParcelUuid;

    sget-object v2, Lcom/example/bleconnectse/BleTileClient;->SERVICE_UUID:Ljava/util/UUID;

    invoke-direct {v1, v2}, Landroid/os/ParcelUuid;-><init>(Ljava/util/UUID;)V

    invoke-virtual {p1, v1}, Landroid/bluetooth/le/ScanFilter$Builder;->setServiceUuid(Landroid/os/ParcelUuid;)Landroid/bluetooth/le/ScanFilter$Builder;

    move-result-object p1

    .line 285
    invoke-virtual {p1}, Landroid/bluetooth/le/ScanFilter$Builder;->build()Landroid/bluetooth/le/ScanFilter;

    move-result-object p1

    .line 286
    new-instance v1, Landroid/bluetooth/le/ScanSettings$Builder;

    invoke-direct {v1}, Landroid/bluetooth/le/ScanSettings$Builder;-><init>()V

    const/4 v3, 0x2

    .line 287
    invoke-virtual {v1, v3}, Landroid/bluetooth/le/ScanSettings$Builder;->setScanMode(I)Landroid/bluetooth/le/ScanSettings$Builder;

    move-result-object v1

    .line 288
    invoke-virtual {v1}, Landroid/bluetooth/le/ScanSettings$Builder;->build()Landroid/bluetooth/le/ScanSettings;

    move-result-object v1

    .line 289
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    iget-object v3, p0, Lcom/example/bleconnectse/BleTileClient;->scanCallback:Lcom/example/bleconnectse/BleTileClient$scanCallback$1;

    check-cast v3, Landroid/bluetooth/le/ScanCallback;

    invoke-virtual {v0, p1, v1, v3}, Landroid/bluetooth/le/BluetoothLeScanner;->startScan(Ljava/util/List;Landroid/bluetooth/le/ScanSettings;Landroid/bluetooth/le/ScanCallback;)V

    .line 290
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->scanTimeout:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 291
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient;->mainHandler:Landroid/os/Handler;

    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient;->scanTimeout:Ljava/lang/Runnable;

    const-wide/16 v3, 0x2710

    invoke-virtual {p1, v0, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 292
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "BLE扫描开始，服务="

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 273
    :cond_98
    :goto_98
    const-string/jumbo p1, "请先打开手机蓝牙"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->setStatus(Ljava/lang/String;)V

    return-void
.end method

.method public final updateVehicleTile(II)V
    .registers 4

    if-ltz p1, :cond_1b

    const/16 v0, 0x8

    if-ge p1, v0, :cond_1b

    if-ltz p2, :cond_1b

    const/4 v0, 0x5

    if-ge p2, v0, :cond_1b

    .line 349
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->instrumentControlsDemand:Z

    if-eqz v0, :cond_10

    goto :goto_1b

    .line 350
    :cond_10
    iput p1, p0, Lcom/example/bleconnectse/BleTileClient;->desiredCenterTileX:I

    .line 351
    iput p2, p0, Lcom/example/bleconnectse/BleTileClient;->desiredCenterTileY:I

    .line 352
    iget-boolean v0, p0, Lcom/example/bleconnectse/BleTileClient;->transportReady:Z

    if-eqz v0, :cond_1b

    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/BleTileClient;->enqueueNeighborhood(II)V

    :cond_1b
    :goto_1b
    return-void
.end method
