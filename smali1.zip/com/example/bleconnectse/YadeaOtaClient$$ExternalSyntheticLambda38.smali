# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$2:Z

.field public final synthetic f$3:Ljava/lang/String;

.field public final synthetic f$4:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(ILcom/example/bleconnectse/YadeaOtaClient;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;->f$0:I

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;->f$1:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-boolean p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;->f$2:Z

    iput-object p4, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;->f$3:Ljava/lang/String;

    iput-object p5, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;->f$4:Lkotlin/jvm/functions/Function0;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;->f$0:I

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;->f$1:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-boolean v2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;->f$2:Z

    iget-object v3, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;->f$3:Ljava/lang/String;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;->f$4:Lkotlin/jvm/functions/Function0;

    invoke-static {v0, v1, v2, v3, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal$finishCleanup$lambda$126(ILcom/example/bleconnectse/YadeaOtaClient;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method
