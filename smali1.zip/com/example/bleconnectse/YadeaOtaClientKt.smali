# classes2.dex

.class public final Lcom/example/bleconnectse/YadeaOtaClientKt;
.super Ljava/lang/Object;
.source "YadeaOtaClient.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0005\n\u0000\u001a\u000e\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u0011\u001a\f\u0010\u0014\u001a\u00020\u0001*\u00020\u0015H\u0002\u001a\u0010\u0010\u0016\u001a\u00020\u00032\u0006\u0010\u0017\u001a\u00020\u0018H\u0002\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0003X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0003X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0005\u001a\u00020\u0003X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0003X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0007\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\b\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\t\u001a\u00020\u0003X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\n\u001a\u00020\u0003X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u000b\u001a\u00020\u0003X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\f\u001a\u00020\u0003X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\r\u001a\u00020\u000eX\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u000f\u001a\u00020\u0003X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0019"
    }
    d2 = {
        "DEFAULT_AP_TARGET_IP",
        "",
        "DEFAULT_TCP_PORT",
        "",
        "DEFAULT_NAV_UDP_PORT",
        "DEFAULT_WALLPAPER_TCP_PORT",
        "DEFAULT_HTTP_PORT",
        "FALLBACK_LOCAL_IP",
        "NO_FIRMWARE_SELECTED",
        "NAV_FALLBACK_WIDTH",
        "NAV_FALLBACK_HEIGHT",
        "NAV_PACKET_SIZE",
        "NAV_CONNECT_RETRY_COUNT",
        "NAV_CONNECT_RETRY_DELAY_MS",
        "",
        "NAV_CONNECT_TIMEOUT_MS",
        "YADEA_WIFI_CMD_RESP",
        "",
        "hex",
        "data",
        "displayLabel",
        "Lcom/example/bleconnectse/MirrorContent;",
        "u",
        "value",
        "",
        "app"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final DEFAULT_AP_TARGET_IP:Ljava/lang/String; = "192.168.7.1"

.field private static final DEFAULT_HTTP_PORT:I = 0x1f90

.field private static final DEFAULT_NAV_UDP_PORT:I = 0x22b9

.field private static final DEFAULT_TCP_PORT:I = 0x22b8

.field private static final DEFAULT_WALLPAPER_TCP_PORT:I = 0x22b0

.field private static final FALLBACK_LOCAL_IP:Ljava/lang/String; = "192.168.7.2"

.field private static final NAV_CONNECT_RETRY_COUNT:I = 0x10

.field private static final NAV_CONNECT_RETRY_DELAY_MS:J = 0xfaL

.field private static final NAV_CONNECT_TIMEOUT_MS:I = 0x2bc

.field private static final NAV_FALLBACK_HEIGHT:I = 0x170

.field private static final NAV_FALLBACK_WIDTH:I = 0x3c0

.field private static final NAV_PACKET_SIZE:I = 0x59a

.field private static final NO_FIRMWARE_SELECTED:Ljava/lang/String; = "未选择升级包"

.field private static final YADEA_WIFI_CMD_RESP:[B


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x7

    .line 78
    new-array v0, v0, [B

    fill-array-data v0, :array_a

    .line 77
    sput-object v0, Lcom/example/bleconnectse/YadeaOtaClientKt;->YADEA_WIFI_CMD_RESP:[B

    return-void

    nop

    :array_a
    .array-data 1
        0x59t
        0x44t
        -0x8t
        0x0t
        -0x8t
        0x4bt
        0x4at
    .end array-data
.end method

.method public static final synthetic access$displayLabel(Lcom/example/bleconnectse/MirrorContent;)Ljava/lang/String;
    .registers 1

    .line 1
    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->displayLabel(Lcom/example/bleconnectse/MirrorContent;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$getYADEA_WIFI_CMD_RESP$p()[B
    .registers 1

    .line 1
    sget-object v0, Lcom/example/bleconnectse/YadeaOtaClientKt;->YADEA_WIFI_CMD_RESP:[B

    return-object v0
.end method

.method public static final synthetic access$u(B)I
    .registers 1

    .line 1
    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->u(B)I

    move-result p0

    return p0
.end method

.method private static final displayLabel(Lcom/example/bleconnectse/MirrorContent;)Ljava/lang/String;
    .registers 2

    .line 2245
    sget-object v0, Lcom/example/bleconnectse/MirrorContent$Demo;->INSTANCE:Lcom/example/bleconnectse/MirrorContent$Demo;

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    const-string/jumbo p0, "地图"

    return-object p0

    .line 2246
    :cond_c
    instance-of v0, p0, Lcom/example/bleconnectse/MirrorContent$Image;

    if-eqz v0, :cond_14

    const-string/jumbo p0, "相册图片"

    return-object p0

    .line 2247
    :cond_14
    instance-of v0, p0, Lcom/example/bleconnectse/MirrorContent$Live;

    if-eqz v0, :cond_1f

    check-cast p0, Lcom/example/bleconnectse/MirrorContent$Live;

    invoke-virtual {p0}, Lcom/example/bleconnectse/MirrorContent$Live;->getSourceName()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 2244
    :cond_1f
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p0
.end method

.method public static final hex([B)Ljava/lang/String;
    .registers 11

    const-string v0, "data"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    const-string v0, " "

    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    new-instance v7, Lcom/example/bleconnectse/YadeaOtaClientKt$$ExternalSyntheticLambda0;

    invoke-direct {v7}, Lcom/example/bleconnectse/YadeaOtaClientKt$$ExternalSyntheticLambda0;-><init>()V

    const/16 v8, 0x1e

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, p0

    invoke-static/range {v1 .. v9}, Lkotlin/collections/ArraysKt;->joinToString$default([BLjava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static final hex$lambda$0(B)Ljava/lang/CharSequence;
    .registers 2

    and-int/lit16 p0, p0, 0xff

    .line 82
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const/4 v0, 0x1

    invoke-static {p0, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const-string v0, "%02x"

    invoke-static {v0, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "format(...)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Ljava/lang/CharSequence;

    return-object p0
.end method

.method private static final u(B)I
    .registers 1

    and-int/lit16 p0, p0, 0xff

    return p0
.end method
