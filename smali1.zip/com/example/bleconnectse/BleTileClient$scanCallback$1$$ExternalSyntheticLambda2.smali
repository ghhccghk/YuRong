# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/BleTileClient;I)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda2;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iput p2, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda2;->f$1:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda2;->f$0:Lcom/example/bleconnectse/BleTileClient;

    iget p0, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda2;->f$1:I

    invoke-static {v0, p0}, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;->onScanFailed$lambda$2(Lcom/example/bleconnectse/BleTileClient;I)V

    return-void
.end method
