# classes2.dex

.class public final Lcom/example/bleconnectse/SimulatedNavigationView;
.super Landroid/view/View;
.source "SimulatedNavigationView.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000i\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t*\u0001 \b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\"\u001a\u00020\u001dJ\u0006\u0010#\u001a\u00020\u001dJ\"\u0010$\u001a\u00020\u001d2\u001a\u0010%\u001a\u0016\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\u001d\u0018\u00010\u001bJ\b\u0010&\u001a\u00020\u001dH\u0014J\b\u0010\'\u001a\u00020\u001dH\u0014J\u0010\u0010(\u001a\u00020\u001d2\u0006\u0010)\u001a\u00020*H\u0014J\u0010\u0010+\u001a\u00020\u000f2\u0006\u0010,\u001a\u00020-H\u0016J\b\u0010.\u001a\u00020\u000fH\u0016J\u0010\u0010/\u001a\u00020\u001d2\u0006\u00100\u001a\u00020\u0017H\u0002J\b\u00101\u001a\u00020\u001dH\u0002J \u00102\u001a\u00020\u001d2\u0006\u0010)\u001a\u00020*2\u0006\u00103\u001a\u00020\u00132\u0006\u00104\u001a\u00020\u0013H\u0002J \u00105\u001a\u00020\u001d2\u0006\u0010)\u001a\u00020*2\u0006\u00103\u001a\u00020\u00132\u0006\u00104\u001a\u00020\u0013H\u0002R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\"\u0010\u001a\u001a\u0016\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\u001d\u0018\u00010\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001cX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001f\u001a\u00020 X\u0082\u0004¢\u0006\u0004\n\u0002\u0010!¨\u00066"
    }
    d2 = {
        "Lcom/example/bleconnectse/SimulatedNavigationView;",
        "Landroid/view/View;",
        "context",
        "Landroid/content/Context;",
        "<init>",
        "(Landroid/content/Context;)V",
        "paint",
        "Landroid/graphics/Paint;",
        "guidancePath",
        "Landroid/graphics/Path;",
        "mapRenderer",
        "Lcom/example/bleconnectse/SyntheticMapRenderer;",
        "frameHandler",
        "Landroid/os/Handler;",
        "publishing",
        "",
        "attached",
        "autoFollow",
        "cameraX",
        "",
        "cameraY",
        "routeDistance",
        "lastAnimationAt",
        "",
        "lastTouchX",
        "lastTouchY",
        "tileDemandListener",
        "Lkotlin/Function2;",
        "",
        "",
        "lastDemandTileId",
        "framePublisher",
        "com/example/bleconnectse/SimulatedNavigationView$framePublisher$1",
        "Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;",
        "startPublishing",
        "stopPublishing",
        "setOnBleTileDemandChanged",
        "listener",
        "onAttachedToWindow",
        "onDetachedFromWindow",
        "onDraw",
        "canvas",
        "Landroid/graphics/Canvas;",
        "onTouchEvent",
        "event",
        "Landroid/view/MotionEvent;",
        "performClick",
        "updateAnimation",
        "now",
        "notifyBleTileDemand",
        "drawNavigation",
        "width",
        "height",
        "drawGuidance",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private attached:Z

.field private autoFollow:Z

.field private cameraX:F

.field private cameraY:F

.field private final frameHandler:Landroid/os/Handler;

.field private final framePublisher:Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;

.field private final guidancePath:Landroid/graphics/Path;

.field private lastAnimationAt:J

.field private lastDemandTileId:I

.field private lastTouchX:F

.field private lastTouchY:F

.field private final mapRenderer:Lcom/example/bleconnectse/SyntheticMapRenderer;

.field private final paint:Landroid/graphics/Paint;

.field private publishing:Z

.field private routeDistance:F

.field private tileDemandListener:Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/Integer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 28
    new-instance p1, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    .line 29
    new-instance p1, Landroid/graphics/Path;

    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    .line 30
    new-instance p1, Lcom/example/bleconnectse/SyntheticMapRenderer;

    invoke-direct {p1}, Lcom/example/bleconnectse/SyntheticMapRenderer;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->mapRenderer:Lcom/example/bleconnectse/SyntheticMapRenderer;

    .line 31
    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {p1, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->frameHandler:Landroid/os/Handler;

    .line 34
    iput-boolean v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->autoFollow:Z

    const/4 p1, -0x1

    .line 42
    iput p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastDemandTileId:I

    .line 44
    new-instance p1, Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;-><init>(Lcom/example/bleconnectse/SimulatedNavigationView;)V

    iput-object p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->framePublisher:Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;

    return-void
.end method

.method public static final synthetic access$drawNavigation(Lcom/example/bleconnectse/SimulatedNavigationView;Landroid/graphics/Canvas;FF)V
    .registers 4

    .line 27
    invoke-direct {p0, p1, p2, p3}, Lcom/example/bleconnectse/SimulatedNavigationView;->drawNavigation(Landroid/graphics/Canvas;FF)V

    return-void
.end method

.method public static final synthetic access$getFrameHandler$p(Lcom/example/bleconnectse/SimulatedNavigationView;)Landroid/os/Handler;
    .registers 1

    .line 27
    iget-object p0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->frameHandler:Landroid/os/Handler;

    return-object p0
.end method

.method public static final synthetic access$getPublishing$p(Lcom/example/bleconnectse/SimulatedNavigationView;)Z
    .registers 1

    .line 27
    iget-boolean p0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->publishing:Z

    return p0
.end method

.method public static final synthetic access$updateAnimation(Lcom/example/bleconnectse/SimulatedNavigationView;J)V
    .registers 3

    .line 27
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/SimulatedNavigationView;->updateAnimation(J)V

    return-void
.end method

.method private final drawGuidance(Landroid/graphics/Canvas;FF)V
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 199
    invoke-static/range {p2 .. p3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    const v3, 0x3ccccccd  # 0.025f

    mul-float/2addr v3, v2

    const v4, 0x3e2e147b  # 0.17f

    mul-float/2addr v4, v2

    const v5, 0x3efae148  # 0.49f

    mul-float v5, v5, p2

    const v6, 0x3f28f5c3  # 0.66f

    mul-float v7, v2, v6

    .line 203
    invoke-static {v5, v7}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v5

    .line 205
    iget-object v7, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v8, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 206
    iget-object v7, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v8, 0x20

    const/16 v9, 0x30

    const/16 v10, 0xe0

    const/16 v11, 0x13

    invoke-static {v10, v11, v8, v9}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    .line 208
    new-instance v7, Landroid/graphics/RectF;

    add-float/2addr v5, v3

    add-float v8, v3, v4

    invoke-direct {v7, v3, v3, v5, v8}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 211
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    .line 207
    invoke-virtual {v1, v7, v3, v3, v5}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 214
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v7, 0xc2

    const/16 v8, 0x6c

    const/16 v9, 0x40

    invoke-static {v9, v7, v8}, Landroid/graphics/Color;->rgb(III)I

    move-result v7

    invoke-virtual {v5, v7}, Landroid/graphics/Paint;->setColor(I)V

    .line 215
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    invoke-virtual {v5}, Landroid/graphics/Path;->reset()V

    .line 216
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    const v7, 0x3e3851ec  # 0.18f

    mul-float/2addr v7, v4

    add-float/2addr v7, v3

    const v8, 0x3f3851ec  # 0.72f

    mul-float/2addr v8, v4

    add-float/2addr v8, v3

    invoke-virtual {v5, v7, v8}, Landroid/graphics/Path;->moveTo(FF)V

    .line 217
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    const v9, 0x3ef5c28f  # 0.48f

    mul-float v10, v4, v9

    add-float/2addr v10, v3

    invoke-virtual {v5, v10, v8}, Landroid/graphics/Path;->lineTo(FF)V

    .line 218
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    const/high16 v8, 0x3e800000  # 0.25f

    mul-float/2addr v8, v4

    add-float/2addr v8, v3

    invoke-virtual {v5, v10, v8}, Landroid/graphics/Path;->lineTo(FF)V

    .line 219
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    const v8, 0x3eae147b  # 0.34f

    mul-float/2addr v8, v4

    add-float/2addr v8, v3

    const v11, 0x3ed70a3d  # 0.42f

    mul-float/2addr v11, v4

    add-float/2addr v11, v3

    invoke-virtual {v5, v8, v11}, Landroid/graphics/Path;->lineTo(FF)V

    .line 220
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    const v8, 0x3e19999a  # 0.15f

    mul-float/2addr v8, v4

    add-float/2addr v8, v3

    invoke-virtual {v5, v10, v8}, Landroid/graphics/Path;->lineTo(FF)V

    .line 221
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    mul-float/2addr v6, v4

    add-float/2addr v6, v3

    invoke-virtual {v5, v6, v11}, Landroid/graphics/Path;->lineTo(FF)V

    .line 222
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    const v6, 0x3f0a3d71  # 0.54f

    mul-float/2addr v6, v4

    add-float/2addr v6, v3

    const v8, 0x3e8f5c29  # 0.28f

    mul-float/2addr v8, v4

    add-float/2addr v8, v3

    invoke-virtual {v5, v6, v8}, Landroid/graphics/Path;->lineTo(FF)V

    .line 223
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    const v8, 0x3f47ae14  # 0.78f

    mul-float/2addr v8, v4

    add-float/2addr v8, v3

    invoke-virtual {v5, v6, v8}, Landroid/graphics/Path;->lineTo(FF)V

    .line 224
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    invoke-virtual {v5, v7, v8}, Landroid/graphics/Path;->lineTo(FF)V

    .line 225
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    invoke-virtual {v5}, Landroid/graphics/Path;->close()V

    .line 226
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->guidancePath:Landroid/graphics/Path;

    iget-object v6, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v5, v6}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 228
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const/4 v6, -0x1

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 229
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v7, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v5, v7}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 230
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v7, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v5, v7}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 231
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const v7, 0x3d4ccccd  # 0.05f

    mul-float/2addr v7, v2

    invoke-virtual {v5, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    const/high16 v5, 0x3f400000  # 0.75f

    mul-float/2addr v5, v4

    add-float/2addr v5, v3

    .line 232
    iget-object v7, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const-string/jumbo v8, "前方沿导航路线行驶"

    invoke-virtual {v1, v8, v5, v10, v7}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 233
    iget-object v7, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v8, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 234
    iget-object v7, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const v8, 0x3ced9168  # 0.029f

    mul-float/2addr v8, v2

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 235
    iget-object v7, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v8, 0xcf

    const/16 v10, 0xdb

    const/16 v11, 0xc5

    invoke-static {v11, v8, v10}, Landroid/graphics/Color;->rgb(III)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    const v7, 0x3f4a3d71  # 0.79f

    mul-float/2addr v4, v7

    add-float/2addr v4, v3

    .line 236
    iget-object v8, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const-string v10, "6400×2400 虚拟城市"

    invoke-virtual {v1, v10, v5, v4, v8}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    const v4, 0x3e051eb8  # 0.13f

    mul-float/2addr v4, v2

    sub-float v5, p3, v3

    sub-float v8, v5, v4

    .line 241
    iget-object v10, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v11, 0x1f

    const/16 v12, 0x2d

    const/16 v13, 0xdc

    const/16 v14, 0x14

    invoke-static {v13, v14, v11, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 243
    new-instance v10, Landroid/graphics/RectF;

    sub-float v11, p2, v3

    invoke-direct {v10, v3, v8, v11, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    const v5, 0x3cb43958  # 0.022f

    mul-float/2addr v5, v2

    .line 246
    iget-object v12, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    .line 242
    invoke-virtual {v1, v10, v5, v5, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 248
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v10, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v5, v10}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 249
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v10, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v5, v10}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 250
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const v10, 0x3d656042  # 0.056f

    mul-float/2addr v10, v2

    invoke-virtual {v5, v10}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 251
    iget-object v5, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    const v5, 0x3d23d70a  # 0.04f

    mul-float/2addr v5, v2

    add-float v10, v3, v5

    const v12, 0x3f2147ae  # 0.63f

    mul-float/2addr v12, v4

    add-float/2addr v12, v8

    .line 252
    iget-object v13, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const-string v14, "42"

    invoke-virtual {v1, v14, v10, v12, v13}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 253
    iget-object v10, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v12, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v10, v12}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 254
    iget-object v10, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v10, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 255
    iget-object v10, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const/16 v12, 0xbe

    const/16 v13, 0xc9

    const/16 v14, 0xd6

    invoke-static {v12, v13, v14}, Landroid/graphics/Color;->rgb(III)I

    move-result v15

    invoke-virtual {v10, v15}, Landroid/graphics/Paint;->setColor(I)V

    const v10, 0x3e23d70a  # 0.16f

    mul-float/2addr v10, v2

    add-float/2addr v3, v10

    const v10, 0x3f1c28f6  # 0.61f

    mul-float/2addr v10, v4

    add-float/2addr v10, v8

    .line 256
    iget-object v15, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    move/from16 v16, v7

    const-string v7, "km/h"

    invoke-virtual {v1, v7, v3, v10, v15}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 257
    iget-object v3, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    sget-object v7, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    invoke-virtual {v3, v7}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 258
    iget-object v3, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const v7, 0x3ce56042  # 0.028f

    mul-float/2addr v7, v2

    invoke-virtual {v3, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 259
    iget-object v3, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setColor(I)V

    sub-float/2addr v11, v5

    mul-float/2addr v9, v4

    add-float/2addr v9, v8

    .line 260
    iget-object v3, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const-string/jumbo v5, "剩余 12.6 km"

    invoke-virtual {v1, v5, v11, v9, v3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 261
    iget-object v3, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const v5, 0x3cc49ba6  # 0.024f

    mul-float/2addr v2, v5

    invoke-virtual {v3, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 262
    iget-object v2, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    invoke-static {v12, v13, v14}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    mul-float v4, v4, v16

    add-float/2addr v8, v4

    .line 263
    iget-object v0, v0, Lcom/example/bleconnectse/SimulatedNavigationView;->paint:Landroid/graphics/Paint;

    const-string/jumbo v2, "拖动地图可自由查看"

    invoke-virtual {v1, v2, v11, v8, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method private final drawNavigation(Landroid/graphics/Canvas;FF)V
    .registers 14

    const/4 v0, 0x0

    cmpg-float v1, p2, v0

    if-lez v1, :cond_32

    cmpg-float v0, p3, v0

    if-gtz v0, :cond_a

    goto :goto_32

    .line 193
    :cond_a
    sget-object v0, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    iget v1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->routeDistance:F

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/SyntheticMapData;->pointAlongRoute(F)Lkotlin/Pair;

    move-result-object v0

    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v1

    move-object v8, v1

    check-cast v8, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v9

    .line 194
    iget-object v2, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->mapRenderer:Lcom/example/bleconnectse/SyntheticMapRenderer;

    iget v6, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->cameraX:F

    iget v7, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->cameraY:F

    move-object v3, p1

    move v4, p2

    move v5, p3

    invoke-virtual/range {v2 .. v9}, Lcom/example/bleconnectse/SyntheticMapRenderer;->draw(Landroid/graphics/Canvas;FFFFLcom/example/bleconnectse/SyntheticPoint;F)V

    .line 195
    invoke-direct {p0, v3, v4, v5}, Lcom/example/bleconnectse/SimulatedNavigationView;->drawGuidance(Landroid/graphics/Canvas;FF)V

    :cond_32
    :goto_32
    return-void
.end method

.method private final notifyBleTileDemand()V
    .registers 6

    .line 177
    iget-object v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->tileDemandListener:Lkotlin/jvm/functions/Function2;

    if-nez v0, :cond_5

    goto :goto_37

    .line 178
    :cond_5
    sget-object v1, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    .line 179
    iget v2, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->routeDistance:F

    const/high16 v3, 0x44160000  # 600.0f

    add-float/2addr v2, v3

    .line 178
    invoke-virtual {v1, v2}, Lcom/example/bleconnectse/SyntheticMapData;->pointAlongRoute(F)Lkotlin/Pair;

    move-result-object v1

    .line 180
    invoke-virtual {v1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/example/bleconnectse/SyntheticPoint;

    .line 181
    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v2

    div-int/lit16 v2, v2, 0x320

    const/4 v3, 0x7

    const/4 v4, 0x0

    .line 182
    invoke-static {v2, v4, v3}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v2

    .line 183
    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v1

    div-int/lit16 v1, v1, 0x1e0

    const/4 v3, 0x4

    .line 184
    invoke-static {v1, v4, v3}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v1

    .line 185
    sget-object v3, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v3, v2, v1}, Lcom/example/bleconnectse/SyntheticMapData;->tileId(II)I

    move-result v3

    .line 186
    iget v4, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastDemandTileId:I

    if-ne v3, v4, :cond_38

    :goto_37
    return-void

    .line 187
    :cond_38
    iput v3, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastDemandTileId:I

    .line 188
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, p0, v1}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private final updateAnimation(J)V
    .registers 12

    .line 152
    iget-wide v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastAnimationAt:J

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-nez v2, :cond_b

    .line 153
    iput-wide p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastAnimationAt:J

    return-void

    :cond_b
    sub-long v3, p1, v0

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0xfa

    .line 156
    invoke-static/range {v3 .. v8}, Lkotlin/ranges/RangesKt;->coerceIn(JJJ)J

    move-result-wide v0

    .line 157
    iput-wide p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastAnimationAt:J

    .line 158
    iget p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->routeDistance:F

    long-to-float p2, v0

    const/high16 v0, 0x42f00000  # 120.0f

    mul-float/2addr p2, v0

    const/high16 v0, 0x447a0000  # 1000.0f

    div-float/2addr p2, v0

    add-float/2addr p1, p2

    iput p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->routeDistance:F

    .line 159
    sget-object p1, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticMapData;->getRouteLength()F

    move-result p1

    const/4 p2, 0x0

    cmpl-float p1, p1, p2

    if-lez p1, :cond_39

    iget p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->routeDistance:F

    sget-object v0, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticMapData;->getRouteLength()F

    move-result v0

    rem-float/2addr p1, v0

    iput p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->routeDistance:F

    .line 160
    :cond_39
    iget-boolean p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->autoFollow:Z

    if-eqz p1, :cond_6d

    .line 161
    sget-object p1, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    iget v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->routeDistance:F

    invoke-virtual {p1, v0}, Lcom/example/bleconnectse/SyntheticMapData;->pointAlongRoute(F)Lkotlin/Pair;

    move-result-object p1

    invoke-virtual {p1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/example/bleconnectse/SyntheticPoint;

    .line 162
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v0

    int-to-float v0, v0

    const v1, 0x44266666  # 665.6f

    sub-float/2addr v0, v1

    .line 163
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result p1

    int-to-float p1, p1

    const v1, 0x43c9999a  # 403.2f

    sub-float/2addr p1, v1

    const/high16 v1, 0x45a00000  # 5120.0f

    .line 164
    invoke-static {v0, p2, v1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    iput v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->cameraX:F

    const/high16 v0, 0x44d20000  # 1680.0f

    .line 168
    invoke-static {p1, p2, v0}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result p1

    iput p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->cameraY:F

    .line 173
    :cond_6d
    invoke-direct {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->notifyBleTileDemand()V

    return-void
.end method


# virtual methods
.method protected onAttachedToWindow()V
    .registers 3

    .line 81
    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    const/4 v0, 0x1

    .line 82
    iput-boolean v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->attached:Z

    .line 83
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastAnimationAt:J

    .line 84
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->postInvalidateOnAnimation()V

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 2

    const/4 v0, 0x0

    .line 88
    iput-boolean v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->attached:Z

    .line 89
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->stopPublishing()V

    .line 90
    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 4

    const-string v0, "canvas"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 95
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    invoke-direct {p0, v0, v1}, Lcom/example/bleconnectse/SimulatedNavigationView;->updateAnimation(J)V

    .line 96
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->getWidth()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->getHeight()I

    move-result v1

    int-to-float v1, v1

    invoke-direct {p0, p1, v0, v1}, Lcom/example/bleconnectse/SimulatedNavigationView;->drawNavigation(Landroid/graphics/Canvas;FF)V

    .line 97
    iget-boolean p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->attached:Z

    if-eqz p1, :cond_23

    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->postInvalidateOnAnimation()V

    :cond_23
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 7

    const-string v0, "event"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 101
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_7e

    if-eq v0, v2, :cond_71

    const/4 v3, 0x2

    if-eq v0, v3, :cond_1a

    const/4 v3, 0x3

    if-eq v0, v3, :cond_71

    .line 143
    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p0

    return p0

    .line 111
    :cond_1a
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iget v1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastTouchX:F

    sub-float/2addr v0, v1

    .line 112
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iget v3, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastTouchY:F

    sub-float/2addr v1, v3

    .line 113
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->getWidth()I

    move-result v3

    const/4 v4, 0x0

    if-lez v3, :cond_39

    const/high16 v3, 0x44a00000  # 1280.0f

    mul-float/2addr v0, v3

    .line 114
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->getWidth()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v0, v3

    goto :goto_3a

    :cond_39
    move v0, v4

    .line 118
    :goto_3a
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->getHeight()I

    move-result v3

    if-lez v3, :cond_4a

    const/high16 v3, 0x44340000  # 720.0f

    mul-float/2addr v1, v3

    .line 119
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->getHeight()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v1, v3

    goto :goto_4b

    :cond_4a
    move v1, v4

    .line 123
    :goto_4b
    iget v3, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->cameraX:F

    sub-float/2addr v3, v0

    const/high16 v0, 0x45a00000  # 5120.0f

    invoke-static {v3, v4, v0}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    iput v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->cameraX:F

    .line 127
    iget v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->cameraY:F

    sub-float/2addr v0, v1

    const/high16 v1, 0x44d20000  # 1680.0f

    invoke-static {v0, v4, v1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    iput v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->cameraY:F

    .line 131
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iput v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastTouchX:F

    .line 132
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iput p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastTouchY:F

    .line 133
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->invalidate()V

    return v2

    .line 138
    :cond_71
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    if-eqz p1, :cond_7a

    invoke-interface {p1, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 139
    :cond_7a
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->performClick()Z

    return v2

    .line 103
    :cond_7e
    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_87

    invoke-interface {v0, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 104
    :cond_87
    iput-boolean v1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->autoFollow:Z

    .line 105
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iput v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastTouchX:F

    .line 106
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iput p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastTouchY:F

    return v2
.end method

.method public performClick()Z
    .registers 1

    .line 147
    invoke-super {p0}, Landroid/view/View;->performClick()Z

    const/4 p0, 0x1

    return p0
.end method

.method public final setOnBleTileDemandChanged(Lkotlin/jvm/functions/Function2;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/Integer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 75
    iput-object p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->tileDemandListener:Lkotlin/jvm/functions/Function2;

    const/4 p1, -0x1

    .line 76
    iput p1, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->lastDemandTileId:I

    .line 77
    invoke-direct {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->notifyBleTileDemand()V

    return-void
.end method

.method public final startPublishing()V
    .registers 2

    .line 64
    iget-boolean v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->publishing:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    .line 65
    iput-boolean v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->publishing:Z

    .line 66
    iget-object v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->frameHandler:Landroid/os/Handler;

    iget-object p0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->framePublisher:Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;

    check-cast p0, Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final stopPublishing()V
    .registers 2

    const/4 v0, 0x0

    .line 70
    iput-boolean v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->publishing:Z

    .line 71
    iget-object v0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->frameHandler:Landroid/os/Handler;

    iget-object p0, p0, Lcom/example/bleconnectse/SimulatedNavigationView;->framePublisher:Lcom/example/bleconnectse/SimulatedNavigationView$framePublisher$1;

    check-cast p0, Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    return-void
.end method
