# classes2.dex

.class public final Lcom/example/bleconnectse/MainActivity;
.super Landroidx/activity/ComponentActivity;
.source "MainActivity.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/MainActivity$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nMainActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MainActivity.kt\ncom/example/bleconnectse/MainActivity\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 5 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,1553:1\n85#2:1554\n117#2,2:1555\n85#2:1557\n117#2,2:1558\n85#2:1560\n117#2,2:1561\n85#2:1563\n117#2,2:1564\n85#2:1566\n117#2,2:1567\n85#2:1569\n117#2,2:1570\n85#2:1572\n117#2,2:1573\n85#2:1575\n117#2,2:1576\n85#2:1578\n117#2,2:1579\n85#2:1581\n117#2,2:1582\n85#2:1584\n117#2,2:1585\n12434#3,2:1587\n12434#3,2:1589\n37#4:1591\n36#4,3:1592\n1128#5,6:1595\n1128#5,6:1601\n1128#5,6:1607\n1128#5,6:1613\n1128#5,6:1619\n1128#5,6:1625\n1128#5,6:1631\n1128#5,6:1637\n1128#5,6:1643\n1128#5,6:1649\n1128#5,6:1655\n1128#5,6:1661\n1128#5,6:1667\n1128#5,6:1673\n1128#5,6:1679\n1128#5,6:1685\n1128#5,6:1691\n1128#5,6:1697\n1128#5,6:1703\n1128#5,6:1709\n1128#5,6:1715\n*S KotlinDebug\n*F\n+ 1 MainActivity.kt\ncom/example/bleconnectse/MainActivity\n*L\n101#1:1554\n101#1:1555,2\n103#1:1557\n103#1:1558,2\n104#1:1560\n104#1:1561,2\n105#1:1563\n105#1:1564,2\n106#1:1566\n106#1:1567,2\n108#1:1569\n108#1:1570,2\n109#1:1572\n109#1:1573,2\n110#1:1575\n110#1:1576,2\n111#1:1578\n111#1:1579,2\n113#1:1581\n113#1:1582,2\n114#1:1584\n114#1:1585,2\n561#1:1587,2\n576#1:1589,2\n598#1:1591\n598#1:1592,3\n258#1:1595,6\n259#1:1601,6\n260#1:1607,6\n263#1:1613,6\n264#1:1619,6\n273#1:1625,6\n284#1:1631,6\n285#1:1637,6\n298#1:1643,6\n311#1:1649,6\n312#1:1655,6\n316#1:1661,6\n320#1:1667,6\n323#1:1673,6\n324#1:1679,6\n325#1:1685,6\n326#1:1691,6\n328#1:1697,6\n329#1:1703,6\n332#1:1709,6\n342#1:1715,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0084\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0018\u0002\n\u0002\b\t\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010X\u001a\u00020Y2\b\u0010Z\u001a\u0004\u0018\u00010[H\u0014J\b\u0010\\\u001a\u00020YH\u0014J\b\u0010]\u001a\u00020YH\u0014J\b\u0010^\u001a\u00020YH\u0014J\b\u0010_\u001a\u00020YH\u0002J\b\u0010`\u001a\u00020YH\u0002J\b\u0010a\u001a\u00020YH\u0002J\b\u0010b\u001a\u00020YH\u0002J\b\u0010c\u001a\u00020YH\u0002J\u0010\u0010d\u001a\u00020Y2\u0006\u0010e\u001a\u00020NH\u0002J\u0010\u0010f\u001a\u00020Y2\u0006\u0010e\u001a\u00020NH\u0002J\b\u0010g\u001a\u00020YH\u0002J\b\u0010h\u001a\u00020YH\u0002J\b\u0010i\u001a\u00020YH\u0002J\b\u0010j\u001a\u00020YH\u0002J\b\u0010k\u001a\u00020YH\u0002J\b\u0010l\u001a\u00020YH\u0002J\b\u0010m\u001a\u00020YH\u0002J\b\u0010n\u001a\u00020YH\u0002J\b\u0010o\u001a\u00020YH\u0002J\b\u0010p\u001a\u00020YH\u0002J\u0010\u0010q\u001a\u00020\u00102\u0006\u0010r\u001a\u00020sH\u0002J\b\u0010t\u001a\u00020\u0010H\u0002J\b\u0010I\u001a\u00020\u0010H\u0002J\u0013\u0010u\u001a\b\u0012\u0004\u0012\u00020\u000e0QH\u0002¢\u0006\u0002\u0010vJ\b\u0010w\u001a\u00020\u0010H\u0002J\u0013\u0010x\u001a\b\u0012\u0004\u0012\u00020\u000e0QH\u0002¢\u0006\u0002\u0010vJ\u0013\u0010y\u001a\b\u0012\u0004\u0012\u00020\u000e0QH\u0002¢\u0006\u0002\u0010vJ\u0010\u0010z\u001a\u00020Y2\u0006\u0010{\u001a\u00020\u000eH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082.¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rX\u0082\u0004¢\u0006\u0002\n\u0000R+\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u000f\u001a\u00020\u00108B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\b\u0016\u0010\u0017\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u000e\u0010\u0018\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R+\u0010\u001a\u001a\u00020\u00192\u0006\u0010\u000f\u001a\u00020\u00198B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\b\u001f\u0010\u0017\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR+\u0010 \u001a\u00020\u00102\u0006\u0010\u000f\u001a\u00020\u00108B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\b#\u0010\u0017\u001a\u0004\b!\u0010\u0013\"\u0004\b\"\u0010\u0015R+\u0010$\u001a\u00020\u00102\u0006\u0010\u000f\u001a\u00020\u00108B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\b\'\u0010\u0017\u001a\u0004\b%\u0010\u0013\"\u0004\b&\u0010\u0015R+\u0010)\u001a\u00020(2\u0006\u0010\u000f\u001a\u00020(8B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\b.\u0010\u0017\u001a\u0004\b*\u0010+\"\u0004\b,\u0010-R\u0010\u0010/\u001a\u0004\u0018\u000100X\u0082\u000e¢\u0006\u0002\n\u0000R+\u00101\u001a\u00020\u00102\u0006\u0010\u000f\u001a\u00020\u00108B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\b4\u0010\u0017\u001a\u0004\b2\u0010\u0013\"\u0004\b3\u0010\u0015R+\u00105\u001a\u00020\u00102\u0006\u0010\u000f\u001a\u00020\u00108B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\b8\u0010\u0017\u001a\u0004\b6\u0010\u0013\"\u0004\b7\u0010\u0015R+\u00109\u001a\u00020(2\u0006\u0010\u000f\u001a\u00020(8B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\b<\u0010\u0017\u001a\u0004\b:\u0010+\"\u0004\b;\u0010-R+\u0010=\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000e8B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\bB\u0010\u0017\u001a\u0004\b>\u0010?\"\u0004\b@\u0010AR\u0010\u0010C\u001a\u0004\u0018\u00010DX\u0082\u000e¢\u0006\u0002\n\u0000R+\u0010E\u001a\u00020\u00102\u0006\u0010\u000f\u001a\u00020\u00108B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\bH\u0010\u0017\u001a\u0004\bF\u0010\u0013\"\u0004\bG\u0010\u0015R+\u0010I\u001a\u00020\u00102\u0006\u0010\u000f\u001a\u00020\u00108B@BX\u0082\u008e\u0002¢\u0006\u0012\n\u0004\bL\u0010\u0017\u001a\u0004\bJ\u0010\u0013\"\u0004\bK\u0010\u0015R\u0010\u0010M\u001a\u0004\u0018\u00010NX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010O\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0Q0PX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010R\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0Q0PX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010S\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0Q0PX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010T\u001a\b\u0012\u0004\u0012\u00020\u000e0PX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010U\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0Q0PX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010V\u001a\b\u0012\u0004\u0012\u00020W0PX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006|"
    }
    d2 = {
        "Lcom/example/bleconnectse/MainActivity;",
        "Landroidx/activity/ComponentActivity;",
        "<init>",
        "()V",
        "mirrorClient",
        "Lcom/example/bleconnectse/YadeaOtaClient;",
        "bleTileClient",
        "Lcom/example/bleconnectse/BleTileClient;",
        "cameraMirrorController",
        "Lcom/example/bleconnectse/CameraMirrorController;",
        "videoMirrorController",
        "Lcom/example/bleconnectse/VideoMirrorController;",
        "appLogs",
        "Landroidx/compose/runtime/snapshots/SnapshotStateList;",
        "",
        "<set-?>",
        "",
        "hasPermissions",
        "getHasPermissions",
        "()Z",
        "setHasPermissions",
        "(Z)V",
        "hasPermissions$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "pendingCameraMirror",
        "Lcom/example/bleconnectse/CandidatePanel;",
        "activeCandidatePanel",
        "getActiveCandidatePanel",
        "()Lcom/example/bleconnectse/CandidatePanel;",
        "setActiveCandidatePanel",
        "(Lcom/example/bleconnectse/CandidatePanel;)V",
        "activeCandidatePanel$delegate",
        "showSimulatedNavigation",
        "getShowSimulatedNavigation",
        "setShowSimulatedNavigation",
        "showSimulatedNavigation$delegate",
        "simulatedNavigationMirrorOn",
        "getSimulatedNavigationMirrorOn",
        "setSimulatedNavigationMirrorOn",
        "simulatedNavigationMirrorOn$delegate",
        "Lcom/example/bleconnectse/NavigationTransport;",
        "simulatedNavigationTransport",
        "getSimulatedNavigationTransport",
        "()Lcom/example/bleconnectse/NavigationTransport;",
        "setSimulatedNavigationTransport",
        "(Lcom/example/bleconnectse/NavigationTransport;)V",
        "simulatedNavigationTransport$delegate",
        "simulatedNavigationView",
        "Lcom/example/bleconnectse/SimulatedNavigationView;",
        "showAmapNavigation",
        "getShowAmapNavigation",
        "setShowAmapNavigation",
        "showAmapNavigation$delegate",
        "amapNavigationMirrorOn",
        "getAmapNavigationMirrorOn",
        "setAmapNavigationMirrorOn",
        "amapNavigationMirrorOn$delegate",
        "amapNavigationTransport",
        "getAmapNavigationTransport",
        "setAmapNavigationTransport",
        "amapNavigationTransport$delegate",
        "amapNavigationStatus",
        "getAmapNavigationStatus",
        "()Ljava/lang/String;",
        "setAmapNavigationStatus",
        "(Ljava/lang/String;)V",
        "amapNavigationStatus$delegate",
        "amapNavigationView",
        "Lcom/example/bleconnectse/AmapNavigationView;",
        "amapPrivacyAgreed",
        "getAmapPrivacyAgreed",
        "setAmapPrivacyAgreed",
        "amapPrivacyAgreed$delegate",
        "hasLocationPermission",
        "getHasLocationPermission",
        "setHasLocationPermission",
        "hasLocationPermission$delegate",
        "pendingBleEntry",
        "Lcom/example/bleconnectse/PendingBleEntry;",
        "mirrorMediaPicker",
        "Landroidx/activity/result/ActivityResultLauncher;",
        "",
        "wallpaperPicker",
        "permissionLauncher",
        "cameraPermissionLauncher",
        "blePermissionLauncher",
        "screenCaptureLauncher",
        "Landroid/content/Intent;",
        "onCreate",
        "",
        "savedInstanceState",
        "Landroid/os/Bundle;",
        "onDestroy",
        "onStart",
        "onStop",
        "requestCameraMirror",
        "startCameraMirror",
        "requestScreenMirror",
        "openSimulatedMap",
        "openAmapMap",
        "requestBleTiles",
        "entry",
        "openBleTiles",
        "startSimulatedNavigationMirror",
        "stopSimulatedNavigationMirror",
        "closeSimulatedNavigation",
        "startAmapNavigationMirror",
        "stopAmapNavigationMirror",
        "closeAmapNavigation",
        "acceptAmapPrivacyConsent",
        "applyAmapPrivacyConsent",
        "stopMirrorProducers",
        "stopAllMirrorSources",
        "isVideoUri",
        "uri",
        "Landroid/net/Uri;",
        "hasRequiredPermissions",
        "locationPermissions",
        "()[Ljava/lang/String;",
        "hasBlePermissions",
        "blePermissions",
        "requiredPermissions",
        "logLine",
        "message",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final activeCandidatePanel$delegate:Landroidx/compose/runtime/MutableState;

.field private final amapNavigationMirrorOn$delegate:Landroidx/compose/runtime/MutableState;

.field private final amapNavigationStatus$delegate:Landroidx/compose/runtime/MutableState;

.field private final amapNavigationTransport$delegate:Landroidx/compose/runtime/MutableState;

.field private amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

.field private final amapPrivacyAgreed$delegate:Landroidx/compose/runtime/MutableState;

.field private final appLogs:Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final blePermissionLauncher:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private bleTileClient:Lcom/example/bleconnectse/BleTileClient;

.field private cameraMirrorController:Lcom/example/bleconnectse/CameraMirrorController;

.field private final cameraPermissionLauncher:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final hasLocationPermission$delegate:Landroidx/compose/runtime/MutableState;

.field private final hasPermissions$delegate:Landroidx/compose/runtime/MutableState;

.field private mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

.field private final mirrorMediaPicker:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private pendingBleEntry:Lcom/example/bleconnectse/PendingBleEntry;

.field private pendingCameraMirror:Z

.field private final permissionLauncher:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final screenCaptureLauncher:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation
.end field

.field private final showAmapNavigation$delegate:Landroidx/compose/runtime/MutableState;

.field private final showSimulatedNavigation$delegate:Landroidx/compose/runtime/MutableState;

.field private final simulatedNavigationMirrorOn$delegate:Landroidx/compose/runtime/MutableState;

.field private final simulatedNavigationTransport$delegate:Landroidx/compose/runtime/MutableState;

.field private simulatedNavigationView:Lcom/example/bleconnectse/SimulatedNavigationView;

.field private videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

.field private final wallpaperPicker:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 5

    .line 95
    invoke-direct {p0}, Landroidx/activity/ComponentActivity;-><init>()V

    .line 100
    invoke-static {}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateListOf()Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->appLogs:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    const/4 v0, 0x0

    .line 101
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lcom/example/bleconnectse/MainActivity;->hasPermissions$delegate:Landroidx/compose/runtime/MutableState;

    .line 103
    sget-object v3, Lcom/example/bleconnectse/CandidatePanel;->Ap:Lcom/example/bleconnectse/CandidatePanel;

    invoke-static {v3, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lcom/example/bleconnectse/MainActivity;->activeCandidatePanel$delegate:Landroidx/compose/runtime/MutableState;

    .line 104
    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lcom/example/bleconnectse/MainActivity;->showSimulatedNavigation$delegate:Landroidx/compose/runtime/MutableState;

    .line 105
    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationMirrorOn$delegate:Landroidx/compose/runtime/MutableState;

    .line 106
    sget-object v3, Lcom/example/bleconnectse/NavigationTransport;->WifiMirror:Lcom/example/bleconnectse/NavigationTransport;

    invoke-static {v3, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationTransport$delegate:Landroidx/compose/runtime/MutableState;

    .line 108
    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lcom/example/bleconnectse/MainActivity;->showAmapNavigation$delegate:Landroidx/compose/runtime/MutableState;

    .line 109
    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationMirrorOn$delegate:Landroidx/compose/runtime/MutableState;

    .line 110
    sget-object v3, Lcom/example/bleconnectse/NavigationTransport;->WifiMirror:Lcom/example/bleconnectse/NavigationTransport;

    invoke-static {v3, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationTransport$delegate:Landroidx/compose/runtime/MutableState;

    .line 111
    const-string/jumbo v3, "长按地图选择目的地"

    invoke-static {v3, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationStatus$delegate:Landroidx/compose/runtime/MutableState;

    .line 113
    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lcom/example/bleconnectse/MainActivity;->amapPrivacyAgreed$delegate:Landroidx/compose/runtime/MutableState;

    .line 114
    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->hasLocationPermission$delegate:Landroidx/compose/runtime/MutableState;

    .line 118
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda0;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lcom/example/bleconnectse/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorMediaPicker:Landroidx/activity/result/ActivityResultLauncher;

    .line 152
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda11;

    invoke-direct {v1, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda11;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lcom/example/bleconnectse/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->wallpaperPicker:Landroidx/activity/result/ActivityResultLauncher;

    .line 166
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda22;

    invoke-direct {v1, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda22;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lcom/example/bleconnectse/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->permissionLauncher:Landroidx/activity/result/ActivityResultLauncher;

    .line 173
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$RequestPermission;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$RequestPermission;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda23;

    invoke-direct {v1, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda23;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lcom/example/bleconnectse/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->cameraPermissionLauncher:Landroidx/activity/result/ActivityResultLauncher;

    .line 184
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda24;

    invoke-direct {v1, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda24;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lcom/example/bleconnectse/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->blePermissionLauncher:Landroidx/activity/result/ActivityResultLauncher;

    .line 195
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$StartActivityForResult;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$StartActivityForResult;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda25;

    invoke-direct {v1, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda25;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lcom/example/bleconnectse/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->screenCaptureLauncher:Landroidx/activity/result/ActivityResultLauncher;

    return-void
.end method

.method private final acceptAmapPrivacyConsent()V
    .registers 4

    .line 514
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->applyAmapPrivacyConsent()V

    .line 515
    const-string v0, "amap_navigation"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/example/bleconnectse/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 516
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 517
    const-string v1, "privacy_agreed"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 518
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 519
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/MainActivity;->setAmapPrivacyAgreed(Z)V

    .line 520
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getHasLocationPermission()Z

    move-result v0

    if-nez v0, :cond_2a

    .line 521
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->permissionLauncher:Landroidx/activity/result/ActivityResultLauncher;

    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->locationPermissions()[Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    :cond_2a
    return-void
.end method

.method public static final synthetic access$getMirrorClient$p(Lcom/example/bleconnectse/MainActivity;)Lcom/example/bleconnectse/YadeaOtaClient;
    .registers 1

    .line 95
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    return-object p0
.end method

.method private final applyAmapPrivacyConsent()V
    .registers 3

    .line 526
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, v1, v1}, Lcom/amap/api/maps/MapsInitializer;->updatePrivacyShow(Landroid/content/Context;ZZ)V

    .line 527
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v1}, Lcom/amap/api/maps/MapsInitializer;->updatePrivacyAgree(Landroid/content/Context;Z)V

    .line 528
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v1, v1}, Lcom/amap/api/location/AMapLocationClient;->updatePrivacyShow(Landroid/content/Context;ZZ)V

    .line 529
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v1}, Lcom/amap/api/location/AMapLocationClient;->updatePrivacyAgree(Landroid/content/Context;Z)V

    .line 530
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v1, v1}, Lcom/amap/api/services/core/ServiceSettings;->updatePrivacyShow(Landroid/content/Context;ZZ)V

    .line 531
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0, v1}, Lcom/amap/api/services/core/ServiceSettings;->updatePrivacyAgree(Landroid/content/Context;Z)V

    return-void
.end method

.method static final blePermissionLauncher$lambda$4(Lcom/example/bleconnectse/MainActivity;Ljava/util/Map;)V
    .registers 3

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 185
    iget-object p1, p0, Lcom/example/bleconnectse/MainActivity;->pendingBleEntry:Lcom/example/bleconnectse/PendingBleEntry;

    const/4 v0, 0x0

    .line 186
    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->pendingBleEntry:Lcom/example/bleconnectse/PendingBleEntry;

    if-eqz p1, :cond_16

    .line 187
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->hasBlePermissions()Z

    move-result v0

    if-eqz v0, :cond_16

    .line 188
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->openBleTiles(Lcom/example/bleconnectse/PendingBleEntry;)V

    return-void

    .line 190
    :cond_16
    const-string/jumbo p1, "缺少附近设备/BLE权限，无法扫描BLE瓦片仪表"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->logLine(Ljava/lang/String;)V

    return-void
.end method

.method private final blePermissions()[Ljava/lang/String;
    .registers 3

    .line 580
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1f

    if-lt v0, v1, :cond_14

    const/4 p0, 0x2

    .line 582
    new-array p0, p0, [Ljava/lang/String;

    const/4 v0, 0x0

    const-string v1, "android.permission.BLUETOOTH_SCAN"

    aput-object v1, p0, v0

    const/4 v0, 0x1

    .line 583
    const-string v1, "android.permission.BLUETOOTH_CONNECT"

    aput-object v1, p0, v0

    return-object p0

    .line 586
    :cond_14
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->locationPermissions()[Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static final cameraPermissionLauncher$lambda$3(Lcom/example/bleconnectse/MainActivity;Z)V
    .registers 3

    const/4 v0, 0x0

    if-eqz p1, :cond_d

    .line 174
    iget-boolean p1, p0, Lcom/example/bleconnectse/MainActivity;->pendingCameraMirror:Z

    if-eqz p1, :cond_d

    .line 175
    iput-boolean v0, p0, Lcom/example/bleconnectse/MainActivity;->pendingCameraMirror:Z

    .line 176
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->startCameraMirror()V

    return-void

    .line 178
    :cond_d
    iput-boolean v0, p0, Lcom/example/bleconnectse/MainActivity;->pendingCameraMirror:Z

    .line 179
    const-string/jumbo p1, "缺少相机权限，无法启动摄像头投屏"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->logLine(Ljava/lang/String;)V

    return-void
.end method

.method private final closeAmapNavigation()V
    .registers 4

    .line 503
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getAmapNavigationTransport()Lcom/example/bleconnectse/NavigationTransport;

    move-result-object v0

    sget-object v1, Lcom/example/bleconnectse/NavigationTransport;->BleTiles:Lcom/example/bleconnectse/NavigationTransport;

    const/4 v2, 0x0

    if-ne v0, v1, :cond_17

    .line 504
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->bleTileClient:Lcom/example/bleconnectse/BleTileClient;

    if-nez v0, :cond_13

    const-string v0, "bleTileClient"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v2

    :cond_13
    invoke-virtual {v0}, Lcom/example/bleconnectse/BleTileClient;->disconnect()V

    goto :goto_20

    .line 505
    :cond_17
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getAmapNavigationMirrorOn()Z

    move-result v0

    if-eqz v0, :cond_20

    .line 506
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->stopAmapNavigationMirror()V

    .line 508
    :cond_20
    :goto_20
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

    if-eqz v0, :cond_27

    invoke-virtual {v0}, Lcom/example/bleconnectse/AmapNavigationView;->close()V

    .line 509
    :cond_27
    iput-object v2, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

    const/4 v0, 0x0

    .line 510
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setShowAmapNavigation(Z)V

    return-void
.end method

.method private final closeSimulatedNavigation()V
    .registers 3

    .line 474
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getSimulatedNavigationTransport()Lcom/example/bleconnectse/NavigationTransport;

    move-result-object v0

    sget-object v1, Lcom/example/bleconnectse/NavigationTransport;->BleTiles:Lcom/example/bleconnectse/NavigationTransport;

    if-ne v0, v1, :cond_16

    .line 475
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->bleTileClient:Lcom/example/bleconnectse/BleTileClient;

    if-nez v0, :cond_12

    const-string v0, "bleTileClient"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v0, 0x0

    :cond_12
    invoke-virtual {v0}, Lcom/example/bleconnectse/BleTileClient;->disconnect()V

    goto :goto_1f

    .line 476
    :cond_16
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getSimulatedNavigationMirrorOn()Z

    move-result v0

    if-eqz v0, :cond_1f

    .line 477
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->stopSimulatedNavigationMirror()V

    :cond_1f
    :goto_1f
    const/4 v0, 0x0

    .line 479
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setShowSimulatedNavigation(Z)V

    return-void
.end method

.method private final getActiveCandidatePanel()Lcom/example/bleconnectse/CandidatePanel;
    .registers 1

    .line 103
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->activeCandidatePanel$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1557
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/example/bleconnectse/CandidatePanel;

    return-object p0
.end method

.method private final getAmapNavigationMirrorOn()Z
    .registers 1

    .line 109
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationMirrorOn$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1572
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private final getAmapNavigationStatus()Ljava/lang/String;
    .registers 1

    .line 111
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationStatus$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1578
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method private final getAmapNavigationTransport()Lcom/example/bleconnectse/NavigationTransport;
    .registers 1

    .line 110
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationTransport$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1575
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/example/bleconnectse/NavigationTransport;

    return-object p0
.end method

.method private final getAmapPrivacyAgreed()Z
    .registers 1

    .line 113
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->amapPrivacyAgreed$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1581
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private final getHasLocationPermission()Z
    .registers 1

    .line 114
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->hasLocationPermission$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1584
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private final getHasPermissions()Z
    .registers 1

    .line 101
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->hasPermissions$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1554
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private final getShowAmapNavigation()Z
    .registers 1

    .line 108
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->showAmapNavigation$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1569
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private final getShowSimulatedNavigation()Z
    .registers 1

    .line 104
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->showSimulatedNavigation$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1560
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private final getSimulatedNavigationMirrorOn()Z
    .registers 1

    .line 105
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationMirrorOn$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1563
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method private final getSimulatedNavigationTransport()Lcom/example/bleconnectse/NavigationTransport;
    .registers 1

    .line 106
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationTransport$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 1566
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/example/bleconnectse/NavigationTransport;

    return-object p0
.end method

.method private final hasBlePermissions()Z
    .registers 7

    .line 576
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->blePermissions()[Ljava/lang/String;

    move-result-object v0

    .line 1589
    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_7
    if-ge v3, v1, :cond_18

    aget-object v4, v0, v3

    .line 577
    move-object v5, p0

    check-cast v5, Landroid/content/Context;

    invoke-static {v5, v4}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_17

    add-int/lit8 v3, v3, 0x1

    goto :goto_7

    :cond_17
    return v2

    :cond_18
    const/4 p0, 0x1

    return p0
.end method

.method private final hasLocationPermission()Z
    .registers 2

    .line 566
    check-cast p0, Landroid/content/Context;

    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_15

    .line 568
    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    if-nez p0, :cond_13

    goto :goto_15

    :cond_13
    const/4 p0, 0x0

    return p0

    :cond_15
    :goto_15
    const/4 p0, 0x1

    return p0
.end method

.method private final hasRequiredPermissions()Z
    .registers 7

    .line 561
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->requiredPermissions()[Ljava/lang/String;

    move-result-object v0

    .line 1587
    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_7
    if-ge v3, v1, :cond_18

    aget-object v4, v0, v3

    .line 562
    move-object v5, p0

    check-cast v5, Landroid/content/Context;

    invoke-static {v5, v4}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_17

    add-int/lit8 v3, v3, 0x1

    goto :goto_7

    :cond_17
    return v2

    :cond_18
    const/4 p0, 0x1

    return p0
.end method

.method private final isVideoUri(Landroid/net/Uri;)Z
    .registers 7

    .line 552
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz p0, :cond_18

    .line 553
    const-string/jumbo v4, "video/"

    invoke-static {p0, v4, v2, v1, v3}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p0

    if-ne p0, v0, :cond_18

    return v0

    .line 554
    :cond_18
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "toString(...)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 p1, 0x3f

    invoke-static {p0, p1, v3, v1, v3}, Lkotlin/text/StringsKt;->substringBefore$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    sget-object p1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const-string v4, "ROOT"

    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "toLowerCase(...)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 555
    const-string p1, ".mp4"

    invoke-static {p0, p1, v2, v1, v3}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_69

    const-string p1, ".mkv"

    invoke-static {p0, p1, v2, v1, v3}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_69

    const-string p1, ".webm"

    invoke-static {p0, p1, v2, v1, v3}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_69

    .line 556
    const-string p1, ".mov"

    invoke-static {p0, p1, v2, v1, v3}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_69

    const-string p1, ".3gp"

    invoke-static {p0, p1, v2, v1, v3}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_69

    const-string p1, ".avi"

    invoke-static {p0, p1, v2, v1, v3}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_68

    goto :goto_69

    :cond_68
    return v2

    :cond_69
    :goto_69
    return v0
.end method

.method private final locationPermissions()[Ljava/lang/String;
    .registers 3

    const/4 p0, 0x2

    .line 572
    new-array p0, p0, [Ljava/lang/String;

    const/4 v0, 0x0

    const-string v1, "android.permission.ACCESS_COARSE_LOCATION"

    aput-object v1, p0, v0

    const/4 v0, 0x1

    .line 573
    const-string v1, "android.permission.ACCESS_FINE_LOCATION"

    aput-object v1, p0, v0

    return-object p0
.end method

.method private final logLine(Ljava/lang/String;)V
    .registers 5

    .line 602
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "HH:mm:ss"

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    .line 603
    iget-object v1, p0, Lcom/example/bleconnectse/MainActivity;->appLogs:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "  "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    invoke-virtual {v1, v0, p1}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->add(ILjava/lang/Object;)V

    .line 604
    :goto_2f
    iget-object p1, p0, Lcom/example/bleconnectse/MainActivity;->appLogs:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    invoke-virtual {p1}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->size()I

    move-result p1

    const/16 v0, 0xc8

    if-le p1, v0, :cond_46

    iget-object p1, p0, Lcom/example/bleconnectse/MainActivity;->appLogs:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-object v0, p1

    check-cast v0, Ljava/util/List;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->getLastIndex(Ljava/util/List;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->remove(I)Ljava/lang/Object;

    goto :goto_2f

    :cond_46
    return-void
.end method

.method static final mirrorMediaPicker$lambda$0(Lcom/example/bleconnectse/MainActivity;Landroid/net/Uri;)V
    .registers 7

    if-nez p1, :cond_4

    goto/16 :goto_93

    .line 121
    :cond_4
    :try_start_4
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/content/ContentResolver;->takePersistableUriPermission(Landroid/net/Uri;I)V
    :try_end_c
    .catch Ljava/lang/SecurityException; {:try_start_4 .. :try_end_c} :catch_d

    goto :goto_13

    .line 126
    :catch_d
    const-string/jumbo v0, "相册媒体本次可读，但无法保留长期读取权限"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->logLine(Ljava/lang/String;)V

    .line 128
    :goto_13
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->cameraMirrorController:Lcom/example/bleconnectse/CameraMirrorController;

    const/4 v1, 0x0

    if-nez v0, :cond_1e

    const-string v0, "cameraMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_1e
    invoke-virtual {v0}, Lcom/example/bleconnectse/CameraMirrorController;->stop()V

    .line 129
    sget-object v0, Lcom/example/bleconnectse/ScreenCaptureService;->Companion:Lcom/example/bleconnectse/ScreenCaptureService$Companion;

    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    invoke-virtual {v0, v2}, Lcom/example/bleconnectse/ScreenCaptureService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 130
    sget-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    invoke-virtual {v0, v2}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 131
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    const-string/jumbo v3, "videoMirrorController"

    if-nez v0, :cond_41

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_41
    invoke-virtual {v0}, Lcom/example/bleconnectse/VideoMirrorController;->stop()V

    .line 132
    sget-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    .line 133
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->isVideoUri(Landroid/net/Uri;)Z

    move-result v0

    const-string v4, "mirrorClient"

    if-eqz v0, :cond_78

    .line 134
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez v0, :cond_59

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_59
    const-string/jumbo v4, "相册视频"

    invoke-virtual {v0, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->startLiveMirror(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_93

    .line 137
    sget-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    invoke-virtual {v0, v2, v4}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->startIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 135
    invoke-static {v2, v0}, Landroidx/core/content/ContextCompat;->startForegroundService(Landroid/content/Context;Landroid/content/Intent;)V

    .line 139
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    if-nez p0, :cond_73

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_74

    :cond_73
    move-object v1, p0

    :goto_74
    invoke-virtual {v1, p1}, Lcom/example/bleconnectse/VideoMirrorController;->open(Landroid/net/Uri;)V

    goto :goto_93

    .line 142
    :cond_78
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez p0, :cond_80

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_81

    :cond_80
    move-object v1, p0

    :goto_81
    invoke-virtual {v1, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->startImageMirror(Landroid/net/Uri;)Z

    move-result p0

    if-eqz p0, :cond_93

    .line 145
    sget-object p0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    const-string/jumbo p1, "相册图片"

    invoke-virtual {p0, v2, p1}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->startIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    .line 143
    invoke-static {v2, p0}, Landroidx/core/content/ContextCompat;->startForegroundService(Landroid/content/Context;Landroid/content/Intent;)V

    :cond_93
    :goto_93
    return-void
.end method

.method static final onCreate$lambda$10(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 3

    .line 235
    sget-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 236
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez p0, :cond_16

    const-string p0, "mirrorClient"

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 p0, 0x0

    :cond_16
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->stopMirrorDemo()V

    .line 237
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55(Lcom/example/bleconnectse/MainActivity;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 9

    const-string v0, "C247@10389L5414,247@10371L5432:MainActivity.kt#p15tle"

    invoke-static {p1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, v1, :cond_d

    move v0, v2

    goto :goto_e

    :cond_d
    const/4 v0, 0x0

    :goto_e
    and-int/lit8 v1, p2, 0x1

    invoke-interface {p1, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_49

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_25

    const/4 v0, -0x1

    const-string v1, "com.example.bleconnectse.MainActivity.onCreate.<anonymous> (MainActivity.kt:247)"

    const v3, -0x19b240f0

    invoke-static {v3, p2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 248
    :cond_25
    new-instance p2, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda14;

    invoke-direct {p2, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda14;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    const/16 p0, 0x36

    const v0, -0x7881c095

    invoke-static {v0, v2, p2, p1, p0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object p0

    move-object v2, p0

    check-cast v2, Lkotlin/jvm/functions/Function2;

    const/16 v4, 0x180

    const/4 v5, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    move-object v3, p1

    invoke-static/range {v0 .. v5}, Lcom/example/bleconnectse/ui/theme/ThemeKt;->BleconnectseTheme(ZZLkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_4d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_4d

    :cond_49
    move-object v3, p1

    .line 247
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 346
    :cond_4d
    :goto_4d
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54(Lcom/example/bleconnectse/MainActivity;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 20

    move-object/from16 v0, p0

    move-object/from16 v13, p1

    move/from16 v1, p2

    const-string v2, "C248@10451L5078,248@10407L5122:MainActivity.kt#p15tle"

    invoke-static {v13, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eq v2, v3, :cond_13

    move v2, v4

    goto :goto_14

    :cond_13
    const/4 v2, 0x0

    :goto_14
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v13, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_c5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_2b

    const/4 v2, -0x1

    const-string v3, "com.example.bleconnectse.MainActivity.onCreate.<anonymous>.<anonymous> (MainActivity.kt:248)"

    const v5, -0x7881c095

    invoke-static {v5, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 249
    :cond_2b
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v1, v2, v4, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    new-instance v2, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda12;

    invoke-direct {v2, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda12;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    const/16 v5, 0x36

    const v6, -0x73b43984

    invoke-static {v6, v4, v2, v13, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object v12, v2

    check-cast v12, Lkotlin/jvm/functions/Function3;

    const v14, 0x30000006

    const/16 v15, 0x1fe

    const/4 v2, 0x0

    move-object v4, v3

    move-object v5, v4

    const/4 v4, 0x0

    move-object v6, v5

    const/4 v5, 0x0

    move-object v7, v6

    const/4 v6, 0x0

    move-object v9, v7

    const-wide/16 v7, 0x0

    move-object v11, v9

    const-wide/16 v9, 0x0

    move-object/from16 v16, v11

    const/4 v11, 0x0

    invoke-static/range {v1 .. v15}, Landroidx/compose/material3/ScaffoldKt;->Scaffold-TvnljyQ(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;IJJLandroidx/compose/foundation/layout/WindowInsets;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 339
    iget-object v3, v0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    const-string/jumbo v1, "videoMirrorController"

    if-nez v3, :cond_6b

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object/from16 v3, v16

    :cond_6b
    invoke-virtual {v3}, Lcom/example/bleconnectse/VideoMirrorController;->getPreviewVisible()Z

    move-result v2

    if-eqz v2, :cond_b2

    const v2, 0x7ce4cf2e

    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "341@15723L26,339@15610L161"

    invoke-static {v13, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 341
    iget-object v3, v0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    if-nez v3, :cond_85

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object/from16 v3, v16

    :cond_85
    const v1, -0x5f11547b

    const-string v2, "CC(remember):MainActivity.kt#9igjgp"

    .line 342
    invoke-static {v13, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v13, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .line 1715
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    if-nez v1, :cond_9f

    .line 1716
    sget-object v1, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v1}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v2, v1, :cond_a7

    .line 342
    :cond_9f
    new-instance v2, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda13;

    invoke-direct {v2, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda13;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1718
    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 342
    :cond_a7
    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-static {v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    sget v0, Lcom/example/bleconnectse/VideoMirrorController;->$stable:I

    .line 340
    invoke-static {v3, v2, v13, v0}, Lcom/example/bleconnectse/MainActivityKt;->access$VideoMirrorDialog(Lcom/example/bleconnectse/VideoMirrorController;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    goto :goto_b8

    :cond_b2
    const v0, 0x7bf8bf77

    .line 339
    invoke-interface {v13, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_b8
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_c8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_c8

    .line 248
    :cond_c5
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 345
    :cond_c8
    :goto_c8
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51(Lcom/example/bleconnectse/MainActivity;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 25

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v7, p2

    const-string v2, "innerPadding"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CN(innerPadding):MainActivity.kt#p15tle"

    invoke-static {v7, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, p3, 0x6

    if-nez v2, :cond_20

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1c

    const/4 v2, 0x4

    goto :goto_1d

    :cond_1c
    const/4 v2, 0x2

    :goto_1d
    or-int v2, p3, v2

    goto :goto_22

    :cond_20
    move/from16 v2, p3

    :goto_22
    and-int/lit8 v3, v2, 0x13

    const/16 v4, 0x12

    if-eq v3, v4, :cond_2a

    const/4 v3, 0x1

    goto :goto_2b

    :cond_2a
    const/4 v3, 0x0

    :goto_2b
    and-int/lit8 v4, v2, 0x1

    invoke-interface {v7, v3, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v3

    if-eqz v3, :cond_2f7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_42

    const/4 v3, -0x1

    const-string v4, "com.example.bleconnectse.MainActivity.onCreate.<anonymous>.<anonymous>.<anonymous> (MainActivity.kt:249)"

    const v5, -0x73b43984

    invoke-static {v5, v2, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 279
    :cond_42
    invoke-direct {v0}, Lcom/example/bleconnectse/MainActivity;->getShowSimulatedNavigation()Z

    move-result v2

    const-string v3, "mirrorClient"

    const/4 v4, 0x0

    const-string v5, "CC(remember):MainActivity.kt#9igjgp"

    if-eqz v2, :cond_fd

    const v2, 0x6629e6f3

    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "283@12468L30,284@12542L712,297@13301L263,279@12218L1443"

    invoke-static {v7, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 281
    iget-object v2, v0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez v2, :cond_60

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v2, v4

    .line 282
    :cond_60
    invoke-direct {v0}, Lcom/example/bleconnectse/MainActivity;->getSimulatedNavigationTransport()Lcom/example/bleconnectse/NavigationTransport;

    move-result-object v3

    .line 283
    iget-object v6, v0, Lcom/example/bleconnectse/MainActivity;->bleTileClient:Lcom/example/bleconnectse/BleTileClient;

    if-nez v6, :cond_6e

    const-string v6, "bleTileClient"

    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_6f

    :cond_6e
    move-object v4, v6

    :goto_6f
    const v6, -0x578aec46

    .line 284
    invoke-static {v7, v6, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    .line 1631
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    if-nez v6, :cond_87

    .line 1632
    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v8, v6, :cond_8f

    .line 284
    :cond_87
    new-instance v8, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda26;

    invoke-direct {v8, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda26;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1634
    invoke-interface {v7, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 284
    :cond_8f
    check-cast v8, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v6, -0x578ae05c

    .line 285
    invoke-static {v7, v6, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    .line 1637
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    if-nez v6, :cond_ac

    .line 1638
    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v9, v6, :cond_b4

    .line 285
    :cond_ac
    new-instance v9, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda2;

    invoke-direct {v9, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda2;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1640
    invoke-interface {v7, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 285
    :cond_b4
    check-cast v9, Lkotlin/jvm/functions/Function1;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v6, -0x578a833d

    .line 298
    invoke-static {v7, v6, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    .line 1643
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    if-nez v5, :cond_d1

    .line 1644
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v6, v5, :cond_d9

    .line 298
    :cond_d1
    new-instance v6, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda3;

    invoke-direct {v6, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda3;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1646
    invoke-interface {v7, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 298
    :cond_d9
    move-object v5, v6

    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 303
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/PaddingKt;->padding(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/PaddingValues;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    sget v0, Lcom/example/bleconnectse/YadeaOtaClient;->$stable:I

    sget v1, Lcom/example/bleconnectse/BleTileClient;->$stable:I

    shl-int/lit8 v1, v1, 0x6

    or-int/2addr v0, v1

    move-object v1, v3

    move-object v3, v8

    move v8, v0

    move-object v0, v2

    move-object v2, v4

    move-object v4, v9

    const/4 v9, 0x0

    .line 280
    invoke-static/range {v0 .. v9}, Lcom/example/bleconnectse/MainActivityKt;->access$SimulatedNavigationScreen(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/NavigationTransport;Lcom/example/bleconnectse/BleTileClient;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    .line 279
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_2ed

    :cond_fd
    const v2, 0x6640b7e8

    .line 305
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "310@14018L52,311@14111L165,315@14318L168,319@14536L119,322@14707L25,323@14784L25,324@14854L26,325@14931L22,327@15062L17,328@15132L106,331@15286L106,305@13715L1774"

    invoke-static {v7, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 307
    iget-object v2, v0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez v2, :cond_110

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_111

    :cond_110
    move-object v4, v2

    .line 308
    :goto_111
    iget-object v2, v0, Lcom/example/bleconnectse/MainActivity;->appLogs:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    check-cast v2, Ljava/util/List;

    move-object v3, v2

    .line 309
    invoke-direct {v0}, Lcom/example/bleconnectse/MainActivity;->getHasPermissions()Z

    move-result v2

    move-object v6, v3

    .line 310
    invoke-direct {v0}, Lcom/example/bleconnectse/MainActivity;->getActiveCandidatePanel()Lcom/example/bleconnectse/CandidatePanel;

    move-result-object v3

    const v8, -0x578a2a70

    .line 311
    invoke-static {v7, v8, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    .line 1649
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    if-nez v8, :cond_137

    .line 1650
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v9, v8, :cond_13f

    .line 311
    :cond_137
    new-instance v9, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda4;

    invoke-direct {v9, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda4;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1652
    invoke-interface {v7, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 311
    :cond_13f
    check-cast v9, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v8, -0x578a1e5f

    .line 312
    invoke-static {v7, v8, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    .line 1655
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    if-nez v8, :cond_15c

    .line 1656
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v10, v8, :cond_164

    .line 312
    :cond_15c
    new-instance v10, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda5;

    invoke-direct {v10, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda5;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1658
    invoke-interface {v7, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 312
    :cond_164
    check-cast v10, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v8, -0x578a047c

    .line 316
    invoke-static {v7, v8, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    .line 1661
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    if-nez v8, :cond_181

    .line 1662
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v11, v8, :cond_189

    .line 316
    :cond_181
    new-instance v11, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda6;

    invoke-direct {v11, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda6;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1664
    invoke-interface {v7, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 316
    :cond_189
    check-cast v11, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v8, -0x5789e96d

    .line 320
    invoke-static {v7, v8, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    .line 1667
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    if-nez v8, :cond_1a6

    .line 1668
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v12, v8, :cond_1ae

    .line 320
    :cond_1a6
    new-instance v12, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda7;

    invoke-direct {v12, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda7;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1670
    invoke-interface {v7, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 320
    :cond_1ae
    check-cast v12, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v8, -0x5789d46b

    .line 323
    invoke-static {v7, v8, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    .line 1673
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    if-nez v8, :cond_1cb

    .line 1674
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v13, v8, :cond_1d3

    .line 323
    :cond_1cb
    new-instance v13, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda8;

    invoke-direct {v13, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda8;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1676
    invoke-interface {v7, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 323
    :cond_1d3
    move-object v8, v13

    check-cast v8, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v13, -0x5789cacb

    .line 324
    invoke-static {v7, v13, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    .line 1679
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    if-nez v13, :cond_1f1

    .line 1680
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v14, v13, :cond_1f9

    .line 324
    :cond_1f1
    new-instance v14, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda9;

    invoke-direct {v14, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda9;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1682
    invoke-interface {v7, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 324
    :cond_1f9
    check-cast v14, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v13, -0x5789c20a

    .line 325
    invoke-static {v7, v13, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    .line 1685
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    if-nez v13, :cond_216

    .line 1686
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v15, v13, :cond_21e

    .line 325
    :cond_216
    new-instance v15, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda10;

    invoke-direct {v15, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda10;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1688
    invoke-interface {v7, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 325
    :cond_21e
    check-cast v15, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v13, -0x5789b86e

    .line 326
    invoke-static {v7, v13, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    move/from16 p3, v2

    .line 1691
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    if-nez v13, :cond_23d

    .line 1692
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v2, v13, :cond_245

    .line 326
    :cond_23d
    new-instance v2, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda27;

    invoke-direct {v2, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda27;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1694
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 326
    :cond_245
    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v13, -0x5789a813

    .line 328
    invoke-static {v7, v13, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    move-object/from16 v16, v2

    .line 1697
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    if-nez v13, :cond_264

    .line 1698
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v2, v13, :cond_26c

    .line 328
    :cond_264
    new-instance v2, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda28;

    invoke-direct {v2, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda28;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1700
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 328
    :cond_26c
    move-object v13, v2

    check-cast v13, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v2, -0x57899efa

    .line 329
    invoke-static {v7, v2, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    move/from16 v17, v2

    .line 1703
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    if-nez v17, :cond_28f

    .line 1704
    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v18, v3

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v2, v3, :cond_299

    goto :goto_291

    :cond_28f
    move-object/from16 v18, v3

    .line 329
    :goto_291
    new-instance v2, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda29;

    invoke-direct {v2, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda29;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1706
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 329
    :cond_299
    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v3, -0x57898bba

    .line 332
    invoke-static {v7, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .line 1709
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    if-nez v3, :cond_2b6

    .line 1710
    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v5, v3, :cond_2be

    .line 332
    :cond_2b6
    new-instance v5, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {v5, v0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    .line 1712
    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 332
    :cond_2be
    check-cast v5, Lkotlin/jvm/functions/Function0;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 335
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/PaddingKt;->padding(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/PaddingValues;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move-object/from16 v3, v18

    sget v18, Lcom/example/bleconnectse/YadeaOtaClient;->$stable:I

    const/16 v19, 0x180

    const/16 v20, 0x0

    move-object v7, v12

    const/4 v12, 0x0

    move-object v1, v15

    move-object v15, v5

    move-object v5, v10

    move-object v10, v1

    move-object/from16 v17, p2

    move-object v1, v6

    move-object v6, v11

    move-object/from16 v11, v16

    move-object/from16 v16, v0

    move-object v0, v4

    move-object v4, v9

    move-object v9, v14

    move-object v14, v2

    move/from16 v2, p3

    .line 306
    invoke-static/range {v0 .. v20}, Lcom/example/bleconnectse/MainActivityKt;->access$MirrorNavScreen(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/util/List;ZLcom/example/bleconnectse/CandidatePanel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;III)V

    .line 305
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_2ed
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2fa

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_2fa

    .line 249
    :cond_2f7
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 338
    :cond_2fa
    :goto_2fa
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final onCreate$lambda$55$lambda$54$lambda$51$lambda$12$lambda$11(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 1

    .line 258
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->closeAmapNavigation()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final onCreate$lambda$55$lambda$54$lambda$51$lambda$14$lambda$13(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 1

    .line 259
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->acceptAmapPrivacyConsent()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final onCreate$lambda$55$lambda$54$lambda$51$lambda$16$lambda$15(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 2

    .line 261
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->permissionLauncher:Landroidx/activity/result/ActivityResultLauncher;

    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->locationPermissions()[Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    .line 262
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final onCreate$lambda$55$lambda$54$lambda$51$lambda$18$lambda$17(Lcom/example/bleconnectse/MainActivity;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 263
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->setAmapNavigationStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final onCreate$lambda$55$lambda$54$lambda$51$lambda$20$lambda$19(Lcom/example/bleconnectse/MainActivity;Lcom/example/bleconnectse/AmapNavigationView;)Lkotlin/Unit;
    .registers 4

    const-string/jumbo v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 265
    iput-object p1, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

    .line 267
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getAmapNavigationTransport()Lcom/example/bleconnectse/NavigationTransport;

    move-result-object v0

    sget-object v1, Lcom/example/bleconnectse/NavigationTransport;->WifiMirror:Lcom/example/bleconnectse/NavigationTransport;

    if-ne v0, v1, :cond_19

    .line 268
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getAmapNavigationMirrorOn()Z

    move-result p0

    if-eqz p0, :cond_19

    .line 270
    invoke-virtual {p1}, Lcom/example/bleconnectse/AmapNavigationView;->startPublishing()V

    .line 272
    :cond_19
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final onCreate$lambda$55$lambda$54$lambda$51$lambda$22$lambda$21(Lcom/example/bleconnectse/MainActivity;Lcom/example/bleconnectse/AmapNavigationView;)Lkotlin/Unit;
    .registers 3

    const-string/jumbo v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 274
    invoke-virtual {p1}, Lcom/example/bleconnectse/AmapNavigationView;->close()V

    .line 275
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

    if-ne v0, p1, :cond_10

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

    .line 276
    :cond_10
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$24$lambda$23(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 1

    .line 284
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->closeSimulatedNavigation()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$26$lambda$25(Lcom/example/bleconnectse/MainActivity;Lcom/example/bleconnectse/SimulatedNavigationView;)Lkotlin/Unit;
    .registers 4

    const-string/jumbo v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 286
    iput-object p1, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationView:Lcom/example/bleconnectse/SimulatedNavigationView;

    .line 288
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getSimulatedNavigationTransport()Lcom/example/bleconnectse/NavigationTransport;

    move-result-object v0

    sget-object v1, Lcom/example/bleconnectse/NavigationTransport;->WifiMirror:Lcom/example/bleconnectse/NavigationTransport;

    if-ne v0, v1, :cond_1a

    .line 289
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getSimulatedNavigationMirrorOn()Z

    move-result v0

    if-eqz v0, :cond_1a

    .line 291
    invoke-virtual {p1}, Lcom/example/bleconnectse/SimulatedNavigationView;->startPublishing()V

    goto :goto_36

    .line 293
    :cond_1a
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getSimulatedNavigationTransport()Lcom/example/bleconnectse/NavigationTransport;

    move-result-object v0

    sget-object v1, Lcom/example/bleconnectse/NavigationTransport;->BleTiles:Lcom/example/bleconnectse/NavigationTransport;

    if-ne v0, v1, :cond_36

    .line 295
    new-instance v0, Lcom/example/bleconnectse/MainActivity$onCreate$6$1$1$8$1$1;

    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->bleTileClient:Lcom/example/bleconnectse/BleTileClient;

    if-nez p0, :cond_2e

    const-string p0, "bleTileClient"

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 p0, 0x0

    :cond_2e
    invoke-direct {v0, p0}, Lcom/example/bleconnectse/MainActivity$onCreate$6$1$1$8$1$1;-><init>(Ljava/lang/Object;)V

    check-cast v0, Lkotlin/jvm/functions/Function2;

    invoke-virtual {p1, v0}, Lcom/example/bleconnectse/SimulatedNavigationView;->setOnBleTileDemandChanged(Lkotlin/jvm/functions/Function2;)V

    .line 297
    :cond_36
    :goto_36
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$28$lambda$27(Lcom/example/bleconnectse/MainActivity;Lcom/example/bleconnectse/SimulatedNavigationView;)Lkotlin/Unit;
    .registers 4

    const-string/jumbo v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    .line 299
    invoke-virtual {p1, v0}, Lcom/example/bleconnectse/SimulatedNavigationView;->setOnBleTileDemandChanged(Lkotlin/jvm/functions/Function2;)V

    .line 300
    invoke-virtual {p1}, Lcom/example/bleconnectse/SimulatedNavigationView;->stopPublishing()V

    .line 301
    iget-object v1, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationView:Lcom/example/bleconnectse/SimulatedNavigationView;

    if-ne v1, p1, :cond_13

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationView:Lcom/example/bleconnectse/SimulatedNavigationView;

    .line 302
    :cond_13
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$30$lambda$29(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 2

    .line 311
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->permissionLauncher:Landroidx/activity/result/ActivityResultLauncher;

    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->requiredPermissions()[Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$32$lambda$31(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 2

    .line 313
    sget-object v0, Lcom/example/bleconnectse/CandidatePanel;->Ap:Lcom/example/bleconnectse/CandidatePanel;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setActiveCandidatePanel(Lcom/example/bleconnectse/CandidatePanel;)V

    .line 314
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    const/4 v0, 0x0

    if-nez p0, :cond_10

    const-string p0, "mirrorClient"

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object p0, v0

    :cond_10
    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->connectAp(Ljava/lang/String;)V

    .line 315
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$34$lambda$33(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 2

    .line 317
    sget-object v0, Lcom/example/bleconnectse/CandidatePanel;->P2p:Lcom/example/bleconnectse/CandidatePanel;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setActiveCandidatePanel(Lcom/example/bleconnectse/CandidatePanel;)V

    .line 318
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    const/4 v0, 0x0

    if-nez p0, :cond_10

    const-string p0, "mirrorClient"

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object p0, v0

    :cond_10
    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->discoverP2p(Ljava/lang/String;)V

    .line 319
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$36$lambda$35(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 4

    .line 321
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorMediaPicker:Landroidx/activity/result/ActivityResultLauncher;

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "image/*"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string/jumbo v2, "video/*"

    aput-object v2, v0, v1

    invoke-virtual {p0, v0}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    .line 322
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$38$lambda$37(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 1

    .line 323
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->requestCameraMirror()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$40$lambda$39(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 1

    .line 324
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->requestScreenMirror()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$42$lambda$41(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 1

    .line 325
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->stopAllMirrorSources()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$44$lambda$43(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 1

    .line 326
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->openSimulatedMap()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$46$lambda$45(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 1

    .line 328
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->openAmapMap()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$48$lambda$47(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 2

    .line 330
    sget-object v0, Lcom/example/bleconnectse/PendingBleEntry;->Simulated:Lcom/example/bleconnectse/PendingBleEntry;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->requestBleTiles(Lcom/example/bleconnectse/PendingBleEntry;)V

    .line 331
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$51$lambda$50$lambda$49(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 4

    .line 333
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->wallpaperPicker:Landroidx/activity/result/ActivityResultLauncher;

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "image/*"

    aput-object v2, v0, v1

    invoke-virtual {p0, v0}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    .line 334
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$55$lambda$54$lambda$53$lambda$52(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 1

    .line 342
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->stopAllMirrorSources()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$6(Lcom/example/bleconnectse/MainActivity;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3

    const-string v0, "message"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->logLine(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$7(Lcom/example/bleconnectse/MainActivity;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3

    const-string v0, "message"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 224
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->logLine(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$8(Lcom/example/bleconnectse/MainActivity;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3

    const-string v0, "message"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 229
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->logLine(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onCreate$lambda$9(Lcom/example/bleconnectse/MainActivity;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3

    const-string v0, "message"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 233
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->logLine(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onStart$lambda$56(Lcom/example/bleconnectse/MainActivity;)Lkotlin/Unit;
    .registers 1

    .line 365
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->stopMirrorProducers()V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private final openAmapMap()V
    .registers 1

    return-void
.end method

.method private final openBleTiles(Lcom/example/bleconnectse/PendingBleEntry;)V
    .registers 6

    .line 434
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->stopAllMirrorSources()V

    .line 435
    sget-object v0, Lcom/example/bleconnectse/MainActivity$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {p1}, Lcom/example/bleconnectse/PendingBleEntry;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x0

    const-string v1, "bleTileClient"

    const/4 v2, 0x1

    if-eq p1, v2, :cond_3f

    const/4 v3, 0x2

    if-ne p1, v3, :cond_39

    .line 444
    sget-object p1, Lcom/example/bleconnectse/NavigationTransport;->BleTiles:Lcom/example/bleconnectse/NavigationTransport;

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->setAmapNavigationTransport(Lcom/example/bleconnectse/NavigationTransport;)V

    .line 445
    const-string/jumbo p1, "高德瓦片入口预留，当前发送共享测试瓦片"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->setAmapNavigationStatus(Ljava/lang/String;)V

    .line 446
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/MainActivity;->setShowAmapNavigation(Z)V

    .line 447
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->bleTileClient:Lcom/example/bleconnectse/BleTileClient;

    if-nez p0, :cond_2a

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_2b

    :cond_2a
    move-object v0, p0

    :goto_2b
    sget-object p0, Lcom/example/bleconnectse/BleTileSource;->AmapTest:Lcom/example/bleconnectse/BleTileSource;

    invoke-virtual {v0, p0}, Lcom/example/bleconnectse/BleTileClient;->startScan(Lcom/example/bleconnectse/BleTileSource;)V

    .line 448
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo p1, "进入高德瓦片，开始扫描BLE仪表"

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    return-void

    .line 435
    :cond_39
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p0

    .line 437
    :cond_3f
    sget-object p1, Lcom/example/bleconnectse/NavigationTransport;->BleTiles:Lcom/example/bleconnectse/NavigationTransport;

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->setSimulatedNavigationTransport(Lcom/example/bleconnectse/NavigationTransport;)V

    .line 438
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/MainActivity;->setShowSimulatedNavigation(Z)V

    .line 439
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->bleTileClient:Lcom/example/bleconnectse/BleTileClient;

    if-nez p0, :cond_4f

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_50

    :cond_4f
    move-object v0, p0

    :goto_50
    sget-object p0, Lcom/example/bleconnectse/BleTileSource;->Simulated:Lcom/example/bleconnectse/BleTileSource;

    invoke-virtual {v0, p0}, Lcom/example/bleconnectse/BleTileClient;->startScan(Lcom/example/bleconnectse/BleTileSource;)V

    .line 440
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo p1, "进入模拟瓦片，开始扫描BLE仪表"

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    return-void
.end method

.method private final openSimulatedMap()V
    .registers 3

    .line 407
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->bleTileClient:Lcom/example/bleconnectse/BleTileClient;

    if-nez v0, :cond_a

    const-string v0, "bleTileClient"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v0, 0x0

    :cond_a
    invoke-virtual {v0}, Lcom/example/bleconnectse/BleTileClient;->disconnect()V

    .line 408
    sget-object v0, Lcom/example/bleconnectse/NavigationTransport;->WifiMirror:Lcom/example/bleconnectse/NavigationTransport;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setSimulatedNavigationTransport(Lcom/example/bleconnectse/NavigationTransport;)V

    const/4 v0, 0x1

    .line 409
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setShowSimulatedNavigation(Z)V

    .line 410
    sget-object v0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v1, "进入模拟地图，自动启动WiFi投屏"

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 411
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->startSimulatedNavigationMirror()V

    return-void
.end method

.method static final permissionLauncher$lambda$2(Lcom/example/bleconnectse/MainActivity;Ljava/util/Map;)V
    .registers 3

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 167
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->hasRequiredPermissions()Z

    move-result p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->setHasPermissions(Z)V

    .line 168
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->hasLocationPermission()Z

    move-result p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->setHasLocationPermission(Z)V

    .line 169
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->getHasPermissions()Z

    move-result p1

    if-eqz p1, :cond_1d

    const-string/jumbo p1, "权限已授予"

    goto :goto_20

    :cond_1d
    const-string/jumbo p1, "缺少 WiFi/定位权限，无法扫描或连接仪表"

    :goto_20
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->logLine(Ljava/lang/String;)V

    return-void
.end method

.method private final requestBleTiles(Lcom/example/bleconnectse/PendingBleEntry;)V
    .registers 3

    .line 425
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->hasBlePermissions()Z

    move-result v0

    if-eqz v0, :cond_a

    .line 426
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->openBleTiles(Lcom/example/bleconnectse/PendingBleEntry;)V

    return-void

    .line 428
    :cond_a
    iput-object p1, p0, Lcom/example/bleconnectse/MainActivity;->pendingBleEntry:Lcom/example/bleconnectse/PendingBleEntry;

    .line 429
    iget-object p1, p0, Lcom/example/bleconnectse/MainActivity;->blePermissionLauncher:Landroidx/activity/result/ActivityResultLauncher;

    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->blePermissions()[Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    return-void
.end method

.method private final requestCameraMirror()V
    .registers 3

    .line 380
    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    const-string v1, "android.permission.CAMERA"

    invoke-static {v0, v1}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_f

    .line 383
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->startCameraMirror()V

    return-void

    :cond_f
    const/4 v0, 0x1

    .line 385
    iput-boolean v0, p0, Lcom/example/bleconnectse/MainActivity;->pendingCameraMirror:Z

    .line 386
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->cameraPermissionLauncher:Landroidx/activity/result/ActivityResultLauncher;

    invoke-virtual {p0, v1}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    return-void
.end method

.method private final requestScreenMirror()V
    .registers 3

    .line 402
    const-class v0, Landroid/media/projection/MediaProjectionManager;

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/projection/MediaProjectionManager;

    .line 403
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->screenCaptureLauncher:Landroidx/activity/result/ActivityResultLauncher;

    invoke-virtual {v0}, Landroid/media/projection/MediaProjectionManager;->createScreenCaptureIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "createScreenCaptureIntent(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    return-void
.end method

.method private final requiredPermissions()[Ljava/lang/String;
    .registers 4

    const/4 p0, 0x2

    .line 591
    new-array p0, p0, [Ljava/lang/String;

    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    const/4 v1, 0x0

    aput-object v0, p0, v1

    const/4 v0, 0x1

    .line 592
    const-string v2, "android.permission.ACCESS_FINE_LOCATION"

    aput-object v2, p0, v0

    .line 590
    invoke-static {p0}, Lkotlin/collections/CollectionsKt;->mutableListOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    .line 594
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x21

    if-lt v0, v2, :cond_24

    .line 595
    move-object v0, p0

    check-cast v0, Ljava/util/Collection;

    const-string v2, "android.permission.NEARBY_WIFI_DEVICES"

    invoke-interface {v0, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 596
    const-string v2, "android.permission.POST_NOTIFICATIONS"

    invoke-interface {v0, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 598
    :cond_24
    check-cast p0, Ljava/util/Collection;

    .line 1594
    new-array v0, v1, [Ljava/lang/String;

    invoke-interface {p0, v0}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Ljava/lang/String;

    return-object p0
.end method

.method static final screenCaptureLauncher$lambda$5(Lcom/example/bleconnectse/MainActivity;Landroidx/activity/result/ActivityResult;)V
    .registers 10

    const-string v0, "result"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 196
    invoke-virtual {p1}, Landroidx/activity/result/ActivityResult;->getResultCode()I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_76

    invoke-virtual {p1}, Landroidx/activity/result/ActivityResult;->getData()Landroid/content/Intent;

    move-result-object v0

    if-nez v0, :cond_13

    goto :goto_76

    .line 200
    :cond_13
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->cameraMirrorController:Lcom/example/bleconnectse/CameraMirrorController;

    const/4 v1, 0x0

    if-nez v0, :cond_1e

    const-string v0, "cameraMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_1e
    invoke-virtual {v0}, Lcom/example/bleconnectse/CameraMirrorController;->stop()V

    .line 201
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    if-nez v0, :cond_2c

    const-string/jumbo v0, "videoMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_2c
    invoke-virtual {v0}, Lcom/example/bleconnectse/VideoMirrorController;->stop()V

    .line 202
    sget-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    invoke-virtual {v0, v2}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 203
    sget-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    .line 204
    sget-object v0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v3, "手机屏幕投屏授权通过，启动取帧服务"

    invoke-virtual {v0, v3}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 207
    sget-object v0, Lcom/example/bleconnectse/ScreenCaptureService;->Companion:Lcom/example/bleconnectse/ScreenCaptureService$Companion;

    invoke-virtual {p1}, Landroidx/activity/result/ActivityResult;->getResultCode()I

    move-result v3

    invoke-virtual {p1}, Landroidx/activity/result/ActivityResult;->getData()Landroid/content/Intent;

    move-result-object p1

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v0, v2, v3, p1}, Lcom/example/bleconnectse/ScreenCaptureService$Companion;->startIntent(Landroid/content/Context;ILandroid/content/Intent;)Landroid/content/Intent;

    move-result-object p1

    .line 205
    invoke-static {v2, p1}, Landroidx/core/content/ContextCompat;->startForegroundService(Landroid/content/Context;Landroid/content/Intent;)V

    .line 209
    move-object p1, p0

    check-cast p1, Landroidx/lifecycle/LifecycleOwner;

    invoke-static {p1}, Landroidx/lifecycle/LifecycleOwnerKt;->getLifecycleScope(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScope;

    move-result-object p1

    move-object v2, p1

    check-cast v2, Lkotlinx/coroutines/CoroutineScope;

    new-instance p1, Lcom/example/bleconnectse/MainActivity$screenCaptureLauncher$1$1;

    invoke-direct {p1, p0, v1}, Lcom/example/bleconnectse/MainActivity$screenCaptureLauncher$1$1;-><init>(Lcom/example/bleconnectse/MainActivity;Lkotlin/coroutines/Continuation;)V

    move-object v5, p1

    check-cast v5, Lkotlin/jvm/functions/Function2;

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static/range {v2 .. v7}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    return-void

    .line 197
    :cond_76
    :goto_76
    const-string/jumbo p1, "手机屏幕投屏授权已取消"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/MainActivity;->logLine(Ljava/lang/String;)V

    return-void
.end method

.method private final setActiveCandidatePanel(Lcom/example/bleconnectse/CandidatePanel;)V
    .registers 2

    .line 103
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->activeCandidatePanel$delegate:Landroidx/compose/runtime/MutableState;

    .line 1558
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setAmapNavigationMirrorOn(Z)V
    .registers 2

    .line 109
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationMirrorOn$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 1573
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setAmapNavigationStatus(Ljava/lang/String;)V
    .registers 2

    .line 111
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationStatus$delegate:Landroidx/compose/runtime/MutableState;

    .line 1579
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setAmapNavigationTransport(Lcom/example/bleconnectse/NavigationTransport;)V
    .registers 2

    .line 110
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationTransport$delegate:Landroidx/compose/runtime/MutableState;

    .line 1576
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setAmapPrivacyAgreed(Z)V
    .registers 2

    .line 113
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->amapPrivacyAgreed$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 1582
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setHasLocationPermission(Z)V
    .registers 2

    .line 114
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->hasLocationPermission$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 1585
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setHasPermissions(Z)V
    .registers 2

    .line 101
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->hasPermissions$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 1555
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setShowAmapNavigation(Z)V
    .registers 2

    .line 108
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->showAmapNavigation$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 1570
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setShowSimulatedNavigation(Z)V
    .registers 2

    .line 104
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->showSimulatedNavigation$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 1561
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setSimulatedNavigationMirrorOn(Z)V
    .registers 2

    .line 105
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationMirrorOn$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 1564
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setSimulatedNavigationTransport(Lcom/example/bleconnectse/NavigationTransport;)V
    .registers 2

    .line 106
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationTransport$delegate:Landroidx/compose/runtime/MutableState;

    .line 1567
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final startAmapNavigationMirror()V
    .registers 4

    .line 483
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->cameraMirrorController:Lcom/example/bleconnectse/CameraMirrorController;

    const/4 v1, 0x0

    if-nez v0, :cond_b

    const-string v0, "cameraMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_b
    invoke-virtual {v0}, Lcom/example/bleconnectse/CameraMirrorController;->stop()V

    .line 484
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    if-nez v0, :cond_19

    const-string/jumbo v0, "videoMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_19
    invoke-virtual {v0}, Lcom/example/bleconnectse/VideoMirrorController;->stop()V

    .line 485
    sget-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    invoke-virtual {v0, v2}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 486
    sget-object v0, Lcom/example/bleconnectse/ScreenCaptureService;->Companion:Lcom/example/bleconnectse/ScreenCaptureService$Companion;

    invoke-virtual {v0, v2}, Lcom/example/bleconnectse/ScreenCaptureService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 487
    sget-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    .line 488
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez v0, :cond_40

    const-string v0, "mirrorClient"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_41

    :cond_40
    move-object v1, v0

    :goto_41
    const-string/jumbo v0, "高德导航"

    invoke-virtual {v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->startLiveMirror(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5d

    const/4 v0, 0x1

    .line 489
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setAmapNavigationMirrorOn(Z)V

    .line 490
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

    if-eqz p0, :cond_55

    invoke-virtual {p0}, Lcom/example/bleconnectse/AmapNavigationView;->startPublishing()V

    .line 491
    :cond_55
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v0, "高德导航投屏启动"

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    :cond_5d
    return-void
.end method

.method private final startCameraMirror()V
    .registers 4

    .line 391
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    const/4 v1, 0x0

    if-nez v0, :cond_c

    const-string/jumbo v0, "videoMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_c
    invoke-virtual {v0}, Lcom/example/bleconnectse/VideoMirrorController;->stop()V

    .line 392
    sget-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    invoke-virtual {v0, v2}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 393
    sget-object v0, Lcom/example/bleconnectse/ScreenCaptureService;->Companion:Lcom/example/bleconnectse/ScreenCaptureService$Companion;

    invoke-virtual {v0, v2}, Lcom/example/bleconnectse/ScreenCaptureService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 394
    sget-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    .line 395
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->cameraMirrorController:Lcom/example/bleconnectse/CameraMirrorController;

    if-nez v0, :cond_33

    const-string v0, "cameraMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_33
    invoke-virtual {v0}, Lcom/example/bleconnectse/CameraMirrorController;->start()V

    .line 396
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez p0, :cond_40

    const-string p0, "mirrorClient"

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_41

    :cond_40
    move-object v1, p0

    :goto_41
    const-string/jumbo p0, "摄像头"

    invoke-virtual {v1, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->startLiveMirror(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_52

    .line 397
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v0, "摄像头投屏启动"

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    :cond_52
    return-void
.end method

.method private final startSimulatedNavigationMirror()V
    .registers 4

    .line 454
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->cameraMirrorController:Lcom/example/bleconnectse/CameraMirrorController;

    const/4 v1, 0x0

    if-nez v0, :cond_b

    const-string v0, "cameraMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_b
    invoke-virtual {v0}, Lcom/example/bleconnectse/CameraMirrorController;->stop()V

    .line 455
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    if-nez v0, :cond_19

    const-string/jumbo v0, "videoMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_19
    invoke-virtual {v0}, Lcom/example/bleconnectse/VideoMirrorController;->stop()V

    .line 456
    sget-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    invoke-virtual {v0, v2}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 457
    sget-object v0, Lcom/example/bleconnectse/ScreenCaptureService;->Companion:Lcom/example/bleconnectse/ScreenCaptureService$Companion;

    invoke-virtual {v0, v2}, Lcom/example/bleconnectse/ScreenCaptureService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 458
    sget-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    .line 459
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez v0, :cond_40

    const-string v0, "mirrorClient"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_41

    :cond_40
    move-object v1, v0

    :goto_41
    const-string/jumbo v0, "模拟导航"

    invoke-virtual {v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->startLiveMirror(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5d

    const/4 v0, 0x1

    .line 460
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setSimulatedNavigationMirrorOn(Z)V

    .line 461
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationView:Lcom/example/bleconnectse/SimulatedNavigationView;

    if-eqz p0, :cond_55

    invoke-virtual {p0}, Lcom/example/bleconnectse/SimulatedNavigationView;->startPublishing()V

    .line 462
    :cond_55
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v0, "模拟导航投屏启动"

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    :cond_5d
    return-void
.end method

.method private final stopAllMirrorSources()V
    .registers 3

    .line 544
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->stopMirrorProducers()V

    .line 545
    sget-object v0, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 546
    sget-object v0, Lcom/example/bleconnectse/ScreenCaptureService;->Companion:Lcom/example/bleconnectse/ScreenCaptureService$Companion;

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/ScreenCaptureService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 547
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez p0, :cond_22

    const-string p0, "mirrorClient"

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 p0, 0x0

    :cond_22
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->stopMirrorDemo()V

    .line 548
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {p0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    return-void
.end method

.method private final stopAmapNavigationMirror()V
    .registers 2

    .line 496
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/example/bleconnectse/AmapNavigationView;->stopPublishing()V

    :cond_7
    const/4 v0, 0x0

    .line 497
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setAmapNavigationMirrorOn(Z)V

    .line 498
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez p0, :cond_15

    const-string p0, "mirrorClient"

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 p0, 0x0

    :cond_15
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->stopMirrorDemo()V

    .line 499
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {p0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    return-void
.end method

.method private final stopMirrorProducers()V
    .registers 3

    .line 535
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationView:Lcom/example/bleconnectse/SimulatedNavigationView;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/example/bleconnectse/SimulatedNavigationView;->stopPublishing()V

    :cond_7
    const/4 v0, 0x0

    .line 536
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setSimulatedNavigationMirrorOn(Z)V

    .line 537
    iget-object v1, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

    if-eqz v1, :cond_12

    invoke-virtual {v1}, Lcom/example/bleconnectse/AmapNavigationView;->stopPublishing()V

    .line 538
    :cond_12
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setAmapNavigationMirrorOn(Z)V

    .line 539
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->cameraMirrorController:Lcom/example/bleconnectse/CameraMirrorController;

    const/4 v1, 0x0

    if-nez v0, :cond_20

    const-string v0, "cameraMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_20
    invoke-virtual {v0}, Lcom/example/bleconnectse/CameraMirrorController;->stop()V

    .line 540
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    if-nez p0, :cond_2e

    const-string/jumbo p0, "videoMirrorController"

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_2f

    :cond_2e
    move-object v1, p0

    :goto_2f
    invoke-virtual {v1}, Lcom/example/bleconnectse/VideoMirrorController;->stop()V

    return-void
.end method

.method private final stopSimulatedNavigationMirror()V
    .registers 2

    .line 467
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->simulatedNavigationView:Lcom/example/bleconnectse/SimulatedNavigationView;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/example/bleconnectse/SimulatedNavigationView;->stopPublishing()V

    :cond_7
    const/4 v0, 0x0

    .line 468
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setSimulatedNavigationMirrorOn(Z)V

    .line 469
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez p0, :cond_15

    const-string p0, "mirrorClient"

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 p0, 0x0

    :cond_15
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->stopMirrorDemo()V

    .line 470
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {p0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    return-void
.end method

.method static final wallpaperPicker$lambda$1(Lcom/example/bleconnectse/MainActivity;Landroid/net/Uri;)V
    .registers 4

    if-nez p1, :cond_3

    return-void

    .line 155
    :cond_3
    :try_start_3
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/content/ContentResolver;->takePersistableUriPermission(Landroid/net/Uri;I)V
    :try_end_b
    .catch Ljava/lang/SecurityException; {:try_start_3 .. :try_end_b} :catch_c

    goto :goto_12

    .line 160
    :catch_c
    const-string/jumbo v0, "仪表壁纸本次可读，但无法保留长期读取权限"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->logLine(Ljava/lang/String;)V

    .line 162
    :goto_12
    iget-object p0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez p0, :cond_1c

    const-string p0, "mirrorClient"

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 p0, 0x0

    :cond_1c
    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->startInstrumentWallpaper(Landroid/net/Uri;)Z

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .registers 7

    .line 218
    invoke-super {p0, p1}, Landroidx/activity/ComponentActivity;->onCreate(Landroid/os/Bundle;)V

    .line 219
    move-object p1, p0

    check-cast p1, Landroidx/activity/ComponentActivity;

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p1, v1, v1, v0, v1}, Landroidx/activity/EdgeToEdge;->enable$default(Landroidx/activity/ComponentActivity;Landroidx/activity/SystemBarStyle;Landroidx/activity/SystemBarStyle;ILjava/lang/Object;)V

    .line 220
    sget-object v0, Lcom/example/bleconnectse/AppConnectionSession;->INSTANCE:Lcom/example/bleconnectse/AppConnectionSession;

    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    new-instance v3, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda16;

    invoke-direct {v3, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda16;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-virtual {v0, v2, v3}, Lcom/example/bleconnectse/AppConnectionSession;->obtain(Landroid/content/Context;Lkotlin/jvm/functions/Function1;)Lcom/example/bleconnectse/YadeaOtaClient;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    .line 221
    new-instance v0, Lcom/example/bleconnectse/BleTileClient;

    .line 223
    new-instance v3, Lcom/example/bleconnectse/SyntheticTileRepository;

    invoke-direct {v3}, Lcom/example/bleconnectse/SyntheticTileRepository;-><init>()V

    .line 221
    new-instance v4, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda17;

    invoke-direct {v4, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda17;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-direct {v0, v2, v3, v4}, Lcom/example/bleconnectse/BleTileClient;-><init>(Landroid/content/Context;Lcom/example/bleconnectse/SyntheticTileRepository;Lkotlin/jvm/functions/Function1;)V

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->bleTileClient:Lcom/example/bleconnectse/BleTileClient;

    .line 226
    new-instance v0, Lcom/example/bleconnectse/CameraMirrorController;

    .line 228
    move-object v3, p0

    check-cast v3, Landroidx/lifecycle/LifecycleOwner;

    .line 226
    new-instance v4, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda18;

    invoke-direct {v4, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda18;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-direct {v0, v2, v3, v4}, Lcom/example/bleconnectse/CameraMirrorController;-><init>(Landroid/content/Context;Landroidx/lifecycle/LifecycleOwner;Lkotlin/jvm/functions/Function1;)V

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->cameraMirrorController:Lcom/example/bleconnectse/CameraMirrorController;

    .line 231
    new-instance v0, Lcom/example/bleconnectse/VideoMirrorController;

    new-instance v3, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda19;

    invoke-direct {v3, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda19;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    new-instance v4, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda20;

    invoke-direct {v4, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda20;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-direct {v0, v2, v3, v4}, Lcom/example/bleconnectse/VideoMirrorController;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V

    iput-object v0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    .line 239
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->hasRequiredPermissions()Z

    move-result v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setHasPermissions(Z)V

    .line 240
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->hasLocationPermission()Z

    move-result v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/MainActivity;->setHasLocationPermission(Z)V

    .line 247
    new-instance v0, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda21;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda21;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    const p0, -0x19b240f0

    const/4 v2, 0x1

    invoke-static {p0, v2, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object p0

    check-cast p0, Lkotlin/jvm/functions/Function2;

    invoke-static {p1, v1, p0, v2, v1}, Landroidx/activity/compose/ComponentActivityKt;->setContent$default(Landroidx/activity/ComponentActivity;Landroidx/compose/runtime/CompositionContext;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)V

    return-void
.end method

.method protected onDestroy()V
    .registers 3

    .line 350
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    const/4 v1, 0x0

    if-nez v0, :cond_b

    const-string v0, "mirrorClient"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_b
    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setOnMirrorSessionEnded(Lkotlin/jvm/functions/Function0;)V

    .line 351
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_18

    .line 352
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->stopAllMirrorSources()V

    goto :goto_26

    .line 354
    :cond_18
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    if-nez v0, :cond_23

    const-string/jumbo v0, "videoMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_23
    invoke-virtual {v0}, Lcom/example/bleconnectse/VideoMirrorController;->stop()V

    .line 356
    :goto_26
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

    if-eqz v0, :cond_2d

    invoke-virtual {v0}, Lcom/example/bleconnectse/AmapNavigationView;->close()V

    .line 357
    :cond_2d
    iput-object v1, p0, Lcom/example/bleconnectse/MainActivity;->amapNavigationView:Lcom/example/bleconnectse/AmapNavigationView;

    .line 358
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->bleTileClient:Lcom/example/bleconnectse/BleTileClient;

    if-nez v0, :cond_39

    const-string v0, "bleTileClient"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_39
    invoke-virtual {v0}, Lcom/example/bleconnectse/BleTileClient;->close()V

    .line 359
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->cameraMirrorController:Lcom/example/bleconnectse/CameraMirrorController;

    if-nez v0, :cond_46

    const-string v0, "cameraMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_47

    :cond_46
    move-object v1, v0

    :goto_47
    invoke-virtual {v1}, Lcom/example/bleconnectse/CameraMirrorController;->close()V

    .line 360
    invoke-super {p0}, Landroidx/activity/ComponentActivity;->onDestroy()V

    return-void
.end method

.method protected onStart()V
    .registers 5

    .line 364
    invoke-super {p0}, Landroidx/activity/ComponentActivity;->onStart()V

    .line 365
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    const-string v1, "mirrorClient"

    const/4 v2, 0x0

    if-nez v0, :cond_e

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v2

    :cond_e
    new-instance v3, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda15;

    invoke-direct {v3, p0}, Lcom/example/bleconnectse/MainActivity$$ExternalSyntheticLambda15;-><init>(Lcom/example/bleconnectse/MainActivity;)V

    invoke-virtual {v0, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->setOnMirrorSessionEnded(Lkotlin/jvm/functions/Function0;)V

    .line 366
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->mirrorClient:Lcom/example/bleconnectse/YadeaOtaClient;

    if-nez v0, :cond_1e

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v2

    :cond_1e
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaOtaClient;->hasActiveMirrorSession()Z

    move-result v0

    if-nez v0, :cond_27

    .line 367
    invoke-direct {p0}, Lcom/example/bleconnectse/MainActivity;->stopMirrorProducers()V

    .line 369
    :cond_27
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    if-nez v0, :cond_32

    const-string/jumbo v0, "videoMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_33

    :cond_32
    move-object v2, v0

    :goto_33
    check-cast p0, Landroid/content/Context;

    invoke-virtual {v2, p0}, Lcom/example/bleconnectse/VideoMirrorController;->enterForeground(Landroid/content/Context;)V

    return-void
.end method

.method protected onStop()V
    .registers 3

    .line 373
    invoke-virtual {p0}, Lcom/example/bleconnectse/MainActivity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_17

    .line 374
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivity;->videoMirrorController:Lcom/example/bleconnectse/VideoMirrorController;

    if-nez v0, :cond_11

    const-string/jumbo v0, "videoMirrorController"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v0, 0x0

    :cond_11
    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/VideoMirrorController;->enterBackground(Landroid/content/Context;)V

    .line 376
    :cond_17
    invoke-super {p0}, Landroidx/activity/ComponentActivity;->onStop()V

    return-void
.end method
