# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/SyntheticMapRenderer;

.field public final synthetic f$1:F

.field public final synthetic f$2:F


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/SyntheticMapRenderer;FF)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda5;->f$0:Lcom/example/bleconnectse/SyntheticMapRenderer;

    iput p2, p0, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda5;->f$1:F

    iput p3, p0, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda5;->f$2:F

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda5;->f$0:Lcom/example/bleconnectse/SyntheticMapRenderer;

    iget v1, p0, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda5;->f$1:F

    iget p0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda5;->f$2:F

    check-cast p1, Lcom/example/bleconnectse/SyntheticArea;

    invoke-static {v0, v1, p0, p1}, Lcom/example/bleconnectse/SyntheticMapRenderer;->draw$lambda$4(Lcom/example/bleconnectse/SyntheticMapRenderer;FFLcom/example/bleconnectse/SyntheticArea;)Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method
