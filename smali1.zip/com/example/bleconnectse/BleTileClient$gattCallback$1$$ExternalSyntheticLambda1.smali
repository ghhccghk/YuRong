# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/bluetooth/BluetoothGattCharacteristic;

.field public final synthetic f$1:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$2:I


# direct methods
.method public synthetic constructor <init>(Landroid/bluetooth/BluetoothGattCharacteristic;Lcom/example/bleconnectse/BleTileClient;I)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda1;->f$0:Landroid/bluetooth/BluetoothGattCharacteristic;

    iput-object p2, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda1;->f$1:Lcom/example/bleconnectse/BleTileClient;

    iput p3, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda1;->f$2:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda1;->f$0:Landroid/bluetooth/BluetoothGattCharacteristic;

    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda1;->f$1:Lcom/example/bleconnectse/BleTileClient;

    iget p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda1;->f$2:I

    invoke-static {v0, v1, p0}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->onCharacteristicWrite$lambda$4(Landroid/bluetooth/BluetoothGattCharacteristic;Lcom/example/bleconnectse/BleTileClient;I)V

    return-void
.end method
