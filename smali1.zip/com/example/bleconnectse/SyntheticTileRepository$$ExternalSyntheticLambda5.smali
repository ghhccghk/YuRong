# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/SyntheticTileRepository;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/SyntheticTileRepository;I)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda5;->f$0:Lcom/example/bleconnectse/SyntheticTileRepository;

    iput p2, p0, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda5;->f$1:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda5;->f$0:Lcom/example/bleconnectse/SyntheticTileRepository;

    iget p0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$$ExternalSyntheticLambda5;->f$1:I

    check-cast p1, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    check-cast p2, Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    invoke-static {v0, p0, p1, p2}, Lcom/example/bleconnectse/SyntheticTileRepository;->clipPolygon$lambda$34(Lcom/example/bleconnectse/SyntheticTileRepository;ILcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;)Lcom/example/bleconnectse/SyntheticTileRepository$DoublePoint;

    move-result-object p0

    return-object p0
.end method
