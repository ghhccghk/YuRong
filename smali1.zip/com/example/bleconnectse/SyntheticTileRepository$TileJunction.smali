# classes2.dex

.class final Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;
.super Ljava/lang/Object;
.source "SyntheticTileRepository.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/bleconnectse/SyntheticTileRepository;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "TileJunction"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001J\t\u0010\u0014\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0015"
    }
    d2 = {
        "Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;",
        "",
        "point",
        "Lcom/example/bleconnectse/SyntheticPoint;",
        "name",
        "",
        "<init>",
        "(Lcom/example/bleconnectse/SyntheticPoint;Ljava/lang/String;)V",
        "getPoint",
        "()Lcom/example/bleconnectse/SyntheticPoint;",
        "getName",
        "()Ljava/lang/String;",
        "component1",
        "component2",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final name:Ljava/lang/String;

.field private final point:Lcom/example/bleconnectse/SyntheticPoint;


# direct methods
.method public constructor <init>(Lcom/example/bleconnectse/SyntheticPoint;Ljava/lang/String;)V
    .registers 4

    const-string v0, "point"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    iput-object p1, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->point:Lcom/example/bleconnectse/SyntheticPoint;

    .line 34
    iput-object p2, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->name:Ljava/lang/String;

    return-void
.end method

.method public static synthetic copy$default(Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;Lcom/example/bleconnectse/SyntheticPoint;Ljava/lang/String;ILjava/lang/Object;)Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;
    .registers 5

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_6

    iget-object p1, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->point:Lcom/example/bleconnectse/SyntheticPoint;

    :cond_6
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_c

    iget-object p2, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->name:Ljava/lang/String;

    :cond_c
    invoke-virtual {p0, p1, p2}, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->copy(Lcom/example/bleconnectse/SyntheticPoint;Ljava/lang/String;)Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Lcom/example/bleconnectse/SyntheticPoint;
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->point:Lcom/example/bleconnectse/SyntheticPoint;

    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->name:Ljava/lang/String;

    return-object p0
.end method

.method public final copy(Lcom/example/bleconnectse/SyntheticPoint;Ljava/lang/String;)Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;
    .registers 3

    const-string p0, "point"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "name"

    invoke-static {p2, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;

    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;-><init>(Lcom/example/bleconnectse/SyntheticPoint;Ljava/lang/String;)V

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;

    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->point:Lcom/example/bleconnectse/SyntheticPoint;

    iget-object v3, p1, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->point:Lcom/example/bleconnectse/SyntheticPoint;

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->name:Ljava/lang/String;

    iget-object p1, p1, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->name:Ljava/lang/String;

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_22

    return v2

    :cond_22
    return v0
.end method

.method public final getName()Ljava/lang/String;
    .registers 1

    .line 34
    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->name:Ljava/lang/String;

    return-object p0
.end method

.method public final getPoint()Lcom/example/bleconnectse/SyntheticPoint;
    .registers 1

    .line 33
    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->point:Lcom/example/bleconnectse/SyntheticPoint;

    return-object p0
.end method

.method public hashCode()I
    .registers 2

    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->point:Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticPoint;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->name:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->point:Lcom/example/bleconnectse/SyntheticPoint;

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticTileRepository$TileJunction;->name:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "TileJunction(point="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", name="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ")"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
