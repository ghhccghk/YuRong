# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Z

.field public final synthetic f$2:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$3:Ljava/lang/String;

.field public final synthetic f$4:Ljava/lang/String;

.field public final synthetic f$5:Ljava/lang/String;

.field public final synthetic f$6:Lcom/example/bleconnectse/P2pPeer;

.field public final synthetic f$7:Landroid/net/wifi/p2p/WifiP2pManager;

.field public final synthetic f$8:Landroid/net/wifi/p2p/WifiP2pManager$Channel;


# direct methods
.method public synthetic constructor <init>(ZZLcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/example/bleconnectse/P2pPeer;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V
    .registers 10

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$0:Z

    iput-boolean p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$1:Z

    iput-object p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$2:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p4, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$3:Ljava/lang/String;

    iput-object p5, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$4:Ljava/lang/String;

    iput-object p6, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$5:Ljava/lang/String;

    iput-object p7, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$6:Lcom/example/bleconnectse/P2pPeer;

    iput-object p8, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$7:Landroid/net/wifi/p2p/WifiP2pManager;

    iput-object p9, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$8:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 10

    .line 0
    iget-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$0:Z

    iget-boolean v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$1:Z

    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$2:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v3, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$3:Ljava/lang/String;

    iget-object v4, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$4:Ljava/lang/String;

    iget-object v5, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$5:Ljava/lang/String;

    iget-object v6, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$6:Lcom/example/bleconnectse/P2pPeer;

    iget-object v7, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$7:Landroid/net/wifi/p2p/WifiP2pManager;

    iget-object v8, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda3;->f$8:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    invoke-static/range {v0 .. v8}, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->onReceive$lambda$12$lambda$10$lambda$9(ZZLcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/example/bleconnectse/P2pPeer;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
