# classes2.dex

.class public final Lcom/example/bleconnectse/SyntheticMapRenderer;
.super Ljava/lang/Object;
.source "SyntheticMapRenderer.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/SyntheticMapRenderer$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSyntheticMapRenderer.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SyntheticMapRenderer.kt\ncom/example/bleconnectse/SyntheticMapRenderer\n+ 2 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,207:1\n1321#2,2:208\n1321#2,2:210\n1321#2,2:212\n1321#2,2:214\n1332#2,3:222\n1321#2,2:226\n1869#3,2:216\n1869#3,2:218\n1869#3,2:220\n1869#3:225\n1870#3:228\n1#4:229\n*S KotlinDebug\n*F\n+ 1 SyntheticMapRenderer.kt\ncom/example/bleconnectse/SyntheticMapRenderer\n*L\n36#1:208,2\n40#1:210,2\n44#1:212,2\n48#1:214,2\n121#1:222,3\n136#1:226,2\n61#1:216,2\n84#1:218,2\n105#1:220,2\n133#1:225\n133#1:228\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000X\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J>\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\rJ\u0018\u0010\u0014\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u0018\u0010\u0017\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0018\u001a\u00020\u0019H\u0002J\u0010\u0010\u001a\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0002J \u0010\u001b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\rH\u0002J \u0010\u001c\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\rH\u0002J \u0010\u001d\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u001e\u001a\u00020\u00122\u0006\u0010\u001f\u001a\u00020\rH\u0002J0\u0010 \u001a\u00020!2\f\u0010\"\u001a\b\u0012\u0004\u0012\u00020\u00120#2\u0006\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\r2\b\b\u0002\u0010$\u001a\u00020%H\u0002J(\u0010&\u001a\u00020!2\u0006\u0010\u001e\u001a\u00020\u00122\u0006\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\r2\u0006\u0010$\u001a\u00020%H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\'"
    }
    d2 = {
        "Lcom/example/bleconnectse/SyntheticMapRenderer;",
        "",
        "<init>",
        "()V",
        "paint",
        "Landroid/graphics/Paint;",
        "path",
        "Landroid/graphics/Path;",
        "draw",
        "",
        "canvas",
        "Landroid/graphics/Canvas;",
        "width",
        "",
        "height",
        "cameraX",
        "cameraY",
        "vehicle",
        "Lcom/example/bleconnectse/SyntheticPoint;",
        "vehicleHeading",
        "drawArea",
        "area",
        "Lcom/example/bleconnectse/SyntheticArea;",
        "drawRoad",
        "road",
        "Lcom/example/bleconnectse/SyntheticRoad;",
        "drawNavigationRoute",
        "drawJunctions",
        "drawRoadLabels",
        "drawVehicle",
        "point",
        "heading",
        "visible",
        "",
        "points",
        "",
        "margin",
        "",
        "pointVisible",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final paint:Landroid/graphics/Paint;

.field private final path:Landroid/graphics/Path;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    .line 13
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    return-void
.end method

.method static final draw$lambda$0(Lcom/example/bleconnectse/SyntheticArea;)Z
    .registers 2

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    invoke-virtual {p0}, Lcom/example/bleconnectse/SyntheticArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object p0

    sget-object v0, Lcom/example/bleconnectse/SyntheticAreaType;->Park:Lcom/example/bleconnectse/SyntheticAreaType;

    if-ne p0, v0, :cond_f

    const/4 p0, 0x1

    return p0

    :cond_f
    const/4 p0, 0x0

    return p0
.end method

.method static final draw$lambda$1(Lcom/example/bleconnectse/SyntheticMapRenderer;FFLcom/example/bleconnectse/SyntheticArea;)Z
    .registers 12

    const-string v0, "it"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    invoke-virtual {p3}, Lcom/example/bleconnectse/SyntheticArea;->getPoints()Ljava/util/List;

    move-result-object v2

    const/16 v6, 0x8

    const/4 v7, 0x0

    const/4 v5, 0x0

    move-object v1, p0

    move v3, p1

    move v4, p2

    invoke-static/range {v1 .. v7}, Lcom/example/bleconnectse/SyntheticMapRenderer;->visible$default(Lcom/example/bleconnectse/SyntheticMapRenderer;Ljava/util/List;FFIILjava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method static final draw$lambda$3(Lcom/example/bleconnectse/SyntheticArea;)Z
    .registers 2

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    invoke-virtual {p0}, Lcom/example/bleconnectse/SyntheticArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object p0

    sget-object v0, Lcom/example/bleconnectse/SyntheticAreaType;->Water:Lcom/example/bleconnectse/SyntheticAreaType;

    if-ne p0, v0, :cond_f

    const/4 p0, 0x1

    return p0

    :cond_f
    const/4 p0, 0x0

    return p0
.end method

.method static final draw$lambda$4(Lcom/example/bleconnectse/SyntheticMapRenderer;FFLcom/example/bleconnectse/SyntheticArea;)Z
    .registers 12

    const-string v0, "it"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    invoke-virtual {p3}, Lcom/example/bleconnectse/SyntheticArea;->getPoints()Ljava/util/List;

    move-result-object v2

    const/16 v6, 0x8

    const/4 v7, 0x0

    const/4 v5, 0x0

    move-object v1, p0

    move v3, p1

    move v4, p2

    invoke-static/range {v1 .. v7}, Lcom/example/bleconnectse/SyntheticMapRenderer;->visible$default(Lcom/example/bleconnectse/SyntheticMapRenderer;Ljava/util/List;FFIILjava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method static final draw$lambda$6(Lcom/example/bleconnectse/SyntheticArea;)Z
    .registers 2

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    invoke-virtual {p0}, Lcom/example/bleconnectse/SyntheticArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object p0

    sget-object v0, Lcom/example/bleconnectse/SyntheticAreaType;->Building:Lcom/example/bleconnectse/SyntheticAreaType;

    if-ne p0, v0, :cond_f

    const/4 p0, 0x1

    return p0

    :cond_f
    const/4 p0, 0x0

    return p0
.end method

.method static final draw$lambda$7(Lcom/example/bleconnectse/SyntheticMapRenderer;FFLcom/example/bleconnectse/SyntheticArea;)Z
    .registers 12

    const-string v0, "it"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    invoke-virtual {p3}, Lcom/example/bleconnectse/SyntheticArea;->getPoints()Ljava/util/List;

    move-result-object v2

    const/16 v6, 0x8

    const/4 v7, 0x0

    const/4 v5, 0x0

    move-object v1, p0

    move v3, p1

    move v4, p2

    invoke-static/range {v1 .. v7}, Lcom/example/bleconnectse/SyntheticMapRenderer;->visible$default(Lcom/example/bleconnectse/SyntheticMapRenderer;Ljava/util/List;FFIILjava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method static final draw$lambda$9(Lcom/example/bleconnectse/SyntheticMapRenderer;FFLcom/example/bleconnectse/SyntheticRoad;)Z
    .registers 5

    const-string v0, "it"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    invoke-virtual {p3}, Lcom/example/bleconnectse/SyntheticRoad;->getPoints()Ljava/util/List;

    move-result-object p3

    const/16 v0, 0x20

    invoke-direct {p0, p3, p1, p2, v0}, Lcom/example/bleconnectse/SyntheticMapRenderer;->visible(Ljava/util/List;FFI)Z

    move-result p0

    return p0
.end method

.method private final drawArea(Landroid/graphics/Canvas;Lcom/example/bleconnectse/SyntheticArea;)V
    .registers 12

    .line 58
    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticArea;->getPoints()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x3

    if-ge v0, v1, :cond_c

    return-void

    .line 59
    :cond_c
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    .line 60
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticArea;->getPoints()Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticArea;->getPoints()Ljava/util/List;

    move-result-object v3

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v0, v2, v3}, Landroid/graphics/Path;->moveTo(FF)V

    .line 61
    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticArea;->getPoints()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    const/4 v2, 0x1

    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 216
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_45
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_61

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticPoint;

    .line 61
    iget-object v4, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v4, v5, v3}, Landroid/graphics/Path;->lineTo(FF)V

    goto :goto_45

    .line 62
    :cond_61
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v0}, Landroid/graphics/Path;->close()V

    .line 63
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 64
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object v3

    sget-object v4, Lcom/example/bleconnectse/SyntheticMapRenderer$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticAreaType;->ordinal()I

    move-result v3

    aget v3, v4, v3

    const/4 v4, 0x2

    const/16 v5, 0xbe

    const/16 v6, 0xd3

    if-eq v3, v2, :cond_a0

    if-eq v3, v4, :cond_97

    if-ne v3, v1, :cond_91

    const/16 v3, 0xd2

    const/16 v7, 0xeb

    const/16 v8, 0x9b

    .line 67
    invoke-static {v8, v3, v7}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    goto :goto_a6

    .line 64
    :cond_91
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p0

    :cond_97
    const/16 v3, 0xbf

    const/16 v7, 0xe0

    .line 66
    invoke-static {v3, v7, v5}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    goto :goto_a6

    :cond_a0
    const/16 v3, 0xd8

    .line 65
    invoke-static {v6, v3, v6}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    .line 64
    :goto_a6
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 69
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    iget-object v3, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 70
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 71
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object v3

    sget-object v7, Lcom/example/bleconnectse/SyntheticAreaType;->Water:Lcom/example/bleconnectse/SyntheticAreaType;

    if-ne v3, v7, :cond_c4

    const/high16 v3, 0x40800000  # 4.0f

    goto :goto_c6

    :cond_c4
    const/high16 v3, 0x40000000  # 2.0f

    :goto_c6
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 72
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticArea;->getAreaType()Lcom/example/bleconnectse/SyntheticAreaType;

    move-result-object p2

    sget-object v3, Lcom/example/bleconnectse/SyntheticMapRenderer$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticAreaType;->ordinal()I

    move-result p2

    aget p2, v3, p2

    if-eq p2, v2, :cond_f3

    if-eq p2, v4, :cond_ec

    if-ne p2, v1, :cond_e6

    const/16 p2, 0x52

    const/16 v1, 0xa7

    .line 75
    invoke-static {p2, v1, v6}, Landroid/graphics/Color;->rgb(III)I

    move-result p2

    goto :goto_fb

    .line 72
    :cond_e6
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p0

    :cond_ec
    const/16 p2, 0x82

    .line 74
    invoke-static {p2, v5, p2}, Landroid/graphics/Color;->rgb(III)I

    move-result p2

    goto :goto_fb

    :cond_f3
    const/16 p2, 0xb6

    const/16 v1, 0xb9

    .line 73
    invoke-static {p2, v5, v1}, Landroid/graphics/Color;->rgb(III)I

    move-result p2

    .line 72
    :goto_fb
    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 77
    iget-object p2, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, p0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    return-void
.end method

.method private final drawJunctions(Landroid/graphics/Canvas;FF)V
    .registers 10

    .line 118
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 119
    sget-object v0, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticMapData;->getJunctions()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->asSequence(Ljava/lang/Iterable;)Lkotlin/sequences/Sequence;

    move-result-object v0

    .line 120
    new-instance v1, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, p2, p3}, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/SyntheticMapRenderer;FF)V

    invoke-static {v0, v1}, Lkotlin/sequences/SequencesKt;->filter(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object p2

    .line 223
    invoke-interface {p2}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object p2

    const/4 p3, 0x0

    :goto_21
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_88

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    add-int/lit8 v1, p3, 0x1

    if-gez p3, :cond_32

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_32
    check-cast v0, Lcom/example/bleconnectse/SyntheticJunction;

    .line 122
    iget-object v2, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 123
    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticJunction;->getPosition()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v2

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticJunction;->getPosition()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v3

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v3

    int-to-float v3, v3

    const/high16 v4, 0x41500000  # 13.0f

    iget-object v5, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 124
    iget-object v2, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    rem-int/lit8 p3, p3, 0x3

    if-nez p3, :cond_60

    const/16 p3, 0x49

    const/16 v3, 0x45

    const/16 v4, 0xe5

    goto :goto_66

    :cond_60
    const/16 p3, 0xae

    const/16 v3, 0x58

    const/16 v4, 0x50

    :goto_66
    invoke-static {v4, p3, v3}, Landroid/graphics/Color;->rgb(III)I

    move-result p3

    invoke-virtual {v2, p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 125
    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticJunction;->getPosition()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object p3

    invoke-virtual {p3}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result p3

    int-to-float p3, p3

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticJunction;->getPosition()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object v0

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v0

    int-to-float v0, v0

    const/high16 v2, 0x41000000  # 8.0f

    iget-object v3, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p3, v0, v2, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    move p3, v1

    goto :goto_21

    :cond_88
    return-void
.end method

.method static final drawJunctions$lambda$14(Lcom/example/bleconnectse/SyntheticMapRenderer;FFLcom/example/bleconnectse/SyntheticJunction;)Z
    .registers 5

    const-string v0, "it"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 120
    invoke-virtual {p3}, Lcom/example/bleconnectse/SyntheticJunction;->getPosition()Lcom/example/bleconnectse/SyntheticPoint;

    move-result-object p3

    const/16 v0, 0x18

    invoke-direct {p0, p3, p1, p2, v0}, Lcom/example/bleconnectse/SyntheticMapRenderer;->pointVisible(Lcom/example/bleconnectse/SyntheticPoint;FFI)Z

    move-result p0

    return p0
.end method

.method private final drawNavigationRoute(Landroid/graphics/Canvas;)V
    .registers 6

    .line 101
    sget-object v0, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticMapData;->getNavigationRoute()Ljava/util/List;

    move-result-object v0

    .line 102
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x2

    if-ge v1, v2, :cond_e

    return-void

    .line 103
    :cond_e
    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v1}, Landroid/graphics/Path;->reset()V

    .line 104
    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v2

    int-to-float v2, v2

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Path;->moveTo(FF)V

    .line 105
    check-cast v0, Ljava/lang/Iterable;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 220
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_57

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/example/bleconnectse/SyntheticPoint;

    .line 105
    iget-object v2, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v2, v3, v1}, Landroid/graphics/Path;->lineTo(FF)V

    goto :goto_3b

    .line 106
    :cond_57
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 107
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 108
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 109
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/high16 v1, 0x41900000  # 18.0f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 110
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 111
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    iget-object v1, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 112
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/high16 v1, 0x41300000  # 11.0f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 113
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/16 v1, 0x70

    const/16 v2, 0xee

    const/16 v3, 0x25

    invoke-static {v3, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 114
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, p0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    return-void
.end method

.method private final drawRoad(Landroid/graphics/Canvas;Lcom/example/bleconnectse/SyntheticRoad;)V
    .registers 9

    .line 81
    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticRoad;->getPoints()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x2

    if-ge v0, v1, :cond_c

    return-void

    .line 82
    :cond_c
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    .line 83
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticRoad;->getPoints()Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticRoad;->getPoints()Ljava/util/List;

    move-result-object v3

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v0, v2, v3}, Landroid/graphics/Path;->moveTo(FF)V

    .line 84
    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticRoad;->getPoints()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    const/4 v2, 0x1

    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 218
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_45
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_61

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticPoint;

    .line 84
    iget-object v4, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v4, v5, v3}, Landroid/graphics/Path;->lineTo(FF)V

    goto :goto_45

    .line 85
    :cond_61
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 86
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 87
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 88
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticRoad;->getRoadClass()Lcom/example/bleconnectse/SyntheticRoadClass;

    move-result-object v3

    sget-object v4, Lcom/example/bleconnectse/SyntheticRoadClass;->Main:Lcom/example/bleconnectse/SyntheticRoadClass;

    if-ne v3, v4, :cond_83

    const/high16 v3, 0x41c00000  # 24.0f

    goto :goto_85

    :cond_83
    const/high16 v3, 0x41500000  # 13.0f

    :goto_85
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 89
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/16 v3, 0xb5

    const/16 v4, 0xb2

    const/16 v5, 0xb0

    invoke-static {v5, v3, v4}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 90
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    iget-object v3, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 91
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticRoad;->getRoadClass()Lcom/example/bleconnectse/SyntheticRoadClass;

    move-result-object v3

    sget-object v4, Lcom/example/bleconnectse/SyntheticRoadClass;->Main:Lcom/example/bleconnectse/SyntheticRoadClass;

    if-ne v3, v4, :cond_ab

    const/high16 v3, 0x41900000  # 18.0f

    goto :goto_ad

    :cond_ab
    const/high16 v3, 0x41100000  # 9.0f

    :goto_ad
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 92
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticRoad;->getTraffic()Lcom/example/bleconnectse/SyntheticTraffic;

    move-result-object p2

    sget-object v3, Lcom/example/bleconnectse/SyntheticMapRenderer$WhenMappings;->$EnumSwitchMapping$1:[I

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticTraffic;->ordinal()I

    move-result p2

    aget p2, v3, p2

    if-eq p2, v2, :cond_e1

    if-eq p2, v1, :cond_d6

    const/4 v1, 0x3

    if-ne p2, v1, :cond_d0

    const/16 p2, 0x48

    const/16 v1, 0x44

    const/16 v2, 0xdd

    .line 95
    invoke-static {v2, p2, v1}, Landroid/graphics/Color;->rgb(III)I

    move-result p2

    goto :goto_e9

    .line 92
    :cond_d0
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p0

    :cond_d6
    const/16 p2, 0xbe

    const/16 v1, 0x3e

    const/16 v2, 0xf7

    .line 94
    invoke-static {v2, p2, v1}, Landroid/graphics/Color;->rgb(III)I

    move-result p2

    goto :goto_e9

    :cond_e1
    const/16 p2, 0xfb

    const/16 v1, 0xfd

    .line 93
    invoke-static {v1, v1, p2}, Landroid/graphics/Color;->rgb(III)I

    move-result p2

    .line 92
    :goto_e9
    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 97
    iget-object p2, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, p0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    return-void
.end method

.method private final drawRoadLabels(Landroid/graphics/Canvas;FF)V
    .registers 14

    .line 130
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 131
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/high16 v1, 0x41900000  # 18.0f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 132
    iget-object v0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 133
    sget-object v0, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {v0}, Lcom/example/bleconnectse/SyntheticMapData;->getRoads()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 225
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_21
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_c4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/example/bleconnectse/SyntheticRoad;

    .line 134
    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticRoad;->getLabelPositions()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->asSequence(Ljava/lang/Iterable;)Lkotlin/sequences/Sequence;

    move-result-object v2

    .line 135
    new-instance v3, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda0;

    invoke-direct {v3, p0, p2, p3}, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda0;-><init>(Lcom/example/bleconnectse/SyntheticMapRenderer;FF)V

    invoke-static {v2, v3}, Lkotlin/sequences/SequencesKt;->filter(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object v2

    .line 226
    invoke-interface {v2}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_44
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_21

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticPoint;

    .line 137
    iget-object v4, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticRoad;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v4

    .line 138
    iget-object v5, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 139
    iget-object v5, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/16 v6, 0xf9

    const/16 v7, 0xf7

    const/16 v8, 0xe1

    const/16 v9, 0xf8

    invoke-static {v8, v9, v6, v7}, Landroid/graphics/Color;->argb(IIII)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 141
    new-instance v5, Landroid/graphics/RectF;

    .line 142
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v6

    int-to-float v6, v6

    const/high16 v7, 0x40000000  # 2.0f

    div-float/2addr v4, v7

    sub-float/2addr v6, v4

    const/high16 v7, 0x40e00000  # 7.0f

    sub-float/2addr v6, v7

    .line 143
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v8

    int-to-float v8, v8

    const/high16 v9, 0x41880000  # 17.0f

    sub-float/2addr v8, v9

    .line 144
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v9

    int-to-float v9, v9

    add-float/2addr v9, v4

    add-float/2addr v9, v7

    .line 145
    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v4

    int-to-float v4, v4

    const/high16 v7, 0x40c00000  # 6.0f

    add-float/2addr v4, v7

    .line 141
    invoke-direct {v5, v6, v8, v9, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 149
    iget-object v4, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/high16 v6, 0x40a00000  # 5.0f

    .line 140
    invoke-virtual {p1, v5, v6, v6, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 151
    iget-object v4, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/16 v5, 0x5b

    const/16 v6, 0x56

    const/16 v7, 0x50

    invoke-static {v7, v5, v6}, Landroid/graphics/Color;->rgb(III)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 152
    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticRoad;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v3

    int-to-float v3, v3

    iget-object v6, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v5, v3, v6}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    goto :goto_44

    .line 155
    :cond_c4
    iget-object p0, p0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object p1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    return-void
.end method

.method static final drawRoadLabels$lambda$18$lambda$16(Lcom/example/bleconnectse/SyntheticMapRenderer;FFLcom/example/bleconnectse/SyntheticPoint;)Z
    .registers 5

    const-string v0, "it"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v0, 0x64

    .line 135
    invoke-direct {p0, p3, p1, p2, v0}, Lcom/example/bleconnectse/SyntheticMapRenderer;->pointVisible(Lcom/example/bleconnectse/SyntheticPoint;FFI)Z

    move-result p0

    return p0
.end method

.method private final drawVehicle(Landroid/graphics/Canvas;Lcom/example/bleconnectse/SyntheticPoint;F)V
    .registers 20

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    .line 159
    iget-object v3, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 160
    iget-object v3, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/4 v4, -0x1

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 161
    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v5

    int-to-float v5, v5

    const/high16 v6, 0x41e00000  # 28.0f

    iget-object v7, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v5, v6, v7}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 162
    iget-object v3, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    const/16 v5, 0x68

    const/16 v6, 0xee

    const/16 v7, 0x1b

    invoke-static {v7, v5, v6}, Landroid/graphics/Color;->rgb(III)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 163
    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v5

    int-to-float v5, v5

    const/high16 v6, 0x41b80000  # 23.0f

    iget-object v7, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v5, v6, v7}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 165
    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v3

    int-to-float v3, v3

    float-to-double v5, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->cos(D)D

    move-result-wide v7

    double-to-float v7, v7

    const/high16 v8, 0x41900000  # 18.0f

    mul-float/2addr v7, v8

    add-float/2addr v3, v7

    .line 166
    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v7

    int-to-float v7, v7

    invoke-static {v5, v6}, Ljava/lang/Math;->sin(D)D

    move-result-wide v5

    double-to-float v5, v5

    mul-float/2addr v5, v8

    add-float/2addr v7, v5

    .line 167
    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v5

    int-to-float v5, v5

    const v6, 0x401ccccd  # 2.45f

    add-float v8, v2, v6

    float-to-double v8, v8

    invoke-static {v8, v9}, Ljava/lang/Math;->cos(D)D

    move-result-wide v10

    double-to-float v10, v10

    const/high16 v11, 0x41500000  # 13.0f

    mul-float/2addr v10, v11

    add-float/2addr v5, v10

    .line 168
    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v10

    int-to-float v10, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v8, v8

    mul-float/2addr v8, v11

    add-float/2addr v10, v8

    .line 169
    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v8

    int-to-float v8, v8

    sub-float/2addr v2, v6

    float-to-double v12, v2

    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    move-result-wide v14

    double-to-float v2, v14

    mul-float/2addr v2, v11

    add-float/2addr v8, v2

    .line 170
    invoke-virtual/range {p2 .. p2}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v2

    int-to-float v2, v2

    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v12

    double-to-float v6, v12

    mul-float/2addr v6, v11

    add-float/2addr v2, v6

    .line 171
    iget-object v6, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v6}, Landroid/graphics/Path;->reset()V

    .line 172
    iget-object v6, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v6, v3, v7}, Landroid/graphics/Path;->moveTo(FF)V

    .line 173
    iget-object v3, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v3, v5, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 174
    iget-object v3, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v3, v8, v2}, Landroid/graphics/Path;->lineTo(FF)V

    .line 175
    iget-object v2, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    invoke-virtual {v2}, Landroid/graphics/Path;->close()V

    .line 176
    iget-object v2, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 177
    iget-object v2, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->path:Landroid/graphics/Path;

    iget-object v0, v0, Lcom/example/bleconnectse/SyntheticMapRenderer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    return-void
.end method

.method private final pointVisible(Lcom/example/bleconnectse/SyntheticPoint;FFI)Z
    .registers 6

    .line 202
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result p0

    int-to-float p0, p0

    int-to-float p4, p4

    sub-float v0, p2, p4

    cmpl-float p0, p0, v0

    if-ltz p0, :cond_33

    .line 203
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result p0

    int-to-float p0, p0

    const/high16 v0, 0x44a00000  # 1280.0f

    add-float/2addr p2, v0

    add-float/2addr p2, p4

    cmpg-float p0, p0, p2

    if-gtz p0, :cond_33

    .line 204
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result p0

    int-to-float p0, p0

    sub-float p2, p3, p4

    cmpl-float p0, p0, p2

    if-ltz p0, :cond_33

    .line 205
    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result p0

    int-to-float p0, p0

    const/high16 p1, 0x44340000  # 720.0f

    add-float/2addr p3, p1

    add-float/2addr p3, p4

    cmpg-float p0, p0, p3

    if-gtz p0, :cond_33

    const/4 p0, 0x1

    return p0

    :cond_33
    const/4 p0, 0x0

    return p0
.end method

.method private final visible(Ljava/util/List;FFI)Z
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/SyntheticPoint;",
            ">;FFI)Z"
        }
    .end annotation

    .line 186
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p0

    const/4 v0, 0x0

    if-eqz p0, :cond_8

    return v0

    .line 187
    :cond_8
    check-cast p1, Ljava/lang/Iterable;

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_e0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v1}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v1

    :cond_1e
    :goto_1e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_32

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v2

    if-le v1, v2, :cond_1e

    move v1, v2

    goto :goto_1e

    .line 188
    :cond_32
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_da

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v2}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v2

    :cond_46
    :goto_46
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_5a

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getX()I

    move-result v3

    if-ge v2, v3, :cond_46

    move v2, v3

    goto :goto_46

    .line 189
    :cond_5a
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_d4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v3}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v3

    :cond_6e
    :goto_6e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_82

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v4}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v4

    if-le v3, v4, :cond_6e

    move v3, v4

    goto :goto_6e

    .line 190
    :cond_82
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_ce

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {p1}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result p1

    :cond_96
    :goto_96
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_aa

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/example/bleconnectse/SyntheticPoint;

    invoke-virtual {v4}, Lcom/example/bleconnectse/SyntheticPoint;->getY()I

    move-result v4

    if-ge p1, v4, :cond_96

    move p1, v4

    goto :goto_96

    :cond_aa
    int-to-float p0, v2

    int-to-float p4, p4

    sub-float v2, p2, p4

    cmpl-float p0, p0, v2

    if-ltz p0, :cond_cd

    int-to-float p0, v1

    const/high16 v1, 0x44a00000  # 1280.0f

    add-float/2addr p2, v1

    add-float/2addr p2, p4

    cmpg-float p0, p0, p2

    if-gtz p0, :cond_cd

    int-to-float p0, p1

    sub-float p1, p3, p4

    cmpl-float p0, p0, p1

    if-ltz p0, :cond_cd

    int-to-float p0, v3

    const/high16 p1, 0x44340000  # 720.0f

    add-float/2addr p3, p1

    add-float/2addr p3, p4

    cmpg-float p0, p0, p3

    if-gtz p0, :cond_cd

    const/4 p0, 0x1

    return p0

    :cond_cd
    return v0

    :cond_ce
    new-instance p0, Ljava/util/NoSuchElementException;

    invoke-direct {p0}, Ljava/util/NoSuchElementException;-><init>()V

    throw p0

    .line 189
    :cond_d4
    new-instance p0, Ljava/util/NoSuchElementException;

    invoke-direct {p0}, Ljava/util/NoSuchElementException;-><init>()V

    throw p0

    .line 188
    :cond_da
    new-instance p0, Ljava/util/NoSuchElementException;

    invoke-direct {p0}, Ljava/util/NoSuchElementException;-><init>()V

    throw p0

    .line 187
    :cond_e0
    new-instance p0, Ljava/util/NoSuchElementException;

    invoke-direct {p0}, Ljava/util/NoSuchElementException;-><init>()V

    throw p0
.end method

.method static synthetic visible$default(Lcom/example/bleconnectse/SyntheticMapRenderer;Ljava/util/List;FFIILjava/lang/Object;)Z
    .registers 7

    const/16 p6, 0x8

    and-int/2addr p5, p6

    if-eqz p5, :cond_6

    move p4, p6

    .line 180
    :cond_6
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/example/bleconnectse/SyntheticMapRenderer;->visible(Ljava/util/List;FFI)Z

    move-result p0

    return p0
.end method


# virtual methods
.method public final draw(Landroid/graphics/Canvas;FFFFLcom/example/bleconnectse/SyntheticPoint;F)V
    .registers 11

    const-string v0, "canvas"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string/jumbo v0, "vehicle"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    cmpg-float v1, p2, v0

    if-lez v1, :cond_102

    cmpg-float v0, p3, v0

    if-gtz v0, :cond_16

    goto/16 :goto_102

    :cond_16
    const/16 v0, 0xed

    const/16 v1, 0xe7

    const/16 v2, 0xe6

    .line 25
    invoke-static {v2, v0, v1}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->drawColor(I)V

    .line 26
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/high16 v0, 0x44a00000  # 1280.0f

    div-float/2addr p2, v0

    const/high16 v0, 0x44340000  # 720.0f

    div-float/2addr p3, v0

    .line 27
    invoke-virtual {p1, p2, p3}, Landroid/graphics/Canvas;->scale(FF)V

    neg-float p2, p4

    neg-float p3, p5

    .line 31
    invoke-virtual {p1, p2, p3}, Landroid/graphics/Canvas;->translate(FF)V

    .line 33
    sget-object p2, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticMapData;->getAreas()Ljava/util/List;

    move-result-object p2

    check-cast p2, Ljava/lang/Iterable;

    invoke-static {p2}, Lkotlin/collections/CollectionsKt;->asSequence(Ljava/lang/Iterable;)Lkotlin/sequences/Sequence;

    move-result-object p2

    new-instance p3, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda2;

    invoke-direct {p3}, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda2;-><init>()V

    .line 34
    invoke-static {p2, p3}, Lkotlin/sequences/SequencesKt;->filter(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object p2

    .line 35
    new-instance p3, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda3;

    invoke-direct {p3, p0, p4, p5}, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda3;-><init>(Lcom/example/bleconnectse/SyntheticMapRenderer;FF)V

    invoke-static {p2, p3}, Lkotlin/sequences/SequencesKt;->filter(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object p2

    .line 208
    invoke-interface {p2}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_56
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_66

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lcom/example/bleconnectse/SyntheticArea;

    .line 36
    invoke-direct {p0, p1, p3}, Lcom/example/bleconnectse/SyntheticMapRenderer;->drawArea(Landroid/graphics/Canvas;Lcom/example/bleconnectse/SyntheticArea;)V

    goto :goto_56

    .line 37
    :cond_66
    sget-object p2, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticMapData;->getAreas()Ljava/util/List;

    move-result-object p2

    check-cast p2, Ljava/lang/Iterable;

    invoke-static {p2}, Lkotlin/collections/CollectionsKt;->asSequence(Ljava/lang/Iterable;)Lkotlin/sequences/Sequence;

    move-result-object p2

    new-instance p3, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda4;

    invoke-direct {p3}, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda4;-><init>()V

    .line 38
    invoke-static {p2, p3}, Lkotlin/sequences/SequencesKt;->filter(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object p2

    .line 39
    new-instance p3, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda5;

    invoke-direct {p3, p0, p4, p5}, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda5;-><init>(Lcom/example/bleconnectse/SyntheticMapRenderer;FF)V

    invoke-static {p2, p3}, Lkotlin/sequences/SequencesKt;->filter(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object p2

    .line 210
    invoke-interface {p2}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_88
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_98

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lcom/example/bleconnectse/SyntheticArea;

    .line 40
    invoke-direct {p0, p1, p3}, Lcom/example/bleconnectse/SyntheticMapRenderer;->drawArea(Landroid/graphics/Canvas;Lcom/example/bleconnectse/SyntheticArea;)V

    goto :goto_88

    .line 41
    :cond_98
    sget-object p2, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticMapData;->getAreas()Ljava/util/List;

    move-result-object p2

    check-cast p2, Ljava/lang/Iterable;

    invoke-static {p2}, Lkotlin/collections/CollectionsKt;->asSequence(Ljava/lang/Iterable;)Lkotlin/sequences/Sequence;

    move-result-object p2

    new-instance p3, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda6;

    invoke-direct {p3}, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda6;-><init>()V

    .line 42
    invoke-static {p2, p3}, Lkotlin/sequences/SequencesKt;->filter(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object p2

    .line 43
    new-instance p3, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda7;

    invoke-direct {p3, p0, p4, p5}, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda7;-><init>(Lcom/example/bleconnectse/SyntheticMapRenderer;FF)V

    invoke-static {p2, p3}, Lkotlin/sequences/SequencesKt;->filter(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object p2

    .line 212
    invoke-interface {p2}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_ba
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_ca

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lcom/example/bleconnectse/SyntheticArea;

    .line 44
    invoke-direct {p0, p1, p3}, Lcom/example/bleconnectse/SyntheticMapRenderer;->drawArea(Landroid/graphics/Canvas;Lcom/example/bleconnectse/SyntheticArea;)V

    goto :goto_ba

    .line 46
    :cond_ca
    sget-object p2, Lcom/example/bleconnectse/SyntheticMapData;->INSTANCE:Lcom/example/bleconnectse/SyntheticMapData;

    invoke-virtual {p2}, Lcom/example/bleconnectse/SyntheticMapData;->getRoads()Ljava/util/List;

    move-result-object p2

    check-cast p2, Ljava/lang/Iterable;

    invoke-static {p2}, Lkotlin/collections/CollectionsKt;->asSequence(Ljava/lang/Iterable;)Lkotlin/sequences/Sequence;

    move-result-object p2

    .line 47
    new-instance p3, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda8;

    invoke-direct {p3, p0, p4, p5}, Lcom/example/bleconnectse/SyntheticMapRenderer$$ExternalSyntheticLambda8;-><init>(Lcom/example/bleconnectse/SyntheticMapRenderer;FF)V

    invoke-static {p2, p3}, Lkotlin/sequences/SequencesKt;->filter(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object p2

    .line 214
    invoke-interface {p2}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_e3
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_f3

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lcom/example/bleconnectse/SyntheticRoad;

    .line 48
    invoke-direct {p0, p1, p3}, Lcom/example/bleconnectse/SyntheticMapRenderer;->drawRoad(Landroid/graphics/Canvas;Lcom/example/bleconnectse/SyntheticRoad;)V

    goto :goto_e3

    .line 49
    :cond_f3
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/SyntheticMapRenderer;->drawNavigationRoute(Landroid/graphics/Canvas;)V

    .line 50
    invoke-direct {p0, p1, p4, p5}, Lcom/example/bleconnectse/SyntheticMapRenderer;->drawJunctions(Landroid/graphics/Canvas;FF)V

    .line 51
    invoke-direct {p0, p1, p4, p5}, Lcom/example/bleconnectse/SyntheticMapRenderer;->drawRoadLabels(Landroid/graphics/Canvas;FF)V

    .line 52
    invoke-direct {p0, p1, p6, p7}, Lcom/example/bleconnectse/SyntheticMapRenderer;->drawVehicle(Landroid/graphics/Canvas;Lcom/example/bleconnectse/SyntheticPoint;F)V

    .line 54
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    :cond_102
    :goto_102
    return-void
.end method
