# classes.dex

.class public final synthetic Lcom/example/bleconnectse/CameraMirrorController$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/CameraMirrorController;

.field public final synthetic f$1:Lcom/google/common/util/concurrent/ListenableFuture;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/CameraMirrorController;Lcom/google/common/util/concurrent/ListenableFuture;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/CameraMirrorController$$ExternalSyntheticLambda1;->f$0:Lcom/example/bleconnectse/CameraMirrorController;

    iput-object p2, p0, Lcom/example/bleconnectse/CameraMirrorController$$ExternalSyntheticLambda1;->f$1:Lcom/google/common/util/concurrent/ListenableFuture;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/CameraMirrorController$$ExternalSyntheticLambda1;->f$0:Lcom/example/bleconnectse/CameraMirrorController;

    iget-object p0, p0, Lcom/example/bleconnectse/CameraMirrorController$$ExternalSyntheticLambda1;->f$1:Lcom/google/common/util/concurrent/ListenableFuture;

    invoke-static {v0, p0}, Lcom/example/bleconnectse/CameraMirrorController;->start$lambda$1(Lcom/example/bleconnectse/CameraMirrorController;Lcom/google/common/util/concurrent/ListenableFuture;)V

    return-void
.end method
