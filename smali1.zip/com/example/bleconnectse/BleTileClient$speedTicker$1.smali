# classes2.dex

.class public final Lcom/example/bleconnectse/BleTileClient$speedTicker$1;
.super Ljava/lang/Object;
.source "BleTileClient.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/BleTileClient;-><init>(Landroid/content/Context;Lcom/example/bleconnectse/SyntheticTileRepository;Lkotlin/jvm/functions/Function1;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016¨\u0006\u0004"
    }
    d2 = {
        "com/example/bleconnectse/BleTileClient$speedTicker$1",
        "Ljava/lang/Runnable;",
        "run",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/BleTileClient;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/BleTileClient;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$speedTicker$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    .line 153
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 155
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$speedTicker$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getSpeedWindowBytes$p(Lcom/example/bleconnectse/BleTileClient;)J

    move-result-wide v1

    invoke-static {v0, v1, v2}, Lcom/example/bleconnectse/BleTileClient;->access$setSpeedBytesPerSecond(Lcom/example/bleconnectse/BleTileClient;J)V

    .line 156
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$speedTicker$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    const-wide/16 v1, 0x0

    invoke-static {v0, v1, v2}, Lcom/example/bleconnectse/BleTileClient;->access$setSpeedWindowBytes$p(Lcom/example/bleconnectse/BleTileClient;J)V

    .line 157
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$speedTicker$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getClosed$p(Lcom/example/bleconnectse/BleTileClient;)Z

    move-result v0

    if-nez v0, :cond_25

    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$speedTicker$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object v0

    check-cast p0, Ljava/lang/Runnable;

    const-wide/16 v1, 0x3e8

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_25
    return-void
.end method
