# classes2.dex

.class public final Lcom/example/bleconnectse/ScreenCaptureServiceKt;
.super Ljava/lang/Object;
.source "ScreenCaptureService.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u001a\u0016\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0002¨\u0006\u0004"
    }
    d2 = {
        "intentExtra",
        "Landroid/content/Intent;",
        "name",
        "",
        "app"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static final synthetic access$intentExtra(Landroid/content/Intent;Ljava/lang/String;)Landroid/content/Intent;
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lcom/example/bleconnectse/ScreenCaptureServiceKt;->intentExtra(Landroid/content/Intent;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    return-object p0
.end method

.method private static final intentExtra(Landroid/content/Intent;Ljava/lang/String;)Landroid/content/Intent;
    .registers 4

    .line 181
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    if-lt v0, v1, :cond_f

    .line 182
    const-class v0, Landroid/content/Intent;

    invoke-virtual {p0, p1, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/Intent;

    return-object p0

    .line 185
    :cond_f
    invoke-virtual {p0, p1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p0

    check-cast p0, Landroid/content/Intent;

    return-object p0
.end method
