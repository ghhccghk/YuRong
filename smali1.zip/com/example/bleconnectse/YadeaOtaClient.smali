# classes2.dex

.class public final Lcom/example/bleconnectse/YadeaOtaClient;
.super Ljava/lang/Object;
.source "YadeaOtaClient.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nYadeaOtaClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 YadeaOtaClient.kt\ncom/example/bleconnectse/YadeaOtaClient\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 5 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n+ 6 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,2252:1\n85#2:2253\n117#2,2:2254\n85#2:2256\n117#2,2:2257\n85#2:2259\n117#2,2:2260\n85#2:2262\n117#2,2:2263\n85#2:2265\n117#2,2:2266\n85#2:2268\n117#2,2:2269\n85#2:2271\n117#2,2:2272\n85#2:2274\n117#2,2:2275\n85#2:2277\n117#2,2:2278\n85#2:2280\n117#2,2:2281\n85#2:2283\n117#2,2:2284\n85#2:2286\n117#2,2:2287\n85#2:2289\n117#2,2:2290\n85#2:2292\n117#2,2:2293\n85#2:2295\n117#2,2:2296\n1#3:2298\n1#3:2317\n1#3:2369\n295#4,2:2299\n295#4,2:2301\n1563#4:2303\n1634#4,3:2304\n1617#4,9:2307\n1869#4:2316\n1870#4:2318\n1626#4:2319\n1669#4,8:2320\n1068#4:2328\n295#4,2:2329\n1869#4,2:2333\n1869#4,2:2335\n774#4:2339\n865#4,2:2340\n1374#4:2342\n1460#4,5:2343\n808#4,11:2348\n1617#4,9:2359\n1869#4:2368\n1870#4:2370\n1626#4:2371\n295#4,2:2372\n1069#5,2:2331\n434#5:2374\n507#5,5:2375\n13479#6,2:2337\n*S KotlinDebug\n*F\n+ 1 YadeaOtaClient.kt\ncom/example/bleconnectse/YadeaOtaClient\n*L\n153#1:2253\n153#1:2254,2\n155#1:2256\n155#1:2257,2\n157#1:2259\n157#1:2260,2\n159#1:2262\n159#1:2263,2\n161#1:2265\n161#1:2266,2\n163#1:2268\n163#1:2269,2\n165#1:2271\n165#1:2272,2\n167#1:2274\n167#1:2275,2\n169#1:2277\n169#1:2278,2\n171#1:2280\n171#1:2281,2\n173#1:2283\n173#1:2284,2\n175#1:2286\n175#1:2287,2\n177#1:2289\n177#1:2290,2\n179#1:2292\n179#1:2293,2\n181#1:2295\n181#1:2296,2\n1029#1:2317\n1712#1:2369\n504#1:2299,2\n506#1:2301,2\n1004#1:2303\n1004#1:2304,3\n1029#1:2307,9\n1029#1:2316\n1029#1:2318\n1029#1:2319\n1030#1:2320,8\n1031#1:2328\n1039#1:2329,2\n1329#1:2333,2\n1422#1:2335,2\n1709#1:2339\n1709#1:2340,2\n1710#1:2342\n1710#1:2343,5\n1711#1:2348,11\n1712#1:2359,9\n1712#1:2368\n1712#1:2370\n1712#1:2371\n1713#1:2372,2\n1100#1:2331,2\n2010#1:2374\n2010#1:2375,5\n1639#1:2337,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0090\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b2\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\b0\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u0005\n\u0002\b\u0019\n\u0002\u0018\u0002\n\u0002\b\u0007*\u0002\u0092\u0001\b\u0007\u0018\u00002\u00020\u0001B#\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005¢\u0006\u0004\b\b\u0010\tJ\u0006\u0010?\u001a\u00020\u0019J\u0010\u0010\u0094\u0001\u001a\u00020\u00072\u0007\u0010\u0095\u0001\u001a\u00020!J\u0012\u0010\u0096\u0001\u001a\u00020\u00072\t\u0010\u0097\u0001\u001a\u0004\u0018\u00010\u0006J\u0012\u0010\u0098\u0001\u001a\u00020\u00072\t\u0010\u0097\u0001\u001a\u0004\u0018\u00010\u0006J\u0012\u0010\u0099\u0001\u001a\u00020\u00072\t\u0010\u0097\u0001\u001a\u0004\u0018\u00010\u0006J\u0012\u0010\u009a\u0001\u001a\u00020\u00072\t\u0010\u0097\u0001\u001a\u0004\u0018\u00010\u0006J\u001b\u0010\u009b\u0001\u001a\u00020\u00072\u0007\u0010\u009c\u0001\u001a\u00020P2\t\b\u0002\u0010\u009d\u0001\u001a\u00020\u0019J\u0012\u0010\u009e\u0001\u001a\u00020\u00072\u0007\u0010\u009f\u0001\u001a\u00020\u0019H\u0003J\u0012\u0010\u00a0\u0001\u001a\u00020\u00072\u0007\u0010\u009c\u0001\u001a\u00020PH\u0003J\u0014\u0010¡\u0001\u001a\u00020\u00072\t\u0010\u0097\u0001\u001a\u0004\u0018\u00010\u0006H\u0007J\u0007\u0010¢\u0001\u001a\u00020\u0007J\u001d\u0010£\u0001\u001a\u00020\u00072\u0007\u0010¤\u0001\u001a\u00020&2\t\b\u0002\u0010\u009d\u0001\u001a\u00020\u0019H\u0007J\u0007\u0010¥\u0001\u001a\u00020\u0007J\u0007\u0010¦\u0001\u001a\u00020\u0007J\u0007\u0010§\u0001\u001a\u00020\u0007J\u0007\u0010¨\u0001\u001a\u00020\u0007J\u0007\u0010©\u0001\u001a\u00020\u0007J\u0007\u0010ª\u0001\u001a\u00020\u0019J\u0010\u0010«\u0001\u001a\u00020\u00192\u0007\u0010\u0095\u0001\u001a\u00020!J\u0010\u0010¬\u0001\u001a\u00020\u00192\u0007\u0010\u00ad\u0001\u001a\u00020\u0006J\u0010\u0010®\u0001\u001a\u00020\u00192\u0007\u0010\u0095\u0001\u001a\u00020!J\u0007\u0010¯\u0001\u001a\u00020\u0007J\u001b\u0010°\u0001\u001a\u00020\u00192\u0007\u0010±\u0001\u001a\u00020W2\u0007\u0010\u00ad\u0001\u001a\u00020\u0006H\u0002J\u0007\u0010²\u0001\u001a\u00020\u0007J\u0012\u0010³\u0001\u001a\u00020\u00192\u0007\u0010´\u0001\u001a\u000206H\u0002J\u0007\u0010µ\u0001\u001a\u00020\u0007J\u0007\u0010¶\u0001\u001a\u00020\u0007J\u0007\u0010·\u0001\u001a\u00020\u0007J\u0016\u0010¸\u0001\u001a\u0004\u0018\u00010P2\t\u0010\u0097\u0001\u001a\u0004\u0018\u00010\u0006H\u0002J\u000b\u0010¹\u0001\u001a\u0004\u0018\u00010PH\u0002J\u001b\u0010º\u0001\u001a\u00020\u00192\u0007\u0010¤\u0001\u001a\u00020&2\u0007\u0010\u009c\u0001\u001a\u00020PH\u0002J\u001b\u0010»\u0001\u001a\u00020\u00192\u0007\u0010¼\u0001\u001a\u00020P2\u0007\u0010\u009c\u0001\u001a\u00020PH\u0002J\u0016\u0010½\u0001\u001a\u0004\u0018\u00010P2\t\u0010\u0097\u0001\u001a\u0004\u0018\u00010\u0006H\u0002J\u0012\u0010¾\u0001\u001a\u00020\u00072\u0007\u0010¿\u0001\u001a\u00020\u0019H\u0003J\u0015\u0010À\u0001\u001a\u0004\u0018\u00010P2\b\u0010Á\u0001\u001a\u00030Â\u0001H\u0002J\u001b\u0010Ã\u0001\u001a\u00020\u00062\u0007\u0010Ä\u0001\u001a\u00020\u00062\u0007\u0010Å\u0001\u001a\u00020\u0006H\u0002J\t\u0010Æ\u0001\u001a\u00020\u0007H\u0002J\t\u0010Ç\u0001\u001a\u00020\u0007H\u0002J\u0012\u0010È\u0001\u001a\u00020\u00062\u0007\u0010\u0095\u0001\u001a\u00020!H\u0002J\t\u0010É\u0001\u001a\u00020#H\u0002J\u001b\u0010Ê\u0001\u001a\u00020\u00072\u0007\u0010Ë\u0001\u001a\u00020*2\u0007\u0010Ì\u0001\u001a\u00020#H\u0002J#\u0010Í\u0001\u001a\u00020\u00072\u0006\u0010b\u001a\u00020\u00062\u0007\u0010Ë\u0001\u001a\u00020*2\u0007\u0010Î\u0001\u001a\u00020#H\u0002J%\u0010Ï\u0001\u001a\u0002012\u0006\u0010b\u001a\u00020\u00062\u0007\u0010Ë\u0001\u001a\u00020*2\t\b\u0002\u0010Ð\u0001\u001a\u00020*H\u0002J\u001a\u0010Ñ\u0001\u001a\u0002012\u0006\u0010b\u001a\u00020\u00062\u0007\u0010Ë\u0001\u001a\u00020*H\u0002J\t\u0010Ò\u0001\u001a\u000203H\u0002J\u0011\u0010Ó\u0001\u001a\u00020#2\u0006\u0010^\u001a\u00020\u0006H\u0002J\u0012\u0010Ô\u0001\u001a\u00020#2\u0007\u0010Õ\u0001\u001a\u00020*H\u0002J\u0013\u0010Ö\u0001\u001a\u00030×\u00012\u0007\u0010Ø\u0001\u001a\u00020#H\u0002J\t\u0010Ù\u0001\u001a\u00020#H\u0002J\t\u0010Ú\u0001\u001a\u00020#H\u0002J\u001b\u0010Û\u0001\u001a\u00020#2\u0007\u0010Ü\u0001\u001a\u00020*2\u0007\u0010Ø\u0001\u001a\u00020#H\u0002J&\u0010Ý\u0001\u001a\u00030Þ\u00012\b\u0010ß\u0001\u001a\u00030à\u00012\u0007\u0010á\u0001\u001a\u00020*2\u0007\u0010â\u0001\u001a\u000208H\u0002J\u001a\u0010ã\u0001\u001a\n\u0012\u0005\u0012\u00030Þ\u00010ä\u00012\u0007\u0010å\u0001\u001a\u00020#H\u0002J>\u0010æ\u0001\u001a\u00020\u00072\u0007\u0010ç\u0001\u001a\u0002032\u000f\u0010è\u0001\u001a\n\u0012\u0005\u0012\u00030é\u00010ä\u00012\u0007\u0010ê\u0001\u001a\u00020#2\u0007\u0010Õ\u0001\u001a\u00020*2\u0007\u0010ë\u0001\u001a\u00020*H\u0002J\u001c\u0010ì\u0001\u001a\u00020\u00072\b\u0010í\u0001\u001a\u00030î\u00012\u0007\u0010ï\u0001\u001a\u00020\u0006H\u0002J\u0012\u0010ð\u0001\u001a\u00020\u00072\u0007\u0010ñ\u0001\u001a\u000208H\u0002J\u001c\u0010ò\u0001\u001a\u00020\u00192\b\u0010í\u0001\u001a\u00030î\u00012\u0007\u0010ó\u0001\u001a\u000208H\u0002J%\u0010ô\u0001\u001a\u00020#2\b\u0010õ\u0001\u001a\u00030ö\u00012\u0007\u0010÷\u0001\u001a\u00020*2\u0007\u0010ø\u0001\u001a\u00020*H\u0002J$\u0010ù\u0001\u001a\u00020#2\u0007\u0010\u0095\u0001\u001a\u00020!2\u0007\u0010÷\u0001\u001a\u00020*2\u0007\u0010ø\u0001\u001a\u00020*H\u0002J\u001b\u0010ú\u0001\u001a\u00020#2\u0007\u0010÷\u0001\u001a\u00020*2\u0007\u0010ø\u0001\u001a\u00020*H\u0002J\u001b\u0010û\u0001\u001a\u00020*2\u0007\u0010ü\u0001\u001a\u00020#2\u0007\u0010ý\u0001\u001a\u00020*H\u0002J$\u0010þ\u0001\u001a\u00020\u00072\u0007\u0010ÿ\u0001\u001a\u00020#2\u0007\u0010\u0080\u0002\u001a\u00020*2\u0007\u0010\u0081\u0002\u001a\u00020*H\u0002J$\u0010\u0082\u0002\u001a\u00020\u00072\u0007\u0010ÿ\u0001\u001a\u00020#2\u0007\u0010\u0080\u0002\u001a\u00020*2\u0007\u0010\u0081\u0002\u001a\u00020*H\u0002J$\u0010\u0083\u0002\u001a\u00020\u00072\u0007\u0010ÿ\u0001\u001a\u00020#2\u0007\u0010\u0080\u0002\u001a\u00020*2\u0007\u0010\u0081\u0002\u001a\u00020*H\u0002J\u001b\u0010\u0084\u0002\u001a\u00020*2\u0007\u0010ÿ\u0001\u001a\u00020#2\u0007\u0010\u0080\u0002\u001a\u00020*H\u0002J/\u0010\u0085\u0002\u001a\u00030\u0086\u00022\b\u0010õ\u0001\u001a\u00030\u0086\u00022\u0007\u0010\u0087\u0002\u001a\u00020*2\u0007\u0010\u0088\u0002\u001a\u00020*2\u0007\u0010\u0081\u0002\u001a\u00020*H\u0002J\u0012\u0010\u0089\u0002\u001a\u00020*2\u0007\u0010Ø\u0001\u001a\u00020#H\u0002J%\u0010\u008a\u0002\u001a\u00020\u00192\b\u0010ß\u0001\u001a\u00030à\u00012\u0007\u0010\u008b\u0002\u001a\u00020#2\u0007\u0010â\u0001\u001a\u000208H\u0002J\u001b\u0010\u008c\u0002\u001a\u00020\u00192\u0007\u0010Ø\u0001\u001a\u00020#2\u0007\u0010\u008b\u0002\u001a\u00020#H\u0002J\u0011\u0010\u008d\u0002\u001a\u00020\u00062\u0006\u0010b\u001a\u00020\u0006H\u0002J\u0013\u0010\u008e\u0002\u001a\u0004\u0018\u00010\u00062\u0006\u0010b\u001a\u00020\u0006H\u0002J\u000b\u0010\u008f\u0002\u001a\u0004\u0018\u00010\u0006H\u0002J\u001b\u0010\u0090\u0002\u001a\u00020*2\u0007\u0010\u0091\u0002\u001a\u00020\u00062\u0007\u0010\u0092\u0002\u001a\u00020*H\u0002J\t\u0010\u0093\u0002\u001a\u00020\u0007H\u0002J\u0014\u0010\u0094\u0002\u001a\u0004\u0018\u00010\u00152\u0007\u0010\u0095\u0002\u001a\u00020\u0013H\u0002J#\u0010\u0096\u0002\u001a\u00020\u00072\t\b\u0002\u0010\u0097\u0002\u001a\u00020\u00192\r\u0010\u0098\u0002\u001a\b\u0012\u0004\u0012\u00020\u00070:H\u0003J\u0012\u0010\u0099\u0002\u001a\u00020\u00072\u0007\u0010\u0097\u0002\u001a\u00020\u0019H\u0002J\u001b\u0010\u009a\u0002\u001a\u00020\u00072\u0007\u0010\u0095\u0002\u001a\u00020\u00132\u0007\u0010\u009b\u0002\u001a\u00020\u0015H\u0003J$\u0010\u009c\u0002\u001a\u00020\u00072\u0007\u0010\u0095\u0002\u001a\u00020\u00132\u0007\u0010\u009b\u0002\u001a\u00020\u00152\u0007\u0010¤\u0001\u001a\u00020&H\u0003J\u001b\u0010\u009d\u0002\u001a\u00020\u00072\u0007\u0010\u0095\u0002\u001a\u00020\u00132\u0007\u0010\u009b\u0002\u001a\u00020\u0015H\u0002J\t\u0010\u009e\u0002\u001a\u00020\u0007H\u0002J\u000e\u0010\u009f\u0002\u001a\u00020&*\u00030\u00a0\u0002H\u0002J\u0012\u0010¡\u0002\u001a\u00020\u00062\u0007\u0010\u0081\u0002\u001a\u00020\u0006H\u0002J\t\u0010¢\u0002\u001a\u00020\u0019H\u0002J\u0012\u0010£\u0002\u001a\u00020\u00072\u0007\u0010¤\u0002\u001a\u00020\u0006H\u0002J\u0018\u0010¥\u0002\u001a\u00020\u00072\r\u0010¦\u0002\u001a\b\u0012\u0004\u0012\u00020\u00070:H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0013X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001c\u001a\u0004\u0018\u00010\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010 \u001a\u0004\u0018\u00010!X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\"\u001a\u0004\u0018\u00010#X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010$\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010%\u001a\u0004\u0018\u00010&X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\'\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010(\u001a\u0004\u0018\u00010&X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010+\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00100\u001a\u0004\u0018\u000101X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00102\u001a\u0004\u0018\u000103X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u00105\u001a\u0004\u0018\u000106X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u000208X\u0082\u000e¢\u0006\u0002\n\u0000R\"\u00109\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010:X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b;\u0010<\"\u0004\b=\u0010>R\u000e\u0010@\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010A\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010B\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010C\u001a\u0004\u0018\u000101X\u0082\u000e¢\u0006\u0002\n\u0000R+\u0010E\u001a\u00020\u00062\u0006\u0010D\u001a\u00020\u00068F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bJ\u0010K\u001a\u0004\bF\u0010G\"\u0004\bH\u0010IR+\u0010L\u001a\u00020\u00062\u0006\u0010D\u001a\u00020\u00068F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bO\u0010K\u001a\u0004\bM\u0010G\"\u0004\bN\u0010IR/\u0010Q\u001a\u0004\u0018\u00010P2\b\u0010D\u001a\u0004\u0018\u00010P8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bV\u0010K\u001a\u0004\bR\u0010S\"\u0004\bT\u0010UR/\u0010X\u001a\u0004\u0018\u00010W2\b\u0010D\u001a\u0004\u0018\u00010W8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b]\u0010K\u001a\u0004\bY\u0010Z\"\u0004\b[\u0010\\R+\u0010^\u001a\u00020\u00062\u0006\u0010D\u001a\u00020\u00068F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\ba\u0010K\u001a\u0004\b_\u0010G\"\u0004\b`\u0010IR+\u0010b\u001a\u00020\u00062\u0006\u0010D\u001a\u00020\u00068F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\be\u0010K\u001a\u0004\bc\u0010G\"\u0004\bd\u0010IR+\u0010f\u001a\u00020\u00192\u0006\u0010D\u001a\u00020\u00198F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bk\u0010K\u001a\u0004\bg\u0010h\"\u0004\bi\u0010jR+\u0010l\u001a\u00020\u00062\u0006\u0010D\u001a\u00020\u00068F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bo\u0010K\u001a\u0004\bm\u0010G\"\u0004\bn\u0010IR+\u0010p\u001a\u00020*2\u0006\u0010D\u001a\u00020*8F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bu\u0010K\u001a\u0004\bq\u0010r\"\u0004\bs\u0010tR+\u0010v\u001a\u00020\u00062\u0006\u0010D\u001a\u00020\u00068F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\by\u0010K\u001a\u0004\bw\u0010G\"\u0004\bx\u0010IR+\u0010z\u001a\u00020\u00192\u0006\u0010D\u001a\u00020\u00198F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b|\u0010K\u001a\u0004\bz\u0010h\"\u0004\b{\u0010jR+\u0010}\u001a\u00020\u00192\u0006\u0010D\u001a\u00020\u00198F@BX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b\u007f\u0010K\u001a\u0004\b}\u0010h\"\u0004\b~\u0010jR/\u0010\u0080\u0001\u001a\u00020\u00192\u0006\u0010D\u001a\u00020\u00198F@BX\u0086\u008e\u0002¢\u0006\u0015\n\u0005\b\u0082\u0001\u0010K\u001a\u0005\b\u0080\u0001\u0010h\"\u0005\b\u0081\u0001\u0010jR/\u0010\u0083\u0001\u001a\u00020\u00192\u0006\u0010D\u001a\u00020\u00198F@BX\u0086\u008e\u0002¢\u0006\u0015\n\u0005\b\u0085\u0001\u0010K\u001a\u0005\b\u0083\u0001\u0010h\"\u0005\b\u0084\u0001\u0010jR/\u0010\u0086\u0001\u001a\u00020\u00192\u0006\u0010D\u001a\u00020\u00198F@BX\u0086\u008e\u0002¢\u0006\u0015\n\u0005\b\u0088\u0001\u0010K\u001a\u0005\b\u0086\u0001\u0010h\"\u0005\b\u0087\u0001\u0010jR\u001b\u0010\u0089\u0001\u001a\t\u0012\u0004\u0012\u00020&0\u008a\u0001¢\u0006\n\n\u0000\u001a\u0006\b\u008b\u0001\u0010\u008c\u0001R\u001b\u0010\u008d\u0001\u001a\t\u0012\u0004\u0012\u00020P0\u008a\u0001¢\u0006\n\n\u0000\u001a\u0006\b\u008e\u0001\u0010\u008c\u0001R\u0013\u0010\u008f\u0001\u001a\u00020\u00198F¢\u0006\u0007\u001a\u0005\b\u0090\u0001\u0010hR\u0013\u0010\u0091\u0001\u001a\u00030\u0092\u0001X\u0082\u0004¢\u0006\u0005\n\u0003\u0010\u0093\u0001¨\u0006§\u0002"
    }
    d2 = {
        "Lcom/example/bleconnectse/YadeaOtaClient;",
        "",
        "context",
        "Landroid/content/Context;",
        "logger",
        "Lkotlin/Function1;",
        "",
        "",
        "<init>",
        "(Landroid/content/Context;Lkotlin/jvm/functions/Function1;)V",
        "mainHandler",
        "Landroid/os/Handler;",
        "executor",
        "Ljava/util/concurrent/ExecutorService;",
        "connectivityManager",
        "Landroid/net/ConnectivityManager;",
        "wifiManager",
        "Landroid/net/wifi/WifiManager;",
        "p2pManager",
        "Landroid/net/wifi/p2p/WifiP2pManager;",
        "p2pChannel",
        "Landroid/net/wifi/p2p/WifiP2pManager$Channel;",
        "p2pReceiver",
        "Landroid/content/BroadcastReceiver;",
        "apScanReceiverRegistered",
        "",
        "wifiCallback",
        "Landroid/net/ConnectivityManager$NetworkCallback;",
        "wifiNetwork",
        "Landroid/net/Network;",
        "httpServer",
        "Lcom/example/bleconnectse/OtaHttpServer;",
        "firmwareUri",
        "Landroid/net/Uri;",
        "firmwareBytes",
        "",
        "p2pGroupOwnerIp",
        "selectedP2pPeer",
        "Lcom/example/bleconnectse/P2pPeer;",
        "p2pPeerVerified",
        "pendingP2pPeer",
        "p2pOperationGeneration",
        "",
        "bleLockedAddress",
        "autoConnectLockedApAfterScan",
        "autoConnectLockedP2pAfterScan",
        "mirrorStopRequested",
        "mirrorSessionActive",
        "activeMirrorSocket",
        "Ljava/net/Socket;",
        "activeMirrorDataSocket",
        "Ljava/net/DatagramSocket;",
        "mirrorLock",
        "pendingMirrorContent",
        "Lcom/example/bleconnectse/MirrorContent;",
        "mirrorGeneration",
        "",
        "onMirrorSessionEnded",
        "Lkotlin/Function0;",
        "getOnMirrorSessionEnded",
        "()Lkotlin/jvm/functions/Function0;",
        "setOnMirrorSessionEnded",
        "(Lkotlin/jvm/functions/Function0;)V",
        "hasActiveMirrorSession",
        "wallpaperLock",
        "wallpaperSessionActive",
        "wallpaperStopRequested",
        "activeWallpaperSocket",
        "<set-?>",
        "status",
        "getStatus",
        "()Ljava/lang/String;",
        "setStatus",
        "(Ljava/lang/String;)V",
        "status$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "firmwareName",
        "getFirmwareName",
        "setFirmwareName",
        "firmwareName$delegate",
        "Lcom/example/bleconnectse/YadeaWifiProfile;",
        "wifiProfile",
        "getWifiProfile",
        "()Lcom/example/bleconnectse/YadeaWifiProfile;",
        "setWifiProfile",
        "(Lcom/example/bleconnectse/YadeaWifiProfile;)V",
        "wifiProfile$delegate",
        "Lcom/example/bleconnectse/OtaNetworkMode;",
        "activeMode",
        "getActiveMode",
        "()Lcom/example/bleconnectse/OtaNetworkMode;",
        "setActiveMode",
        "(Lcom/example/bleconnectse/OtaNetworkMode;)V",
        "activeMode$delegate",
        "localIp",
        "getLocalIp",
        "setLocalIp",
        "localIp$delegate",
        "targetIp",
        "getTargetIp",
        "setTargetIp",
        "targetIp$delegate",
        "httpRunning",
        "getHttpRunning",
        "()Z",
        "setHttpRunning",
        "(Z)V",
        "httpRunning$delegate",
        "mirrorStatus",
        "getMirrorStatus",
        "setMirrorStatus",
        "mirrorStatus$delegate",
        "mirrorFrameCount",
        "getMirrorFrameCount",
        "()I",
        "setMirrorFrameCount",
        "(I)V",
        "mirrorFrameCount$delegate",
        "wallpaperStatus",
        "getWallpaperStatus",
        "setWallpaperStatus",
        "wallpaperStatus$delegate",
        "isApReady",
        "setApReady",
        "isApReady$delegate",
        "isLockedApSeen",
        "setLockedApSeen",
        "isLockedApSeen$delegate",
        "isApConnectionRequested",
        "setApConnectionRequested",
        "isApConnectionRequested$delegate",
        "isApConnectionFailed",
        "setApConnectionFailed",
        "isApConnectionFailed$delegate",
        "isP2pReady",
        "setP2pReady",
        "isP2pReady$delegate",
        "p2pPeers",
        "Landroidx/compose/runtime/snapshots/SnapshotStateList;",
        "getP2pPeers",
        "()Landroidx/compose/runtime/snapshots/SnapshotStateList;",
        "apCandidates",
        "getApCandidates",
        "hasFirmware",
        "getHasFirmware",
        "apScanReceiver",
        "com/example/bleconnectse/YadeaOtaClient$apScanReceiver$1",
        "Lcom/example/bleconnectse/YadeaOtaClient$apScanReceiver$1;",
        "setFirmware",
        "uri",
        "refreshWifiProfile",
        "bleAddress",
        "updateBleConnectionAddress",
        "connectAp",
        "connectLockedApDirect",
        "connectApProfile",
        "profile",
        "manualOverride",
        "scanApCandidates",
        "autoConnectLockedTarget",
        "requestApNetwork",
        "discoverP2p",
        "autoConnectP2p",
        "connectP2p",
        "peer",
        "disconnectP2p",
        "startApOta",
        "startP2pOta",
        "startApMirrorDemo",
        "startP2pMirrorDemo",
        "startMirrorDemoForCurrentMode",
        "startImageMirror",
        "startLiveMirror",
        "sourceName",
        "startInstrumentWallpaper",
        "stopInstrumentWallpaper",
        "validateMirrorNetwork",
        "mode",
        "startOta",
        "startMirror",
        "content",
        "stopMirrorDemo",
        "stopHttpServer",
        "close",
        "ensureProfile",
        "lockedBleWifiProfile",
        "peerMatchesProfile",
        "apMatchesProfile",
        "ap",
        "buildWifiProfile",
        "handleApScanResults",
        "freshResults",
        "scanResultToWifiProfile",
        "result",
        "Landroid/net/wifi/ScanResult;",
        "passwordMacFromAp",
        "ssid",
        "bssid",
        "registerApScanReceiver",
        "unregisterApScanReceiver",
        "displayNameOf",
        "ensureFirmwareLoaded",
        "startHttpServer",
        "port",
        "firmware",
        "sendTcpOtaRequest",
        "request",
        "createSocket",
        "connectTimeoutMs",
        "createSocketWithRetry",
        "createDatagramSocket",
        "buildYadeaWifiCmdReq",
        "buildNavStartPayload",
        "packetSize",
        "parseNavDisplayConfig",
        "Lcom/example/bleconnectse/NavDisplayConfig;",
        "data",
        "buildHeartbeatPayload",
        "buildNavEndPayload",
        "buildNavFrame",
        "cmd",
        "readNavResponse",
        "Lcom/example/bleconnectse/NavResponse;",
        "input",
        "Ljava/io/InputStream;",
        "expectedCmd",
        "timeoutMs",
        "parseNavResponses",
        "",
        "bytes",
        "sendImagePackets",
        "socket",
        "targets",
        "Ljava/net/InetSocketAddress;",
        "image",
        "imageSequence",
        "sendNavigationHint",
        "output",
        "Ljava/io/OutputStream;",
        "name",
        "sleepMirrorInterval",
        "totalMs",
        "sendHeartbeatIfDue",
        "lastHeartbeatAt",
        "bitmapToMirrorJpeg",
        "source",
        "Landroid/graphics/Bitmap;",
        "width",
        "height",
        "loadMirrorImageJpeg",
        "buildDemoMapJpeg",
        "navChecksum",
        "frame",
        "checksumEndExclusive",
        "writeUInt16Be",
        "buffer",
        "offset",
        "value",
        "writeUInt16Le",
        "writeUInt32Be",
        "readUInt32Be",
        "setBits",
        "",
        "startBit",
        "bitCount",
        "crc16Modbus",
        "readUntil",
        "expected",
        "contains",
        "detectLocalIpv4",
        "detectLocalIpv4BySocket",
        "detectLocalIpv4ByInterface",
        "parseLastOctet",
        "ip",
        "fallback",
        "disconnectWifi",
        "ensureP2pChannel",
        "manager",
        "disconnectP2pInternal",
        "keepSelectedPeer",
        "onComplete",
        "clearP2pConnectionState",
        "discoverPendingP2pPeer",
        "channel",
        "issueP2pConnect",
        "registerP2pReceiver",
        "unregisterP2pReceiver",
        "toPeer",
        "Landroid/net/wifi/p2p/WifiP2pDevice;",
        "normalizeMac",
        "hasWifiPermission",
        "logStatus",
        "message",
        "post",
        "block",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private volatile activeMirrorDataSocket:Ljava/net/DatagramSocket;

.field private volatile activeMirrorSocket:Ljava/net/Socket;

.field private final activeMode$delegate:Landroidx/compose/runtime/MutableState;

.field private volatile activeWallpaperSocket:Ljava/net/Socket;

.field private final apCandidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "Lcom/example/bleconnectse/YadeaWifiProfile;",
            ">;"
        }
    .end annotation
.end field

.field private final apScanReceiver:Lcom/example/bleconnectse/YadeaOtaClient$apScanReceiver$1;

.field private apScanReceiverRegistered:Z

.field private autoConnectLockedApAfterScan:Z

.field private autoConnectLockedP2pAfterScan:Z

.field private bleLockedAddress:Ljava/lang/String;

.field private final connectivityManager:Landroid/net/ConnectivityManager;

.field private final context:Landroid/content/Context;

.field private final executor:Ljava/util/concurrent/ExecutorService;

.field private firmwareBytes:[B

.field private final firmwareName$delegate:Landroidx/compose/runtime/MutableState;

.field private firmwareUri:Landroid/net/Uri;

.field private final httpRunning$delegate:Landroidx/compose/runtime/MutableState;

.field private httpServer:Lcom/example/bleconnectse/OtaHttpServer;

.field private final isApConnectionFailed$delegate:Landroidx/compose/runtime/MutableState;

.field private final isApConnectionRequested$delegate:Landroidx/compose/runtime/MutableState;

.field private final isApReady$delegate:Landroidx/compose/runtime/MutableState;

.field private final isLockedApSeen$delegate:Landroidx/compose/runtime/MutableState;

.field private final isP2pReady$delegate:Landroidx/compose/runtime/MutableState;

.field private final localIp$delegate:Landroidx/compose/runtime/MutableState;

.field private final logger:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final mainHandler:Landroid/os/Handler;

.field private final mirrorFrameCount$delegate:Landroidx/compose/runtime/MutableState;

.field private mirrorGeneration:J

.field private final mirrorLock:Ljava/lang/Object;

.field private volatile mirrorSessionActive:Z

.field private final mirrorStatus$delegate:Landroidx/compose/runtime/MutableState;

.field private volatile mirrorStopRequested:Z

.field private onMirrorSessionEnded:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private p2pChannel:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

.field private p2pGroupOwnerIp:Ljava/lang/String;

.field private final p2pManager:Landroid/net/wifi/p2p/WifiP2pManager;

.field private p2pOperationGeneration:I

.field private p2pPeerVerified:Z

.field private final p2pPeers:Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "Lcom/example/bleconnectse/P2pPeer;",
            ">;"
        }
    .end annotation
.end field

.field private p2pReceiver:Landroid/content/BroadcastReceiver;

.field private pendingMirrorContent:Lcom/example/bleconnectse/MirrorContent;

.field private pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

.field private selectedP2pPeer:Lcom/example/bleconnectse/P2pPeer;

.field private final status$delegate:Landroidx/compose/runtime/MutableState;

.field private final targetIp$delegate:Landroidx/compose/runtime/MutableState;

.field private final wallpaperLock:Ljava/lang/Object;

.field private volatile wallpaperSessionActive:Z

.field private final wallpaperStatus$delegate:Landroidx/compose/runtime/MutableState;

.field private volatile wallpaperStopRequested:Z

.field private wifiCallback:Landroid/net/ConnectivityManager$NetworkCallback;

.field private final wifiManager:Landroid/net/wifi/WifiManager;

.field private wifiNetwork:Landroid/net/Network;

.field private final wifiProfile$delegate:Landroidx/compose/runtime/MutableState;


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "logger"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 104
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 105
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    .line 106
    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->logger:Lkotlin/jvm/functions/Function1;

    .line 108
    new-instance p2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p2, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    .line 109
    invoke-static {}, Ljava/util/concurrent/Executors;->newCachedThreadPool()Ljava/util/concurrent/ExecutorService;

    move-result-object p2

    const-string v0, "newCachedThreadPool(...)"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->executor:Ljava/util/concurrent/ExecutorService;

    .line 111
    const-string p2, "connectivity"

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    const-string v0, "null cannot be cast to non-null type android.net.ConnectivityManager"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Landroid/net/ConnectivityManager;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->connectivityManager:Landroid/net/ConnectivityManager;

    .line 112
    const-string/jumbo p2, "wifi"

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    const-string v0, "null cannot be cast to non-null type android.net.wifi.WifiManager"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Landroid/net/wifi/WifiManager;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiManager:Landroid/net/wifi/WifiManager;

    .line 114
    const-string/jumbo p2, "wifip2p"

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    instance-of p2, p1, Landroid/net/wifi/p2p/WifiP2pManager;

    const/4 v0, 0x0

    if-eqz p2, :cond_55

    check-cast p1, Landroid/net/wifi/p2p/WifiP2pManager;

    goto :goto_56

    :cond_55
    move-object p1, v0

    :goto_56
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pManager:Landroid/net/wifi/p2p/WifiP2pManager;

    .line 139
    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorLock:Ljava/lang/Object;

    .line 145
    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperLock:Ljava/lang/Object;

    .line 153
    const-string/jumbo p1, "网络空闲"

    const/4 p2, 0x2

    invoke-static {p1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->status$delegate:Landroidx/compose/runtime/MutableState;

    .line 155
    const-string/jumbo p1, "未选择升级包"

    invoke-static {p1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->firmwareName$delegate:Landroidx/compose/runtime/MutableState;

    .line 157
    invoke-static {v0, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiProfile$delegate:Landroidx/compose/runtime/MutableState;

    .line 159
    invoke-static {v0, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeMode$delegate:Landroidx/compose/runtime/MutableState;

    .line 161
    const-string p1, ""

    invoke-static {p1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->localIp$delegate:Landroidx/compose/runtime/MutableState;

    .line 163
    const-string p1, "192.168.7.1"

    invoke-static {p1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->targetIp$delegate:Landroidx/compose/runtime/MutableState;

    const/4 p1, 0x0

    .line 165
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->httpRunning$delegate:Landroidx/compose/runtime/MutableState;

    .line 167
    const-string/jumbo v1, "投屏空闲"

    invoke-static {v1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStatus$delegate:Landroidx/compose/runtime/MutableState;

    .line 169
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorFrameCount$delegate:Landroidx/compose/runtime/MutableState;

    .line 171
    const-string/jumbo v1, "壁纸空闲"

    invoke-static {v1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperStatus$delegate:Landroidx/compose/runtime/MutableState;

    .line 173
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isApReady$delegate:Landroidx/compose/runtime/MutableState;

    .line 175
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isLockedApSeen$delegate:Landroidx/compose/runtime/MutableState;

    .line 177
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isApConnectionRequested$delegate:Landroidx/compose/runtime/MutableState;

    .line 179
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isApConnectionFailed$delegate:Landroidx/compose/runtime/MutableState;

    .line 181
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-static {p1, v0, p2, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isP2pReady$delegate:Landroidx/compose/runtime/MutableState;

    .line 184
    invoke-static {}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateListOf()Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeers:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 185
    invoke-static {}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateListOf()Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apCandidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 189
    new-instance p1, Lcom/example/bleconnectse/YadeaOtaClient$apScanReceiver$1;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$apScanReceiver$1;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apScanReceiver:Lcom/example/bleconnectse/YadeaOtaClient$apScanReceiver$1;

    return-void
.end method

.method public static final synthetic access$detectLocalIpv4(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->detectLocalIpv4(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$disconnectP2pInternal$finishCleanup(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;Ljava/lang/String;)V
    .registers 6

    .line 104
    invoke-static/range {p0 .. p5}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal$finishCleanup(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$disconnectP2pInternal$removeCurrentGroup(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V
    .registers 7

    .line 104
    invoke-static/range {p0 .. p6}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal$removeCurrentGroup(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static final synthetic access$getAutoConnectLockedP2pAfterScan$p(Lcom/example/bleconnectse/YadeaOtaClient;)Z
    .registers 1

    .line 104
    iget-boolean p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedP2pAfterScan:Z

    return p0
.end method

.method public static final synthetic access$getPendingP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;)Lcom/example/bleconnectse/P2pPeer;
    .registers 1

    .line 104
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    return-object p0
.end method

.method public static final synthetic access$getSelectedP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;)Lcom/example/bleconnectse/P2pPeer;
    .registers 1

    .line 104
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->selectedP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    return-object p0
.end method

.method public static final synthetic access$getWifiNetwork$p(Lcom/example/bleconnectse/YadeaOtaClient;)Landroid/net/Network;
    .registers 1

    .line 104
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiNetwork:Landroid/net/Network;

    return-object p0
.end method

.method public static final synthetic access$handleApScanResults(Lcom/example/bleconnectse/YadeaOtaClient;Z)V
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->handleApScanResults(Z)V

    return-void
.end method

.method public static final synthetic access$hasWifiPermission(Lcom/example/bleconnectse/YadeaOtaClient;)Z
    .registers 1

    .line 104
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->hasWifiPermission()Z

    move-result p0

    return p0
.end method

.method public static final synthetic access$issueP2pConnect(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Lcom/example/bleconnectse/P2pPeer;)V
    .registers 4

    .line 104
    invoke-direct {p0, p1, p2, p3}, Lcom/example/bleconnectse/YadeaOtaClient;->issueP2pConnect(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Lcom/example/bleconnectse/P2pPeer;)V

    return-void
.end method

.method public static final synthetic access$lockedBleWifiProfile(Lcom/example/bleconnectse/YadeaOtaClient;)Lcom/example/bleconnectse/YadeaWifiProfile;
    .registers 1

    .line 104
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$normalizeMac(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->normalizeMac(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic access$peerMatchesProfile(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;Lcom/example/bleconnectse/YadeaWifiProfile;)Z
    .registers 3

    .line 104
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->peerMatchesProfile(Lcom/example/bleconnectse/P2pPeer;Lcom/example/bleconnectse/YadeaWifiProfile;)Z

    move-result p0

    return p0
.end method

.method public static final synthetic access$post(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/functions/Function0;)V
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static final synthetic access$setApConnectionFailed(Lcom/example/bleconnectse/YadeaOtaClient;Z)V
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionFailed(Z)V

    return-void
.end method

.method public static final synthetic access$setApConnectionRequested(Lcom/example/bleconnectse/YadeaOtaClient;Z)V
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionRequested(Z)V

    return-void
.end method

.method public static final synthetic access$setApReady(Lcom/example/bleconnectse/YadeaOtaClient;Z)V
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApReady(Z)V

    return-void
.end method

.method public static final synthetic access$setAutoConnectLockedP2pAfterScan$p(Lcom/example/bleconnectse/YadeaOtaClient;Z)V
    .registers 2

    .line 104
    iput-boolean p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedP2pAfterScan:Z

    return-void
.end method

.method public static final synthetic access$setLocalIp(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setLocalIp(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setP2pGroupOwnerIp$p(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V
    .registers 2

    .line 104
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$setP2pPeerVerified$p(Lcom/example/bleconnectse/YadeaOtaClient;Z)V
    .registers 2

    .line 104
    iput-boolean p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeerVerified:Z

    return-void
.end method

.method public static final synthetic access$setP2pReady(Lcom/example/bleconnectse/YadeaOtaClient;Z)V
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setP2pReady(Z)V

    return-void
.end method

.method public static final synthetic access$setPendingP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V
    .registers 2

    .line 104
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    return-void
.end method

.method public static final synthetic access$setSelectedP2pPeer$p(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V
    .registers 2

    .line 104
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->selectedP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    return-void
.end method

.method public static final synthetic access$setTargetIp(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setTargetIp(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setWifiNetwork$p(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Network;)V
    .registers 2

    .line 104
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiNetwork:Landroid/net/Network;

    return-void
.end method

.method public static final synthetic access$toPeer(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/wifi/p2p/WifiP2pDevice;)Lcom/example/bleconnectse/P2pPeer;
    .registers 2

    .line 104
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->toPeer(Landroid/net/wifi/p2p/WifiP2pDevice;)Lcom/example/bleconnectse/P2pPeer;

    move-result-object p0

    return-object p0
.end method

.method private final apMatchesProfile(Lcom/example/bleconnectse/YadeaWifiProfile;Lcom/example/bleconnectse/YadeaWifiProfile;)Z
    .registers 6

    .line 996
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_42

    .line 997
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getWifiMac()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->normalizeMac(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2}, Lcom/example/bleconnectse/YadeaWifiProfile;->getWifiMac()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->normalizeMac(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_42

    .line 998
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBssid()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_2d

    const-string p1, ""

    :cond_2d
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->normalizeMac(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2}, Lcom/example/bleconnectse/YadeaWifiProfile;->getWifiMac()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->normalizeMac(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_40

    goto :goto_42

    :cond_40
    const/4 p0, 0x0

    return p0

    :cond_42
    :goto_42
    return v2
.end method

.method static final autoConnectP2p$lambda$14(Lcom/example/bleconnectse/P2pPeer;)Ljava/lang/CharSequence;
    .registers 3

    const-string v0, "candidate"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 511
    invoke-virtual {p0}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_14

    const-string/jumbo v0, "未命名"

    :cond_14
    invoke-virtual {p0}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, ")"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    check-cast p0, Ljava/lang/CharSequence;

    return-object p0
.end method

.method private final bitmapToMirrorJpeg(Landroid/graphics/Bitmap;II)[B
    .registers 9

    .line 1471
    sget-object p0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p2, p3, p0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p0

    const-string v0, "createBitmap(...)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1472
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v0, v1

    int-to-float p2, p2

    int-to-float p3, p3

    div-float v1, p2, p3

    cmpl-float v0, v0, v1

    const/4 v2, 0x0

    if-lez v0, :cond_38

    .line 1475
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v0

    int-to-float v0, v0

    mul-float/2addr v0, v1

    float-to-int v0, v0

    .line 1476
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    sub-int/2addr v1, v0

    div-int/lit8 v1, v1, 0x2

    .line 1477
    new-instance v3, Landroid/graphics/Rect;

    add-int/2addr v0, v1

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    invoke-direct {v3, v1, v2, v0, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    goto :goto_50

    .line 1479
    :cond_38
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    int-to-float v0, v0

    div-float/2addr v0, v1

    float-to-int v0, v0

    .line 1480
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    sub-int/2addr v1, v0

    div-int/lit8 v1, v1, 0x2

    .line 1481
    new-instance v3, Landroid/graphics/Rect;

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    add-int/2addr v0, v1

    invoke-direct {v3, v2, v1, v4, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 1483
    :goto_50
    new-instance v0, Landroid/graphics/Canvas;

    invoke-direct {v0, p0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 1486
    new-instance v1, Landroid/graphics/RectF;

    const/4 v2, 0x0

    invoke-direct {v1, v2, v2, p2, p3}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1487
    new-instance p2, Landroid/graphics/Paint;

    const/4 p3, 0x3

    invoke-direct {p2, p3}, Landroid/graphics/Paint;-><init>(I)V

    .line 1483
    invoke-virtual {v0, p1, v3, v1, p2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    const/16 p1, 0x3c

    .line 1493
    :cond_66
    :try_start_66
    new-instance p2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    check-cast p2, Ljava/io/Closeable;
    :try_end_6d
    .catchall {:try_start_66 .. :try_end_6d} :catchall_9c

    :try_start_6d
    move-object p3, p2

    check-cast p3, Ljava/io/ByteArrayOutputStream;

    .line 1494
    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    move-object v1, p3

    check-cast v1, Ljava/io/OutputStream;

    invoke-virtual {p0, v0, p1, v1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 1495
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p3
    :try_end_7c
    .catchall {:try_start_6d .. :try_end_7c} :catchall_95

    const/4 v0, 0x0

    .line 1493
    :try_start_7d
    invoke-static {p2, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    const-string p2, "use(...)"

    invoke-static {p3, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    add-int/lit8 p1, p1, -0xf

    .line 1498
    array-length p2, p3
    :try_end_88
    .catchall {:try_start_7d .. :try_end_88} :catchall_9c

    const v0, 0x3c000

    if-le p2, v0, :cond_91

    const/16 p2, 0x23

    if-ge p1, p2, :cond_66

    .line 1501
    :cond_91
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->recycle()V

    return-object p3

    :catchall_95
    move-exception p1

    .line 1493
    :try_start_96
    throw p1
    :try_end_97
    .catchall {:try_start_96 .. :try_end_97} :catchall_97

    :catchall_97
    move-exception p3

    :try_start_98
    invoke-static {p2, p1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p3
    :try_end_9c
    .catchall {:try_start_98 .. :try_end_9c} :catchall_9c

    :catchall_9c
    move-exception p1

    .line 1501
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->recycle()V

    throw p1
.end method

.method private final buildDemoMapJpeg(II)[B
    .registers 21

    move/from16 v0, p2

    .line 1517
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    move/from16 v2, p1

    invoke-static {v2, v0, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    const-string v2, "createBitmap(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1518
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/16 v3, 0xf2

    const/16 v4, 0xeb

    const/16 v5, 0xec

    .line 1519
    invoke-static {v5, v3, v4}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/Canvas;->drawColor(I)V

    int-to-float v0, v0

    const/high16 v3, 0x43f00000  # 480.0f

    div-float/2addr v0, v3

    const/high16 v3, 0x3f800000  # 1.0f

    .line 1520
    invoke-virtual {v2, v3, v0}, Landroid/graphics/Canvas;->scale(FF)V

    .line 1521
    new-instance v0, Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-direct {v0, v3}, Landroid/graphics/Paint;-><init>(I)V

    .line 1523
    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/16 v4, 0xe7

    const/16 v5, 0xda

    const/16 v6, 0xd5

    .line 1524
    invoke-static {v6, v4, v5}, Landroid/graphics/Color;->rgb(III)I

    move-result v4

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v4, 0x0

    move v5, v4

    :goto_44
    const/high16 v6, 0x43c30000  # 390.0f

    const/4 v7, 0x5

    if-ge v5, v7, :cond_70

    mul-int/lit16 v7, v5, 0xd2

    add-int/lit8 v7, v7, -0x50

    int-to-float v7, v7

    .line 1527
    new-instance v8, Landroid/graphics/RectF;

    const/high16 v9, 0x43820000  # 260.0f

    add-float/2addr v9, v7

    const/high16 v10, 0x432a0000  # 170.0f

    const/high16 v11, -0x3d600000  # -80.0f

    invoke-direct {v8, v7, v11, v9, v10}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v2, v8, v0}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 1528
    new-instance v8, Landroid/graphics/RectF;

    const/high16 v9, 0x42b40000  # 90.0f

    add-float/2addr v9, v7

    add-float/2addr v7, v6

    const/high16 v6, 0x440c0000  # 560.0f

    const/high16 v10, 0x43a00000  # 320.0f

    invoke-direct {v8, v9, v10, v7, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v2, v8, v0}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    add-int/lit8 v5, v5, 0x1

    goto :goto_44

    .line 1531
    :cond_70
    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1532
    sget-object v5, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 1533
    sget-object v5, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    const/high16 v5, 0x42280000  # 42.0f

    .line 1534
    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/16 v5, 0xf7

    const/16 v7, 0xfa

    .line 1535
    invoke-static {v7, v7, v5}, Landroid/graphics/Color;->rgb(III)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 1536
    new-instance v7, Landroid/graphics/Path;

    invoke-direct {v7}, Landroid/graphics/Path;-><init>()V

    const/high16 v5, -0x3de00000  # -40.0f

    .line 1537
    invoke-virtual {v7, v5, v6}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v12, 0x43cd0000  # 410.0f

    const/high16 v13, 0x43750000  # 245.0f

    const/high16 v8, 0x43200000  # 160.0f

    const/high16 v9, 0x43a50000  # 330.0f

    const/high16 v10, 0x43820000  # 260.0f

    const/high16 v11, 0x43700000  # 240.0f

    .line 1538
    invoke-virtual/range {v7 .. v13}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    const/high16 v12, 0x447a0000  # 1000.0f

    const/high16 v13, 0x42bc0000  # 94.0f

    const v8, 0x44138000  # 590.0f

    const/high16 v9, 0x437a0000  # 250.0f

    const/high16 v10, 0x44200000  # 640.0f

    const/high16 v11, 0x42f00000  # 120.0f

    .line 1539
    invoke-virtual/range {v7 .. v13}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 1541
    invoke-virtual {v2, v7, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    const/high16 v5, 0x41100000  # 9.0f

    .line 1543
    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/16 v5, 0xb8

    const/16 v6, 0x45

    const/16 v8, 0xea

    .line 1544
    invoke-static {v8, v5, v6}, Landroid/graphics/Color;->rgb(III)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 1545
    invoke-virtual {v2, v7, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    const/high16 v5, 0x41900000  # 18.0f

    .line 1547
    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/16 v6, 0x4e

    const/16 v7, 0x8d

    const/16 v9, 0xf5

    .line 1548
    invoke-static {v6, v7, v9}, Landroid/graphics/Color;->rgb(III)I

    move-result v10

    invoke-virtual {v0, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 1549
    new-instance v11, Landroid/graphics/Path;

    invoke-direct {v11}, Landroid/graphics/Path;-><init>()V

    const/high16 v10, 0x428c0000  # 70.0f

    const/high16 v12, 0x43b40000  # 360.0f

    .line 1550
    invoke-virtual {v11, v10, v12}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v16, 0x43ce0000  # 412.0f

    const/high16 v17, 0x43860000  # 268.0f

    const/high16 v12, 0x43520000  # 210.0f

    const/high16 v13, 0x439f0000  # 318.0f

    const/high16 v14, 0x43910000  # 290.0f

    const/high16 v15, 0x43860000  # 268.0f

    .line 1551
    invoke-virtual/range {v11 .. v17}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    const/high16 v16, 0x445d0000  # 884.0f

    const/high16 v17, 0x42f40000  # 122.0f

    const v12, 0x44124000  # 585.0f

    const/high16 v13, 0x43860000  # 268.0f

    const v14, 0x4423c000  # 655.0f

    const/high16 v15, 0x431e0000  # 158.0f

    .line 1552
    invoke-virtual/range {v11 .. v17}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 1554
    invoke-virtual {v2, v11, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1556
    sget-object v10, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/16 v10, 0x5b

    const/16 v11, 0xd6

    const/16 v12, 0x1d

    .line 1557
    invoke-static {v12, v10, v11}, Landroid/graphics/Color;->rgb(III)I

    move-result v10

    invoke-virtual {v0, v10}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v10, 0x42a80000  # 84.0f

    const/high16 v11, 0x43b30000  # 358.0f

    .line 1558
    invoke-virtual {v2, v10, v11, v5, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/16 v10, 0x43

    const/16 v12, 0x35

    .line 1559
    invoke-static {v8, v10, v12}, Landroid/graphics/Color;->rgb(III)I

    move-result v8

    invoke-virtual {v0, v8}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v8, 0x445d0000  # 884.0f

    const/high16 v10, 0x42f40000  # 122.0f

    const/high16 v12, 0x41a00000  # 20.0f

    .line 1560
    invoke-virtual {v2, v8, v10, v12, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/16 v8, 0x18

    const/16 v10, 0x1f

    const/16 v13, 0x2a

    .line 1562
    invoke-static {v8, v10, v13}, Landroid/graphics/Color;->rgb(III)I

    move-result v14

    invoke-virtual {v0, v14}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v14, 0x42000000  # 32.0f

    .line 1563
    invoke-virtual {v0, v14}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1564
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 1565
    const-string v14, "Yadea Map Demo"

    const/high16 v15, 0x42500000  # 52.0f

    const/high16 v12, 0x42080000  # 34.0f

    invoke-virtual {v2, v14, v12, v15, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    const/high16 v14, 0x41c00000  # 24.0f

    .line 1566
    invoke-virtual {v0, v14}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1567
    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 1568
    const-string v14, "960x480 WiFi navigation mirror"

    const/high16 v15, 0x42ac0000  # 86.0f

    invoke-virtual {v2, v14, v12, v15, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1570
    sget-object v12, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v12}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/16 v12, 0xff

    .line 1571
    invoke-static {v12, v12, v12}, Landroid/graphics/Color;->rgb(III)I

    move-result v12

    invoke-virtual {v0, v12}, Landroid/graphics/Paint;->setColor(I)V

    .line 1572
    new-instance v12, Landroid/graphics/RectF;

    const/high16 v14, 0x44680000  # 928.0f

    const/high16 v15, 0x43e00000  # 448.0f

    const v4, 0x44228000  # 650.0f

    const/high16 v3, 0x43aa0000  # 340.0f

    invoke-direct {v12, v4, v3, v14, v15}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v2, v12, v5, v5, v0}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1573
    invoke-static {v6, v7, v9}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 1574
    new-instance v3, Landroid/graphics/Path;

    invoke-direct {v3}, Landroid/graphics/Path;-><init>()V

    const v4, 0x442c8000  # 690.0f

    const/high16 v5, 0x43ca0000  # 404.0f

    .line 1575
    invoke-virtual {v3, v4, v5}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v4, 0x44370000  # 732.0f

    .line 1576
    invoke-virtual {v3, v4, v11}, Landroid/graphics/Path;->lineTo(FF)V

    const v4, 0x44418000  # 774.0f

    .line 1577
    invoke-virtual {v3, v4, v5}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v4, 0x443b0000  # 748.0f

    .line 1578
    invoke-virtual {v3, v4, v5}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v6, 0x43d70000  # 430.0f

    .line 1579
    invoke-virtual {v3, v4, v6}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v4, 0x44330000  # 716.0f

    .line 1580
    invoke-virtual {v3, v4, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1581
    invoke-virtual {v3, v4, v5}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1582
    invoke-virtual {v3}, Landroid/graphics/Path;->close()V

    .line 1584
    invoke-virtual {v2, v3, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1585
    invoke-static {v8, v10, v13}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v3, 0x41f00000  # 30.0f

    .line 1586
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    const/4 v3, 0x1

    .line 1587
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 1588
    const-string v3, "320 m"

    const/high16 v4, 0x43c20000  # 388.0f

    const v5, 0x44488000  # 802.0f

    invoke-virtual {v2, v3, v5, v4, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    const/high16 v3, 0x41a00000  # 20.0f

    .line 1589
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    const/4 v3, 0x0

    .line 1590
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 1591
    const-string/jumbo v3, "直行进入演示大道"

    const/high16 v4, 0x43d30000  # 422.0f

    invoke-virtual {v2, v3, v5, v4, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1593
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    move-object v2, v0

    check-cast v2, Ljava/io/Closeable;

    :try_start_1f4
    move-object v0, v2

    check-cast v0, Ljava/io/ByteArrayOutputStream;

    .line 1594
    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    move-object v4, v0

    check-cast v4, Ljava/io/OutputStream;

    const/16 v5, 0x58

    invoke-virtual {v1, v3, v5, v4}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 1595
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 1596
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_208
    .catchall {:try_start_1f4 .. :try_end_208} :catchall_212

    const/4 v1, 0x0

    .line 1593
    invoke-static {v2, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    const-string v1, "use(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :catchall_212
    move-exception v0

    move-object v1, v0

    :try_start_214
    throw v1
    :try_end_215
    .catchall {:try_start_214 .. :try_end_215} :catchall_215

    :catchall_215
    move-exception v0

    invoke-static {v2, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method private final buildHeartbeatPayload()[B
    .registers 6

    .line 1276
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object p0

    const/16 v0, 0x8

    .line 1277
    new-array v1, v0, [B

    const/4 v2, 0x0

    move v3, v2

    :goto_a
    if-ge v3, v0, :cond_12

    const/4 v4, -0x1

    aput-byte v4, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_a

    :cond_12
    const/4 v0, 0x1

    .line 1278
    invoke-virtual {p0, v0}, Ljava/util/Calendar;->get(I)I

    move-result v3

    add-int/lit16 v3, v3, -0x7d0

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    const/4 v2, 0x2

    .line 1279
    invoke-virtual {p0, v2}, Ljava/util/Calendar;->get(I)I

    move-result v3

    add-int/2addr v3, v0

    int-to-byte v3, v3

    aput-byte v3, v1, v0

    const/4 v0, 0x5

    .line 1280
    invoke-virtual {p0, v0}, Ljava/util/Calendar;->get(I)I

    move-result v3

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    const/16 v2, 0xb

    .line 1281
    invoke-virtual {p0, v2}, Ljava/util/Calendar;->get(I)I

    move-result v2

    int-to-byte v2, v2

    const/4 v3, 0x3

    aput-byte v2, v1, v3

    const/16 v2, 0xc

    .line 1282
    invoke-virtual {p0, v2}, Ljava/util/Calendar;->get(I)I

    move-result v2

    int-to-byte v2, v2

    const/4 v3, 0x4

    aput-byte v2, v1, v3

    const/16 v2, 0xd

    .line 1283
    invoke-virtual {p0, v2}, Ljava/util/Calendar;->get(I)I

    move-result p0

    int-to-byte p0, p0

    aput-byte p0, v1, v0

    return-object v1
.end method

.method private final buildNavEndPayload()[B
    .registers 1

    const/16 p0, 0x8

    .line 1296
    new-array p0, p0, [B

    fill-array-data p0, :array_8

    return-object p0

    :array_8
    .array-data 1
        0x2t
        -0x1t
        -0x1t
        -0x1t
        -0x1t
        -0x1t
        -0x1t
        -0x1t
    .end array-data
.end method

.method private final buildNavFrame(I[B)[B
    .registers 14

    .line 1300
    array-length v0, p2

    add-int/lit8 v1, v0, 0x8

    add-int/lit8 v0, v0, 0xf

    .line 1301
    new-array v3, v0, [B

    const/4 v0, 0x0

    const/16 v2, 0x59

    .line 1302
    aput-byte v2, v3, v0

    const/16 v0, 0x44

    const/4 v9, 0x1

    .line 1303
    aput-byte v0, v3, v9

    const/16 v0, 0x3c

    const/4 v10, 0x2

    .line 1304
    aput-byte v0, v3, v10

    const/4 v0, 0x3

    .line 1305
    invoke-direct {p0, v3, v0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt32Be([BII)V

    const/4 v0, 0x7

    int-to-byte p1, p1

    .line 1306
    aput-byte p1, v3, v0

    .line 1307
    array-length p1, p2

    const/16 v0, 0x8

    invoke-direct {p0, v3, v0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt32Be([BII)V

    const/16 v7, 0xc

    const/4 v8, 0x0

    const/16 v4, 0xc

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v2, p2

    .line 1308
    invoke-static/range {v2 .. v8}, Lkotlin/collections/ArraysKt;->copyInto$default([B[BIIIILjava/lang/Object;)[B

    .line 1309
    invoke-static {v3}, Lkotlin/collections/ArraysKt;->getLastIndex([B)I

    move-result p1

    sub-int/2addr p1, v10

    invoke-static {v3}, Lkotlin/collections/ArraysKt;->getLastIndex([B)I

    move-result p2

    sub-int/2addr p2, v10

    invoke-direct {p0, v3, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->navChecksum([BI)I

    move-result p0

    int-to-byte p0, p0

    aput-byte p0, v3, p1

    .line 1310
    invoke-static {v3}, Lkotlin/collections/ArraysKt;->getLastIndex([B)I

    move-result p0

    sub-int/2addr p0, v9

    const/16 p1, 0x4b

    aput-byte p1, v3, p0

    .line 1311
    invoke-static {v3}, Lkotlin/collections/ArraysKt;->getLastIndex([B)I

    move-result p0

    const/16 p1, 0x4a

    aput-byte p1, v3, p0

    return-object v3
.end method

.method private final buildNavStartPayload(I)[B
    .registers 7

    const/16 v0, 0x8

    .line 1241
    new-array v1, v0, [B

    const/4 v2, 0x0

    move v3, v2

    :goto_6
    const/4 v4, -0x1

    if-ge v3, v0, :cond_e

    aput-byte v4, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_6

    .line 1242
    :cond_e
    invoke-direct {p0, v1, v2, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt16Be([BII)V

    const/4 v0, 0x2

    const/16 v2, -0x10

    .line 1243
    aput-byte v2, v1, v0

    const/4 v0, 0x3

    .line 1244
    aput-byte v4, v1, v0

    const/4 v0, 0x4

    .line 1245
    invoke-direct {p0, v1, v0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt32Be([BII)V

    return-object v1
.end method

.method private final buildWifiProfile(Ljava/lang/String;)Lcom/example/bleconnectse/YadeaWifiProfile;
    .registers 29

    const/4 v0, 0x0

    if-eqz p1, :cond_e6

    .line 1001
    move-object/from16 v1, p1

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v7, 0x1

    new-array v2, v7, [Ljava/lang/String;

    const/4 v3, 0x0

    const-string v8, ":"

    aput-object v8, v2, v3

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v1

    if-nez v1, :cond_1a

    goto/16 :goto_e6

    .line 1002
    :cond_1a
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x6

    if-eq v2, v3, :cond_22

    return-object v0

    .line 1004
    :cond_22
    :try_start_22
    move-object v2, v1

    check-cast v2, Ljava/lang/Iterable;

    .line 2303
    new-instance v3, Ljava/util/ArrayList;

    const/16 v4, 0xa

    invoke-static {v2, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .line 2304
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_36
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_56

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .line 2305
    check-cast v4, Ljava/lang/String;

    const/16 v5, 0x10

    .line 1004
    invoke-static {v5}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v4

    and-int/lit16 v4, v4, 0xff

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    .line 2305
    invoke-interface {v3, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_36

    .line 2306
    :cond_56
    check-cast v3, Ljava/util/List;
    :try_end_58
    .catch Ljava/lang/NumberFormatException; {:try_start_22 .. :try_end_58} :catch_e6

    .line 1008
    move-object v0, v3

    check-cast v0, Ljava/util/Collection;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toMutableList(Ljava/util/Collection;)Ljava/util/List;

    move-result-object v0

    .line 1009
    invoke-interface {v0, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    add-int/lit16 v2, v2, 0x82

    and-int/lit16 v2, v2, 0xff

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v7, v2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 1010
    move-object v9, v0

    check-cast v9, Ljava/lang/Iterable;

    move-object v10, v8

    check-cast v10, Ljava/lang/CharSequence;

    new-instance v15, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda9;

    invoke-direct {v15}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda9;-><init>()V

    const/16 v16, 0x1e

    const/16 v17, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-static/range {v9 .. v17}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 1011
    check-cast v3, Ljava/lang/Iterable;

    const/4 v2, 0x2

    invoke-static {v3, v2}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v2

    move-object v9, v2

    check-cast v9, Ljava/lang/Iterable;

    const-string v2, ""

    move-object v10, v2

    check-cast v10, Ljava/lang/CharSequence;

    new-instance v15, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda10;

    invoke-direct {v15}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda10;-><init>()V

    invoke-static/range {v9 .. v17}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 1012
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "YD"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "ICM"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v21

    .line 1013
    new-instance v18, Lcom/example/bleconnectse/YadeaWifiProfile;

    .line 1014
    move-object v9, v1

    check-cast v9, Ljava/lang/Iterable;

    move-object v10, v8

    check-cast v10, Ljava/lang/CharSequence;

    new-instance v15, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda12;

    invoke-direct {v15}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda12;-><init>()V

    invoke-static/range {v9 .. v17}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v19

    .line 1017
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Yadea@"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    const/16 v25, 0x30

    const/16 v26, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    move-object/from16 v20, v0

    .line 1013
    invoke-direct/range {v18 .. v26}, Lcom/example/bleconnectse/YadeaWifiProfile;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v18

    :catch_e6
    :cond_e6
    :goto_e6
    return-object v0
.end method

.method static final buildWifiProfile$lambda$77(I)Ljava/lang/CharSequence;
    .registers 3

    .line 1010
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    invoke-static {p0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const-string v1, "%02X"

    invoke-static {v0, v1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "format(...)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Ljava/lang/CharSequence;

    return-object p0
.end method

.method static final buildWifiProfile$lambda$78(I)Ljava/lang/CharSequence;
    .registers 3

    .line 1011
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    invoke-static {p0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const-string v1, "%02X"

    invoke-static {v0, v1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "format(...)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Ljava/lang/CharSequence;

    return-object p0
.end method

.method static final buildWifiProfile$lambda$79(Ljava/lang/String;)Ljava/lang/CharSequence;
    .registers 3

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1014
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v1, "US"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "toUpperCase(...)"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Ljava/lang/CharSequence;

    return-object p0
.end method

.method private final buildYadeaWifiCmdReq(Ljava/lang/String;)[B
    .registers 10

    const/16 v0, 0x9

    .line 1234
    new-array v0, v0, [B

    const/16 v1, 0x59

    const/4 v2, 0x0

    aput-byte v1, v0, v2

    const/4 v1, 0x1

    const/16 v3, 0x44

    aput-byte v3, v0, v1

    const/4 v1, 0x2

    const/16 v3, -0x10

    aput-byte v3, v0, v1

    const/4 v4, 0x3

    aput-byte v1, v0, v4

    const/16 v5, -0x7d

    const/4 v6, 0x4

    aput-byte v5, v0, v6

    const/4 v5, 0x5

    aput-byte v2, v0, v5

    const/4 v2, 0x6

    aput-byte v3, v0, v2

    const/4 v3, 0x7

    const/16 v7, 0x4b

    aput-byte v7, v0, v3

    const/16 v3, 0x8

    const/16 v7, 0x4a

    aput-byte v7, v0, v3

    .line 1235
    invoke-direct {p0, p1, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->parseLastOctet(Ljava/lang/String;I)I

    move-result p0

    int-to-byte p0, p0

    aput-byte p0, v0, v5

    .line 1236
    aget-byte p0, v0, v1

    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result p0

    aget-byte p1, v0, v4

    invoke-static {p1}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result p1

    add-int/2addr p0, p1

    aget-byte p1, v0, v6

    invoke-static {p1}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result p1

    add-int/2addr p0, p1

    aget-byte p1, v0, v5

    invoke-static {p1}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result p1

    add-int/2addr p0, p1

    and-int/lit16 p0, p0, 0xff

    int-to-byte p0, p0

    aput-byte p0, v0, v2

    return-object v0
.end method

.method private final clearP2pConnectionState(Z)V
    .registers 4

    const/4 v0, 0x0

    .line 1809
    iput-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeerVerified:Z

    .line 1810
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setP2pReady(Z)V

    const/4 v0, 0x0

    .line 1811
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    .line 1812
    const-string v1, "192.168.7.1"

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setTargetIp(Ljava/lang/String;)V

    if-nez p1, :cond_19

    .line 1814
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->selectedP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    .line 1815
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    .line 1816
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeers:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    invoke-virtual {p0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    :cond_19
    return-void
.end method

.method public static synthetic connectApProfile$default(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;ZILjava/lang/Object;)V
    .registers 5

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_5

    const/4 p2, 0x0

    .line 301
    :cond_5
    invoke-virtual {p0, p1, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->connectApProfile(Lcom/example/bleconnectse/YadeaWifiProfile;Z)V

    return-void
.end method

.method static final connectApProfile$lambda$1(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;)Lkotlin/Unit;
    .registers 2

    .line 330
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->requestApNetwork(Lcom/example/bleconnectse/YadeaWifiProfile;)V

    .line 331
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final connectLockedApDirect$lambda$0(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;)Lkotlin/Unit;
    .registers 2

    .line 297
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->requestApNetwork(Lcom/example/bleconnectse/YadeaWifiProfile;)V

    .line 298
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static synthetic connectP2p$default(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;ZILjava/lang/Object;)V
    .registers 5

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_5

    const/4 p2, 0x0

    .line 526
    :cond_5
    invoke-virtual {p0, p1, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->connectP2p(Lcom/example/bleconnectse/P2pPeer;Z)V

    return-void
.end method

.method static final connectP2p$lambda$21(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pInfo;)V
    .registers 5

    .line 555
    iget-boolean p4, p4, Landroid/net/wifi/p2p/WifiP2pInfo;->groupFormed:Z

    if-eqz p4, :cond_16

    .line 556
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    .line 557
    const-string/jumbo p4, "检测到旧 P2P Group，断开后重新发现目标"

    invoke-direct {p0, p4}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 558
    new-instance p4, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda46;

    invoke-direct {p4, p0, p1, p2, p3}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda46;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    const/4 p1, 0x1

    invoke-direct {p0, p1, p4}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal(ZLkotlin/jvm/functions/Function0;)V

    return-void

    :cond_16
    const/4 p4, 0x0

    .line 563
    iput-object p4, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    .line 564
    invoke-direct {p0, p2, p3, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->issueP2pConnect(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Lcom/example/bleconnectse/P2pPeer;)V

    return-void
.end method

.method static final connectP2p$lambda$21$lambda$20(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)Lkotlin/Unit;
    .registers 4

    .line 559
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->selectedP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    .line 560
    invoke-direct {p0, p2, p3}, Lcom/example/bleconnectse/YadeaOtaClient;->discoverPendingP2pPeer(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    .line 561
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private final contains([B[B)Z
    .registers 9

    .line 1671
    array-length p0, p1

    array-length v0, p2

    sub-int/2addr p0, v0

    const/4 v0, 0x0

    if-ltz p0, :cond_1d

    move v1, v0

    .line 1673
    :goto_7
    array-length v2, p2

    move v3, v0

    :goto_9
    if-ge v3, v2, :cond_1b

    add-int v4, v1, v3

    .line 1674
    aget-byte v4, p1, v4

    aget-byte v5, p2, v3

    if-eq v4, v5, :cond_18

    if-eq v1, p0, :cond_1d

    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_18
    add-int/lit8 v3, v3, 0x1

    goto :goto_9

    :cond_1b
    const/4 p0, 0x1

    return p0

    :cond_1d
    return v0
.end method

.method private final crc16Modbus([B)I
    .registers 8

    .line 2337
    array-length p0, p1

    const v0, 0xffff

    const/4 v1, 0x0

    move v3, v0

    move v2, v1

    :goto_7
    if-ge v2, p0, :cond_28

    aget-byte v4, p1, v2

    .line 1640
    invoke-static {v4}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v4

    xor-int/2addr v3, v4

    move v4, v1

    :goto_11
    const/16 v5, 0x8

    if-ge v4, v5, :cond_25

    and-int/lit8 v5, v3, 0x1

    if-eqz v5, :cond_20

    ushr-int/lit8 v3, v3, 0x1

    const v5, 0xa001

    xor-int/2addr v3, v5

    goto :goto_22

    :cond_20
    ushr-int/lit8 v3, v3, 0x1

    :goto_22
    add-int/lit8 v4, v4, 0x1

    goto :goto_11

    :cond_25
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_28
    and-int p0, v3, v0

    return p0
.end method

.method private final createDatagramSocket()Ljava/net/DatagramSocket;
    .registers 2

    .line 1229
    new-instance v0, Ljava/net/DatagramSocket;

    invoke-direct {v0}, Ljava/net/DatagramSocket;-><init>()V

    .line 1230
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiNetwork:Landroid/net/Network;

    if-eqz p0, :cond_c

    invoke-virtual {p0, v0}, Landroid/net/Network;->bindSocket(Ljava/net/DatagramSocket;)V

    :cond_c
    return-object v0
.end method

.method private final createSocket(Ljava/lang/String;II)Ljava/net/Socket;
    .registers 5

    .line 1191
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiNetwork:Landroid/net/Network;

    if-eqz p0, :cond_1c

    .line 1193
    invoke-virtual {p0}, Landroid/net/Network;->getSocketFactory()Ljavax/net/SocketFactory;

    move-result-object p0

    invoke-virtual {p0}, Ljavax/net/SocketFactory;->createSocket()Ljava/net/Socket;

    move-result-object p0

    .line 1194
    new-instance v0, Ljava/net/InetSocketAddress;

    invoke-direct {v0, p1, p2}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    check-cast v0, Ljava/net/SocketAddress;

    invoke-virtual {p0, v0, p3}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    .line 1193
    const-string p1, "apply(...)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0

    .line 1197
    :cond_1c
    new-instance p0, Ljava/net/Socket;

    invoke-direct {p0}, Ljava/net/Socket;-><init>()V

    .line 1198
    new-instance v0, Ljava/net/InetSocketAddress;

    invoke-direct {v0, p1, p2}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    check-cast v0, Ljava/net/SocketAddress;

    invoke-virtual {p0, v0, p3}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    return-object p0
.end method

.method static synthetic createSocket$default(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;IIILjava/lang/Object;)Ljava/net/Socket;
    .registers 6

    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_6

    const/16 p3, 0x1f40

    .line 1186
    :cond_6
    invoke-direct {p0, p1, p2, p3}, Lcom/example/bleconnectse/YadeaOtaClient;->createSocket(Ljava/lang/String;II)Ljava/net/Socket;

    move-result-object p0

    return-object p0
.end method

.method private final createSocketWithRetry(Ljava/lang/String;I)Ljava/net/Socket;
    .registers 9

    const/4 v0, 0x0

    const/4 v1, 0x0

    :cond_2
    :goto_2
    const/16 v2, 0x10

    if-ge v1, v2, :cond_52

    const/16 v0, 0x2bc

    .line 1206
    :try_start_8
    invoke-direct {p0, p1, p2, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->createSocket(Ljava/lang/String;II)Ljava/net/Socket;

    move-result-object v0

    if-lez v1, :cond_2d

    add-int/lit8 v3, v1, 0x1

    .line 1212
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "导航投屏：第 "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " 次连接成功"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V
    :try_end_2d
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_2d} :catch_2e

    :cond_2d
    return-object v0

    :catch_2e
    move-exception v0

    add-int/lit8 v1, v1, 0x1

    if-ge v1, v2, :cond_2

    .line 1219
    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "导航投屏：8888 尚未监听，第 "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/16 次连接失败，稍后重试"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 1218
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    const-wide/16 v2, 0xfa

    .line 1221
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    goto :goto_2

    :cond_52
    if-eqz v0, :cond_57

    .line 1225
    check-cast v0, Ljava/lang/Throwable;

    goto :goto_7f

    :cond_57
    new-instance p0, Ljava/io/IOException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "连接 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, ":"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p2, " 失败"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    move-object v0, p0

    check-cast v0, Ljava/lang/Throwable;

    :goto_7f
    throw v0
.end method

.method private final detectLocalIpv4(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1685
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->detectLocalIpv4BySocket(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_15

    .line 1686
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->detectLocalIpv4ByInterface()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_15

    .line 1687
    const-string/jumbo p1, "无法识别本机 IP，使用 192.168.7.2"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    const-string p0, "192.168.7.2"

    return-object p0

    :cond_15
    return-object p1
.end method

.method private final detectLocalIpv4ByInterface()Ljava/lang/String;
    .registers 7

    .line 1707
    const-string p0, "list(...)"

    const/4 v0, 0x0

    .line 1708
    :try_start_3
    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    move-result-object v1

    const-string v2, "getNetworkInterfaces(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-static {v1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/util/List;

    check-cast v1, Ljava/lang/Iterable;

    .line 2339
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .line 2340
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_22
    :goto_22
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3f

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    move-object v4, v3

    check-cast v4, Ljava/net/NetworkInterface;

    .line 1709
    invoke-virtual {v4}, Ljava/net/NetworkInterface;->isUp()Z

    move-result v5

    if-eqz v5, :cond_22

    invoke-virtual {v4}, Ljava/net/NetworkInterface;->isLoopback()Z

    move-result v4

    if-nez v4, :cond_22

    .line 2340
    invoke-interface {v2, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_22

    .line 2341
    :cond_3f
    check-cast v2, Ljava/util/List;

    .line 2339
    check-cast v2, Ljava/lang/Iterable;

    .line 2342
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    check-cast v1, Ljava/util/Collection;

    .line 2343
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_4e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_72

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .line 2344
    check-cast v3, Ljava/net/NetworkInterface;

    .line 1710
    invoke-virtual {v3}, Ljava/net/NetworkInterface;->getInetAddresses()Ljava/util/Enumeration;

    move-result-object v3

    const-string v4, "getInetAddresses(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v3}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-static {v3, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Ljava/util/List;

    check-cast v3, Ljava/lang/Iterable;

    .line 2345
    invoke-static {v1, v3}, Lkotlin/collections/CollectionsKt;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    goto :goto_4e

    .line 2347
    :cond_72
    check-cast v1, Ljava/util/List;

    .line 2342
    check-cast v1, Ljava/lang/Iterable;

    .line 2348
    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    check-cast p0, Ljava/util/Collection;

    .line 2357
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_81
    :goto_81
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_93

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    instance-of v3, v2, Ljava/net/Inet4Address;

    if-eqz v3, :cond_81

    invoke-interface {p0, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_81

    .line 2358
    :cond_93
    check-cast p0, Ljava/util/List;

    .line 2348
    check-cast p0, Ljava/lang/Iterable;

    .line 2359
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    check-cast v1, Ljava/util/Collection;

    .line 2368
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_a2
    :goto_a2
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_b8

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .line 2367
    check-cast v2, Ljava/net/Inet4Address;

    .line 1712
    invoke-virtual {v2}, Ljava/net/Inet4Address;->getHostAddress()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_a2

    .line 2367
    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_a2

    .line 2371
    :cond_b8
    check-cast v1, Ljava/util/List;

    .line 2359
    check-cast v1, Ljava/lang/Iterable;

    .line 2372
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_c0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_e0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Ljava/lang/String;

    .line 1713
    const-string v3, "192.168.7."

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v2, v3, v5, v4, v0}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_e1

    const-string v3, "192.168.49."

    invoke-static {v2, v3, v5, v4, v0}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_c0

    goto :goto_e1

    :cond_e0
    move-object v1, v0

    .line 2373
    :cond_e1
    :goto_e1
    check-cast v1, Ljava/lang/String;
    :try_end_e3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_e3} :catch_e4

    return-object v1

    :catch_e4
    return-object v0
.end method

.method private final detectLocalIpv4BySocket(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    const/4 v0, 0x0

    .line 1691
    :try_start_1
    new-instance v1, Ljava/net/DatagramSocket;

    invoke-direct {v1}, Ljava/net/DatagramSocket;-><init>()V

    check-cast v1, Ljava/io/Closeable;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_8} :catch_4e

    :try_start_8
    move-object v2, v1

    check-cast v2, Ljava/net/DatagramSocket;

    .line 1692
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiNetwork:Landroid/net/Network;

    if-eqz p0, :cond_12

    invoke-virtual {p0, v2}, Landroid/net/Network;->bindSocket(Ljava/net/DatagramSocket;)V

    .line 1693
    :cond_12
    invoke-static {p1}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object p0

    const/16 p1, 0x50

    invoke-virtual {v2, p0, p1}, Ljava/net/DatagramSocket;->connect(Ljava/net/InetAddress;I)V

    .line 1694
    invoke-virtual {v2}, Ljava/net/DatagramSocket;->getLocalAddress()Ljava/net/InetAddress;

    move-result-object p0

    .line 1695
    instance-of p1, p0, Ljava/net/Inet4Address;

    if-eqz p1, :cond_42

    move-object p1, p0

    check-cast p1, Ljava/net/Inet4Address;

    invoke-virtual {p1}, Ljava/net/Inet4Address;->isLoopbackAddress()Z

    move-result p1

    if-nez p1, :cond_42

    move-object p1, p0

    check-cast p1, Ljava/net/Inet4Address;

    invoke-virtual {p1}, Ljava/net/Inet4Address;->getHostAddress()Ljava/lang/String;

    move-result-object p1

    const-string v2, "0.0.0.0"

    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_42

    .line 1696
    check-cast p0, Ljava/net/Inet4Address;

    invoke-virtual {p0}, Ljava/net/Inet4Address;->getHostAddress()Ljava/lang/String;

    move-result-object p0
    :try_end_41
    .catchall {:try_start_8 .. :try_end_41} :catchall_47

    goto :goto_43

    :cond_42
    move-object p0, v0

    .line 1691
    :goto_43
    :try_start_43
    invoke-static {v1, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_46
    .catch Ljava/lang/Exception; {:try_start_43 .. :try_end_46} :catch_4e

    return-object p0

    :catchall_47
    move-exception p0

    :try_start_48
    throw p0
    :try_end_49
    .catchall {:try_start_48 .. :try_end_49} :catchall_49

    :catchall_49
    move-exception p1

    :try_start_4a
    invoke-static {v1, p0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1
    :try_end_4e
    .catch Ljava/lang/Exception; {:try_start_4a .. :try_end_4e} :catch_4e

    :catch_4e
    return-object v0
.end method

.method static final disconnectP2p$lambda$22(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 571
    const-string v0, "P2P 已主动断开，可以连接另一辆车"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 572
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private final disconnectP2pInternal(ZLkotlin/jvm/functions/Function0;)V
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 1755
    iget v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pOperationGeneration:I

    add-int/lit8 v4, v0, 0x1

    iput v4, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pOperationGeneration:I

    .line 1756
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pManager:Landroid/net/wifi/p2p/WifiP2pManager;

    const/4 v1, 0x0

    if-eqz v0, :cond_11

    .line 1757
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->ensureP2pChannel(Landroid/net/wifi/p2p/WifiP2pManager;)Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    move-result-object v2

    move-object v7, v2

    goto :goto_12

    :cond_11
    move-object v7, v1

    :goto_12
    if-eqz v0, :cond_4e

    if-eqz v7, :cond_4e

    .line 1758
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->hasWifiPermission()Z

    move-result v2

    if-nez v2, :cond_1d

    goto :goto_4e

    .line 1764
    :cond_1d
    const-string/jumbo v2, "正在清理旧 P2P 连接"

    invoke-direct {p0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 1765
    invoke-virtual {v0, v7, v1}, Landroid/net/wifi/p2p/WifiP2pManager;->stopPeerDiscovery(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;)V

    .line 1766
    new-instance v2, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v2, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 1781
    iget-object v8, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;

    move-object v3, p0

    move v5, p1

    move-object v6, p2

    invoke-direct/range {v1 .. v6}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda30;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V

    const-wide/16 p0, 0x9c4

    invoke-virtual {v8, v1, p0, p1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1797
    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$2;

    move v8, v5

    move-object v5, v3

    move-object v3, v7

    move v7, v8

    move-object v8, v6

    move v6, v4

    move-object v4, v2

    move-object v2, v0

    invoke-direct/range {v1 .. v8}, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$2;-><init>(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V

    check-cast v1, Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;

    invoke-virtual {v2, v3, v1}, Landroid/net/wifi/p2p/WifiP2pManager;->cancelConnect(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;)V

    return-void

    :cond_4e
    :goto_4e
    move-object v3, p0

    move v5, p1

    move-object v6, p2

    .line 1759
    invoke-direct {v3, v5}, Lcom/example/bleconnectse/YadeaOtaClient;->clearP2pConnectionState(Z)V

    .line 1760
    iget p0, v3, Lcom/example/bleconnectse/YadeaOtaClient;->p2pOperationGeneration:I

    if-ne v4, p0, :cond_5b

    invoke-interface {v6}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    :cond_5b
    return-void
.end method

.method static synthetic disconnectP2pInternal$default(Lcom/example/bleconnectse/YadeaOtaClient;ZLkotlin/jvm/functions/Function0;ILjava/lang/Object;)V
    .registers 5

    and-int/lit8 p3, p3, 0x1

    if-eqz p3, :cond_5

    const/4 p1, 0x0

    .line 1750
    :cond_5
    invoke-direct {p0, p1, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal(ZLkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method private static final disconnectP2pInternal$finishCleanup(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;Ljava/lang/String;)V
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/atomic/AtomicBoolean;",
            "Lcom/example/bleconnectse/YadeaOtaClient;",
            "IZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x1

    .line 1769
    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result p0

    if-nez p0, :cond_9

    return-void

    .line 1770
    :cond_9
    iget-object p0, p1, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;

    move-object v2, p1

    move v1, p2

    move v3, p3

    move-object v5, p4

    move-object v4, p5

    invoke-direct/range {v0 .. v5}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda38;-><init>(ILcom/example/bleconnectse/YadeaOtaClient;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;)V

    const-wide/16 p1, 0x258

    invoke-virtual {p0, v0, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method static final disconnectP2pInternal$finishCleanup$lambda$126(ILcom/example/bleconnectse/YadeaOtaClient;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .registers 6

    .line 1771
    iget v0, p1, Lcom/example/bleconnectse/YadeaOtaClient;->p2pOperationGeneration:I

    if-eq p0, v0, :cond_b

    .line 1772
    const-string/jumbo p0, "忽略已过期的 P2P 清理回调"

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 1775
    :cond_b
    invoke-direct {p1, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->clearP2pConnectionState(Z)V

    .line 1776
    new-instance p0, Ljava/lang/StringBuilder;

    const-string/jumbo p2, "旧 P2P 连接已清理："

    invoke-direct {p0, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 1777
    invoke-interface {p4}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method static final disconnectP2pInternal$lambda$127(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V
    .registers 11

    .line 1782
    const-string/jumbo v5, "系统回调超时，已强制重置"

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move-object v4, p4

    invoke-static/range {v0 .. v5}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal$finishCleanup(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;Ljava/lang/String;)V

    return-void
.end method

.method private static final disconnectP2pInternal$removeCurrentGroup(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/wifi/p2p/WifiP2pManager;",
            "Landroid/net/wifi/p2p/WifiP2pManager$Channel;",
            "Ljava/util/concurrent/atomic/AtomicBoolean;",
            "Lcom/example/bleconnectse/YadeaOtaClient;",
            "IZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 1786
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;

    move-object v1, p2

    move-object v2, p3

    move v3, p4

    move v4, p5

    move-object v5, p6

    invoke-direct/range {v0 .. v5}, Lcom/example/bleconnectse/YadeaOtaClient$disconnectP2pInternal$removeCurrentGroup$1;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/example/bleconnectse/YadeaOtaClient;IZLkotlin/jvm/functions/Function0;)V

    check-cast v0, Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;

    invoke-virtual {p0, p1, v0}, Landroid/net/wifi/p2p/WifiP2pManager;->removeGroup(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;)V

    return-void
.end method

.method private final disconnectWifi()V
    .registers 3

    .line 1728
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    if-eqz v0, :cond_9

    .line 1730
    :try_start_4
    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->connectivityManager:Landroid/net/ConnectivityManager;

    invoke-virtual {v1, v0}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_9} :catch_9

    :catch_9
    :cond_9
    const/4 v0, 0x0

    .line 1734
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    .line 1735
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiNetwork:Landroid/net/Network;

    const/4 v0, 0x0

    .line 1736
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setApReady(Z)V

    .line 1737
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionRequested(Z)V

    return-void
.end method

.method static final discoverP2p$lambda$9(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)Lkotlin/Unit;
    .registers 6

    if-eqz p1, :cond_17

    .line 475
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "正在搜索并自动连接锁定 P2P："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_1a

    .line 477
    :cond_17
    const-string/jumbo p1, "正在搜索 P2P 设备"

    .line 473
    :goto_1a
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 480
    new-instance p1, Lcom/example/bleconnectse/YadeaOtaClient$discoverP2p$2$1;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$discoverP2p$2$1;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    check-cast p1, Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;

    invoke-virtual {p2, p3, p1}, Landroid/net/wifi/p2p/WifiP2pManager;->discoverPeers(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;)V

    .line 489
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    new-instance p2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda0;

    invoke-direct {p2, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda0;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    const-wide/16 v0, 0x2ee0

    invoke-virtual {p1, p2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 495
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final discoverP2p$lambda$9$lambda$8(Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 2

    .line 490
    iget-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedP2pAfterScan:Z

    if-eqz v0, :cond_d

    const/4 v0, 0x0

    .line 491
    iput-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedP2pAfterScan:Z

    .line 492
    const-string/jumbo v0, "自动 P2P 超时：未发现锁定目标，请确认仪表 P2P 已开启"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    :cond_d
    return-void
.end method

.method private final discoverPendingP2pPeer(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V
    .registers 7

    .line 1825
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    if-nez v0, :cond_5

    return-void

    .line 1826
    :cond_5
    invoke-virtual {v0}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_15

    invoke-virtual {v0}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v1

    :cond_15
    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "重新搜索目标 P2P："

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 1827
    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$discoverPendingP2pPeer$2;

    invoke-direct {v1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$discoverPendingP2pPeer$2;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    check-cast v1, Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;

    invoke-virtual {p1, p2, v1}, Landroid/net/wifi/p2p/WifiP2pManager;->discoverPeers(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;)V

    .line 1837
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    new-instance p2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda11;

    invoke-direct {p2, p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda11;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V

    const-wide/16 v0, 0x2ee0

    invoke-virtual {p1, p2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method static final discoverPendingP2pPeer$lambda$129(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;)V
    .registers 3

    .line 1838
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_11

    .line 1839
    const-string/jumbo p1, "切车超时：目标 P2P 未重新出现，请再次搜索"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    const/4 p1, 0x0

    .line 1840
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    :cond_11
    return-void
.end method

.method private final displayNameOf(Landroid/net/Uri;)Ljava/lang/String;
    .registers 8

    .line 1128
    :try_start_0
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v1, p1

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0

    if-eqz p0, :cond_47

    check-cast p0, Ljava/io/Closeable;
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_13} :catch_47

    :try_start_13
    move-object p1, p0

    check-cast p1, Landroid/database/Cursor;

    .line 1129
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_39

    .line 1130
    const-string v0, "_display_name"

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    if-ltz v0, :cond_39

    .line 1132
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 1133
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    if-eqz v0, :cond_39

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_32
    .catchall {:try_start_13 .. :try_end_32} :catchall_3f

    if-eqz v0, :cond_35

    goto :goto_39

    :cond_35
    :try_start_35
    invoke-static {p0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_38
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_38} :catch_47

    return-object p1

    .line 1136
    :cond_39
    :goto_39
    :try_start_39
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_3b
    .catchall {:try_start_39 .. :try_end_3b} :catchall_3f

    .line 1128
    :try_start_3b
    invoke-static {p0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_3e
    .catch Ljava/lang/Exception; {:try_start_3b .. :try_end_3e} :catch_47

    goto :goto_47

    :catchall_3f
    move-exception v0

    move-object p1, v0

    :try_start_41
    throw p1
    :try_end_42
    .catchall {:try_start_41 .. :try_end_42} :catchall_42

    :catchall_42
    move-exception v0

    :try_start_43
    invoke-static {p0, p1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
    :try_end_47
    .catch Ljava/lang/Exception; {:try_start_43 .. :try_end_47} :catch_47

    .line 1139
    :catch_47
    :cond_47
    :goto_47
    const-string p0, "firmware.bin"

    return-object p0
.end method

.method private final ensureFirmwareLoaded()[B
    .registers 7

    .line 1143
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->firmwareBytes:[B

    if-eqz v0, :cond_5

    return-object v0

    .line 1144
    :cond_5
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->firmwareUri:Landroid/net/Uri;

    if-eqz v0, :cond_84

    .line 1145
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getFirmwareName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "正在读取升级包："

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 1146
    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v0

    if-eqz v0, :cond_7b

    check-cast v0, Ljava/io/Closeable;

    :try_start_2e
    move-object v1, v0

    check-cast v1, Ljava/io/InputStream;

    .line 1147
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    check-cast v2, Ljava/io/Closeable;
    :try_end_38
    .catchall {:try_start_2e .. :try_end_38} :catchall_74

    :try_start_38
    move-object v3, v2

    check-cast v3, Ljava/io/ByteArrayOutputStream;

    .line 1148
    move-object v4, v3

    check-cast v4, Ljava/io/OutputStream;

    const/high16 v5, 0x10000

    invoke-static {v1, v4, v5}, Lkotlin/io/ByteStreamsKt;->copyTo(Ljava/io/InputStream;Ljava/io/OutputStream;I)J

    .line 1149
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1
    :try_end_47
    .catchall {:try_start_38 .. :try_end_47} :catchall_6d

    const/4 v3, 0x0

    .line 1147
    :try_start_48
    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_4b
    .catchall {:try_start_48 .. :try_end_4b} :catchall_74

    .line 1146
    invoke-static {v0, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    if-eqz v1, :cond_7b

    .line 1152
    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->firmwareBytes:[B

    .line 1153
    array-length v0, v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "升级包已加载："

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " bytes"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-object v1

    :catchall_6d
    move-exception p0

    .line 1147
    :try_start_6e
    throw p0
    :try_end_6f
    .catchall {:try_start_6e .. :try_end_6f} :catchall_6f

    :catchall_6f
    move-exception v1

    :try_start_70
    invoke-static {v2, p0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v1
    :try_end_74
    .catchall {:try_start_70 .. :try_end_74} :catchall_74

    :catchall_74
    move-exception p0

    .line 1146
    :try_start_75
    throw p0
    :try_end_76
    .catchall {:try_start_75 .. :try_end_76} :catchall_76

    :catchall_76
    move-exception v1

    invoke-static {v0, p0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v1

    .line 1151
    :cond_7b
    new-instance p0, Ljava/io/IOException;

    const-string/jumbo v0, "无法打开升级包"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 1144
    :cond_84
    new-instance p0, Ljava/io/IOException;

    const-string/jumbo v0, "未选择升级包"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private final ensureP2pChannel(Landroid/net/wifi/p2p/WifiP2pManager;)Landroid/net/wifi/p2p/WifiP2pManager$Channel;
    .registers 5

    .line 1741
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pChannel:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    if-nez v0, :cond_15

    .line 1742
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    new-instance v2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda13;

    invoke-direct {v2, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda13;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-virtual {p1, v0, v1, v2}, Landroid/net/wifi/p2p/WifiP2pManager;->initialize(Landroid/content/Context;Landroid/os/Looper;Landroid/net/wifi/p2p/WifiP2pManager$ChannelListener;)Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pChannel:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    .line 1747
    :cond_15
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pChannel:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    return-object p0
.end method

.method static final ensureP2pChannel$lambda$124(Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 2

    .line 1743
    const-string v0, "P2P 通道已断开"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    const/4 v0, 0x0

    .line 1744
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pChannel:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    return-void
.end method

.method private final ensureProfile(Ljava/lang/String;)Lcom/example/bleconnectse/YadeaWifiProfile;
    .registers 5

    .line 972
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object v0

    if-eqz v0, :cond_12

    .line 973
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBleMac()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v1, p1, v2}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_12

    return-object v0

    .line 976
    :cond_12
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->buildWifiProfile(Ljava/lang/String;)Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object v0

    if-nez v0, :cond_2d

    .line 978
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "无法生成 WiFi 信息，BLE MAC 无效："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    .line 981
    :cond_2d
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setWifiProfile(Lcom/example/bleconnectse/YadeaWifiProfile;)V

    return-object v0
.end method

.method private final handleApScanResults(Z)V
    .registers 13

    .line 1023
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->hasWifiPermission()Z

    move-result v0

    if-nez v0, :cond_d

    .line 1024
    const-string/jumbo p1, "缺少 WiFi/定位权限，无法读取 AP 扫描结果"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 1028
    :cond_d
    :try_start_d
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiManager:Landroid/net/wifi/WifiManager;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager;->getScanResults()Ljava/util/List;

    move-result-object v0

    const-string v1, "getScanResults(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    .line 2307
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    check-cast v1, Ljava/util/Collection;

    .line 2316
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_25
    :goto_25
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .line 2315
    check-cast v2, Landroid/net/wifi/ScanResult;

    .line 1029
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->scanResultToWifiProfile(Landroid/net/wifi/ScanResult;)Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object v2

    if-eqz v2, :cond_25

    .line 2315
    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_25

    .line 2319
    :cond_3b
    check-cast v1, Ljava/util/List;

    .line 2307
    check-cast v1, Ljava/lang/Iterable;

    .line 2320
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 2321
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 2322
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_4d
    :goto_4d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_6e

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .line 2323
    move-object v4, v3

    check-cast v4, Lcom/example/bleconnectse/YadeaWifiProfile;

    .line 1030
    invoke-virtual {v4}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBssid()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_64

    invoke-virtual {v4}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v5

    .line 2324
    :cond_64
    invoke-virtual {v0, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4d

    .line 2325
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4d

    .line 2327
    :cond_6e
    check-cast v2, Ljava/util/List;

    check-cast v2, Ljava/lang/Iterable;

    .line 2328
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$handleApScanResults$$inlined$sortedByDescending$1;

    invoke-direct {v0}, Lcom/example/bleconnectse/YadeaOtaClient$handleApScanResults$$inlined$sortedByDescending$1;-><init>()V

    check-cast v0, Ljava/util/Comparator;

    invoke-static {v2, v0}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0
    :try_end_7d
    .catch Ljava/lang/SecurityException; {:try_start_d .. :try_end_7d} :catch_7e

    goto :goto_82

    .line 1033
    :catch_7e
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    .line 1035
    :goto_82
    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apCandidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    invoke-virtual {v1}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    .line 1036
    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apCandidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-virtual {v1, v2}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->addAll(Ljava/util/Collection;)Z

    .line 1037
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object v1

    .line 1038
    iget-boolean v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedApAfterScan:Z

    const/4 v3, 0x1

    if-eqz v2, :cond_102

    if-eqz v1, :cond_102

    .line 1039
    check-cast v0, Ljava/lang/Iterable;

    .line 2329
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_a0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_b5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lcom/example/bleconnectse/YadeaWifiProfile;

    .line 1039
    invoke-direct {p0, v4, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->apMatchesProfile(Lcom/example/bleconnectse/YadeaWifiProfile;Lcom/example/bleconnectse/YadeaWifiProfile;)Z

    move-result v4

    if-eqz v4, :cond_a0

    goto :goto_b6

    :cond_b5
    move-object v0, v2

    :goto_b6
    check-cast v0, Lcom/example/bleconnectse/YadeaWifiProfile;

    if-eqz v0, :cond_e3

    const/4 p1, 0x0

    .line 1041
    iput-boolean p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedApAfterScan:Z

    .line 1042
    invoke-direct {p0, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->setLockedApSeen(Z)V

    .line 1043
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    const-string/jumbo v4, "已发现锁定 AP："

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v3, "，开始连接"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    const/4 v1, 0x2

    .line 1044
    invoke-static {p0, v0, p1, v1, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->connectApProfile$default(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;ZILjava/lang/Object;)V

    return-void

    .line 1047
    :cond_e3
    invoke-virtual {v1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "未发现锁定 AP："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v0, "，继续等待扫描结果"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 1051
    :cond_102
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_111

    if-eqz p1, :cond_111

    .line 1052
    const-string/jumbo p1, "未发现 SSID 为 YD…ICM 的仪表 AP"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    goto :goto_183

    .line 1053
    :cond_111
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_11e

    .line 1054
    const-string/jumbo p1, "未找到仪表 AP；请确认仪表 AP 已开启，或稍后重试"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    goto :goto_183

    .line 1055
    :cond_11e
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result p1

    const-string/jumbo v1, "找到 "

    if-ne p1, v3, :cond_149

    .line 1056
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/example/bleconnectse/YadeaWifiProfile;

    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v0, "，请在下方 AP 列表中手动连接"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    goto :goto_183

    .line 1058
    :cond_149
    move-object p1, v0

    check-cast p1, Ljava/lang/Iterable;

    const/4 v2, 0x4

    invoke-static {p1, v2}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object p1

    move-object v2, p1

    check-cast v2, Ljava/lang/Iterable;

    new-instance v8, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda41;

    invoke-direct {v8}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda41;-><init>()V

    const/16 v9, 0x1f

    const/4 v10, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v2 .. v10}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    .line 1061
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " 个仪表 AP，请在列表中选择："

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    :goto_183
    return-void
.end method

.method static final handleApScanResults$lambda$83(Lcom/example/bleconnectse/YadeaWifiProfile;)Ljava/lang/CharSequence;
    .registers 3

    const-string v0, "profile"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1059
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getRssi()Ljava/lang/Integer;

    move-result-object p0

    if-eqz p0, :cond_14

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    goto :goto_15

    :cond_14
    const/4 p0, 0x0

    :goto_15
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, "dBm)"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    check-cast p0, Ljava/lang/CharSequence;

    return-object p0
.end method

.method private final hasWifiPermission()Z
    .registers 6

    .line 2014
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    .line 2015
    const-string v1, "android.permission.ACCESS_FINE_LOCATION"

    .line 2013
    invoke-static {v0, v1}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_e

    move v0, v1

    goto :goto_f

    :cond_e
    move v0, v2

    .line 2017
    :goto_f
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x21

    if-lt v3, v4, :cond_22

    .line 2019
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    .line 2020
    const-string v3, "android.permission.NEARBY_WIFI_DEVICES"

    .line 2018
    invoke-static {p0, v3}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    if-nez p0, :cond_20

    goto :goto_22

    :cond_20
    move p0, v2

    goto :goto_23

    :cond_22
    :goto_22
    move p0, v1

    :goto_23
    if-eqz v0, :cond_28

    if-eqz p0, :cond_28

    return v1

    :cond_28
    return v2
.end method

.method private final issueP2pConnect(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;Lcom/example/bleconnectse/P2pPeer;)V
    .registers 7

    .line 1851
    new-instance v0, Landroid/net/wifi/p2p/WifiP2pConfig;

    invoke-direct {v0}, Landroid/net/wifi/p2p/WifiP2pConfig;-><init>()V

    .line 1852
    invoke-virtual {p3}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Landroid/net/wifi/p2p/WifiP2pConfig;->deviceAddress:Ljava/lang/String;

    .line 1853
    iget-object v1, v0, Landroid/net/wifi/p2p/WifiP2pConfig;->wps:Landroid/net/wifi/WpsInfo;

    const/4 v2, 0x0

    iput v2, v1, Landroid/net/wifi/WpsInfo;->setup:I

    .line 1854
    iput v2, v0, Landroid/net/wifi/p2p/WifiP2pConfig;->groupOwnerIntent:I

    .line 1856
    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;

    invoke-direct {v1, p3, p0}, Lcom/example/bleconnectse/YadeaOtaClient$issueP2pConnect$1;-><init>(Lcom/example/bleconnectse/P2pPeer;Lcom/example/bleconnectse/YadeaOtaClient;)V

    check-cast v1, Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;

    invoke-virtual {p1, p2, v0, v1}, Landroid/net/wifi/p2p/WifiP2pManager;->connect(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pConfig;Landroid/net/wifi/p2p/WifiP2pManager$ActionListener;)V

    return-void
.end method

.method private final loadMirrorImageJpeg(Landroid/net/Uri;II)[B
    .registers 6

    .line 1506
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p1

    if-eqz p1, :cond_2f

    check-cast p1, Ljava/io/Closeable;

    :try_start_e
    move-object v0, p1

    check-cast v0, Ljava/io/InputStream;

    .line 1507
    invoke-static {v0}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v0
    :try_end_15
    .catchall {:try_start_e .. :try_end_15} :catchall_28

    const/4 v1, 0x0

    .line 1506
    invoke-static {p1, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    if-eqz v0, :cond_2f

    .line 1510
    :try_start_1b
    invoke-direct {p0, v0, p2, p3}, Lcom/example/bleconnectse/YadeaOtaClient;->bitmapToMirrorJpeg(Landroid/graphics/Bitmap;II)[B

    move-result-object p0
    :try_end_1f
    .catchall {:try_start_1b .. :try_end_1f} :catchall_23

    .line 1512
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    return-object p0

    :catchall_23
    move-exception p0

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    throw p0

    :catchall_28
    move-exception p0

    .line 1506
    :try_start_29
    throw p0
    :try_end_2a
    .catchall {:try_start_29 .. :try_end_2a} :catchall_2a

    :catchall_2a
    move-exception p2

    invoke-static {p1, p0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2

    .line 1508
    :cond_2f
    new-instance p0, Ljava/io/IOException;

    const-string/jumbo p1, "无法读取所选图片"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private final lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;
    .registers 5

    .line 986
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->bleLockedAddress:Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return-object v1

    .line 987
    :cond_6
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p0

    if-nez p0, :cond_d

    return-object v1

    .line 988
    :cond_d
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBleMac()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    invoke-static {v2, v0, v3}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_19

    return-object p0

    :cond_19
    return-object v1
.end method

.method private final logStatus(Ljava/lang/String;)V
    .registers 4

    .line 2026
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->logger:Lkotlin/jvm/functions/Function1;

    invoke-interface {v0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2027
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_17

    .line 2028
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setStatus(Ljava/lang/String;)V

    return-void

    .line 2030
    :cond_17
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda7;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static final logStatus$lambda$134(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V
    .registers 2

    .line 2030
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setStatus(Ljava/lang/String;)V

    return-void
.end method

.method private final navChecksum([BI)I
    .registers 5

    const/4 p0, 0x0

    const/4 v0, 0x2

    :goto_2
    if-ge v0, p2, :cond_10

    .line 1603
    aget-byte v1, p1, v0

    invoke-static {v1}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v1

    add-int/2addr p0, v1

    and-int/lit16 p0, p0, 0xff

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_10
    return p0
.end method

.method private final normalizeMac(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    .line 2374
    check-cast p1, Ljava/lang/CharSequence;

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    check-cast p0, Ljava/lang/Appendable;

    .line 2375
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, 0x0

    :goto_e
    if-ge v1, v0, :cond_20

    .line 2376
    invoke-interface {p1, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    .line 2010
    invoke-static {v2}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v3

    if-eqz v3, :cond_1d

    .line 2377
    invoke-interface {p0, v2}, Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;

    :cond_1d
    add-int/lit8 v1, v1, 0x1

    goto :goto_e

    .line 2379
    :cond_20
    check-cast p0, Ljava/lang/StringBuilder;

    .line 2374
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 2010
    sget-object p1, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v0, "US"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "toLowerCase(...)"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method private final parseLastOctet(Ljava/lang/String;I)I
    .registers 5

    const/16 p0, 0x2e

    const/4 v0, 0x2

    const/4 v1, 0x0

    .line 1721
    :try_start_4
    invoke-static {p1, p0, v1, v0, v1}, Lkotlin/text/StringsKt;->substringAfterLast$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    move-object p1, p0

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    if-ltz p1, :cond_1e

    const/16 v0, 0x100

    if-ge p1, v0, :cond_1e

    move-object v1, p0

    :cond_1e
    if-eqz v1, :cond_25

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_24} :catch_25

    return p0

    :catch_25
    :cond_25
    return p2
.end method

.method private final parseNavDisplayConfig([B)Lcom/example/bleconnectse/NavDisplayConfig;
    .registers 13

    .line 1249
    array-length v0, p1

    const/16 v1, 0x8

    if-ge v0, v1, :cond_18

    .line 1251
    const-string/jumbo p1, "导航投屏：0x20 数据不足8字节，使用默认画布 960x368"

    .line 1250
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 1254
    new-instance v0, Lcom/example/bleconnectse/NavDisplayConfig;

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/16 v1, 0x3c0

    const/16 v2, 0x170

    const/4 v3, 0x0

    invoke-direct/range {v0 .. v5}, Lcom/example/bleconnectse/NavDisplayConfig;-><init>(IIIII)V

    return-object v0

    :cond_18
    const/4 p0, 0x0

    .line 1262
    aget-byte p0, p1, p0

    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result p0

    shl-int/2addr p0, v1

    const/4 v0, 0x1

    aget-byte v2, p1, v0

    invoke-static {v2}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v2

    or-int/2addr p0, v2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    .line 1263
    move-object v2, p0

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    const/16 v3, 0x140

    const/4 v4, 0x0

    if-gt v3, v2, :cond_3d

    const/16 v3, 0x1001

    if-ge v2, v3, :cond_3d

    goto :goto_3e

    :cond_3d
    move-object p0, v4

    :goto_3e
    if-eqz p0, :cond_45

    .line 1262
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    goto :goto_47

    :cond_45
    const/16 p0, 0x3c0

    :goto_47
    move v6, p0

    const/4 p0, 0x2

    .line 1264
    aget-byte p0, p1, p0

    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result p0

    shl-int/2addr p0, v1

    const/4 v1, 0x3

    aget-byte v1, p1, v1

    invoke-static {v1}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v1

    or-int/2addr p0, v1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    .line 1265
    move-object v1, p0

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    const/16 v2, 0xa0

    if-gt v2, v1, :cond_6c

    const/16 v2, 0x871

    if-ge v1, v2, :cond_6c

    move-object v4, p0

    :cond_6c
    if-eqz v4, :cond_73

    .line 1264
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result p0

    goto :goto_75

    :cond_73
    const/16 p0, 0x170

    :goto_75
    move v7, p0

    .line 1266
    new-instance v5, Lcom/example/bleconnectse/NavDisplayConfig;

    const/4 p0, 0x4

    .line 1269
    aget-byte p0, p1, p0

    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v8

    const/4 p0, 0x6

    .line 1270
    aget-byte p0, p1, p0

    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v9

    const/4 p0, 0x7

    .line 1271
    aget-byte p0, p1, p0

    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result p0

    invoke-static {p0, v0}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v10

    .line 1266
    invoke-direct/range {v5 .. v10}, Lcom/example/bleconnectse/NavDisplayConfig;-><init>(IIIII)V

    return-object v5
.end method

.method private final parseNavResponses([B)Ljava/util/List;
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([B)",
            "Ljava/util/List<",
            "Lcom/example/bleconnectse/NavResponse;",
            ">;"
        }
    .end annotation

    .line 1345
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    check-cast v0, Ljava/util/List;

    const/4 v1, 0x0

    :goto_8
    add-int/lit8 v2, v1, 0xc

    .line 1347
    array-length v3, p1

    if-gt v2, v3, :cond_d9

    :goto_d
    add-int/lit8 v2, v1, 0x1

    .line 1349
    array-length v3, p1

    if-ge v2, v3, :cond_20

    .line 1350
    aget-byte v3, p1, v1

    const/16 v4, 0x59

    if-ne v3, v4, :cond_1e

    aget-byte v3, p1, v2

    const/16 v4, 0x44

    if-eq v3, v4, :cond_20

    :cond_1e
    move v1, v2

    goto :goto_d

    :cond_20
    add-int/lit8 v2, v1, 0xc

    .line 1354
    array-length v3, p1

    if-gt v2, v3, :cond_d9

    add-int/lit8 v3, v1, 0x2

    .line 1355
    aget-byte v4, p1, v3

    invoke-static {v4}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v4

    const/16 v5, 0x4c

    if-eq v4, v5, :cond_33

    :cond_31
    :goto_31
    move v1, v3

    goto :goto_8

    :cond_33
    add-int/lit8 v4, v1, 0x3

    .line 1359
    invoke-direct {p0, p1, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->readUInt32Be([BI)I

    move-result v4

    const/16 v5, 0x8

    if-lt v4, v5, :cond_31

    const/high16 v5, 0x100000

    if-le v4, v5, :cond_42

    goto :goto_31

    :cond_42
    add-int/lit8 v5, v4, 0x7

    add-int/2addr v5, v1

    .line 1366
    array-length v6, p1

    if-gt v5, v6, :cond_d9

    add-int/lit8 v6, v5, -0x2

    .line 1367
    aget-byte v6, p1, v6

    const/16 v7, 0x4b

    if-ne v6, v7, :cond_31

    add-int/lit8 v6, v5, -0x1

    aget-byte v6, p1, v6

    const/16 v7, 0x4a

    if-eq v6, v7, :cond_59

    goto :goto_31

    :cond_59
    add-int/lit8 v3, v1, 0x8

    .line 1371
    invoke-direct {p0, p1, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->readUInt32Be([BI)I

    move-result v3

    add-int/lit8 v6, v4, -0x8

    if-eq v3, v6, :cond_64

    goto :goto_d6

    .line 1376
    :cond_64
    invoke-static {p1, v1, v5}, Lkotlin/collections/ArraysKt;->copyOfRange([BII)[B

    move-result-object v6

    add-int/lit8 v4, v4, 0x4

    .line 1377
    invoke-direct {p0, v6, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->navChecksum([BI)I

    move-result v4

    add-int/lit8 v7, v5, -0x3

    .line 1378
    aget-byte v7, p1, v7

    invoke-static {v7}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v7

    if-eq v4, v7, :cond_be

    const/16 v8, 0x10

    .line 1381
    invoke-static {v8}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result v9

    invoke-static {v4, v9}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object v4

    const-string v9, "toString(...)"

    invoke-static {v4, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1382
    invoke-static {v8}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result v8

    invoke-static {v7, v8}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6}, Lcom/example/bleconnectse/YadeaOtaClientKt;->hex([B)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    const-string/jumbo v9, "导航响应校验告警：计算=0x"

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v8, " 报文=0x"

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string/jumbo v7, "，继续解析 "

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1380
    invoke-direct {p0, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    :cond_be
    add-int/lit8 v1, v1, 0x7

    .line 1385
    aget-byte v1, p1, v1

    invoke-static {v1}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v1

    .line 1387
    move-object v4, v0

    check-cast v4, Ljava/util/Collection;

    new-instance v6, Lcom/example/bleconnectse/NavResponse;

    add-int/2addr v3, v2

    invoke-static {p1, v2, v3}, Lkotlin/collections/ArraysKt;->copyOfRange([BII)[B

    move-result-object v2

    invoke-direct {v6, v1, v2}, Lcom/example/bleconnectse/NavResponse;-><init>(I[B)V

    invoke-interface {v4, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :goto_d6
    move v1, v5

    goto/16 :goto_8

    :cond_d9
    return-object v0
.end method

.method private final passwordMacFromAp(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 14

    const/4 v0, 0x3

    .line 1095
    invoke-static {p1, v0}, Lkotlin/text/StringsKt;->dropLast(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    .line 1096
    invoke-static {v0, v1}, Lkotlin/text/StringsKt;->takeLast(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v3, "US"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "toUpperCase(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1097
    move-object v3, p2

    check-cast v3, Ljava/lang/CharSequence;

    const/4 v2, 0x1

    new-array v4, v2, [Ljava/lang/String;

    const/4 v9, 0x0

    const-string v10, ":"

    aput-object v10, v4, v9

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v3 .. v8}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v3

    .line 1099
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    if-ne v4, v1, :cond_88

    .line 1100
    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    .line 2331
    :goto_36
    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-ge v9, v4, :cond_55

    invoke-interface {v1, v9}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    const/16 v5, 0x30

    if-gt v5, v4, :cond_49

    const/16 v5, 0x3a

    if-ge v4, v5, :cond_49

    goto :goto_51

    :cond_49
    const/16 v5, 0x41

    if-gt v5, v4, :cond_54

    const/16 v5, 0x47

    if-ge v4, v5, :cond_54

    :goto_51
    add-int/lit8 v9, v9, 0x1

    goto :goto_36

    :cond_54
    return-object p2

    .line 1101
    :cond_55
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x6

    if-ne v1, v4, :cond_88

    .line 1103
    const-string v1, "C1"

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    const/4 v4, 0x5

    invoke-interface {v3, v2, v4}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v1, v2}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-static {v1, v0}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/Iterable;

    move-object v2, v10

    check-cast v2, Ljava/lang/CharSequence;

    const/16 v8, 0x3e

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v1 .. v9}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_88
    return-object p2
.end method

.method private final peerMatchesProfile(Lcom/example/bleconnectse/P2pPeer;Lcom/example/bleconnectse/YadeaWifiProfile;)Z
    .registers 5

    .line 992
    invoke-virtual {p1}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->normalizeMac(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2}, Lcom/example/bleconnectse/YadeaWifiProfile;->getWifiMac()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->normalizeMac(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    const/4 v0, 0x1

    if-nez p0, :cond_28

    .line 993
    invoke-virtual {p1}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1, v0}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p0

    if-eqz p0, :cond_26

    goto :goto_28

    :cond_26
    const/4 p0, 0x0

    return p0

    :cond_28
    :goto_28
    return v0
.end method

.method private final post(Lkotlin/jvm/functions/Function0;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 2035
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_12

    .line 2036
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void

    .line 2038
    :cond_12
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda15;

    invoke-direct {v0, p1}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda15;-><init>(Lkotlin/jvm/functions/Function0;)V

    invoke-virtual {p0, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static final post$lambda$135(Lkotlin/jvm/functions/Function0;)V
    .registers 1

    .line 2038
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method private final readNavResponse(Ljava/io/InputStream;IJ)Lcom/example/bleconnectse/NavResponse;
    .registers 16

    .line 1316
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    add-long/2addr v0, p3

    .line 1317
    new-instance p3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 p4, 0x0

    move v2, p4

    .line 1319
    :cond_c
    :goto_c
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    cmp-long v3, v3, v0

    const-string v4, "toByteArray(...)"

    const-string v5, "toString(...)"

    const/16 v6, 0x10

    if-gez v3, :cond_ea

    .line 1320
    invoke-virtual {p1}, Ljava/io/InputStream;->available()I

    move-result v3

    if-nez v3, :cond_26

    const-wide/16 v3, 0x28

    .line 1321
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V

    goto :goto_c

    .line 1324
    :cond_26
    invoke-virtual {p1}, Ljava/io/InputStream;->available()I

    move-result v3

    const/4 v7, 0x1

    invoke-static {v3, v7}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v3

    new-array v3, v3, [B

    .line 1325
    invoke-virtual {p1, v3}, Ljava/io/InputStream;->read([B)I

    move-result v7

    if-ltz v7, :cond_ea

    .line 1327
    invoke-virtual {p3, v3, p4, v7}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 1328
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->parseNavResponses([B)Ljava/util/List;

    move-result-object v3

    .line 1329
    check-cast v3, Ljava/lang/Iterable;

    invoke-static {v3, v2}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .line 2333
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_51
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_c

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/example/bleconnectse/NavResponse;

    add-int/lit8 v2, v2, 0x1

    .line 1332
    invoke-virtual {v4}, Lcom/example/bleconnectse/NavResponse;->getCmd()I

    move-result v7

    invoke-static {v6}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result v8

    invoke-static {v7, v8}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/16 v9, 0x30

    invoke-static {v7, v8, v9}, Lkotlin/text/StringsKt;->padStart(Ljava/lang/String;IC)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4}, Lcom/example/bleconnectse/NavResponse;->getData()[B

    move-result-object v8

    invoke-static {v8}, Lcom/example/bleconnectse/YadeaOtaClientKt;->hex([B)Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    const-string/jumbo v10, "导航投屏：收到 CMD=0x"

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v9, " data="

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 1331
    invoke-direct {p0, v7}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 1334
    invoke-virtual {v4}, Lcom/example/bleconnectse/NavResponse;->getCmd()I

    move-result v7

    const/16 v8, 0xf1

    if-ne v7, v8, :cond_e3

    .line 1335
    invoke-virtual {v4}, Lcom/example/bleconnectse/NavResponse;->getData()[B

    move-result-object p0

    invoke-static {p0}, Lkotlin/collections/ArraysKt;->firstOrNull([B)Ljava/lang/Byte;

    move-result-object p0

    if-eqz p0, :cond_b7

    invoke-virtual {p0}, Ljava/lang/Byte;->byteValue()B

    move-result p0

    and-int/lit16 p0, p0, 0xff

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    goto :goto_b8

    :cond_b7
    const/4 p0, 0x0

    .line 1336
    :goto_b8
    new-instance p1, Ljava/io/IOException;

    if-eqz p0, :cond_cd

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-static {v6}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result p2

    invoke-static {p0, p2}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    if-nez p0, :cond_cf

    :cond_cd
    const-string p0, "??"

    :cond_cf
    new-instance p2, Ljava/lang/StringBuilder;

    const-string/jumbo p3, "仪表否定响应 NRC=0x"

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 1338
    :cond_e3
    invoke-virtual {v4}, Lcom/example/bleconnectse/NavResponse;->getCmd()I

    move-result v7

    if-ne v7, p2, :cond_51

    return-object v4

    .line 1341
    :cond_ea
    new-instance p0, Ljava/io/IOException;

    invoke-static {v6}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result p1

    invoke-static {p2, p1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p2

    invoke-static {p2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p2}, Lcom/example/bleconnectse/YadeaOtaClientKt;->hex([B)Ljava/lang/String;

    move-result-object p2

    new-instance p3, Ljava/lang/StringBuilder;

    const-string/jumbo p4, "等待导航响应 0x"

    invoke-direct {p3, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p3, " 超时，已收到 "

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private final readUInt32Be([BI)I
    .registers 4

    .line 1626
    aget-byte p0, p1, p2

    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result p0

    shl-int/lit8 p0, p0, 0x18

    add-int/lit8 v0, p2, 0x1

    .line 1627
    aget-byte v0, p1, v0

    invoke-static {v0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v0

    shl-int/lit8 v0, v0, 0x10

    or-int/2addr p0, v0

    add-int/lit8 v0, p2, 0x2

    .line 1628
    aget-byte v0, p1, v0

    invoke-static {v0}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result v0

    shl-int/lit8 v0, v0, 0x8

    or-int/2addr p0, v0

    add-int/lit8 p2, p2, 0x3

    .line 1629
    aget-byte p1, p1, p2

    invoke-static {p1}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$u(B)I

    move-result p1

    or-int/2addr p0, p1

    return p0
.end method

.method private final readUntil(Ljava/io/InputStream;[BJ)Z
    .registers 10

    .line 1653
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    add-long/2addr v0, p3

    .line 1654
    new-instance p3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 p4, 0x100

    .line 1655
    new-array p4, p4, [B

    .line 1656
    :cond_e
    :goto_e
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    cmp-long v2, v2, v0

    const/4 v3, 0x0

    const-string v4, "toByteArray(...)"

    if-gez v2, :cond_3d

    .line 1657
    invoke-virtual {p1}, Ljava/io/InputStream;->available()I

    move-result v2

    if-nez v2, :cond_25

    const-wide/16 v2, 0x50

    .line 1658
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    goto :goto_e

    .line 1661
    :cond_25
    invoke-virtual {p1, p4}, Ljava/io/InputStream;->read([B)I

    move-result v2

    if-ltz v2, :cond_3d

    .line 1663
    invoke-virtual {p3, p4, v3, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 1664
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v2, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->contains([B[B)Z

    move-result v2

    if-eqz v2, :cond_e

    const/4 p0, 0x1

    return p0

    .line 1666
    :cond_3d
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1

    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, Lcom/example/bleconnectse/YadeaOtaClientKt;->hex([B)Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "TCP 已收到："

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return v3
.end method

.method private final registerApScanReceiver()V
    .registers 5

    .line 1110
    iget-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apScanReceiverRegistered:Z

    if-eqz v0, :cond_5

    return-void

    .line 1112
    :cond_5
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    .line 1113
    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apScanReceiver:Lcom/example/bleconnectse/YadeaOtaClient$apScanReceiver$1;

    check-cast v1, Landroid/content/BroadcastReceiver;

    .line 1114
    new-instance v2, Landroid/content/IntentFilter;

    const-string v3, "android.net.wifi.SCAN_RESULTS"

    invoke-direct {v2, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    .line 1111
    invoke-static {v0, v1, v2, v3}, Landroidx/core/content/ContextCompat;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/4 v0, 0x1

    .line 1117
    iput-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apScanReceiverRegistered:Z

    return-void
.end method

.method private final registerP2pReceiver(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V
    .registers 5

    .line 1872
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_5

    return-void

    .line 1873
    :cond_5
    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 1874
    const-string v1, "android.net.wifi.p2p.STATE_CHANGED"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 1875
    const-string v1, "android.net.wifi.p2p.PEERS_CHANGED"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 1876
    const-string v1, "android.net.wifi.p2p.CONNECTION_STATE_CHANGE"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 1877
    const-string v1, "android.net.wifi.p2p.THIS_DEVICE_CHANGED"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 1879
    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;

    invoke-direct {v1, p0, p1, p2}, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    check-cast v1, Landroid/content/BroadcastReceiver;

    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pReceiver:Landroid/content/BroadcastReceiver;

    .line 1984
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1988
    iget-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    const/16 v1, 0x21

    if-lt p1, v1, :cond_36

    .line 1985
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pReceiver:Landroid/content/BroadcastReceiver;

    const/4 p1, 0x4

    invoke-virtual {p2, p0, v0, p1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    return-void

    .line 1988
    :cond_36
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p2, p0, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    return-void
.end method

.method private final requestApNetwork(Lcom/example/bleconnectse/YadeaWifiProfile;)V
    .registers 7

    .line 379
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectWifi()V

    .line 380
    sget-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->Ap:Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setActiveMode(Lcom/example/bleconnectse/OtaNetworkMode;)V

    .line 381
    const-string v0, "192.168.7.1"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setTargetIp(Ljava/lang/String;)V

    .line 382
    sget-object v0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "请求连接 AP："

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 383
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 385
    new-instance v0, Landroid/net/wifi/WifiNetworkSpecifier$Builder;

    invoke-direct {v0}, Landroid/net/wifi/WifiNetworkSpecifier$Builder;-><init>()V

    .line 386
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/net/wifi/WifiNetworkSpecifier$Builder;->setSsid(Ljava/lang/String;)Landroid/net/wifi/WifiNetworkSpecifier$Builder;

    move-result-object v0

    .line 388
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBssid()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_65

    .line 389
    :try_start_4d
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Landroid/net/MacAddress;->fromString(Ljava/lang/String;)Landroid/net/MacAddress;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/net/wifi/WifiNetworkSpecifier$Builder;->setBssid(Landroid/net/MacAddress;)Landroid/net/wifi/WifiNetworkSpecifier$Builder;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5a
    .catchall {:try_start_4d .. :try_end_5a} :catchall_5b

    goto :goto_65

    :catchall_5b
    move-exception v1

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 392
    :cond_65
    :goto_65
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getPassword()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/net/wifi/WifiNetworkSpecifier$Builder;->setWpa2Passphrase(Ljava/lang/String;)Landroid/net/wifi/WifiNetworkSpecifier$Builder;

    move-result-object v0

    .line 393
    invoke-virtual {v0}, Landroid/net/wifi/WifiNetworkSpecifier$Builder;->build()Landroid/net/wifi/WifiNetworkSpecifier;

    move-result-object v0

    const-string v1, "build(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 394
    new-instance v1, Landroid/net/NetworkRequest$Builder;

    invoke-direct {v1}, Landroid/net/NetworkRequest$Builder;-><init>()V

    const/4 v2, 0x1

    .line 395
    invoke-virtual {v1, v2}, Landroid/net/NetworkRequest$Builder;->addTransportType(I)Landroid/net/NetworkRequest$Builder;

    move-result-object v1

    const/16 v3, 0xc

    .line 396
    invoke-virtual {v1, v3}, Landroid/net/NetworkRequest$Builder;->removeCapability(I)Landroid/net/NetworkRequest$Builder;

    move-result-object v1

    .line 397
    check-cast v0, Landroid/net/NetworkSpecifier;

    invoke-virtual {v1, v0}, Landroid/net/NetworkRequest$Builder;->setNetworkSpecifier(Landroid/net/NetworkSpecifier;)Landroid/net/NetworkRequest$Builder;

    move-result-object v0

    .line 398
    invoke-virtual {v0}, Landroid/net/NetworkRequest$Builder;->build()Landroid/net/NetworkRequest;

    move-result-object v0

    .line 400
    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;

    invoke-direct {v1, p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;)V

    check-cast v1, Landroid/net/ConnectivityManager$NetworkCallback;

    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    const/4 p1, 0x0

    .line 435
    :try_start_9a
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionRequested(Z)V

    .line 436
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionFailed(Z)V

    .line 437
    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->connectivityManager:Landroid/net/ConnectivityManager;

    iget-object v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiCallback:Landroid/net/ConnectivityManager$NetworkCallback;

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/16 v4, 0x7530

    invoke-virtual {v1, v0, v3, v4}, Landroid/net/ConnectivityManager;->requestNetwork(Landroid/net/NetworkRequest;Landroid/net/ConnectivityManager$NetworkCallback;I)V
    :try_end_ac
    .catch Ljava/lang/SecurityException; {:try_start_9a .. :try_end_ac} :catch_ad

    goto :goto_ca

    :catch_ad
    move-exception v0

    .line 439
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionRequested(Z)V

    .line 440
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionFailed(Z)V

    .line 441
    invoke-virtual {v0}, Ljava/lang/SecurityException;->getMessage()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "AP 连接请求失败："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    :goto_ca
    return-void
.end method

.method private final scanApCandidates(Z)V
    .registers 5

    .line 336
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    if-ge v0, v1, :cond_16

    .line 337
    sget-object p1, Lcom/example/bleconnectse/OtaNetworkMode;->Ap:Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setActiveMode(Lcom/example/bleconnectse/OtaNetworkMode;)V

    .line 338
    const-string p1, "192.168.7.1"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setTargetIp(Ljava/lang/String;)V

    .line 339
    const-string p1, "Android 10 以下请手动连接仪表 AP，当前将使用手机 WiFi 通道"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 342
    :cond_16
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->hasWifiPermission()Z

    move-result v0

    if-nez v0, :cond_23

    .line 343
    const-string/jumbo p1, "缺少 WiFi/定位权限，无法扫描仪表 AP"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 346
    :cond_23
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiManager:Landroid/net/wifi/WifiManager;

    invoke-virtual {v0}, Landroid/net/wifi/WifiManager;->isWifiEnabled()Z

    move-result v0

    if-nez v0, :cond_32

    .line 347
    const-string/jumbo p1, "请先打开手机 WiFi，再扫描仪表 AP"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 350
    :cond_32
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->registerApScanReceiver()V

    .line 351
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apCandidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    invoke-virtual {v0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    const/4 v0, 0x0

    if-eqz p1, :cond_45

    .line 352
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p1

    if-eqz p1, :cond_45

    const/4 p1, 0x1

    goto :goto_46

    :cond_45
    move p1, v0

    :goto_46
    iput-boolean p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedApAfterScan:Z

    .line 353
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p1

    .line 355
    iget-boolean v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedApAfterScan:Z

    if-eqz v1, :cond_67

    if-eqz p1, :cond_67

    .line 356
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "正在扫描并自动连接锁定 AP："

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_6a

    .line 358
    :cond_67
    const-string/jumbo p1, "正在扫描仪表 AP：SSID=YD…ICM"

    .line 354
    :goto_6a
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 362
    :try_start_6d
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiManager:Landroid/net/wifi/WifiManager;

    invoke-virtual {p1}, Landroid/net/wifi/WifiManager;->startScan()Z

    move-result p1
    :try_end_73
    .catch Ljava/lang/SecurityException; {:try_start_6d .. :try_end_73} :catch_74

    goto :goto_75

    :catch_74
    move p1, v0

    :goto_75
    if-nez p1, :cond_7a

    .line 367
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->handleApScanResults(Z)V

    .line 369
    :cond_7a
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda42;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda42;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    const-wide/16 v1, 0x2ee0

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method static final scanApCandidates$lambda$2(Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 2

    .line 370
    iget-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedApAfterScan:Z

    if-eqz v0, :cond_d

    const/4 v0, 0x0

    .line 371
    iput-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedApAfterScan:Z

    .line 372
    const-string/jumbo v0, "自动 AP 超时：未发现锁定目标，请确认仪表 AP 已开启"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    :cond_d
    return-void
.end method

.method private final scanResultToWifiProfile(Landroid/net/wifi/ScanResult;)Lcom/example/bleconnectse/YadeaWifiProfile;
    .registers 15

    .line 1067
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    const-string v2, ""

    const/4 v3, 0x0

    if-lt v0, v1, :cond_18

    .line 1068
    invoke-virtual {p1}, Landroid/net/wifi/ScanResult;->getWifiSsid()Landroid/net/wifi/WifiSsid;

    move-result-object v0

    if-eqz v0, :cond_14

    invoke-virtual {v0}, Landroid/net/wifi/WifiSsid;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_15

    :cond_14
    move-object v0, v3

    :goto_15
    if-nez v0, :cond_1d

    goto :goto_1e

    .line 1071
    :cond_18
    iget-object v0, p1, Landroid/net/wifi/ScanResult;->SSID:Ljava/lang/String;

    if-nez v0, :cond_1d

    goto :goto_1e

    :cond_1d
    move-object v2, v0

    .line 1072
    :goto_1e
    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    new-array v2, v1, [C

    const/16 v4, 0x22

    const/4 v5, 0x0

    aput-char v4, v2, v5

    invoke-static {v0, v2}, Lkotlin/text/StringsKt;->trim(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v9

    .line 1073
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x5

    if-lt v0, v2, :cond_90

    .line 1074
    const-string v0, "YD"

    invoke-static {v9, v0, v1}, Lkotlin/text/StringsKt;->startsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_90

    .line 1075
    const-string v0, "ICM"

    invoke-static {v9, v0, v1}, Lkotlin/text/StringsKt;->endsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_4c

    goto :goto_90

    .line 1079
    :cond_4c
    iget-object v0, p1, Landroid/net/wifi/ScanResult;->BSSID:Ljava/lang/String;

    if-eqz v0, :cond_90

    .line 1080
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v2, "US"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "toUpperCase(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz v0, :cond_90

    .line 1081
    const-string v1, "02:00:00:00:00:00"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6c

    move-object v11, v0

    goto :goto_6d

    :cond_6c
    move-object v11, v3

    :goto_6d
    if-eqz v11, :cond_90

    .line 1083
    invoke-direct {p0, v9, v11}, Lcom/example/bleconnectse/YadeaOtaClient;->passwordMacFromAp(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 1084
    new-instance v6, Lcom/example/bleconnectse/YadeaWifiProfile;

    .line 1088
    new-instance p0, Ljava/lang/StringBuilder;

    const-string v0, "Yadea@"

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    .line 1090
    iget p0, p1, Landroid/net/wifi/ScanResult;->level:I

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    .line 1084
    const-string v7, ""

    invoke-direct/range {v6 .. v12}, Lcom/example/bleconnectse/YadeaWifiProfile;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;)V

    return-object v6

    :cond_90
    :goto_90
    return-object v3
.end method

.method private final sendHeartbeatIfDue(Ljava/io/OutputStream;J)Z
    .registers 6

    .line 1464
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    sub-long/2addr v0, p2

    const-wide/16 p2, 0x3e8

    cmp-long p2, v0, p2

    if-gez p2, :cond_d

    const/4 p0, 0x0

    return p0

    :cond_d
    const/16 p2, 0x1f

    .line 1465
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->buildHeartbeatPayload()[B

    move-result-object p3

    invoke-direct {p0, p2, p3}, Lcom/example/bleconnectse/YadeaOtaClient;->buildNavFrame(I[B)[B

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/io/OutputStream;->write([B)V

    .line 1466
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    const/4 p0, 0x1

    return p0
.end method

.method private final sendImagePackets(Ljava/net/DatagramSocket;Ljava/util/List;[BII)V
    .registers 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/net/DatagramSocket;",
            "Ljava/util/List<",
            "+",
            "Ljava/net/InetSocketAddress;",
            ">;[BII)V"
        }
    .end annotation

    move-object/from16 v0, p3

    move/from16 v1, p5

    .line 1400
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->crc16Modbus([B)I

    move-result v2

    const/4 v3, 0x0

    move v4, v3

    move v5, v4

    .line 1403
    :goto_b
    array-length v6, v0

    const/4 v7, 0x1

    if-ge v4, v6, :cond_8a

    .line 1404
    array-length v6, v0

    sub-int/2addr v6, v4

    move/from16 v8, p4

    invoke-static {v8, v6}, Ljava/lang/Math;->min(II)I

    move-result v6

    add-int/lit8 v9, v6, 0x14

    .line 1405
    new-array v9, v9, [B

    .line 1406
    invoke-direct {p0, v9, v3, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt16Le([BII)V

    const/4 v10, 0x2

    .line 1407
    invoke-direct {p0, v9, v10, v6}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt16Be([BII)V

    const/4 v10, 0x4

    .line 1408
    invoke-direct {p0, v9, v10, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt32Be([BII)V

    const/16 v10, 0x8

    .line 1409
    array-length v11, v0

    invoke-direct {p0, v9, v10, v11}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt32Be([BII)V

    const/16 v10, 0xc

    .line 1410
    invoke-direct {p0, v9, v10, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt32Be([BII)V

    .line 1411
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    const-wide v12, 0xffffffffL

    and-long/2addr v10, v12

    long-to-int v10, v10

    const/16 v11, 0x10

    invoke-direct {p0, v9, v11, v10}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt32Be([BII)V

    add-int/2addr v6, v4

    const/16 v10, 0x14

    .line 1412
    invoke-static {v0, v9, v10, v4, v6}, Lkotlin/collections/ArraysKt;->copyInto([B[BIII)[B

    const/16 v10, 0x12

    .line 1418
    invoke-direct {p0, v10, v9}, Lcom/example/bleconnectse/YadeaOtaClient;->buildNavFrame(I[B)[B

    move-result-object v9

    if-ne v1, v7, :cond_59

    if-nez v4, :cond_59

    .line 1420
    sget-object v4, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v7, "投屏 UDP 首包发送"

    invoke-virtual {v4, v7}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 1422
    :cond_59
    move-object/from16 v4, p2

    check-cast v4, Ljava/lang/Iterable;

    .line 2335
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_61
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_79

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/net/InetSocketAddress;

    .line 1423
    new-instance v10, Ljava/net/DatagramPacket;

    array-length v11, v9

    check-cast v7, Ljava/net/SocketAddress;

    invoke-direct {v10, v9, v11, v7}, Ljava/net/DatagramPacket;-><init>([BILjava/net/SocketAddress;)V

    invoke-virtual {p1, v10}, Ljava/net/DatagramSocket;->send(Ljava/net/DatagramPacket;)V

    goto :goto_61

    :cond_79
    add-int/lit8 v5, v5, 0x1

    .line 1427
    array-length v4, v0

    invoke-static {v6, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    .line 1428
    new-instance v7, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;

    invoke-direct {v7, p0, v1, v4, v0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda33;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;II[B)V

    invoke-direct {p0, v7}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    move v4, v6

    goto :goto_b

    :cond_8a
    add-int/lit8 p1, v1, 0x1

    .line 1433
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "导航投屏：第 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, " 帧发送完成，共 "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, " 包"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void
.end method

.method static final sendImagePackets$lambda$106(Lcom/example/bleconnectse/YadeaOtaClient;II[B)Lkotlin/Unit;
    .registers 5

    add-int/lit8 p1, p1, 0x1

    .line 1429
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorFrameCount(I)V

    .line 1430
    array-length p1, p3

    new-instance p3, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "投屏发送中："

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string p3, "/"

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p2, " bytes"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    .line 1431
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private final sendNavigationHint(Ljava/io/OutputStream;Ljava/lang/String;)V
    .registers 12

    const/16 v0, 0x40

    .line 1437
    new-array v2, v0, [B

    const/4 v1, 0x0

    move v3, v1

    :goto_6
    if-ge v3, v0, :cond_e

    const/4 v4, -0x1

    aput-byte v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_6

    :cond_e
    const/4 v0, 0x2

    .line 1438
    aput-byte v0, v2, v1

    const/4 v3, 0x7

    const/16 v4, 0x140

    .line 1439
    invoke-direct {p0, v2, v3, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt16Be([BII)V

    const/16 v3, 0x35c

    const/16 v4, 0xb

    .line 1440
    invoke-direct {p0, v2, v4, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt16Be([BII)V

    .line 1441
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v3

    .line 1442
    invoke-virtual {v3, v4}, Ljava/util/Calendar;->get(I)I

    move-result v4

    int-to-byte v4, v4

    const/16 v5, 0x11

    aput-byte v4, v2, v5

    const/16 v4, 0xc

    .line 1443
    invoke-virtual {v3, v4}, Ljava/util/Calendar;->get(I)I

    move-result v4

    int-to-byte v4, v4

    const/16 v5, 0x12

    aput-byte v4, v2, v5

    const/16 v4, 0xd

    .line 1444
    invoke-virtual {v3, v4}, Ljava/util/Calendar;->get(I)I

    move-result v3

    int-to-byte v3, v3

    const/16 v4, 0x13

    aput-byte v3, v2, v4

    const/16 v3, 0x8

    const/16 v8, 0x14

    .line 1445
    invoke-direct {p0, v2, v8, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->writeUInt16Be([BII)V

    const/16 v3, 0x1e

    .line 1446
    aget-byte v4, v2, v3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {p0, v4, v5, v0, v6}, Lcom/example/bleconnectse/YadeaOtaClient;->setBits(BIII)B

    move-result v0

    aput-byte v0, v2, v3

    .line 1447
    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    const-string v3, "UTF_8"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p2, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const-string v4, "getBytes(...)"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v5, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p2, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p2

    invoke-static {p2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    array-length p2, p2

    const/16 v3, 0x20

    invoke-static {v3, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    invoke-static {v0, v1, p2}, Lkotlin/collections/ArraysKt;->copyOfRange([BII)[B

    move-result-object v1

    .line 1448
    array-length p2, v1

    int-to-byte p2, p2

    const/16 v0, 0x1f

    aput-byte p2, v2, v0

    const/16 v6, 0xc

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    .line 1449
    invoke-static/range {v1 .. v7}, Lkotlin/collections/ArraysKt;->copyInto$default([B[BIIIILjava/lang/Object;)[B

    .line 1450
    invoke-direct {p0, v8, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->buildNavFrame(I[B)[B

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/io/OutputStream;->write([B)V

    .line 1451
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    return-void
.end method

.method private final sendTcpOtaRequest(Ljava/lang/String;I[B)V
    .registers 11

    const-string v0, "F0 已发送，等待 "

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    .line 1172
    invoke-static/range {v1 .. v6}, Lcom/example/bleconnectse/YadeaOtaClient;->createSocket$default(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;IIILjava/lang/Object;)Ljava/net/Socket;

    move-result-object p0

    check-cast p0, Ljava/io/Closeable;

    :try_start_e
    move-object p1, p0

    check-cast p1, Ljava/net/Socket;

    const/16 p2, 0x3a98

    .line 1173
    invoke-virtual {p1, p2}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 1174
    invoke-virtual {p1}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p2

    check-cast p2, Ljava/io/Closeable;
    :try_end_1c
    .catchall {:try_start_e .. :try_end_1c} :catchall_76

    :try_start_1c
    move-object v2, p2

    check-cast v2, Ljava/io/OutputStream;

    .line 1175
    invoke-virtual {v2, p3}, Ljava/io/OutputStream;->write([B)V

    .line 1176
    invoke-virtual {v2}, Ljava/io/OutputStream;->flush()V

    .line 1177
    sget-object p3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_27
    .catchall {:try_start_1c .. :try_end_27} :catchall_6d

    const/4 p3, 0x0

    .line 1174
    :try_start_28
    invoke-static {p2, p3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1178
    invoke-static {}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$getYADEA_WIFI_CMD_RESP$p()[B

    move-result-object p2

    invoke-static {p2}, Lcom/example/bleconnectse/YadeaOtaClientKt;->hex([B)Ljava/lang/String;

    move-result-object p2

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {v1, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 1179
    invoke-virtual {p1}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object p1

    const-string p2, "getInputStream(...)"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$getYADEA_WIFI_CMD_RESP$p()[B

    move-result-object p2

    const-wide/16 v2, 0x3a98

    invoke-direct {v1, p1, p2, v2, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->readUntil(Ljava/io/InputStream;[BJ)Z

    move-result p1

    if-eqz p1, :cond_64

    .line 1182
    const-string/jumbo p1, "已收到 F8 响应，等待车端通过 HTTP 拉取升级包"

    invoke-direct {v1, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 1183
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_60
    .catchall {:try_start_28 .. :try_end_60} :catchall_76

    .line 1172
    invoke-static {p0, p3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-void

    .line 1180
    :cond_64
    :try_start_64
    new-instance p1, Ljava/io/IOException;

    const-string/jumbo p2, "等待 F8 响应超时"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_6d
    .catchall {:try_start_64 .. :try_end_6d} :catchall_76

    :catchall_6d
    move-exception v0

    move-object p1, v0

    .line 1174
    :try_start_6f
    throw p1
    :try_end_70
    .catchall {:try_start_6f .. :try_end_70} :catchall_70

    :catchall_70
    move-exception v0

    move-object p3, v0

    :try_start_72
    invoke-static {p2, p1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p3
    :try_end_76
    .catchall {:try_start_72 .. :try_end_76} :catchall_76

    :catchall_76
    move-exception v0

    move-object p1, v0

    .line 1172
    :try_start_78
    throw p1
    :try_end_79
    .catchall {:try_start_78 .. :try_end_79} :catchall_79

    :catchall_79
    move-exception v0

    move-object p2, v0

    invoke-static {p0, p1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2
.end method

.method private final setActiveMode(Lcom/example/bleconnectse/OtaNetworkMode;)V
    .registers 2

    .line 159
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeMode$delegate:Landroidx/compose/runtime/MutableState;

    .line 2263
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setApConnectionFailed(Z)V
    .registers 2

    .line 179
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isApConnectionFailed$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 2293
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setApConnectionRequested(Z)V
    .registers 2

    .line 177
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isApConnectionRequested$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 2290
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setApReady(Z)V
    .registers 2

    .line 173
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isApReady$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 2284
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setBits(BIII)B
    .registers 5

    const/4 p0, 0x1

    shl-int p3, p0, p3

    sub-int/2addr p3, p0

    shl-int p0, p3, p2

    and-int/lit16 p1, p1, 0xff

    not-int p0, p0

    and-int/2addr p0, p1

    and-int p1, p4, p3

    shl-int/2addr p1, p2

    or-int/2addr p0, p1

    int-to-byte p0, p0

    return p0
.end method

.method private final setFirmwareName(Ljava/lang/String;)V
    .registers 2

    .line 155
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->firmwareName$delegate:Landroidx/compose/runtime/MutableState;

    .line 2257
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setHttpRunning(Z)V
    .registers 2

    .line 165
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->httpRunning$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 2272
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setLocalIp(Ljava/lang/String;)V
    .registers 2

    .line 161
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->localIp$delegate:Landroidx/compose/runtime/MutableState;

    .line 2266
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setLockedApSeen(Z)V
    .registers 2

    .line 175
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isLockedApSeen$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 2287
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setMirrorFrameCount(I)V
    .registers 2

    .line 169
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorFrameCount$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    .line 2278
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setMirrorStatus(Ljava/lang/String;)V
    .registers 2

    .line 167
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStatus$delegate:Landroidx/compose/runtime/MutableState;

    .line 2275
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setP2pReady(Z)V
    .registers 2

    .line 181
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isP2pReady$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    .line 2296
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setStatus(Ljava/lang/String;)V
    .registers 2

    .line 153
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->status$delegate:Landroidx/compose/runtime/MutableState;

    .line 2254
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setTargetIp(Ljava/lang/String;)V
    .registers 2

    .line 163
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->targetIp$delegate:Landroidx/compose/runtime/MutableState;

    .line 2269
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setWallpaperStatus(Ljava/lang/String;)V
    .registers 2

    .line 171
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperStatus$delegate:Landroidx/compose/runtime/MutableState;

    .line 2281
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final setWifiProfile(Lcom/example/bleconnectse/YadeaWifiProfile;)V
    .registers 2

    .line 157
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiProfile$delegate:Landroidx/compose/runtime/MutableState;

    .line 2260
    invoke-interface {p0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    return-void
.end method

.method private final sleepMirrorInterval(J)V
    .registers 7

    .line 1455
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    add-long/2addr v0, p1

    .line 1456
    :goto_5
    iget-boolean p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStopRequested:Z

    if-nez p1, :cond_20

    .line 1457
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    sub-long p1, v0, p1

    const-wide/16 v2, 0x0

    cmp-long v2, p1, v2

    if-gtz v2, :cond_16

    goto :goto_20

    :cond_16
    const-wide/16 v2, 0x14

    .line 1459
    invoke-static {p1, p2, v2, v3}, Lkotlin/ranges/RangesKt;->coerceAtMost(JJ)J

    move-result-wide p1

    invoke-static {p1, p2}, Ljava/lang/Thread;->sleep(J)V

    goto :goto_5

    :cond_20
    :goto_20
    return-void
.end method

.method private final startHttpServer(I[B)V
    .registers 7

    .line 1158
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->httpServer:Lcom/example/bleconnectse/OtaHttpServer;

    const/4 v1, 0x1

    if-eqz v0, :cond_c

    invoke-virtual {v0}, Lcom/example/bleconnectse/OtaHttpServer;->isRunning()Z

    move-result v0

    if-ne v0, v1, :cond_c

    return-void

    .line 1161
    :cond_c
    new-instance v0, Lcom/example/bleconnectse/OtaHttpServer;

    .line 1164
    new-instance v2, Lcom/example/bleconnectse/YadeaOtaClient$startHttpServer$1;

    invoke-direct {v2, p0}, Lcom/example/bleconnectse/YadeaOtaClient$startHttpServer$1;-><init>(Ljava/lang/Object;)V

    check-cast v2, Lkotlin/jvm/functions/Function1;

    .line 1166
    new-instance v3, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda45;

    invoke-direct {v3, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda45;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    .line 1161
    invoke-direct {v0, p1, p2, v2, v3}, Lcom/example/bleconnectse/OtaHttpServer;-><init>(I[BLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V

    .line 1166
    invoke-virtual {v0}, Lcom/example/bleconnectse/OtaHttpServer;->start()V

    .line 1161
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->httpServer:Lcom/example/bleconnectse/OtaHttpServer;

    .line 1167
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setHttpRunning(Z)V

    .line 1168
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "HTTP 服务已启动：0.0.0.0:"

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p2, " /icm/upgrade"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void
.end method

.method static final startHttpServer$lambda$91(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 1165
    const-string v0, "ICM 请求 finish=1，文件拉取完成"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startInstrumentWallpaper$lambda$29$lambda$28(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 634
    const-string/jumbo v0, "壁纸失败：未选择网络模式"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setWallpaperStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startInstrumentWallpaper$lambda$30(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 639
    const-string/jumbo v0, "壁纸失败：AP 网络未就绪"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setWallpaperStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startInstrumentWallpaper$lambda$31(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 644
    const-string/jumbo v0, "壁纸失败：P2P 目标未校验"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setWallpaperStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startInstrumentWallpaper$lambda$33$lambda$32(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 649
    const-string/jumbo v0, "已有壁纸任务正在运行"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setWallpaperStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startInstrumentWallpaper$lambda$44(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Uri;Lcom/example/bleconnectse/OtaNetworkMode;Ljava/lang/String;)V
    .registers 11

    const-string/jumbo v0, "仪表壁纸设置成功："

    const-string/jumbo v1, "仪表壁纸：连接 "

    const-string/jumbo v2, "壁纸设置失败："

    const/4 v3, 0x0

    const/4 v4, 0x0

    .line 658
    :try_start_b
    new-instance v5, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda31;

    invoke-direct {v5, p0, p3}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda31;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    invoke-direct {p0, v5}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 659
    iget-object v5, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    invoke-virtual {v5, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p1

    if-eqz p1, :cond_e4

    check-cast p1, Ljava/io/Closeable;
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_21} :catch_ef
    .catchall {:try_start_b .. :try_end_21} :catchall_ed

    :try_start_21
    move-object v5, p1

    check-cast v5, Ljava/io/InputStream;

    invoke-static {v5}, Lkotlin/io/ByteStreamsKt;->readBytes(Ljava/io/InputStream;)[B

    move-result-object v5
    :try_end_28
    .catchall {:try_start_21 .. :try_end_28} :catchall_dd

    :try_start_28
    invoke-static {p1, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    if-eqz v5, :cond_e4

    .line 661
    array-length p1, v5

    const/high16 v6, 0x1e00000

    if-gt p1, v6, :cond_d0

    .line 662
    sget-object p1, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;

    if-ne p2, p1, :cond_47

    .line 663
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    if-eqz p1, :cond_3b

    goto :goto_49

    :cond_3b
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "P2P 目标已失效"

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 665
    :cond_47
    const-string p1, "192.168.7.1"

    .line 667
    :goto_49
    new-instance p2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda32;

    invoke-direct {p2, p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda32;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    invoke-direct {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 671
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string v1, ":8880，图片="

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    const/16 p2, 0x22b0

    const/16 v1, 0xbb8

    .line 672
    invoke-direct {p0, p1, p2, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->createSocket(Ljava/lang/String;II)Ljava/net/Socket;

    move-result-object p1

    .line 673
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeWallpaperSocket:Ljava/net/Socket;

    .line 674
    new-instance p2, Lcom/example/bleconnectse/InstrumentWallpaperClient;

    .line 678
    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda34;

    invoke-direct {v1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda34;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    .line 677
    iget-object v6, p0, Lcom/example/bleconnectse/YadeaOtaClient;->logger:Lkotlin/jvm/functions/Function1;

    .line 674
    invoke-direct {p2, p1, v1, v6}, Lcom/example/bleconnectse/InstrumentWallpaperClient;-><init>(Ljava/net/Socket;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V

    check-cast p2, Ljava/lang/AutoCloseable;
    :try_end_83
    .catch Ljava/lang/Exception; {:try_start_28 .. :try_end_83} :catch_ef
    .catchall {:try_start_28 .. :try_end_83} :catchall_ed

    .line 678
    :try_start_83
    move-object p1, p2

    check-cast p1, Lcom/example/bleconnectse/InstrumentWallpaperClient;

    invoke-virtual {p1, v5}, Lcom/example/bleconnectse/InstrumentWallpaperClient;->upload([B)V

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_8b
    .catchall {:try_start_83 .. :try_end_8b} :catchall_c9

    :try_start_8b
    invoke-static {p2, v4}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    .line 679
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V
    :try_end_9e
    .catch Ljava/lang/Exception; {:try_start_8b .. :try_end_9e} :catch_ef
    .catchall {:try_start_8b .. :try_end_9e} :catchall_ed

    .line 690
    :try_start_9e
    sget-object p1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeWallpaperSocket:Ljava/net/Socket;

    if-eqz p1, :cond_aa

    invoke-virtual {p1}, Ljava/net/Socket;->close()V

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_ab

    :cond_aa
    move-object p1, v4

    :goto_ab
    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_ae
    .catchall {:try_start_9e .. :try_end_ae} :catchall_af

    goto :goto_b9

    :catchall_af
    move-exception p1

    sget-object p2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 691
    :goto_b9
    iput-object v4, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeWallpaperSocket:Ljava/net/Socket;

    .line 692
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperLock:Ljava/lang/Object;

    monitor-enter p1

    .line 693
    :try_start_be
    iput-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperSessionActive:Z

    .line 694
    iput-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperStopRequested:Z

    .line 695
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_c4
    .catchall {:try_start_be .. :try_end_c4} :catchall_c6

    goto/16 :goto_144

    :catchall_c6
    move-exception p0

    .line 692
    monitor-exit p1

    throw p0

    :catchall_c9
    move-exception p1

    .line 678
    :try_start_ca
    throw p1
    :try_end_cb
    .catchall {:try_start_ca .. :try_end_cb} :catchall_cb

    :catchall_cb
    move-exception p3

    :try_start_cc
    invoke-static {p2, p1}, Lkotlin/jdk7/AutoCloseableKt;->closeFinally(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    throw p3

    .line 661
    :cond_d0
    const-string/jumbo p1, "原图超过 30 MiB，拒绝处理"

    new-instance p2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2
    :try_end_dd
    .catch Ljava/lang/Exception; {:try_start_cc .. :try_end_dd} :catch_ef
    .catchall {:try_start_cc .. :try_end_dd} :catchall_ed

    :catchall_dd
    move-exception p2

    .line 659
    :try_start_de
    throw p2
    :try_end_df
    .catchall {:try_start_de .. :try_end_df} :catchall_df

    :catchall_df
    move-exception p3

    :try_start_e0
    invoke-static {p1, p2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p3

    .line 660
    :cond_e4
    new-instance p1, Ljava/io/IOException;

    const-string/jumbo p2, "无法打开所选图片"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_ed
    .catch Ljava/lang/Exception; {:try_start_e0 .. :try_end_ed} :catch_ef
    .catchall {:try_start_e0 .. :try_end_ed} :catchall_ed

    :catchall_ed
    move-exception p1

    goto :goto_149

    :catch_ef
    move-exception p1

    .line 681
    :try_start_f0
    iget-boolean p2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperStopRequested:Z

    if-eqz p2, :cond_f8

    .line 683
    const-string/jumbo p1, "壁纸设置已停止"

    goto :goto_113

    .line 685
    :cond_f8
    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p2

    if-nez p2, :cond_106

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p2

    :cond_106
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 687
    :goto_113
    new-instance p2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda35;

    invoke-direct {p2, p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda35;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    invoke-direct {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 688
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V
    :try_end_11e
    .catchall {:try_start_f0 .. :try_end_11e} :catchall_ed

    .line 690
    :try_start_11e
    sget-object p1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeWallpaperSocket:Ljava/net/Socket;

    if-eqz p1, :cond_12a

    invoke-virtual {p1}, Ljava/net/Socket;->close()V

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_12b

    :cond_12a
    move-object p1, v4

    :goto_12b
    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_12e
    .catchall {:try_start_11e .. :try_end_12e} :catchall_12f

    goto :goto_139

    :catchall_12f
    move-exception p1

    sget-object p2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 691
    :goto_139
    iput-object v4, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeWallpaperSocket:Ljava/net/Socket;

    .line 692
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperLock:Ljava/lang/Object;

    monitor-enter p1

    .line 693
    :try_start_13e
    iput-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperSessionActive:Z

    .line 694
    iput-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperStopRequested:Z

    .line 695
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_144
    .catchall {:try_start_13e .. :try_end_144} :catchall_146

    .line 692
    :goto_144
    monitor-exit p1

    return-void

    :catchall_146
    move-exception p0

    monitor-exit p1

    throw p0

    .line 690
    :goto_149
    :try_start_149
    sget-object p2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    iget-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeWallpaperSocket:Ljava/net/Socket;

    if-eqz p2, :cond_155

    invoke-virtual {p2}, Ljava/net/Socket;->close()V

    sget-object p2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_156

    :cond_155
    move-object p2, v4

    :goto_156
    invoke-static {p2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_159
    .catchall {:try_start_149 .. :try_end_159} :catchall_15a

    goto :goto_164

    :catchall_15a
    move-exception p2

    sget-object p3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {p2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p2

    invoke-static {p2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 691
    :goto_164
    iput-object v4, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeWallpaperSocket:Ljava/net/Socket;

    .line 692
    iget-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperLock:Ljava/lang/Object;

    monitor-enter p2

    .line 693
    :try_start_169
    iput-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperSessionActive:Z

    .line 694
    iput-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperStopRequested:Z

    .line 695
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_16f
    .catchall {:try_start_169 .. :try_end_16f} :catchall_171

    .line 692
    monitor-exit p2

    throw p1

    :catchall_171
    move-exception p0

    monitor-exit p2

    throw p0
.end method

.method static final startInstrumentWallpaper$lambda$44$lambda$34(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Lkotlin/Unit;
    .registers 4

    .line 658
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "正在读取图片："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setWallpaperStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startInstrumentWallpaper$lambda$44$lambda$37(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Lkotlin/Unit;
    .registers 2

    .line 668
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setTargetIp(Ljava/lang/String;)V

    .line 669
    const-string/jumbo p1, "正在连接仪表壁纸端口"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setWallpaperStatus(Ljava/lang/String;)V

    .line 670
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startInstrumentWallpaper$lambda$44$lambda$39(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3

    const-string v0, "message"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 676
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda44;

    invoke-direct {v0, p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda44;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startInstrumentWallpaper$lambda$44$lambda$39$lambda$38(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Lkotlin/Unit;
    .registers 2

    .line 676
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setWallpaperStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startInstrumentWallpaper$lambda$44$lambda$41(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Lkotlin/Unit;
    .registers 2

    .line 687
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setWallpaperStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startLiveMirror$lambda$27$lambda$26(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 623
    const-string/jumbo v0, "投屏失败：未选择网络模式"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private final startMirror(Lcom/example/bleconnectse/MirrorContent;)Z
    .registers 8

    const-string/jumbo v0, "正在切换投屏源："

    .line 742
    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorLock:Ljava/lang/Object;

    monitor-enter v1

    .line 743
    :try_start_6
    iget-wide v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorGeneration:J

    const-wide/16 v4, 0x1

    add-long/2addr v2, v4

    iput-wide v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorGeneration:J

    .line 744
    iget-boolean v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorSessionActive:Z

    const/4 v3, 0x1

    if-eqz v2, :cond_6f

    .line 745
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingMirrorContent:Lcom/example/bleconnectse/MirrorContent;

    .line 746
    iput-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStopRequested:Z
    :try_end_16
    .catchall {:try_start_6 .. :try_end_16} :catchall_82

    const/4 v2, 0x0

    .line 747
    :try_start_17
    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v4, p0

    check-cast v4, Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v4, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorSocket:Ljava/net/Socket;

    if-eqz v4, :cond_26

    invoke-virtual {v4}, Ljava/net/Socket;->close()V

    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_27

    :cond_26
    move-object v4, v2

    :goto_27
    invoke-static {v4}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2a
    .catchall {:try_start_17 .. :try_end_2a} :catchall_2b

    goto :goto_35

    :catchall_2b
    move-exception v4

    :try_start_2c
    sget-object v5, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v4}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_35
    .catchall {:try_start_2c .. :try_end_35} :catchall_82

    .line 748
    :goto_35
    :try_start_35
    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v4, p0

    check-cast v4, Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v4, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorDataSocket:Ljava/net/DatagramSocket;

    if-eqz v4, :cond_43

    invoke-virtual {v4}, Ljava/net/DatagramSocket;->close()V

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :cond_43
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_46
    .catchall {:try_start_35 .. :try_end_46} :catchall_47

    goto :goto_51

    :catchall_47
    move-exception v2

    :try_start_48
    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 749
    :goto_51
    new-instance v2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda24;

    invoke-direct {v2, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda24;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {p0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 750
    invoke-static {p1}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$displayLabel(Lcom/example/bleconnectse/MirrorContent;)Ljava/lang/String;

    move-result-object p1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V
    :try_end_6d
    .catchall {:try_start_48 .. :try_end_6d} :catchall_82

    .line 751
    monitor-exit v1

    return v3

    .line 753
    :cond_6f
    :try_start_6f
    iput-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorSessionActive:Z

    const/4 v0, 0x0

    .line 754
    iput-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStopRequested:Z

    .line 755
    iget-wide v4, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorGeneration:J
    :try_end_76
    .catchall {:try_start_6f .. :try_end_76} :catchall_82

    .line 742
    monitor-exit v1

    .line 757
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->executor:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda25;

    invoke-direct {v1, p0, p1, v4, v5}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda25;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/MirrorContent;J)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return v3

    :catchall_82
    move-exception p0

    .line 742
    monitor-exit v1

    throw p0
.end method

.method static final startMirror$lambda$53$lambda$52(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 749
    const-string/jumbo v0, "正在切换投屏源"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startMirror$lambda$70(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/MirrorContent;J)V
    .registers 31

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    const-string/jumbo v2, "导航投屏：仪表画布="

    const-string/jumbo v3, "导航投屏：开始响应 CMD=0x"

    const-string/jumbo v4, "投屏 TCP 已连接："

    const-string/jumbo v5, "导航投屏：TCP控制="

    .line 761
    :try_start_10
    invoke-virtual {v1}, Lcom/example/bleconnectse/YadeaOtaClient;->getActiveMode()Lcom/example/bleconnectse/OtaNetworkMode;

    move-result-object v6

    if-nez v6, :cond_18

    sget-object v6, Lcom/example/bleconnectse/OtaNetworkMode;->Ap:Lcom/example/bleconnectse/OtaNetworkMode;

    .line 762
    :cond_18
    sget-object v11, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;

    if-ne v6, v11, :cond_23

    .line 763
    iget-object v6, v1, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    if-nez v6, :cond_25

    const-string v6, "192.168.7.1"

    goto :goto_25

    .line 765
    :cond_23
    const-string v6, "192.168.7.1"

    .line 767
    :cond_25
    :goto_25
    new-instance v11, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda16;

    invoke-direct {v11, v1, v6}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda16;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    invoke-direct {v1, v11}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 774
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v11, ":8888，UDP图片="

    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v11, ":8889"

    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 772
    invoke-direct {v1, v5}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    const/16 v5, 0x22b8

    .line 776
    invoke-direct {v1, v6, v5}, Lcom/example/bleconnectse/YadeaOtaClient;->createSocketWithRetry(Ljava/lang/String;I)Ljava/net/Socket;

    move-result-object v5

    move-object v11, v5

    check-cast v11, Ljava/io/Closeable;
    :try_end_56
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_56} :catch_3de
    .catchall {:try_start_10 .. :try_end_56} :catchall_3d7

    :try_start_56
    move-object v12, v11

    check-cast v12, Ljava/net/Socket;
    :try_end_59
    .catchall {:try_start_56 .. :try_end_59} :catchall_3c0

    .line 778
    :try_start_59
    iput-object v12, v1, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorSocket:Ljava/net/Socket;

    .line 779
    sget-object v5, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v13, ":8888"

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 780
    invoke-virtual {v12}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v13

    .line 781
    invoke-virtual {v12}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v14

    const/16 v4, 0x1f40

    .line 782
    invoke-virtual {v12, v4}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 784
    invoke-direct {v1}, Lcom/example/bleconnectse/YadeaOtaClient;->buildHeartbeatPayload()[B

    move-result-object v4

    const/16 v5, 0x1f

    invoke-direct {v1, v5, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->buildNavFrame(I[B)[B

    move-result-object v4

    invoke-virtual {v14, v4}, Ljava/io/OutputStream;->write([B)V

    const/16 v4, 0x59a

    .line 785
    invoke-direct {v1, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->buildNavStartPayload(I)[B

    move-result-object v4

    const/16 v5, 0x10

    invoke-direct {v1, v5, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->buildNavFrame(I[B)[B

    move-result-object v4

    invoke-virtual {v14, v4}, Ljava/io/OutputStream;->write([B)V

    .line 786
    invoke-virtual {v14}, Ljava/io/OutputStream;->flush()V

    .line 787
    sget-object v4, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v15, "投屏启动命令已发送，等待 0x20"

    invoke-virtual {v4, v15}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 789
    invoke-static {v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/16 v4, 0x20

    const-wide/16 v9, 0x1f40

    .line 788
    invoke-direct {v1, v13, v4, v9, v10}, Lcom/example/bleconnectse/YadeaOtaClient;->readNavResponse(Ljava/io/InputStream;IJ)Lcom/example/bleconnectse/NavResponse;

    move-result-object v4

    .line 793
    invoke-virtual {v4}, Lcom/example/bleconnectse/NavResponse;->getCmd()I

    move-result v9

    invoke-static {v5}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result v10

    invoke-static {v9, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object v9

    const-string v10, "toString(...)"

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4}, Lcom/example/bleconnectse/NavResponse;->getData()[B

    move-result-object v10

    invoke-static {v10}, Lcom/example/bleconnectse/YadeaOtaClientKt;->hex([B)Ljava/lang/String;

    move-result-object v10

    move/from16 v16, v5

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, " data="

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 794
    invoke-virtual {v4}, Lcom/example/bleconnectse/NavResponse;->getData()[B

    move-result-object v3

    invoke-direct {v1, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->parseNavDisplayConfig([B)Lcom/example/bleconnectse/NavDisplayConfig;

    move-result-object v9

    .line 796
    sget-object v3, Lcom/example/bleconnectse/MirrorContent$Demo;->INSTANCE:Lcom/example/bleconnectse/MirrorContent$Demo;

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3
    :try_end_f5
    .catchall {:try_start_59 .. :try_end_f5} :catchall_3b8

    if-eqz v3, :cond_10c

    :try_start_f7
    invoke-virtual {v9}, Lcom/example/bleconnectse/NavDisplayConfig;->getWidth()I

    move-result v3

    invoke-virtual {v9}, Lcom/example/bleconnectse/NavDisplayConfig;->getHeight()I

    move-result v4

    invoke-direct {v1, v3, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->buildDemoMapJpeg(II)[B

    move-result-object v3
    :try_end_103
    .catchall {:try_start_f7 .. :try_end_103} :catchall_105

    :goto_103
    move-object v10, v3

    goto :goto_129

    :catchall_105
    move-exception v0

    move-wide/from16 v7, p2

    move-object v2, v0

    move-object v5, v11

    goto/16 :goto_3c6

    .line 797
    :cond_10c
    :try_start_10c
    instance-of v3, v0, Lcom/example/bleconnectse/MirrorContent$Image;
    :try_end_10e
    .catchall {:try_start_10c .. :try_end_10e} :catchall_3b8

    if-eqz v3, :cond_124

    .line 798
    :try_start_110
    move-object v3, v0

    check-cast v3, Lcom/example/bleconnectse/MirrorContent$Image;

    invoke-virtual {v3}, Lcom/example/bleconnectse/MirrorContent$Image;->getUri()Landroid/net/Uri;

    move-result-object v3

    .line 799
    invoke-virtual {v9}, Lcom/example/bleconnectse/NavDisplayConfig;->getWidth()I

    move-result v4

    .line 800
    invoke-virtual {v9}, Lcom/example/bleconnectse/NavDisplayConfig;->getHeight()I

    move-result v5

    .line 797
    invoke-direct {v1, v3, v4, v5}, Lcom/example/bleconnectse/YadeaOtaClient;->loadMirrorImageJpeg(Landroid/net/Uri;II)[B

    move-result-object v3
    :try_end_123
    .catchall {:try_start_110 .. :try_end_123} :catchall_105

    goto :goto_103

    .line 802
    :cond_124
    :try_start_124
    instance-of v3, v0, Lcom/example/bleconnectse/MirrorContent$Live;

    if-eqz v3, :cond_3a8

    const/4 v10, 0x0

    .line 804
    :goto_129
    new-instance v3, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda17;

    invoke-direct {v3, v1, v0, v9}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda17;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/MirrorContent;Lcom/example/bleconnectse/NavDisplayConfig;)V

    invoke-direct {v1, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 813
    invoke-virtual {v9}, Lcom/example/bleconnectse/NavDisplayConfig;->getWidth()I

    move-result v3

    invoke-virtual {v9}, Lcom/example/bleconnectse/NavDisplayConfig;->getHeight()I

    move-result v4

    .line 814
    invoke-virtual {v9}, Lcom/example/bleconnectse/NavDisplayConfig;->getImageFormat()I

    move-result v5

    invoke-static/range {v16 .. v16}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result v15

    invoke-static {v5, v15}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object v5

    const-string v15, "toString(...)"

    invoke-static {v5, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 815
    invoke-virtual {v9}, Lcom/example/bleconnectse/NavDisplayConfig;->getCapabilities()I

    move-result v15

    move-object/from16 v17, v9

    invoke-static/range {v16 .. v16}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result v9

    invoke-static {v15, v9}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object v9

    const-string v15, "toString(...)"

    invoke-static {v9, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 816
    invoke-virtual/range {v17 .. v17}, Lcom/example/bleconnectse/NavDisplayConfig;->getMaxFps()I

    move-result v15

    move-object/from16 v16, v10

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "x"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "，格式=0x"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "，能力=0x"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "，仪表报告最大FPS="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string/jumbo v3, "，实时投屏目标FPS=10"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 812
    invoke-direct {v1, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 819
    invoke-direct {v1}, Lcom/example/bleconnectse/YadeaOtaClient;->createDatagramSocket()Ljava/net/DatagramSocket;

    move-result-object v2

    move-object v9, v2

    check-cast v9, Ljava/io/Closeable;
    :try_end_1ad
    .catchall {:try_start_124 .. :try_end_1ad} :catchall_3b8

    :try_start_1ad
    move-object v2, v9

    check-cast v2, Ljava/net/DatagramSocket;
    :try_end_1b0
    .catchall {:try_start_1ad .. :try_end_1b0} :catchall_394

    .line 821
    :try_start_1b0
    iput-object v2, v1, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorDataSocket:Ljava/net/DatagramSocket;

    .line 823
    new-instance v3, Ljava/net/InetSocketAddress;

    const/16 v4, 0x22b9

    invoke-direct {v3, v6, v4}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    .line 822
    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    .line 826
    new-instance v10, Lkotlin/jvm/internal/Ref$IntRef;

    invoke-direct {v10}, Lkotlin/jvm/internal/Ref$IntRef;-><init>()V

    const/4 v15, 0x1

    iput v15, v10, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    .line 829
    instance-of v4, v0, Lcom/example/bleconnectse/MirrorContent$Live;

    if-eqz v4, :cond_1cc

    const-wide/16 v4, 0x64

    goto :goto_1ce

    :cond_1cc
    const-wide/16 v4, 0x3e8

    :goto_1ce
    move-wide/from16 v18, v4

    move/from16 v22, v15

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    .line 830
    :goto_1d5
    iget-boolean v15, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStopRequested:Z
    :try_end_1d7
    .catchall {:try_start_1b0 .. :try_end_1d7} :catchall_38a

    if-nez v15, :cond_2c9

    .line 832
    :try_start_1d9
    sget-object v15, Lcom/example/bleconnectse/MirrorContent$Demo;->INSTANCE:Lcom/example/bleconnectse/MirrorContent$Demo;

    invoke-static {v0, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_1e2

    goto :goto_1e6

    .line 833
    :cond_1e2
    instance-of v15, v0, Lcom/example/bleconnectse/MirrorContent$Image;

    if-eqz v15, :cond_1ee

    :goto_1e6
    move-object/from16 v23, v2

    move-object/from16 v24, v3

    move v15, v4

    move-object/from16 v4, v16

    goto :goto_248

    .line 834
    :cond_1ee
    instance-of v15, v0, Lcom/example/bleconnectse/MirrorContent$Live;

    if-eqz v15, :cond_2b0

    .line 835
    sget-object v15, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v15}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->take()Landroid/graphics/Bitmap;

    move-result-object v15
    :try_end_1f8
    .catchall {:try_start_1d9 .. :try_end_1f8} :catchall_2bc

    if-nez v15, :cond_217

    .line 837
    :try_start_1fa
    invoke-static {v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v1, v14, v5, v6}, Lcom/example/bleconnectse/YadeaOtaClient;->sendHeartbeatIfDue(Ljava/io/OutputStream;J)Z

    move-result v15

    if-eqz v15, :cond_207

    .line 838
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    :cond_207
    const-wide/16 v23, 0x14

    .line 840
    invoke-static/range {v23 .. v24}, Ljava/lang/Thread;->sleep(J)V
    :try_end_20c
    .catchall {:try_start_1fa .. :try_end_20c} :catchall_20d

    goto :goto_1d5

    :catchall_20d
    move-exception v0

    move-wide/from16 v7, p2

    move-object/from16 v23, v2

    move-object v5, v11

    move-object/from16 v21, v12

    goto/16 :goto_392

    :cond_217
    if-nez v4, :cond_233

    .line 845
    :try_start_219
    sget-object v4, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;
    :try_end_21b
    .catchall {:try_start_219 .. :try_end_21b} :catchall_228

    move-object/from16 v23, v2

    :try_start_21d
    const-string/jumbo v2, "实时投屏首帧开始编码"

    invoke-virtual {v4, v2}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V
    :try_end_223
    .catchall {:try_start_21d .. :try_end_223} :catchall_226

    move/from16 v4, v22

    goto :goto_235

    :catchall_226
    move-exception v0

    goto :goto_22b

    :catchall_228
    move-exception v0

    move-object/from16 v23, v2

    :goto_22b
    move-wide/from16 v7, p2

    move-object v2, v0

    move-object v5, v11

    move-object/from16 v21, v12

    goto/16 :goto_39d

    :cond_233
    move-object/from16 v23, v2

    .line 848
    :goto_235
    :try_start_235
    invoke-virtual/range {v17 .. v17}, Lcom/example/bleconnectse/NavDisplayConfig;->getWidth()I

    move-result v2

    move-object/from16 v24, v3

    invoke-virtual/range {v17 .. v17}, Lcom/example/bleconnectse/NavDisplayConfig;->getHeight()I

    move-result v3

    invoke-direct {v1, v15, v2, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->bitmapToMirrorJpeg(Landroid/graphics/Bitmap;II)[B

    move-result-object v2
    :try_end_243
    .catchall {:try_start_235 .. :try_end_243} :catchall_2a5

    .line 850
    :try_start_243
    invoke-virtual {v15}, Landroid/graphics/Bitmap;->recycle()V

    move v15, v4

    move-object v4, v2

    :goto_248
    if-nez v4, :cond_250

    move v4, v15

    move-object/from16 v2, v23

    move-object/from16 v3, v24

    goto :goto_1d5

    .line 854
    :cond_250
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v25

    move-wide v2, v5

    .line 860
    iget v6, v10, Lkotlin/jvm/internal/Ref$IntRef;->element:I
    :try_end_257
    .catchall {:try_start_243 .. :try_end_257} :catchall_29b

    const/16 v5, 0x59a

    move-wide v7, v2

    move-object/from16 v20, v11

    move-object/from16 v21, v12

    move-object/from16 v2, v23

    move-object/from16 v3, v24

    const-wide/16 v11, 0x0

    .line 855
    :try_start_264
    invoke-direct/range {v1 .. v6}, Lcom/example/bleconnectse/YadeaOtaClient;->sendImagePackets(Ljava/net/DatagramSocket;Ljava/util/List;[BII)V

    .line 862
    iget v4, v10, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    add-int/lit8 v4, v4, 0x1

    iput v4, v10, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    .line 863
    new-instance v4, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda18;

    invoke-direct {v4, v1, v0, v10}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda18;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/MirrorContent;Lkotlin/jvm/internal/Ref$IntRef;)V

    invoke-direct {v1, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 870
    invoke-static {v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v1, v14, v7, v8}, Lcom/example/bleconnectse/YadeaOtaClient;->sendHeartbeatIfDue(Ljava/io/OutputStream;J)Z

    move-result v4

    if-eqz v4, :cond_284

    .line 871
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    move-wide v5, v4

    goto :goto_285

    :cond_284
    move-wide v5, v7

    .line 874
    :goto_285
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    sub-long v7, v7, v25

    sub-long v7, v18, v7

    .line 875
    invoke-static {v7, v8, v11, v12}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v7

    .line 873
    invoke-direct {v1, v7, v8}, Lcom/example/bleconnectse/YadeaOtaClient;->sleepMirrorInterval(J)V

    move v4, v15

    move-object/from16 v11, v20

    move-object/from16 v12, v21

    goto/16 :goto_1d5

    :catchall_29b
    move-exception v0

    move-object/from16 v20, v11

    move-object/from16 v21, v12

    move-object/from16 v2, v23

    move-wide/from16 v7, p2

    goto :goto_2c5

    :catchall_2a5
    move-exception v0

    move-object/from16 v20, v11

    move-object/from16 v21, v12

    move-object/from16 v2, v23

    .line 850
    invoke-virtual {v15}, Landroid/graphics/Bitmap;->recycle()V

    throw v0

    :cond_2b0
    move-object/from16 v20, v11

    move-object/from16 v21, v12

    .line 831
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0
    :try_end_2ba
    .catchall {:try_start_264 .. :try_end_2ba} :catchall_2ba

    :catchall_2ba
    move-exception v0

    goto :goto_2c1

    :catchall_2bc
    move-exception v0

    move-object/from16 v20, v11

    move-object/from16 v21, v12

    :goto_2c1
    move-wide/from16 v7, p2

    move-object/from16 v23, v2

    :goto_2c5
    move-object/from16 v5, v20

    goto/16 :goto_392

    :cond_2c9
    move-object/from16 v20, v11

    move-object/from16 v21, v12

    .line 878
    :try_start_2cd
    invoke-direct {v1}, Lcom/example/bleconnectse/YadeaOtaClient;->buildNavEndPayload()[B

    move-result-object v0

    const/16 v3, 0x13

    invoke-direct {v1, v3, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->buildNavFrame(I[B)[B

    move-result-object v0

    invoke-virtual {v14, v0}, Ljava/io/OutputStream;->write([B)V

    .line 879
    invoke-virtual {v14}, Ljava/io/OutputStream;->flush()V
    :try_end_2dd
    .catchall {:try_start_2cd .. :try_end_2dd} :catchall_384

    .line 880
    :try_start_2dd
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    const/16 v0, 0x23

    const-wide/16 v3, 0x1388

    .line 881
    invoke-direct {v1, v13, v0, v3, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->readNavResponse(Ljava/io/InputStream;IJ)Lcom/example/bleconnectse/NavResponse;

    move-result-object v0

    .line 880
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2ea
    .catchall {:try_start_2dd .. :try_end_2ea} :catchall_2eb

    goto :goto_2f5

    :catchall_2eb
    move-exception v0

    :try_start_2ec
    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 887
    :goto_2f5
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda19;

    invoke-direct {v0, v1, v10}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda19;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/internal/Ref$IntRef;)V

    invoke-direct {v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 888
    iget v0, v10, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "导航投屏已结束，共播放 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, " 帧"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 889
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_31e
    .catchall {:try_start_2ec .. :try_end_31e} :catchall_384

    const/4 v3, 0x0

    .line 819
    :try_start_31f
    invoke-static {v9, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 890
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_324
    .catchall {:try_start_31f .. :try_end_324} :catchall_379

    move-object/from16 v5, v20

    .line 776
    :try_start_326
    invoke-static {v5, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_329
    .catch Ljava/lang/Exception; {:try_start_326 .. :try_end_329} :catch_371
    .catchall {:try_start_326 .. :try_end_329} :catchall_36a

    .line 900
    sget-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    .line 901
    iput-object v3, v1, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorSocket:Ljava/net/Socket;

    .line 902
    iput-object v3, v1, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorDataSocket:Ljava/net/DatagramSocket;

    if-eqz v2, :cond_33b

    .line 905
    :try_start_334
    invoke-virtual {v2}, Ljava/net/DatagramSocket;->close()V
    :try_end_337
    .catch Ljava/io/IOException; {:try_start_334 .. :try_end_337} :catch_337

    .line 908
    :catch_337
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 903
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :cond_33b
    if-eqz v21, :cond_344

    .line 911
    :try_start_33d
    invoke-virtual/range {v21 .. v21}, Ljava/net/Socket;->close()V
    :try_end_340
    .catch Ljava/io/IOException; {:try_start_33d .. :try_end_340} :catch_340

    .line 914
    :catch_340
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 909
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 915
    :cond_344
    iget-object v2, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorLock:Ljava/lang/Object;

    monitor-enter v2

    const/4 v15, 0x0

    .line 916
    :try_start_348
    iput-boolean v15, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorSessionActive:Z

    .line 917
    iget-object v0, v1, Lcom/example/bleconnectse/YadeaOtaClient;->pendingMirrorContent:Lcom/example/bleconnectse/MirrorContent;

    const/4 v3, 0x0

    .line 918
    iput-object v3, v1, Lcom/example/bleconnectse/YadeaOtaClient;->pendingMirrorContent:Lcom/example/bleconnectse/MirrorContent;

    .line 919
    iput-boolean v15, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStopRequested:Z
    :try_end_351
    .catchall {:try_start_348 .. :try_end_351} :catchall_367

    .line 915
    monitor-exit v2

    if-eqz v0, :cond_359

    .line 923
    :goto_354
    invoke-direct {v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->startMirror(Lcom/example/bleconnectse/MirrorContent;)Z

    goto/16 :goto_468

    .line 925
    :cond_359
    iget-object v0, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    new-instance v2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;

    move-wide/from16 v7, p2

    invoke-direct {v2, v1, v7, v8}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;J)V

    :goto_362
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_468

    :catchall_367
    move-exception v0

    .line 915
    monitor-exit v2

    throw v0

    :catchall_36a
    move-exception v0

    move-wide/from16 v7, p2

    move-object/from16 v12, v21

    goto/16 :goto_46e

    :catch_371
    move-exception v0

    move-wide/from16 v7, p2

    move-object v10, v2

    move-object/from16 v12, v21

    goto/16 :goto_3e3

    :catchall_379
    move-exception v0

    move-wide/from16 v7, p2

    move-object/from16 v5, v20

    move-object/from16 v23, v2

    move-object/from16 v12, v21

    move-object v2, v0

    goto :goto_3c8

    :catchall_384
    move-exception v0

    move-wide/from16 v7, p2

    move-object/from16 v5, v20

    goto :goto_390

    :catchall_38a
    move-exception v0

    move-wide/from16 v7, p2

    move-object v5, v11

    move-object/from16 v21, v12

    :goto_390
    move-object/from16 v23, v2

    :goto_392
    move-object v2, v0

    goto :goto_39d

    :catchall_394
    move-exception v0

    move-wide/from16 v7, p2

    move-object v5, v11

    move-object/from16 v21, v12

    move-object v2, v0

    const/16 v23, 0x0

    .line 819
    :goto_39d
    :try_start_39d
    throw v2
    :try_end_39e
    .catchall {:try_start_39d .. :try_end_39e} :catchall_39e

    :catchall_39e
    move-exception v0

    :try_start_39f
    invoke-static {v9, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
    :try_end_3a3
    .catchall {:try_start_39f .. :try_end_3a3} :catchall_3a3

    :catchall_3a3
    move-exception v0

    move-object v2, v0

    move-object/from16 v12, v21

    goto :goto_3c8

    :cond_3a8
    move-wide/from16 v7, p2

    move-object v5, v11

    move-object/from16 v21, v12

    .line 795
    :try_start_3ad
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0
    :try_end_3b3
    .catchall {:try_start_3ad .. :try_end_3b3} :catchall_3b3

    :catchall_3b3
    move-exception v0

    move-object v2, v0

    move-object/from16 v12, v21

    goto :goto_3c6

    :catchall_3b8
    move-exception v0

    move-wide/from16 v7, p2

    move-object v5, v11

    move-object/from16 v21, v12

    move-object v2, v0

    goto :goto_3c6

    :catchall_3c0
    move-exception v0

    move-wide/from16 v7, p2

    move-object v5, v11

    move-object v2, v0

    const/4 v12, 0x0

    :goto_3c6
    const/16 v23, 0x0

    .line 776
    :goto_3c8
    :try_start_3c8
    throw v2
    :try_end_3c9
    .catchall {:try_start_3c8 .. :try_end_3c9} :catchall_3c9

    :catchall_3c9
    move-exception v0

    :try_start_3ca
    invoke-static {v5, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
    :try_end_3ce
    .catch Ljava/lang/Exception; {:try_start_3ca .. :try_end_3ce} :catch_3d3
    .catchall {:try_start_3ca .. :try_end_3ce} :catchall_3ce

    :catchall_3ce
    move-exception v0

    move-object/from16 v2, v23

    goto/16 :goto_46e

    :catch_3d3
    move-exception v0

    move-object/from16 v10, v23

    goto :goto_3e3

    :catchall_3d7
    move-exception v0

    move-wide/from16 v7, p2

    const/4 v2, 0x0

    const/4 v12, 0x0

    goto/16 :goto_46e

    :catch_3de
    move-exception v0

    move-wide/from16 v7, p2

    const/4 v10, 0x0

    const/4 v12, 0x0

    .line 892
    :goto_3e3
    :try_start_3e3
    iget-boolean v2, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStopRequested:Z

    if-eqz v2, :cond_3f6

    .line 893
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda21;

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda21;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 894
    const-string/jumbo v0, "导航投屏已停止"

    invoke-direct {v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    goto :goto_42b

    .line 896
    :cond_3f6
    new-instance v2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda23;

    invoke-direct {v2, v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda23;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/Exception;)V

    invoke-direct {v1, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 897
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "导航投屏失败："

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ": "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V
    :try_end_42b
    .catchall {:try_start_3e3 .. :try_end_42b} :catchall_46c

    .line 900
    :goto_42b
    sget-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    const/4 v3, 0x0

    .line 901
    iput-object v3, v1, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorSocket:Ljava/net/Socket;

    .line 902
    iput-object v3, v1, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorDataSocket:Ljava/net/DatagramSocket;

    .line 903
    move-object v0, v10

    check-cast v0, Ljava/net/DatagramSocket;

    if-eqz v10, :cond_441

    .line 905
    :try_start_43a
    invoke-virtual {v10}, Ljava/net/DatagramSocket;->close()V
    :try_end_43d
    .catch Ljava/io/IOException; {:try_start_43a .. :try_end_43d} :catch_43d

    .line 908
    :catch_43d
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 903
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 909
    :cond_441
    move-object v0, v12

    check-cast v0, Ljava/net/Socket;

    if-eqz v12, :cond_44d

    .line 911
    :try_start_446
    invoke-virtual {v12}, Ljava/net/Socket;->close()V
    :try_end_449
    .catch Ljava/io/IOException; {:try_start_446 .. :try_end_449} :catch_449

    .line 914
    :catch_449
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 909
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 915
    :cond_44d
    iget-object v2, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorLock:Ljava/lang/Object;

    monitor-enter v2

    const/4 v15, 0x0

    .line 916
    :try_start_451
    iput-boolean v15, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorSessionActive:Z

    .line 917
    iget-object v0, v1, Lcom/example/bleconnectse/YadeaOtaClient;->pendingMirrorContent:Lcom/example/bleconnectse/MirrorContent;

    const/4 v3, 0x0

    .line 918
    iput-object v3, v1, Lcom/example/bleconnectse/YadeaOtaClient;->pendingMirrorContent:Lcom/example/bleconnectse/MirrorContent;

    .line 919
    iput-boolean v15, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStopRequested:Z
    :try_end_45a
    .catchall {:try_start_451 .. :try_end_45a} :catchall_469

    .line 915
    monitor-exit v2

    if-eqz v0, :cond_45f

    goto/16 :goto_354

    .line 925
    :cond_45f
    iget-object v0, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    new-instance v2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;

    invoke-direct {v2, v1, v7, v8}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;J)V

    goto/16 :goto_362

    :goto_468
    return-void

    :catchall_469
    move-exception v0

    .line 915
    monitor-exit v2

    throw v0

    :catchall_46c
    move-exception v0

    move-object v2, v10

    .line 900
    :goto_46e
    sget-object v3, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v3}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    const/4 v3, 0x0

    .line 901
    iput-object v3, v1, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorSocket:Ljava/net/Socket;

    .line 902
    iput-object v3, v1, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorDataSocket:Ljava/net/DatagramSocket;

    .line 903
    move-object v3, v2

    check-cast v3, Ljava/net/DatagramSocket;

    if-eqz v2, :cond_484

    .line 905
    :try_start_47d
    invoke-virtual {v2}, Ljava/net/DatagramSocket;->close()V
    :try_end_480
    .catch Ljava/io/IOException; {:try_start_47d .. :try_end_480} :catch_480

    .line 908
    :catch_480
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 903
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 909
    :cond_484
    move-object v2, v12

    check-cast v2, Ljava/net/Socket;

    if-eqz v12, :cond_490

    .line 911
    :try_start_489
    invoke-virtual {v12}, Ljava/net/Socket;->close()V
    :try_end_48c
    .catch Ljava/io/IOException; {:try_start_489 .. :try_end_48c} :catch_48c

    .line 914
    :catch_48c
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 909
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 915
    :cond_490
    iget-object v2, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorLock:Ljava/lang/Object;

    monitor-enter v2

    const/4 v15, 0x0

    .line 916
    :try_start_494
    iput-boolean v15, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorSessionActive:Z

    .line 917
    iget-object v3, v1, Lcom/example/bleconnectse/YadeaOtaClient;->pendingMirrorContent:Lcom/example/bleconnectse/MirrorContent;

    const/4 v4, 0x0

    .line 918
    iput-object v4, v1, Lcom/example/bleconnectse/YadeaOtaClient;->pendingMirrorContent:Lcom/example/bleconnectse/MirrorContent;

    .line 919
    iput-boolean v15, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStopRequested:Z
    :try_end_49d
    .catchall {:try_start_494 .. :try_end_49d} :catchall_4af

    .line 915
    monitor-exit v2

    if-eqz v3, :cond_4a4

    .line 923
    invoke-direct {v1, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->startMirror(Lcom/example/bleconnectse/MirrorContent;)Z

    goto :goto_4ae

    .line 925
    :cond_4a4
    iget-object v2, v1, Lcom/example/bleconnectse/YadeaOtaClient;->mainHandler:Landroid/os/Handler;

    new-instance v3, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;

    invoke-direct {v3, v1, v7, v8}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda20;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;J)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_4ae
    throw v0

    :catchall_4af
    move-exception v0

    .line 915
    monitor-exit v2

    throw v0
.end method

.method static final startMirror$lambda$70$lambda$54(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Lkotlin/Unit;
    .registers 2

    .line 768
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setTargetIp(Ljava/lang/String;)V

    .line 769
    const-string/jumbo p1, "正在建立导航控制通道"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    const/4 p1, 0x0

    .line 770
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorFrameCount(I)V

    .line 771
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startMirror$lambda$70$lambda$61$lambda$55(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/MirrorContent;Lcom/example/bleconnectse/NavDisplayConfig;)Lkotlin/Unit;
    .registers 6

    .line 806
    sget-object v0, Lcom/example/bleconnectse/MirrorContent$Demo;->INSTANCE:Lcom/example/bleconnectse/MirrorContent$Demo;

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const-string/jumbo v1, "正在投屏 "

    if-eqz v0, :cond_32

    invoke-virtual {p2}, Lcom/example/bleconnectse/NavDisplayConfig;->getWidth()I

    move-result v0

    invoke-virtual {p2}, Lcom/example/bleconnectse/NavDisplayConfig;->getHeight()I

    move-result p2

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string v0, " 地图"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    goto :goto_66

    .line 807
    :cond_32
    instance-of p2, p1, Lcom/example/bleconnectse/MirrorContent$Image;

    if-eqz p2, :cond_4e

    move-object p2, p1

    check-cast p2, Lcom/example/bleconnectse/MirrorContent$Image;

    invoke-virtual {p2}, Lcom/example/bleconnectse/MirrorContent$Image;->getName()Ljava/lang/String;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "正在投屏相册图片："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    goto :goto_66

    .line 808
    :cond_4e
    instance-of p2, p1, Lcom/example/bleconnectse/MirrorContent$Live;

    if-eqz p2, :cond_85

    move-object p2, p1

    check-cast p2, Lcom/example/bleconnectse/MirrorContent$Live;

    invoke-virtual {p2}, Lcom/example/bleconnectse/MirrorContent$Live;->getSourceName()Ljava/lang/String;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 805
    :goto_66
    invoke-direct {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    .line 810
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    invoke-static {p1}, Lcom/example/bleconnectse/YadeaOtaClientKt;->access$displayLabel(Lcom/example/bleconnectse/MirrorContent;)Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "投屏控制通道就绪："

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 811
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0

    .line 805
    :cond_85
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p0
.end method

.method static final startMirror$lambda$70$lambda$61$lambda$60$lambda$57(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/MirrorContent;Lkotlin/jvm/internal/Ref$IntRef;)Lkotlin/Unit;
    .registers 5

    .line 865
    sget-object v0, Lcom/example/bleconnectse/MirrorContent$Demo;->INSTANCE:Lcom/example/bleconnectse/MirrorContent$Demo;

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const-string v1, " 帧"

    if-eqz v0, :cond_21

    iget p1, p2, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    new-instance p2, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "地图投屏：第 "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_64

    .line 866
    :cond_21
    instance-of v0, p1, Lcom/example/bleconnectse/MirrorContent$Image;

    if-eqz v0, :cond_3c

    iget p1, p2, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    new-instance p2, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "相册图片：第 "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_64

    .line 867
    :cond_3c
    instance-of v0, p1, Lcom/example/bleconnectse/MirrorContent$Live;

    if-eqz v0, :cond_6a

    check-cast p1, Lcom/example/bleconnectse/MirrorContent$Live;

    invoke-virtual {p1}, Lcom/example/bleconnectse/MirrorContent$Live;->getSourceName()Ljava/lang/String;

    move-result-object p1

    iget p2, p2, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v0, "：第 "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 864
    :goto_64
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    .line 869
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0

    .line 864
    :cond_6a
    new-instance p0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p0
.end method

.method static final startMirror$lambda$70$lambda$61$lambda$60$lambda$59(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/internal/Ref$IntRef;)Lkotlin/Unit;
    .registers 4

    .line 887
    iget p1, p1, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "投屏已结束，共播放 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, " 帧"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startMirror$lambda$70$lambda$62(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 893
    const-string/jumbo v0, "投屏已停止"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startMirror$lambda$70$lambda$63(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/Exception;)Lkotlin/Unit;
    .registers 4

    .line 896
    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "投屏失败："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startMirror$lambda$70$lambda$69(Lcom/example/bleconnectse/YadeaOtaClient;J)V
    .registers 6

    .line 926
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorLock:Ljava/lang/Object;

    monitor-enter v0

    .line 927
    :try_start_3
    iget-boolean v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorSessionActive:Z

    if-nez v1, :cond_13

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingMirrorContent:Lcom/example/bleconnectse/MirrorContent;

    if-nez v1, :cond_13

    .line 928
    iget-wide v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorGeneration:J
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_46

    cmp-long p1, v1, p1

    if-nez p1, :cond_13

    const/4 p1, 0x1

    goto :goto_14

    :cond_13
    const/4 p1, 0x0

    .line 926
    :goto_14
    monitor-exit v0

    if-eqz p1, :cond_45

    .line 931
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    sget-object p2, Lcom/example/bleconnectse/MediaMirrorKeepAliveService;->Companion:Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;

    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    invoke-virtual {p2, v0}, Lcom/example/bleconnectse/MediaMirrorKeepAliveService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 932
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    sget-object p2, Lcom/example/bleconnectse/VideoBackgroundFrameService;->Companion:Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;

    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    invoke-virtual {p2, v0}, Lcom/example/bleconnectse/VideoBackgroundFrameService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 933
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    sget-object p2, Lcom/example/bleconnectse/ScreenCaptureService;->Companion:Lcom/example/bleconnectse/ScreenCaptureService$Companion;

    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    invoke-virtual {p2, v0}, Lcom/example/bleconnectse/ScreenCaptureService$Companion;->stopIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 934
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->onMirrorSessionEnded:Lkotlin/jvm/functions/Function0;

    if-eqz p0, :cond_45

    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    :cond_45
    return-void

    :catchall_46
    move-exception p0

    .line 926
    monitor-exit v0

    throw p0
.end method

.method static final startOta$lambda$49(Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 5

    .line 719
    :try_start_0
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->ensureFirmwareLoaded()[B

    move-result-object v0

    const/16 v1, 0x1f90

    .line 720
    invoke-direct {p0, v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->startHttpServer(I[B)V

    .line 721
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getActiveMode()Lcom/example/bleconnectse/OtaNetworkMode;

    move-result-object v0

    if-nez v0, :cond_11

    sget-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->Ap:Lcom/example/bleconnectse/OtaNetworkMode;

    .line 722
    :cond_11
    sget-object v1, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_13} :catch_33

    const-string v2, "192.168.7.1"

    if-ne v0, v1, :cond_1d

    .line 723
    :try_start_17
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    if-nez v0, :cond_1c

    goto :goto_1d

    :cond_1c
    move-object v2, v0

    .line 727
    :cond_1d
    :goto_1d
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->detectLocalIpv4(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 728
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->buildYadeaWifiCmdReq(Ljava/lang/String;)[B

    move-result-object v1

    .line 729
    new-instance v3, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda36;

    invoke-direct {v3, p0, v0, v2, v1}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda36;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Ljava/lang/String;[B)V

    invoke-direct {p0, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    const/16 v0, 0x22b8

    .line 734
    invoke-direct {p0, v2, v0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->sendTcpOtaRequest(Ljava/lang/String;I[B)V
    :try_end_32
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_32} :catch_33

    return-void

    :catch_33
    move-exception v0

    .line 736
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "OTA 失败："

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void
.end method

.method static final startOta$lambda$49$lambda$48(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Ljava/lang/String;[B)Lkotlin/Unit;
    .registers 6

    .line 730
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setLocalIp(Ljava/lang/String;)V

    .line 731
    invoke-direct {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->setTargetIp(Ljava/lang/String;)V

    .line 732
    invoke-static {p3}, Lcom/example/bleconnectse/YadeaOtaClientKt;->hex([B)Ljava/lang/String;

    move-result-object p3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "发送 F0 到 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string v0, ":8888，本机 IP="

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p2, " data="

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 733
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final startP2pMirrorDemo$lambda$23(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 595
    const-string/jumbo v0, "投屏失败：P2P 目标未校验"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final stopInstrumentWallpaper$lambda$46(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 704
    iget-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperSessionActive:Z

    if-eqz v0, :cond_8

    const-string/jumbo v0, "壁纸停止中"

    goto :goto_b

    :cond_8
    const-string/jumbo v0, "壁纸空闲"

    :goto_b
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setWallpaperStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final stopMirrorDemo$lambda$74(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 951
    const-string/jumbo v0, "投屏停止中"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private final toPeer(Landroid/net/wifi/p2p/WifiP2pDevice;)Lcom/example/bleconnectse/P2pPeer;
    .registers 5

    .line 2003
    new-instance p0, Lcom/example/bleconnectse/P2pPeer;

    .line 2004
    iget-object v0, p1, Landroid/net/wifi/p2p/WifiP2pDevice;->deviceName:Ljava/lang/String;

    const-string v1, ""

    if-nez v0, :cond_9

    move-object v0, v1

    .line 2005
    :cond_9
    iget-object v2, p1, Landroid/net/wifi/p2p/WifiP2pDevice;->deviceAddress:Ljava/lang/String;

    if-nez v2, :cond_e

    goto :goto_f

    :cond_e
    move-object v1, v2

    .line 2006
    :goto_f
    iget p1, p1, Landroid/net/wifi/p2p/WifiP2pDevice;->status:I

    .line 2003
    invoke-direct {p0, v0, v1, p1}, Lcom/example/bleconnectse/P2pPeer;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    return-object p0
.end method

.method private final unregisterApScanReceiver()V
    .registers 3

    .line 1121
    iget-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apScanReceiverRegistered:Z

    if-nez v0, :cond_5

    return-void

    .line 1122
    :cond_5
    :try_start_5
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apScanReceiver:Lcom/example/bleconnectse/YadeaOtaClient$apScanReceiver$1;

    check-cast v1, Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_18
    .catchall {:try_start_5 .. :try_end_18} :catchall_19

    goto :goto_23

    :catchall_19
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_23
    const/4 v0, 0x0

    .line 1123
    iput-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apScanReceiverRegistered:Z

    return-void
.end method

.method private final unregisterP2pReceiver()V
    .registers 3

    .line 1993
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_9

    .line 1995
    :try_start_4
    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->context:Landroid/content/Context;

    invoke-virtual {v1, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_9} :catch_9

    :catch_9
    :cond_9
    const/4 v0, 0x0

    .line 1999
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pReceiver:Landroid/content/BroadcastReceiver;

    return-void
.end method

.method private final validateMirrorNetwork(Lcom/example/bleconnectse/OtaNetworkMode;Ljava/lang/String;)Z
    .registers 4

    .line 708
    sget-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;

    if-ne p1, v0, :cond_28

    iget-boolean p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeerVerified:Z

    if-eqz p1, :cond_c

    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    if-nez p1, :cond_28

    .line 709
    :cond_c
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "P2P 目标尚未完成身份校验，禁止发送"

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 710
    new-instance p1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda22;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda22;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    const/4 p0, 0x0

    return p0

    :cond_28
    const/4 p0, 0x1

    return p0
.end method

.method static final validateMirrorNetwork$lambda$47(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    .line 710
    const-string/jumbo v0, "投屏失败：P2P 目标未校验"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setMirrorStatus(Ljava/lang/String;)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private final writeUInt16Be([BII)V
    .registers 4

    ushr-int/lit8 p0, p3, 0x8

    and-int/lit16 p0, p0, 0xff

    int-to-byte p0, p0

    .line 1609
    aput-byte p0, p1, p2

    add-int/lit8 p2, p2, 0x1

    and-int/lit16 p0, p3, 0xff

    int-to-byte p0, p0

    .line 1610
    aput-byte p0, p1, p2

    return-void
.end method

.method private final writeUInt16Le([BII)V
    .registers 4

    and-int/lit16 p0, p3, 0xff

    int-to-byte p0, p0

    .line 1614
    aput-byte p0, p1, p2

    add-int/lit8 p2, p2, 0x1

    ushr-int/lit8 p0, p3, 0x8

    and-int/lit16 p0, p0, 0xff

    int-to-byte p0, p0

    .line 1615
    aput-byte p0, p1, p2

    return-void
.end method

.method private final writeUInt32Be([BII)V
    .registers 5

    ushr-int/lit8 p0, p3, 0x18

    and-int/lit16 p0, p0, 0xff

    int-to-byte p0, p0

    .line 1619
    aput-byte p0, p1, p2

    add-int/lit8 p0, p2, 0x1

    ushr-int/lit8 v0, p3, 0x10

    and-int/lit16 v0, v0, 0xff

    int-to-byte v0, v0

    .line 1620
    aput-byte v0, p1, p0

    add-int/lit8 p0, p2, 0x2

    ushr-int/lit8 v0, p3, 0x8

    and-int/lit16 v0, v0, 0xff

    int-to-byte v0, v0

    .line 1621
    aput-byte v0, p1, p0

    add-int/lit8 p2, p2, 0x3

    and-int/lit16 p0, p3, 0xff

    int-to-byte p0, p0

    .line 1622
    aput-byte p0, p1, p2

    return-void
.end method


# virtual methods
.method public final autoConnectP2p()V
    .registers 12

    .line 499
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object v0

    if-nez v0, :cond_f

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/YadeaOtaClient;

    .line 500
    const-string v0, "BLE 未连接，不能自动匹配 P2P；请在下方 P2P 列表中手动选择"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 503
    :cond_f
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getWifiMac()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->normalizeMac(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 504
    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeers:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    check-cast v2, Ljava/lang/Iterable;

    .line 2299
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_3c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    move-object v5, v3

    check-cast v5, Lcom/example/bleconnectse/P2pPeer;

    .line 505
    invoke-virtual {v5}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v5}, Lcom/example/bleconnectse/YadeaOtaClient;->normalizeMac(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1f

    goto :goto_3d

    :cond_3c
    move-object v3, v4

    .line 504
    :goto_3d
    check-cast v3, Lcom/example/bleconnectse/P2pPeer;

    if-nez v3, :cond_6a

    .line 506
    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeers:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    check-cast v1, Ljava/lang/Iterable;

    .line 2301
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_49
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_66

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Lcom/example/bleconnectse/P2pPeer;

    .line 507
    invoke-virtual {v3}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x1

    invoke-static {v3, v5, v6}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v3

    if-eqz v3, :cond_49

    goto :goto_67

    :cond_66
    move-object v2, v4

    .line 2302
    :goto_67
    move-object v3, v2

    check-cast v3, Lcom/example/bleconnectse/P2pPeer;

    :cond_6a
    if-nez v3, :cond_b9

    .line 510
    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeers:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    move-object v2, v1

    check-cast v2, Ljava/lang/Iterable;

    new-instance v8, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda29;

    invoke-direct {v8}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda29;-><init>()V

    const/16 v9, 0x1f

    const/4 v10, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v2 .. v10}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 514
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v2

    .line 515
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getWifiMac()Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    const-string/jumbo v4, "未发现与当前 BLE 匹配的 P2P：期望 SSID="

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " 或 MAC="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v2, "；扫描到 ["

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "]"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 513
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 520
    :cond_b9
    invoke-virtual {v3}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_c9

    invoke-virtual {v3}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v0

    .line 521
    :cond_c9
    invoke-virtual {v3}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v5, "自动 P2P 严格匹配成功："

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " ("

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 519
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    const/4 v0, 0x0

    const/4 v1, 0x2

    .line 523
    invoke-static {p0, v3, v0, v1, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->connectP2p$default(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;ZILjava/lang/Object;)V

    return-void
.end method

.method public final close()V
    .registers 1

    .line 963
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->stopInstrumentWallpaper()V

    .line 964
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->stopHttpServer()V

    .line 965
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectWifi()V

    .line 966
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->unregisterP2pReceiver()V

    .line 967
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->unregisterApScanReceiver()V

    .line 968
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->executor:Ljava/util/concurrent/ExecutorService;

    invoke-interface {p0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    return-void
.end method

.method public final connectAp(Ljava/lang/String;)V
    .registers 5

    .line 255
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->buildWifiProfile(Ljava/lang/String;)Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p1

    if-nez p1, :cond_a

    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p1

    :cond_a
    const/4 v0, 0x0

    .line 256
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setLockedApSeen(Z)V

    .line 257
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionFailed(Z)V

    if-nez p1, :cond_1f

    .line 259
    sget-object p1, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v1, "扫描 AP 候选"

    invoke-virtual {p1, v1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 260
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->scanApCandidates(Z)V

    return-void

    .line 263
    :cond_1f
    sget-object v0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "扫描并连接锁定 AP："

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    const/4 p1, 0x1

    .line 264
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->scanApCandidates(Z)V

    return-void
.end method

.method public final connectApProfile(Lcom/example/bleconnectse/YadeaWifiProfile;Z)V
    .registers 12

    const-string v0, "profile"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 302
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object v0

    if-eqz v0, :cond_54

    if-nez p2, :cond_54

    .line 304
    invoke-direct {p0, p1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->apMatchesProfile(Lcom/example/bleconnectse/YadeaWifiProfile;Lcom/example/bleconnectse/YadeaWifiProfile;)Z

    move-result p2

    if-nez p2, :cond_39

    .line 305
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "BLE 已锁定 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string/jumbo v0, "，忽略其他 AP："

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 309
    :cond_39
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBleMac()Ljava/lang/String;

    move-result-object v1

    .line 310
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getWifiMac()Ljava/lang/String;

    move-result-object v2

    .line 311
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v3

    .line 312
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getPassword()Ljava/lang/String;

    move-result-object v4

    const/16 v7, 0x30

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, p1

    .line 308
    invoke-static/range {v0 .. v8}, Lcom/example/bleconnectse/YadeaWifiProfile;->copy$default(Lcom/example/bleconnectse/YadeaWifiProfile;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;ILjava/lang/Object;)Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p1

    goto :goto_76

    :cond_54
    if-eqz v0, :cond_76

    if-eqz p2, :cond_76

    .line 315
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "手动选择 AP："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string/jumbo v0, "，本次不套用 BLE 锁定目标"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 320
    :cond_76
    :goto_76
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setWifiProfile(Lcom/example/bleconnectse/YadeaWifiProfile;)V

    .line 321
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1d

    if-ge p2, v0, :cond_97

    .line 322
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "自动连接 AP 需要 Android 10+，请手动连接 "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 325
    :cond_97
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->hasWifiPermission()Z

    move-result p2

    if-nez p2, :cond_a4

    .line 326
    const-string/jumbo p1, "缺少 WiFi/定位权限，无法连接 AP"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 329
    :cond_a4
    new-instance p2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda27;

    invoke-direct {p2, p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda27;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;)V

    const/4 p1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, v1, p2, p1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal$default(Lcom/example/bleconnectse/YadeaOtaClient;ZLkotlin/jvm/functions/Function0;ILjava/lang/Object;)V

    return-void
.end method

.method public final connectLockedApDirect(Ljava/lang/String;)V
    .registers 8

    .line 268
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->buildWifiProfile(Ljava/lang/String;)Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object v0

    if-nez v0, :cond_a

    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object v0

    :cond_a
    const/4 v1, 0x1

    if-nez v0, :cond_24

    .line 270
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "无法生成锁定 AP 信息，BLE MAC 无效："

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 271
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionFailed(Z)V

    return-void

    .line 274
    :cond_24
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBleMac()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->bleLockedAddress:Ljava/lang/String;

    .line 275
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setWifiProfile(Lcom/example/bleconnectse/YadeaWifiProfile;)V

    .line 276
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setLockedApSeen(Z)V

    const/4 p1, 0x0

    .line 277
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionFailed(Z)V

    .line 278
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1d

    if-ge v2, v3, :cond_5b

    .line 279
    sget-object p1, Lcom/example/bleconnectse/OtaNetworkMode;->Ap:Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setActiveMode(Lcom/example/bleconnectse/OtaNetworkMode;)V

    .line 280
    const-string p1, "192.168.7.1"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setTargetIp(Ljava/lang/String;)V

    .line 281
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Android 10 以下请手动连接仪表 AP："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 284
    :cond_5b
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->hasWifiPermission()Z

    move-result v2

    if-nez v2, :cond_6b

    .line 285
    const-string/jumbo p1, "缺少 WiFi/定位权限，无法连接 AP"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 286
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionFailed(Z)V

    return-void

    .line 289
    :cond_6b
    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiManager:Landroid/net/wifi/WifiManager;

    invoke-virtual {v2}, Landroid/net/wifi/WifiManager;->isWifiEnabled()Z

    move-result v2

    if-nez v2, :cond_7d

    .line 290
    const-string/jumbo p1, "请先打开手机 WiFi，再连接仪表 AP"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 291
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionFailed(Z)V

    return-void

    .line 294
    :cond_7d
    sget-object v2, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    const-string/jumbo v5, "直接连接锁定 AP："

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 295
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 296
    new-instance v2, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda37;

    invoke-direct {v2, p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda37;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;)V

    const/4 v0, 0x0

    invoke-static {p0, p1, v2, v1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal$default(Lcom/example/bleconnectse/YadeaOtaClient;ZLkotlin/jvm/functions/Function0;ILjava/lang/Object;)V

    return-void
.end method

.method public final connectP2p(Lcom/example/bleconnectse/P2pPeer;Z)V
    .registers 7

    const-string v0, "peer"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 528
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->hasWifiPermission()Z

    move-result v0

    if-nez v0, :cond_12

    .line 529
    const-string/jumbo p1, "缺少 WiFi/定位权限，无法连接 P2P"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 532
    :cond_12
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object v0

    if-eqz v0, :cond_52

    if-nez p2, :cond_52

    .line 533
    invoke-direct {p0, p1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->peerMatchesProfile(Lcom/example/bleconnectse/P2pPeer;Lcom/example/bleconnectse/YadeaWifiProfile;)Z

    move-result v1

    if-nez v1, :cond_52

    .line 535
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p2

    .line 536
    invoke-virtual {p1}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_34

    invoke-virtual {p1}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v0

    :cond_34
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "BLE 已锁定 "

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo p2, "，禁止连接其他 P2P："

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 534
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    :cond_52
    if-eqz v0, :cond_80

    if-eqz p2, :cond_80

    .line 540
    invoke-virtual {p1}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object p2

    check-cast p2, Ljava/lang/CharSequence;

    invoke-static {p2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_66

    invoke-virtual {p1}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object p2

    :cond_66
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "手动选择 P2P："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string/jumbo v0, "，本次不套用 BLE 锁定目标"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 542
    :cond_80
    iget-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pManager:Landroid/net/wifi/p2p/WifiP2pManager;

    if-nez p2, :cond_8e

    move-object p1, p0

    check-cast p1, Lcom/example/bleconnectse/YadeaOtaClient;

    .line 543
    const-string/jumbo p1, "当前设备不支持 WiFi P2P"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 546
    :cond_8e
    invoke-direct {p0, p2}, Lcom/example/bleconnectse/YadeaOtaClient;->ensureP2pChannel(Landroid/net/wifi/p2p/WifiP2pManager;)Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    move-result-object v0

    if-nez v0, :cond_95

    return-void

    .line 547
    :cond_95
    invoke-direct {p0, p2, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->registerP2pReceiver(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    .line 548
    sget-object v1, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setActiveMode(Lcom/example/bleconnectse/OtaNetworkMode;)V

    .line 549
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->selectedP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    const/4 v1, 0x0

    .line 550
    iput-boolean v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeerVerified:Z

    .line 551
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setP2pReady(Z)V

    const/4 v1, 0x0

    .line 552
    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    .line 553
    invoke-virtual {p1}, Lcom/example/bleconnectse/P2pPeer;->getName()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_b8

    invoke-virtual {p1}, Lcom/example/bleconnectse/P2pPeer;->getAddress()Ljava/lang/String;

    move-result-object v1

    :cond_b8
    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "正在连接 P2P："

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 554
    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, p1, p2, v0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/P2pPeer;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    invoke-virtual {p2, v0, v1}, Landroid/net/wifi/p2p/WifiP2pManager;->requestConnectionInfo(Landroid/net/wifi/p2p/WifiP2pManager$Channel;Landroid/net/wifi/p2p/WifiP2pManager$ConnectionInfoListener;)V

    return-void
.end method

.method public final disconnectP2p()V
    .registers 5

    .line 570
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda39;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda39;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v3, v0, v1, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal$default(Lcom/example/bleconnectse/YadeaOtaClient;ZLkotlin/jvm/functions/Function0;ILjava/lang/Object;)V

    return-void
.end method

.method public final discoverP2p(Ljava/lang/String;)V
    .registers 8

    .line 447
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->buildWifiProfile(Ljava/lang/String;)Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p1

    if-eqz p1, :cond_f

    .line 448
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBleMac()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->bleLockedAddress:Ljava/lang/String;

    .line 449
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setWifiProfile(Lcom/example/bleconnectse/YadeaWifiProfile;)V

    .line 451
    :cond_f
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->lockedBleWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p1

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_19

    move v2, v0

    goto :goto_1a

    :cond_19
    move v2, v1

    .line 452
    :goto_1a
    iput-boolean v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedP2pAfterScan:Z

    .line 453
    sget-object v2, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    if-eqz p1, :cond_35

    .line 455
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    const-string/jumbo v5, "扫描并连接锁定 P2P："

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_38

    .line 457
    :cond_35
    const-string/jumbo v3, "扫描 P2P 候选"

    .line 453
    :goto_38
    invoke-virtual {v2, v3}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 460
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->hasWifiPermission()Z

    move-result v2

    if-nez v2, :cond_48

    .line 461
    const-string/jumbo p1, "缺少 WiFi/定位权限，无法搜索 P2P"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 464
    :cond_48
    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pManager:Landroid/net/wifi/p2p/WifiP2pManager;

    if-nez v2, :cond_56

    move-object p1, p0

    check-cast p1, Lcom/example/bleconnectse/YadeaOtaClient;

    .line 465
    const-string/jumbo p1, "当前设备不支持 WiFi P2P"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 468
    :cond_56
    invoke-direct {p0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->ensureP2pChannel(Landroid/net/wifi/p2p/WifiP2pManager;)Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    move-result-object v3

    if-nez v3, :cond_5d

    return-void

    .line 469
    :cond_5d
    invoke-direct {p0, v2, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->registerP2pReceiver(Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    .line 470
    sget-object v4, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-direct {p0, v4}, Lcom/example/bleconnectse/YadeaOtaClient;->setActiveMode(Lcom/example/bleconnectse/OtaNetworkMode;)V

    .line 471
    invoke-direct {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectWifi()V

    .line 472
    new-instance v4, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda28;

    invoke-direct {v4, p0, p1, v2, v3}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda28;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V

    const/4 p1, 0x0

    invoke-static {p0, v1, v4, v0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->disconnectP2pInternal$default(Lcom/example/bleconnectse/YadeaOtaClient;ZLkotlin/jvm/functions/Function0;ILjava/lang/Object;)V

    return-void
.end method

.method public final getActiveMode()Lcom/example/bleconnectse/OtaNetworkMode;
    .registers 1

    .line 159
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeMode$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2262
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/example/bleconnectse/OtaNetworkMode;

    return-object p0
.end method

.method public final getApCandidates()Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "Lcom/example/bleconnectse/YadeaWifiProfile;",
            ">;"
        }
    .end annotation

    .line 185
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apCandidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    return-object p0
.end method

.method public final getFirmwareName()Ljava/lang/String;
    .registers 1

    .line 155
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->firmwareName$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2256
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public final getHasFirmware()Z
    .registers 1

    .line 187
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->firmwareUri:Landroid/net/Uri;

    if-eqz p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method public final getHttpRunning()Z
    .registers 1

    .line 165
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->httpRunning$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2271
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final getLocalIp()Ljava/lang/String;
    .registers 1

    .line 161
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->localIp$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2265
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public final getMirrorFrameCount()I
    .registers 1

    .line 169
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorFrameCount$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2277
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    return p0
.end method

.method public final getMirrorStatus()Ljava/lang/String;
    .registers 1

    .line 167
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStatus$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2274
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public final getOnMirrorSessionEnded()Lkotlin/jvm/functions/Function0;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 142
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->onMirrorSessionEnded:Lkotlin/jvm/functions/Function0;

    return-object p0
.end method

.method public final getP2pPeers()Landroidx/compose/runtime/snapshots/SnapshotStateList;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/compose/runtime/snapshots/SnapshotStateList<",
            "Lcom/example/bleconnectse/P2pPeer;",
            ">;"
        }
    .end annotation

    .line 184
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeers:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    return-object p0
.end method

.method public final getStatus()Ljava/lang/String;
    .registers 1

    .line 153
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->status$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2253
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public final getTargetIp()Ljava/lang/String;
    .registers 1

    .line 163
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->targetIp$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2268
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public final getWallpaperStatus()Ljava/lang/String;
    .registers 1

    .line 171
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperStatus$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2280
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public final getWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;
    .registers 1

    .line 157
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wifiProfile$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2259
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/example/bleconnectse/YadeaWifiProfile;

    return-object p0
.end method

.method public final hasActiveMirrorSession()Z
    .registers 1

    .line 144
    iget-boolean p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorSessionActive:Z

    return p0
.end method

.method public final isApConnectionFailed()Z
    .registers 1

    .line 179
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isApConnectionFailed$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2292
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final isApConnectionRequested()Z
    .registers 1

    .line 177
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isApConnectionRequested$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2289
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final isApReady()Z
    .registers 1

    .line 173
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isApReady$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2283
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final isLockedApSeen()Z
    .registers 1

    .line 175
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isLockedApSeen$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2286
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final isP2pReady()Z
    .registers 1

    .line 181
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->isP2pReady$delegate:Landroidx/compose/runtime/MutableState;

    check-cast p0, Landroidx/compose/runtime/State;

    .line 2295
    invoke-interface {p0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public final refreshWifiProfile(Ljava/lang/String;)V
    .registers 5

    .line 205
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->buildWifiProfile(Ljava/lang/String;)Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object v0

    if-nez v0, :cond_1a

    .line 207
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "无法生成 WiFi 信息，BLE MAC 无效："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    .line 210
    :cond_1a
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBleMac()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->bleLockedAddress:Ljava/lang/String;

    .line 211
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setWifiProfile(Lcom/example/bleconnectse/YadeaWifiProfile;)V

    .line 212
    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0}, Lcom/example/bleconnectse/YadeaWifiProfile;->getPassword()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "已生成 WiFi 信息：SSID="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v1, " PSK="

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void
.end method

.method public final setFirmware(Landroid/net/Uri;)V
    .registers 4

    const-string v0, "uri"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 198
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->firmwareUri:Landroid/net/Uri;

    const/4 v0, 0x0

    .line 199
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->firmwareBytes:[B

    .line 200
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->displayNameOf(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setFirmwareName(Ljava/lang/String;)V

    .line 201
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getFirmwareName()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "已选择升级包："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void
.end method

.method public final setOnMirrorSessionEnded(Lkotlin/jvm/functions/Function0;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 142
    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->onMirrorSessionEnded:Lkotlin/jvm/functions/Function0;

    return-void
.end method

.method public final startApMirrorDemo()V
    .registers 2

    .line 588
    sget-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->Ap:Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setActiveMode(Lcom/example/bleconnectse/OtaNetworkMode;)V

    .line 589
    sget-object v0, Lcom/example/bleconnectse/MirrorContent$Demo;->INSTANCE:Lcom/example/bleconnectse/MirrorContent$Demo;

    check-cast v0, Lcom/example/bleconnectse/MirrorContent;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->startMirror(Lcom/example/bleconnectse/MirrorContent;)Z

    return-void
.end method

.method public final startApOta()V
    .registers 3

    .line 576
    sget-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->Ap:Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setActiveMode(Lcom/example/bleconnectse/OtaNetworkMode;)V

    .line 577
    sget-object v0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v1, "启动 AP OTA"

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 578
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->startOta()V

    return-void
.end method

.method public final startImageMirror(Landroid/net/Uri;)Z
    .registers 5

    const-string v0, "uri"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 612
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getActiveMode()Lcom/example/bleconnectse/OtaNetworkMode;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_16

    move-object p1, p0

    check-cast p1, Lcom/example/bleconnectse/YadeaOtaClient;

    .line 613
    const-string/jumbo p1, "请先连接 AP 或 P2P，再启动相册投屏"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return v1

    .line 616
    :cond_16
    const-string/jumbo v2, "相册图片"

    invoke-direct {p0, v0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->validateMirrorNetwork(Lcom/example/bleconnectse/OtaNetworkMode;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_20

    return v1

    .line 617
    :cond_20
    new-instance v0, Lcom/example/bleconnectse/MirrorContent$Image;

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->displayNameOf(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, p1, v1}, Lcom/example/bleconnectse/MirrorContent$Image;-><init>(Landroid/net/Uri;Ljava/lang/String;)V

    check-cast v0, Lcom/example/bleconnectse/MirrorContent;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->startMirror(Lcom/example/bleconnectse/MirrorContent;)Z

    move-result p0

    return p0
.end method

.method public final startInstrumentWallpaper(Landroid/net/Uri;)Z
    .registers 7

    const-string v0, "uri"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 632
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getActiveMode()Lcom/example/bleconnectse/OtaNetworkMode;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_1e

    move-object p1, p0

    check-cast p1, Lcom/example/bleconnectse/YadeaOtaClient;

    .line 633
    const-string/jumbo p1, "请先连接 AP 或 P2P，再设置仪表壁纸"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 634
    new-instance p1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda2;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda2;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    return v1

    .line 637
    :cond_1e
    sget-object v2, Lcom/example/bleconnectse/OtaNetworkMode;->Ap:Lcom/example/bleconnectse/OtaNetworkMode;

    if-ne v0, v2, :cond_36

    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->isApReady()Z

    move-result v2

    if-nez v2, :cond_36

    .line 638
    const-string p1, "AP 尚未完成目标网络连接，禁止设置仪表壁纸"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 639
    new-instance p1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda3;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda3;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    return v1

    .line 642
    :cond_36
    sget-object v2, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;

    if-ne v0, v2, :cond_50

    iget-boolean v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeerVerified:Z

    if-eqz v2, :cond_42

    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    if-nez v2, :cond_50

    .line 643
    :cond_42
    const-string p1, "P2P 目标尚未完成身份校验，禁止设置仪表壁纸"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 644
    new-instance p1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda4;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda4;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    return v1

    .line 647
    :cond_50
    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperLock:Ljava/lang/Object;

    monitor-enter v2

    .line 648
    :try_start_53
    iget-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperSessionActive:Z

    if-eqz v3, :cond_61

    .line 649
    new-instance p1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda5;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda5;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V
    :try_end_5f
    .catchall {:try_start_53 .. :try_end_5f} :catchall_78

    .line 650
    monitor-exit v2

    return v1

    :cond_61
    const/4 v3, 0x1

    .line 652
    :try_start_62
    iput-boolean v3, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperSessionActive:Z

    .line 653
    iput-boolean v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperStopRequested:Z

    .line 654
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_68
    .catchall {:try_start_62 .. :try_end_68} :catchall_78

    .line 647
    monitor-exit v2

    .line 655
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->displayNameOf(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v1

    .line 656
    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->executor:Ljava/util/concurrent/ExecutorService;

    new-instance v4, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;

    invoke-direct {v4, p0, p1, v0, v1}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda6;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Uri;Lcom/example/bleconnectse/OtaNetworkMode;Ljava/lang/String;)V

    invoke-interface {v2, v4}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return v3

    :catchall_78
    move-exception p0

    .line 647
    monitor-exit v2

    throw p0
.end method

.method public final startLiveMirror(Ljava/lang/String;)Z
    .registers 5

    const-string v0, "sourceName"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 621
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getActiveMode()Lcom/example/bleconnectse/OtaNetworkMode;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_2b

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/YadeaOtaClient;

    .line 622
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "请先连接 AP 或 P2P，再启动"

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 623
    new-instance p1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda26;

    invoke-direct {p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda26;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    return v1

    .line 626
    :cond_2b
    invoke-direct {p0, v0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->validateMirrorNetwork(Lcom/example/bleconnectse/OtaNetworkMode;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_32

    return v1

    .line 627
    :cond_32
    sget-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    .line 628
    new-instance v0, Lcom/example/bleconnectse/MirrorContent$Live;

    invoke-direct {v0, p1}, Lcom/example/bleconnectse/MirrorContent$Live;-><init>(Ljava/lang/String;)V

    check-cast v0, Lcom/example/bleconnectse/MirrorContent;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->startMirror(Lcom/example/bleconnectse/MirrorContent;)Z

    move-result p0

    return p0
.end method

.method public final startMirrorDemoForCurrentMode()Z
    .registers 4

    .line 603
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getActiveMode()Lcom/example/bleconnectse/OtaNetworkMode;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_11

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/YadeaOtaClient;

    .line 604
    const-string/jumbo v0, "请先连接 AP 或 P2P，再启动地图投屏"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return v1

    .line 607
    :cond_11
    const-string/jumbo v2, "地图投屏"

    invoke-direct {p0, v0, v2}, Lcom/example/bleconnectse/YadeaOtaClient;->validateMirrorNetwork(Lcom/example/bleconnectse/OtaNetworkMode;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1b

    return v1

    .line 608
    :cond_1b
    sget-object v0, Lcom/example/bleconnectse/MirrorContent$Demo;->INSTANCE:Lcom/example/bleconnectse/MirrorContent$Demo;

    check-cast v0, Lcom/example/bleconnectse/MirrorContent;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->startMirror(Lcom/example/bleconnectse/MirrorContent;)Z

    move-result p0

    return p0
.end method

.method public final startOta()V
    .registers 3

    .line 717
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->executor:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda43;

    invoke-direct {v1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda43;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final startP2pMirrorDemo()V
    .registers 2

    .line 593
    iget-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeerVerified:Z

    if-eqz v0, :cond_16

    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    if-nez v0, :cond_9

    goto :goto_16

    .line 598
    :cond_9
    sget-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setActiveMode(Lcom/example/bleconnectse/OtaNetworkMode;)V

    .line 599
    sget-object v0, Lcom/example/bleconnectse/MirrorContent$Demo;->INSTANCE:Lcom/example/bleconnectse/MirrorContent$Demo;

    check-cast v0, Lcom/example/bleconnectse/MirrorContent;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->startMirror(Lcom/example/bleconnectse/MirrorContent;)Z

    return-void

    .line 594
    :cond_16
    :goto_16
    const-string v0, "P2P 目标尚未完成身份校验，禁止发送投屏数据"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 595
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda14;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda14;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public final startP2pOta()V
    .registers 3

    .line 582
    sget-object v0, Lcom/example/bleconnectse/OtaNetworkMode;->P2p:Lcom/example/bleconnectse/OtaNetworkMode;

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setActiveMode(Lcom/example/bleconnectse/OtaNetworkMode;)V

    .line 583
    sget-object v0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v1, "启动 P2P OTA"

    invoke-virtual {v0, v1}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 584
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->startOta()V

    return-void
.end method

.method public final stopHttpServer()V
    .registers 2

    .line 956
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->httpServer:Lcom/example/bleconnectse/OtaHttpServer;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lcom/example/bleconnectse/OtaHttpServer;->stop()V

    :cond_7
    const/4 v0, 0x0

    .line 957
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->httpServer:Lcom/example/bleconnectse/OtaHttpServer;

    const/4 v0, 0x0

    .line 958
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setHttpRunning(Z)V

    .line 959
    const-string v0, "HTTP 服务已停止"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void
.end method

.method public final stopInstrumentWallpaper()V
    .registers 3

    const/4 v0, 0x1

    .line 702
    iput-boolean v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->wallpaperStopRequested:Z

    .line 703
    :try_start_3
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeWallpaperSocket:Ljava/net/Socket;

    if-eqz v0, :cond_12

    invoke-virtual {v0}, Ljava/net/Socket;->close()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_16
    .catchall {:try_start_3 .. :try_end_16} :catchall_17

    goto :goto_21

    :catchall_17
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 704
    :goto_21
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda40;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda40;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public final stopMirrorDemo()V
    .registers 4

    .line 944
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorLock:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x0

    .line 945
    :try_start_4
    iput-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingMirrorContent:Lcom/example/bleconnectse/MirrorContent;

    const/4 v2, 0x1

    .line 946
    iput-boolean v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->mirrorStopRequested:Z

    .line 947
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_b
    .catchall {:try_start_4 .. :try_end_b} :catchall_5a

    .line 944
    monitor-exit v0

    .line 948
    :try_start_c
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorSocket:Ljava/net/Socket;

    if-eqz v0, :cond_1b

    invoke-virtual {v0}, Ljava/net/Socket;->close()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_1c

    :cond_1b
    move-object v0, v1

    :goto_1c
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1f
    .catchall {:try_start_c .. :try_end_1f} :catchall_20

    goto :goto_2a

    :catchall_20
    move-exception v0

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 949
    :goto_2a
    :try_start_2a
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->activeMirrorDataSocket:Ljava/net/DatagramSocket;

    if-eqz v0, :cond_38

    invoke-virtual {v0}, Ljava/net/DatagramSocket;->close()V

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :cond_38
    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_3b
    .catchall {:try_start_2a .. :try_end_3b} :catchall_3c

    goto :goto_46

    :catchall_3c
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 950
    :goto_46
    sget-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-virtual {v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;->clear()V

    .line 951
    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda8;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda8;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->post(Lkotlin/jvm/functions/Function0;)V

    .line 952
    const-string/jumbo v0, "导航投屏停止请求已发出"

    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void

    :catchall_5a
    move-exception p0

    .line 944
    monitor-exit v0

    throw p0
.end method

.method public final updateBleConnectionAddress(Ljava/lang/String;)V
    .registers 5

    .line 216
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->buildWifiProfile(Ljava/lang/String;)Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p1

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-nez p1, :cond_5d

    .line 218
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->bleLockedAddress:Ljava/lang/String;

    const/4 v2, 0x1

    if-nez p1, :cond_22

    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p1

    if-eqz p1, :cond_27

    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBleMac()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_27

    check-cast p1, Ljava/lang/CharSequence;

    invoke-static {p1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result p1

    xor-int/2addr p1, v2

    if-ne p1, v2, :cond_27

    .line 219
    :cond_22
    const-string p1, "BLE 未连接，已清除上一辆车的专用 WiFi/P2P 信息"

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    .line 221
    :cond_27
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->bleLockedAddress:Ljava/lang/String;

    .line 222
    invoke-virtual {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->getWifiProfile()Lcom/example/bleconnectse/YadeaWifiProfile;

    move-result-object p1

    if-eqz p1, :cond_41

    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBleMac()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_41

    check-cast p1, Ljava/lang/CharSequence;

    invoke-static {p1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result p1

    xor-int/2addr p1, v2

    if-ne p1, v2, :cond_41

    .line 223
    invoke-direct {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->setWifiProfile(Lcom/example/bleconnectse/YadeaWifiProfile;)V

    .line 225
    :cond_41
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->selectedP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    .line 226
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    .line 227
    iput-boolean v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeerVerified:Z

    .line 228
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setP2pReady(Z)V

    .line 229
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    .line 230
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApReady(Z)V

    .line 231
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setLockedApSeen(Z)V

    .line 232
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionRequested(Z)V

    .line 233
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionFailed(Z)V

    .line 234
    iput-boolean v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedApAfterScan:Z

    .line 235
    iput-boolean v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->autoConnectLockedP2pAfterScan:Z

    return-void

    .line 238
    :cond_5d
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getBleMac()Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->bleLockedAddress:Ljava/lang/String;

    .line 239
    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->setWifiProfile(Lcom/example/bleconnectse/YadeaWifiProfile;)V

    .line 240
    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->apCandidates:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    invoke-virtual {v2}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    .line 241
    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeers:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    invoke-virtual {v2}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    .line 242
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->selectedP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    .line 243
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->pendingP2pPeer:Lcom/example/bleconnectse/P2pPeer;

    .line 244
    iput-boolean v1, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pPeerVerified:Z

    .line 245
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setP2pReady(Z)V

    .line 246
    iput-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient;->p2pGroupOwnerIp:Ljava/lang/String;

    .line 247
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApReady(Z)V

    .line 248
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setLockedApSeen(Z)V

    .line 249
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionRequested(Z)V

    .line 250
    invoke-direct {p0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->setApConnectionFailed(Z)V

    .line 251
    invoke-virtual {p1}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "已锁定当前 BLE 车辆 WiFi："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->logStatus(Ljava/lang/String;)V

    return-void
.end method
