# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda25;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$1:Lcom/example/bleconnectse/NavigationTransport;

.field public final synthetic f$2:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$3:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;Lcom/example/bleconnectse/NavigationTransport;Lcom/example/bleconnectse/BleTileClient;Lcom/example/bleconnectse/YadeaOtaClient;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda25;->f$0:Lkotlin/jvm/functions/Function0;

    iput-object p2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda25;->f$1:Lcom/example/bleconnectse/NavigationTransport;

    iput-object p3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda25;->f$2:Lcom/example/bleconnectse/BleTileClient;

    iput-object p4, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda25;->f$3:Lcom/example/bleconnectse/YadeaOtaClient;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda25;->f$0:Lkotlin/jvm/functions/Function0;

    iget-object v1, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda25;->f$1:Lcom/example/bleconnectse/NavigationTransport;

    iget-object v2, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda25;->f$2:Lcom/example/bleconnectse/BleTileClient;

    iget-object v3, p0, Lcom/example/bleconnectse/MainActivityKt$$ExternalSyntheticLambda25;->f$3:Lcom/example/bleconnectse/YadeaOtaClient;

    move-object v4, p1

    check-cast v4, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-static/range {v0 .. v5}, Lcom/example/bleconnectse/MainActivityKt;->SimulatedNavigationScreen$lambda$54$lambda$50(Lkotlin/jvm/functions/Function0;Lcom/example/bleconnectse/NavigationTransport;Lcom/example/bleconnectse/BleTileClient;Lcom/example/bleconnectse/YadeaOtaClient;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
