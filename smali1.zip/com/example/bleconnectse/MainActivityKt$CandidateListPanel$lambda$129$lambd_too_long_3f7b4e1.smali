# classes2.dex

.class public final Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$5;
.super Ljava/lang/Object;
.source "LazyDsl.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/MainActivityKt;->CandidateListPanel(Lcom/example/bleconnectse/CandidatePanel;Lcom/example/bleconnectse/YadeaOtaClient;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLazyDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt$items$1\n*L\n1#1,523:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$5;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$5;

    invoke-direct {v0}, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$5;-><init>()V

    sput-object v0, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$5;->INSTANCE:Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$5;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 171
    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/MainActivityKt$CandidateListPanel$lambda$129$lambda$128$lambda$127$lambda$126$$inlined$items$default$5;->invoke(Ljava/lang/Object;)Ljava/lang/Void;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Void;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/example/bleconnectse/P2pPeer;",
            ")",
            "Ljava/lang/Void;"
        }
    .end annotation

    const/4 p0, 0x0

    return-object p0
.end method
