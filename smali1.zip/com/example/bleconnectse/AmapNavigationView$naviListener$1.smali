# classes2.dex

.class public final Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;
.super Lcom/amap/api/navi/SimpleNaviListener;
.source "AmapNavigationView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/AmapNavigationView;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAmapNavigationView.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AmapNavigationView.kt\ncom/example/bleconnectse/AmapNavigationView$naviListener$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1189:1\n1#2:1190\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000G\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016J\b\u0010\u0004\u001a\u00020\u0003H\u0016J\u0010\u0010\u0005\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\u0018\u0010\b\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fH\u0016J\u0010\u0010\b\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\fH\u0016J\u0010\u0010\r\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\u000fH\u0016J\u0010\u0010\u0010\u001a\u00020\u00032\u0006\u0010\u0011\u001a\u00020\u0012H\u0016J\u0010\u0010\u0010\u001a\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J\u0010\u0010\u0015\u001a\u00020\u00032\u0006\u0010\u0016\u001a\u00020\nH\u0016J\u0010\u0010\u0015\u001a\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J\b\u0010\u0017\u001a\u00020\u0003H\u0016J\b\u0010\u0018\u001a\u00020\u0003H\u0016J\u0010\u0010\u0019\u001a\u00020\u00032\u0006\u0010\u001a\u001a\u00020\u001bH\u0016J\u0010\u0010\u001c\u001a\u00020\u00032\u0006\u0010\u001d\u001a\u00020\u001bH\u0016¨\u0006\u001e"
    }
    d2 = {
        "com/example/bleconnectse/AmapNavigationView$naviListener$1",
        "Lcom/amap/api/navi/SimpleNaviListener;",
        "onInitNaviSuccess",
        "",
        "onInitNaviFailure",
        "onLocationChange",
        "location",
        "Lcom/amap/api/navi/model/AMapNaviLocation;",
        "onGetNavigationText",
        "type",
        "",
        "text",
        "",
        "onNaviInfoUpdate",
        "info",
        "Lcom/amap/api/navi/model/NaviInfo;",
        "onCalculateRouteSuccess",
        "routeIds",
        "",
        "result",
        "Lcom/amap/api/navi/model/AMapCalcRouteResult;",
        "onCalculateRouteFailure",
        "errorCode",
        "onReCalculateRouteForYaw",
        "onArriveDestination",
        "onGpsOpenStatus",
        "enabled",
        "",
        "onGpsSignalWeak",
        "weak",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/AmapNavigationView;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/AmapNavigationView;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    .line 170
    invoke-direct {p0}, Lcom/amap/api/navi/SimpleNaviListener;-><init>()V

    return-void
.end method


# virtual methods
.method public onArriveDestination()V
    .registers 2

    .line 254
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    const-string/jumbo v0, "已到达目的地"

    invoke-static {p0, v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    return-void
.end method

.method public onCalculateRouteFailure(I)V
    .registers 5

    .line 235
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->access$setRouteStarting$p(Lcom/example/bleconnectse/AmapNavigationView;Z)V

    .line 236
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$restoreRealLocationAfterEmulatorFailure(Lcom/example/bleconnectse/AmapNavigationView;)V

    .line 237
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$routeErrorMessage(Lcom/example/bleconnectse/AmapNavigationView;I)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "路线规划失败："

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "（"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v0, "）"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    return-void
.end method

.method public onCalculateRouteFailure(Lcom/amap/api/navi/model/AMapCalcRouteResult;)V
    .registers 5

    const-string v0, "result"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 241
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->access$setRouteStarting$p(Lcom/example/bleconnectse/AmapNavigationView;Z)V

    .line 242
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$restoreRealLocationAfterEmulatorFailure(Lcom/example/bleconnectse/AmapNavigationView;)V

    .line 243
    invoke-virtual {p1}, Lcom/amap/api/navi/model/AMapCalcRouteResult;->getErrorDescription()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_18

    const-string v0, ""

    :cond_18
    check-cast v0, Ljava/lang/CharSequence;

    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_2a

    .line 244
    invoke-virtual {p1}, Lcom/amap/api/navi/model/AMapCalcRouteResult;->getErrorCode()I

    move-result v0

    invoke-static {v1, v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$routeErrorMessage(Lcom/example/bleconnectse/AmapNavigationView;I)Ljava/lang/String;

    move-result-object v0

    .line 243
    :cond_2a
    check-cast v0, Ljava/lang/String;

    .line 246
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-virtual {p1}, Lcom/amap/api/navi/model/AMapCalcRouteResult;->getErrorCode()I

    move-result p1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "路线规划失败："

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string/jumbo v1, "（"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string/jumbo v0, "）"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    return-void
.end method

.method public onCalculateRouteSuccess(Lcom/amap/api/navi/model/AMapCalcRouteResult;)V
    .registers 3

    const-string v0, "result"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 231
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0}, Lcom/example/bleconnectse/AmapNavigationView;->access$startGpsNavigation(Lcom/example/bleconnectse/AmapNavigationView;)V

    return-void
.end method

.method public onCalculateRouteSuccess([I)V
    .registers 3

    const-string v0, "routeIds"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 227
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0}, Lcom/example/bleconnectse/AmapNavigationView;->access$startGpsNavigation(Lcom/example/bleconnectse/AmapNavigationView;)V

    return-void
.end method

.method public onGetNavigationText(ILjava/lang/String;)V
    .registers 16

    const-string p1, "text"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 202
    move-object p1, p2

    check-cast p1, Ljava/lang/CharSequence;

    invoke-static {p1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_28

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object v0

    const/16 v11, 0x3fb

    const/4 v12, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v3, p2

    invoke-static/range {v0 .. v12}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->copy$default(Lcom/example/bleconnectse/AmapNavigationView$Guidance;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;ILjava/lang/Object;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$setGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;Lcom/example/bleconnectse/AmapNavigationView$Guidance;)V

    :cond_28
    return-void
.end method

.method public onGetNavigationText(Ljava/lang/String;)V
    .registers 15

    const-string v0, "text"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 206
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_28

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object v0

    const/16 v11, 0x3fb

    const/4 v12, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v3, p1

    invoke-static/range {v0 .. v12}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->copy$default(Lcom/example/bleconnectse/AmapNavigationView$Guidance;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;ILjava/lang/Object;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$setGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;Lcom/example/bleconnectse/AmapNavigationView$Guidance;)V

    :cond_28
    return-void
.end method

.method public onGpsOpenStatus(Z)V
    .registers 2

    if-nez p1, :cond_12

    .line 258
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$getEmulatorNavigationActive$p(Lcom/example/bleconnectse/AmapNavigationView;)Z

    move-result p1

    if-nez p1, :cond_12

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    const-string/jumbo p1, "请开启手机定位服务"

    invoke-static {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    :cond_12
    return-void
.end method

.method public onGpsSignalWeak(Z)V
    .registers 2

    if-eqz p1, :cond_11

    .line 262
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$getEmulatorNavigationActive$p(Lcom/example/bleconnectse/AmapNavigationView;)Z

    move-result p1

    if-nez p1, :cond_11

    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    const-string p1, "GPS 信号弱"

    invoke-static {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    :cond_11
    return-void
.end method

.method public onInitNaviFailure()V
    .registers 2

    .line 179
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    const-string/jumbo v0, "高德导航初始化失败，请检查 Key 与网络"

    invoke-static {p0, v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    return-void
.end method

.method public onInitNaviSuccess()V
    .registers 3

    .line 172
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getNavi$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/amap/api/navi/AMapNavi;

    move-result-object v0

    if-eqz v0, :cond_c

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/amap/api/navi/AMapNavi;->setUseInnerVoice(Z)V

    .line 173
    :cond_c
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getNavi$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/amap/api/navi/AMapNavi;

    move-result-object v0

    if-eqz v0, :cond_18

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/amap/api/navi/AMapNavi;->setTrafficSignalEnable(Z)V

    .line 174
    :cond_18
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getEmulatorNavigationActive$p(Lcom/example/bleconnectse/AmapNavigationView;)Z

    move-result v0

    if-nez v0, :cond_2b

    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getNavi$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/amap/api/navi/AMapNavi;

    move-result-object v0

    if-eqz v0, :cond_2b

    invoke-virtual {v0}, Lcom/amap/api/navi/AMapNavi;->startGPS()Z

    .line 175
    :cond_2b
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    const-string/jumbo v0, "定位中，长按地图选择目的地"

    invoke-static {p0, v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    return-void
.end method

.method public onLocationChange(Lcom/amap/api/navi/model/AMapNaviLocation;)V
    .registers 16

    const-string v0, "location"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 183
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getEmulatorNavigationActive$p(Lcom/example/bleconnectse/AmapNavigationView;)Z

    move-result v0

    if-eqz v0, :cond_e

    goto :goto_7f

    .line 184
    :cond_e
    invoke-virtual {p1}, Lcom/amap/api/navi/model/AMapNaviLocation;->getCoord()Lcom/amap/api/navi/model/NaviLatLng;

    move-result-object v0

    if-nez v0, :cond_15

    goto :goto_7f

    .line 185
    :cond_15
    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    new-instance v2, Lcom/amap/api/maps/model/LatLng;

    invoke-virtual {v0}, Lcom/amap/api/navi/model/NaviLatLng;->getLatitude()D

    move-result-wide v3

    invoke-virtual {v0}, Lcom/amap/api/navi/model/NaviLatLng;->getLongitude()D

    move-result-wide v5

    invoke-direct {v2, v3, v4, v5, v6}, Lcom/amap/api/maps/model/LatLng;-><init>(DD)V

    invoke-static {v1, v2}, Lcom/example/bleconnectse/AmapNavigationView;->access$setCurrentLocation$p(Lcom/example/bleconnectse/AmapNavigationView;Lcom/amap/api/maps/model/LatLng;)V

    .line 186
    invoke-virtual {p1}, Lcom/amap/api/navi/model/AMapNaviLocation;->getSpeed()F

    move-result p1

    const v0, 0x40666666  # 3.6f

    mul-float/2addr p1, v0

    float-to-int p1, p1

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v5

    .line 187
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$getGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object p1

    invoke-virtual {p1}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->getSpeedKph()I

    move-result p1

    if-nez p1, :cond_5c

    if-lez v5, :cond_5c

    .line 188
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$getGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object v1

    const/16 v12, 0x3f7

    const/4 v13, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v1 .. v13}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->copy$default(Lcom/example/bleconnectse/AmapNavigationView$Guidance;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;ILjava/lang/Object;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$setGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;Lcom/example/bleconnectse/AmapNavigationView$Guidance;)V

    .line 190
    :cond_5c
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$getDidCenterOnLocation$p(Lcom/example/bleconnectse/AmapNavigationView;)Z

    move-result p1

    if-nez p1, :cond_7f

    .line 191
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$setDidCenterOnLocation$p(Lcom/example/bleconnectse/AmapNavigationView;Z)V

    .line 192
    iget-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$getMap$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/amap/api/maps/AMap;

    move-result-object p1

    .line 194
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getCurrentLocation$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/amap/api/maps/model/LatLng;

    move-result-object p0

    const/high16 v0, 0x41700000  # 15.0f

    .line 193
    invoke-static {p0, v0}, Lcom/amap/api/maps/CameraUpdateFactory;->newLatLngZoom(Lcom/amap/api/maps/model/LatLng;F)Lcom/amap/api/maps/CameraUpdate;

    move-result-object p0

    .line 192
    invoke-virtual {p1, p0}, Lcom/amap/api/maps/AMap;->animateCamera(Lcom/amap/api/maps/CameraUpdate;)V

    :cond_7f
    :goto_7f
    return-void
.end method

.method public onNaviInfoUpdate(Lcom/amap/api/navi/model/NaviInfo;)V
    .registers 20

    move-object/from16 v0, p0

    const-string v1, "info"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 210
    iget-object v1, v0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v1}, Lcom/example/bleconnectse/AmapNavigationView;->access$getGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object v3

    .line 211
    invoke-virtual {v2}, Lcom/amap/api/navi/model/NaviInfo;->getCurrentRoadName()Ljava/lang/String;

    move-result-object v4

    const-string v16, ""

    if-nez v4, :cond_19

    move-object/from16 v4, v16

    .line 212
    :cond_19
    invoke-virtual {v2}, Lcom/amap/api/navi/model/NaviInfo;->getNextRoadName()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_21

    move-object/from16 v5, v16

    :cond_21
    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v5}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v6

    const-string/jumbo v17, "前方道路"

    if-eqz v6, :cond_2e

    move-object/from16 v5, v17

    :cond_2e
    check-cast v5, Ljava/lang/String;

    .line 213
    invoke-virtual {v2}, Lcom/amap/api/navi/model/NaviInfo;->getCurrentSpeed()I

    move-result v6

    const/4 v7, 0x0

    invoke-static {v6, v7}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v6

    .line 214
    invoke-virtual {v2}, Lcom/amap/api/navi/model/NaviInfo;->getCurStepRetainDistance()I

    move-result v8

    invoke-static {v8, v7}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v8

    .line 215
    invoke-virtual {v2}, Lcom/amap/api/navi/model/NaviInfo;->getPathRetainDistance()I

    move-result v9

    invoke-static {v9, v7}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v9

    .line 216
    invoke-virtual {v2}, Lcom/amap/api/navi/model/NaviInfo;->getPathRetainTime()I

    move-result v10

    invoke-static {v10, v7}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v10

    .line 217
    invoke-virtual {v2}, Lcom/amap/api/navi/model/NaviInfo;->getRouteRemainLightCount()I

    move-result v11

    invoke-static {v11, v7}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v11

    .line 218
    invoke-virtual {v2}, Lcom/amap/api/navi/model/NaviInfo;->getIconBitmap()Landroid/graphics/Bitmap;

    move-result-object v13

    const/16 v14, 0x104

    const/4 v15, 0x0

    move v7, v6

    const/4 v6, 0x0

    const/4 v12, 0x0

    .line 210
    invoke-static/range {v3 .. v15}, Lcom/example/bleconnectse/AmapNavigationView$Guidance;->copy$default(Lcom/example/bleconnectse/AmapNavigationView$Guidance;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILjava/lang/String;Landroid/graphics/Bitmap;ILjava/lang/Object;)Lcom/example/bleconnectse/AmapNavigationView$Guidance;

    move-result-object v3

    invoke-static {v1, v3}, Lcom/example/bleconnectse/AmapNavigationView;->access$setGuidance$p(Lcom/example/bleconnectse/AmapNavigationView;Lcom/example/bleconnectse/AmapNavigationView$Guidance;)V

    .line 220
    iget-object v0, v0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    .line 221
    invoke-virtual {v2}, Lcom/amap/api/navi/model/NaviInfo;->getCurStepRetainDistance()I

    move-result v1

    invoke-static {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->access$formatDistance(Lcom/example/bleconnectse/AmapNavigationView;I)Ljava/lang/String;

    move-result-object v1

    .line 222
    invoke-virtual {v2}, Lcom/amap/api/navi/model/NaviInfo;->getNextRoadName()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_7b

    goto :goto_7d

    :cond_7b
    move-object/from16 v16, v2

    :goto_7d
    check-cast v16, Ljava/lang/CharSequence;

    invoke-static/range {v16 .. v16}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_88

    move-object/from16 v2, v17

    goto :goto_8a

    :cond_88
    move-object/from16 v2, v16

    :goto_8a
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " 后进入 "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 220
    invoke-static {v0, v1}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    return-void
.end method

.method public onReCalculateRouteForYaw()V
    .registers 2

    .line 250
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$naviListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    const-string/jumbo v0, "检测到偏航，正在重新规划"

    invoke-static {p0, v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    return-void
.end method
