# classes2.dex

.class public final Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;
.super Ljava/lang/Object;
.source "AmapNavigationView.kt"

# interfaces
.implements Lcom/amap/api/services/geocoder/GeocodeSearch$OnGeocodeSearchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/AmapNavigationView;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAmapNavigationView.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AmapNavigationView.kt\ncom/example/bleconnectse/AmapNavigationView$geocodeListener$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1189:1\n1#2:1190\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000#\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u001a\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\u001a\u0010\b\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\t2\u0006\u0010\u0006\u001a\u00020\u0007H\u0016¨\u0006\n"
    }
    d2 = {
        "com/example/bleconnectse/AmapNavigationView$geocodeListener$1",
        "Lcom/amap/api/services/geocoder/GeocodeSearch$OnGeocodeSearchListener;",
        "onGeocodeSearched",
        "",
        "result",
        "Lcom/amap/api/services/geocoder/GeocodeResult;",
        "resultCode",
        "",
        "onRegeocodeSearched",
        "Lcom/amap/api/services/geocoder/RegeocodeResult;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/AmapNavigationView;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/AmapNavigationView;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    .line 266
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onGeocodeSearched(Lcom/amap/api/services/geocoder/GeocodeResult;I)V
    .registers 9

    .line 268
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getClosed$p(Lcom/example/bleconnectse/AmapNavigationView;)Z

    move-result v0

    if-eqz v0, :cond_9

    return-void

    :cond_9
    const/16 v0, 0x3e8

    if-eq p2, v0, :cond_23

    .line 270
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "终点搜索失败："

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    return-void

    :cond_23
    const/4 p2, 0x0

    if-eqz p1, :cond_33

    .line 273
    invoke-virtual {p1}, Lcom/amap/api/services/geocoder/GeocodeResult;->getGeocodeAddressList()Ljava/util/List;

    move-result-object p1

    if-eqz p1, :cond_33

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/amap/api/services/geocoder/GeocodeAddress;

    goto :goto_34

    :cond_33
    move-object p1, p2

    :goto_34
    if-eqz p1, :cond_3a

    .line 274
    invoke-virtual {p1}, Lcom/amap/api/services/geocoder/GeocodeAddress;->getLatLonPoint()Lcom/amap/api/services/core/LatLonPoint;

    move-result-object p2

    :cond_3a
    if-nez p2, :cond_45

    .line 276
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    const-string/jumbo p1, "没有找到该终点，请输入城市和完整名称"

    invoke-static {p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$updateStatus(Lcom/example/bleconnectse/AmapNavigationView;Ljava/lang/String;)V

    return-void

    .line 279
    :cond_45
    invoke-virtual {p1}, Lcom/amap/api/services/geocoder/GeocodeAddress;->getFormatAddress()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_4d

    const-string p1, ""

    :cond_4d
    check-cast p1, Ljava/lang/CharSequence;

    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_5b

    invoke-static {v0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getPendingDestinationName$p(Lcom/example/bleconnectse/AmapNavigationView;)Ljava/lang/String;

    move-result-object p1

    :cond_5b
    check-cast p1, Ljava/lang/String;

    .line 280
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    .line 281
    new-instance v1, Lcom/amap/api/maps/model/LatLng;

    invoke-virtual {p2}, Lcom/amap/api/services/core/LatLonPoint;->getLatitude()D

    move-result-wide v2

    invoke-virtual {p2}, Lcom/amap/api/services/core/LatLonPoint;->getLongitude()D

    move-result-wide v4

    invoke-direct {v1, v2, v3, v4, v5}, Lcom/amap/api/maps/model/LatLng;-><init>(DD)V

    .line 282
    iget-object p0, p0, Lcom/example/bleconnectse/AmapNavigationView$geocodeListener$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    invoke-static {p0}, Lcom/example/bleconnectse/AmapNavigationView;->access$getPendingNaviType$p(Lcom/example/bleconnectse/AmapNavigationView;)I

    move-result p0

    .line 280
    invoke-static {v0, v1, p0, p1}, Lcom/example/bleconnectse/AmapNavigationView;->access$selectDestination(Lcom/example/bleconnectse/AmapNavigationView;Lcom/amap/api/maps/model/LatLng;ILjava/lang/String;)V

    return-void
.end method

.method public onRegeocodeSearched(Lcom/amap/api/services/geocoder/RegeocodeResult;I)V
    .registers 3

    return-void
.end method
