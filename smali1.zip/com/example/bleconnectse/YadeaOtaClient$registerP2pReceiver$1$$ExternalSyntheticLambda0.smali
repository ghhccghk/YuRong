# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:Ljava/util/List;

.field public final synthetic f$2:Landroid/net/wifi/p2p/WifiP2pManager;

.field public final synthetic f$3:Landroid/net/wifi/p2p/WifiP2pManager$Channel;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/util/List;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;->f$1:Ljava/util/List;

    iput-object p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;->f$2:Landroid/net/wifi/p2p/WifiP2pManager;

    iput-object p4, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;->f$3:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;->f$1:Ljava/util/List;

    iget-object v2, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;->f$2:Landroid/net/wifi/p2p/WifiP2pManager;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1$$ExternalSyntheticLambda0;->f$3:Landroid/net/wifi/p2p/WifiP2pManager$Channel;

    invoke-static {v0, v1, v2, p0}, Lcom/example/bleconnectse/YadeaOtaClient$registerP2pReceiver$1;->onReceive$lambda$7$lambda$6(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/util/List;Landroid/net/wifi/p2p/WifiP2pManager;Landroid/net/wifi/p2p/WifiP2pManager$Channel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method
