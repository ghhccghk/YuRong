# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda25;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/YadeaOtaClient;

.field public final synthetic f$1:Lcom/example/bleconnectse/MirrorContent;

.field public final synthetic f$2:J


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/MirrorContent;J)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda25;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda25;->f$1:Lcom/example/bleconnectse/MirrorContent;

    iput-wide p3, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda25;->f$2:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda25;->f$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object v1, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda25;->f$1:Lcom/example/bleconnectse/MirrorContent;

    iget-wide v2, p0, Lcom/example/bleconnectse/YadeaOtaClient$$ExternalSyntheticLambda25;->f$2:J

    invoke-static {v0, v1, v2, v3}, Lcom/example/bleconnectse/YadeaOtaClient;->startMirror$lambda$70(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/MirrorContent;J)V

    return-void
.end method
