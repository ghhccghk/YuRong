# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:Lcom/example/bleconnectse/BleTileClient;

.field public final synthetic f$2:Landroid/bluetooth/BluetoothGatt;


# direct methods
.method public synthetic constructor <init>(ILcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda0;->f$0:I

    iput-object p2, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda0;->f$1:Lcom/example/bleconnectse/BleTileClient;

    iput-object p3, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda0;->f$2:Landroid/bluetooth/BluetoothGatt;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget v0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda0;->f$0:I

    iget-object v1, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda0;->f$1:Lcom/example/bleconnectse/BleTileClient;

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$gattCallback$1$$ExternalSyntheticLambda0;->f$2:Landroid/bluetooth/BluetoothGatt;

    invoke-static {v0, v1, p0}, Lcom/example/bleconnectse/BleTileClient$gattCallback$1;->onDescriptorWrite$lambda$3(ILcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/BluetoothGatt;)V

    return-void
.end method
