# classes2.dex

.class public final Lcom/example/bleconnectse/LiveMirrorFrameBus;
.super Ljava/lang/Object;
.source "LiveMirrorFrameBus.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u0006J\b\u0010\f\u001a\u0004\u0018\u00010\u0006J\u0006\u0010\r\u001a\u00020\nR\u0016\u0010\u0004\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"
    }
    d2 = {
        "Lcom/example/bleconnectse/LiveMirrorFrameBus;",
        "",
        "<init>",
        "()V",
        "latest",
        "Ljava/util/concurrent/atomic/AtomicReference;",
        "Landroid/graphics/Bitmap;",
        "submittedSinceClear",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "submit",
        "",
        "bitmap",
        "take",
        "clear",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

.field private static final latest:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field

.field private static final submittedSinceClear:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;

    invoke-direct {v0}, Lcom/example/bleconnectse/LiveMirrorFrameBus;-><init>()V

    sput-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->INSTANCE:Lcom/example/bleconnectse/LiveMirrorFrameBus;

    .line 8
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    sput-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->latest:Ljava/util/concurrent/atomic/AtomicReference;

    .line 9
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    sput-object v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->submittedSinceClear:Ljava/util/concurrent/atomic/AtomicInteger;

    const/16 v0, 0x8

    sput v0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final clear()V
    .registers 2

    .line 21
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->submittedSinceClear:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 22
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->latest:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    if-eqz p0, :cond_14

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->recycle()V

    :cond_14
    return-void
.end method

.method public final submit(Landroid/graphics/Bitmap;)V
    .registers 3

    const-string p0, "bitmap"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->submittedSinceClear:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result p0

    if-nez p0, :cond_15

    .line 13
    sget-object p0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    const-string/jumbo v0, "瀹炴椂鎶曞睆棣栧抚鍒拌揪"

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 15
    :cond_15
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->latest:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    if-eqz p0, :cond_22

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->recycle()V

    :cond_22
    return-void
.end method

.method public final take()Landroid/graphics/Bitmap;
    .registers 2

    .line 18
    sget-object p0, Lcom/example/bleconnectse/LiveMirrorFrameBus;->latest:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    return-object p0
.end method
