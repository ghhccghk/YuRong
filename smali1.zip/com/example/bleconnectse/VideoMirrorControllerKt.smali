# classes2.dex

.class public final Lcom/example/bleconnectse/VideoMirrorControllerKt;
.super Ljava/lang/Object;
.source "VideoMirrorController.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000e\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0003X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0004"
    }
    d2 = {
        "VIDEO_MIRROR_FRAME_INTERVAL_MS",
        "",
        "VIDEO_MIRROR_MAX_CAPTURE_EDGE",
        "",
        "app"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final VIDEO_MIRROR_FRAME_INTERVAL_MS:J = 0x64L

.field private static final VIDEO_MIRROR_MAX_CAPTURE_EDGE:I = 0x500
