# classes2.dex

.class public final Lcom/example/bleconnectse/BleTileClient$scanCallback$1;
.super Landroid/bluetooth/le/ScanCallback;
.source "BleTileClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/BleTileClient;-><init>(Landroid/content/Context;Lcom/example/bleconnectse/SyntheticTileRepository;Lkotlin/jvm/functions/Function1;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nBleTileClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BleTileClient.kt\ncom/example/bleconnectse/BleTileClient$scanCallback$1\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,858:1\n1869#2,2:859\n*S KotlinDebug\n*F\n+ 1 BleTileClient.kt\ncom/example/bleconnectse/BleTileClient$scanCallback$1\n*L\n177#1:859,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\'\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\u0016\u0010\b\u001a\u00020\u00032\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00070\nH\u0016J\u0010\u0010\u000b\u001a\u00020\u00032\u0006\u0010\f\u001a\u00020\u0005H\u0016¨\u0006\r"
    }
    d2 = {
        "com/example/bleconnectse/BleTileClient$scanCallback$1",
        "Landroid/bluetooth/le/ScanCallback;",
        "onScanResult",
        "",
        "callbackType",
        "",
        "result",
        "Landroid/bluetooth/le/ScanResult;",
        "onBatchScanResults",
        "results",
        "",
        "onScanFailed",
        "errorCode",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/BleTileClient;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/BleTileClient;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    .line 171
    invoke-direct {p0}, Landroid/bluetooth/le/ScanCallback;-><init>()V

    return-void
.end method

.method static final onBatchScanResults$lambda$1(Ljava/util/List;Lcom/example/bleconnectse/BleTileClient;)V
    .registers 3

    .line 177
    check-cast p0, Ljava/lang/Iterable;

    .line 859
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_6
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_16

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/bluetooth/le/ScanResult;

    .line 177
    invoke-static {p1, v0}, Lcom/example/bleconnectse/BleTileClient;->access$acceptScanResult(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/le/ScanResult;)V

    goto :goto_6

    :cond_16
    return-void
.end method

.method static final onScanFailed$lambda$2(Lcom/example/bleconnectse/BleTileClient;I)V
    .registers 4

    const/4 v0, 0x0

    .line 182
    invoke-static {p0, v0}, Lcom/example/bleconnectse/BleTileClient;->access$setScanning(Lcom/example/bleconnectse/BleTileClient;Z)V

    .line 183
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "BLE扫描失败：错误码"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->access$setStatus(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V

    .line 184
    invoke-virtual {p0}, Lcom/example/bleconnectse/BleTileClient;->getStatus()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->access$logStatus(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V

    return-void
.end method

.method static final onScanResult$lambda$0(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/le/ScanResult;)V
    .registers 2

    .line 173
    invoke-static {p0, p1}, Lcom/example/bleconnectse/BleTileClient;->access$acceptScanResult(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/le/ScanResult;)V

    return-void
.end method


# virtual methods
.method public onBatchScanResults(Ljava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/bluetooth/le/ScanResult;",
            ">;)V"
        }
    .end annotation

    const-string v0, "results"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 177
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object v0

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    new-instance v1, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda0;

    invoke-direct {v1, p1, p0}, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda0;-><init>(Ljava/util/List;Lcom/example/bleconnectse/BleTileClient;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onScanFailed(I)V
    .registers 4

    .line 181
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object v0

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    new-instance v1, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p1}, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda2;-><init>(Lcom/example/bleconnectse/BleTileClient;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onScanResult(ILandroid/bluetooth/le/ScanResult;)V
    .registers 4

    const-string p1, "result"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 173
    iget-object p1, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {p1}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object p1

    iget-object p0, p0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    new-instance v0, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0, p2}, Lcom/example/bleconnectse/BleTileClient$scanCallback$1$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/BleTileClient;Landroid/bluetooth/le/ScanResult;)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
