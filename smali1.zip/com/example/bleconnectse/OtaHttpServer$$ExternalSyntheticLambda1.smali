# classes2.dex

.class public final synthetic Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/bleconnectse/OtaHttpServer;


# direct methods
.method public synthetic constructor <init>(Lcom/example/bleconnectse/OtaHttpServer;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda1;->f$0:Lcom/example/bleconnectse/OtaHttpServer;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 1

    .line 0
    iget-object p0, p0, Lcom/example/bleconnectse/OtaHttpServer$$ExternalSyntheticLambda1;->f$0:Lcom/example/bleconnectse/OtaHttpServer;

    invoke-static {p0}, Lcom/example/bleconnectse/OtaHttpServer;->$r8$lambda$dhGINebUvOTik0JhYDrXlpJg3xo(Lcom/example/bleconnectse/OtaHttpServer;)V

    return-void
.end method
