# classes2.dex

.class public final Lcom/example/bleconnectse/WallpaperProtocol;
.super Ljava/lang/Object;
.source "InstrumentWallpaperClient.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInstrumentWallpaperClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InstrumentWallpaperClient.kt\ncom/example/bleconnectse/WallpaperProtocol\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,424:1\n1#2:425\n12897#3,3:426\n*S KotlinDebug\n*F\n+ 1 InstrumentWallpaperClient.kt\ncom/example/bleconnectse/WallpaperProtocol\n*L\n411#1:426,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0005\n\u0002\b\u0004\bÁ\u0002\u0018\u00002\u00020\u0001:\u0001\u001fB\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0016\u0010\b\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\tJ\u0018\u0010\u000b\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\t2\b\b\u0002\u0010\r\u001a\u00020\u0005J\u000e\u0010\u000e\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u0010J\u000e\u0010\u0011\u001a\u00020\u00122\u0006\u0010\f\u001a\u00020\tJ\u000e\u0010\u0013\u001a\u00020\t2\u0006\u0010\u0014\u001a\u00020\tJ\u000e\u0010\u0015\u001a\u00020\t2\u0006\u0010\u0016\u001a\u00020\u0005J\u000e\u0010\u0017\u001a\u00020\t2\u0006\u0010\u0016\u001a\u00020\u0005J\u0016\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0014\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\u0005J\u0016\u0010\u001a\u001a\u00020\u00052\u0006\u0010\u0014\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\u0005J\u0010\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u0014\u001a\u00020\tH\u0002J\u0018\u0010\u001d\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u001e\u001a\u00020\u0005H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006 "
    }
    d2 = {
        "Lcom/example/bleconnectse/WallpaperProtocol;",
        "",
        "<init>",
        "()V",
        "REQUEST_PROTOCOL_ID",
        "",
        "RESPONSE_PROTOCOL_ID",
        "MAX_INNER_BYTES",
        "command",
        "",
        "data",
        "outerFrame",
        "inner",
        "protocolId",
        "readOuterFrame",
        "input",
        "Ljava/io/InputStream;",
        "parseInner",
        "Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;",
        "crc16ModbusBytes",
        "bytes",
        "int16",
        "value",
        "int32",
        "readInt16",
        "offset",
        "readInt32",
        "checksum",
        "",
        "readExact",
        "size",
        "InnerFrame",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x0

.field public static final INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

.field private static final MAX_INNER_BYTES:I = 0x200000

.field private static final REQUEST_PROTOCOL_ID:I = 0x3c

.field private static final RESPONSE_PROTOCOL_ID:I = 0x4c


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/example/bleconnectse/WallpaperProtocol;

    invoke-direct {v0}, Lcom/example/bleconnectse/WallpaperProtocol;-><init>()V

    sput-object v0, Lcom/example/bleconnectse/WallpaperProtocol;->INSTANCE:Lcom/example/bleconnectse/WallpaperProtocol;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 273
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final checksum([B)B
    .registers 5

    .line 427
    array-length p0, p1

    const/4 v0, 0x0

    move v1, v0

    :goto_3
    if-ge v0, p0, :cond_f

    aget-byte v2, p1, v0

    and-int/lit16 v2, v2, 0xff

    add-int/2addr v1, v2

    and-int/lit16 v1, v1, 0xff

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_f
    int-to-byte p0, v1

    return p0
.end method

.method public static synthetic outerFrame$default(Lcom/example/bleconnectse/WallpaperProtocol;[BIILjava/lang/Object;)[B
    .registers 5

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_6

    const/16 p2, 0x3c

    .line 283
    :cond_6
    invoke-virtual {p0, p1, p2}, Lcom/example/bleconnectse/WallpaperProtocol;->outerFrame([BI)[B

    move-result-object p0

    return-object p0
.end method

.method private final readExact(Ljava/io/InputStream;I)[B
    .registers 5

    .line 414
    new-array p0, p2, [B

    const/4 v0, 0x0

    :goto_3
    if-ge v0, p2, :cond_18

    sub-int v1, p2, v0

    .line 417
    invoke-virtual {p1, p0, v0, v1}, Ljava/io/InputStream;->read([BII)I

    move-result v1

    if-ltz v1, :cond_f

    add-int/2addr v0, v1

    goto :goto_3

    .line 418
    :cond_f
    new-instance p0, Ljava/io/EOFException;

    const-string/jumbo p1, "壁纸帧未接收完整"

    invoke-direct {p0, p1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_18
    return-object p0
.end method


# virtual methods
.method public final command(I[B)[B
    .registers 5

    const-string v0, "data"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    int-to-byte p1, p1

    const/4 v0, 0x1

    .line 281
    new-array v0, v0, [B

    const/4 v1, 0x0

    aput-byte p1, v0, v1

    array-length p1, p2

    invoke-virtual {p0, p1}, Lcom/example/bleconnectse/WallpaperProtocol;->int32(I)[B

    move-result-object p0

    invoke-static {v0, p0}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object p0

    invoke-static {p0, p2}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object p0

    return-object p0
.end method

.method public final crc16ModbusBytes([B)[B
    .registers 8

    const-string p0, "bytes"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 377
    array-length p0, p1

    const v0, 0xffff

    const/4 v1, 0x0

    move v2, v1

    :goto_b
    const/16 v3, 0x8

    if-ge v2, p0, :cond_27

    aget-byte v4, p1, v2

    and-int/lit16 v4, v4, 0xff

    xor-int/2addr v0, v4

    move v4, v1

    :goto_15
    if-ge v4, v3, :cond_24

    and-int/lit8 v5, v0, 0x1

    ushr-int/lit8 v0, v0, 0x1

    if-eqz v5, :cond_21

    const v5, 0xa001

    xor-int/2addr v0, v5

    :cond_21
    add-int/lit8 v4, v4, 0x1

    goto :goto_15

    :cond_24
    add-int/lit8 v2, v2, 0x1

    goto :goto_b

    :cond_27
    and-int/lit16 p0, v0, 0xff

    int-to-byte p0, p0

    ushr-int/lit8 p1, v0, 0x8

    and-int/lit16 p1, p1, 0xff

    int-to-byte p1, p1

    const/4 v0, 0x2

    .line 385
    new-array v0, v0, [B

    aput-byte p0, v0, v1

    const/4 p0, 0x1

    aput-byte p1, v0, p0

    return-object v0
.end method

.method public final int16(I)[B
    .registers 4

    ushr-int/lit8 p0, p1, 0x8

    int-to-byte p0, p0

    int-to-byte p1, p1

    const/4 v0, 0x2

    .line 388
    new-array v0, v0, [B

    const/4 v1, 0x0

    aput-byte p0, v0, v1

    const/4 p0, 0x1

    aput-byte p1, v0, p0

    return-object v0
.end method

.method public final int32(I)[B
    .registers 6

    ushr-int/lit8 p0, p1, 0x18

    int-to-byte p0, p0

    ushr-int/lit8 v0, p1, 0x10

    int-to-byte v0, v0

    ushr-int/lit8 v1, p1, 0x8

    int-to-byte v1, v1

    int-to-byte p1, p1

    const/4 v2, 0x4

    .line 394
    new-array v2, v2, [B

    const/4 v3, 0x0

    aput-byte p0, v2, v3

    const/4 p0, 0x1

    aput-byte v0, v2, p0

    const/4 p0, 0x2

    aput-byte v1, v2, p0

    const/4 p0, 0x3

    aput-byte p1, v2, p0

    return-object v2
.end method

.method public final outerFrame([BI)[B
    .registers 9

    const-string v0, "inner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    if-ltz p2, :cond_4b

    const/16 v0, 0x100

    if-ge p2, v0, :cond_4b

    .line 285
    array-length v0, p1

    const/4 v1, 0x3

    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Lcom/example/bleconnectse/WallpaperProtocol;->int32(I)[B

    move-result-object v0

    int-to-byte p2, p2

    const/4 v2, 0x1

    .line 286
    new-array v3, v2, [B

    const/4 v4, 0x0

    aput-byte p2, v3, v4

    invoke-static {v3, v0}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object v3

    invoke-static {v3, p1}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object v3

    invoke-direct {p0, v3}, Lcom/example/bleconnectse/WallpaperProtocol;->checksum([B)B

    move-result p0

    .line 287
    new-array v3, v1, [B

    const/16 v5, 0x59

    aput-byte v5, v3, v4

    const/16 v5, 0x44

    aput-byte v5, v3, v2

    const/4 v5, 0x2

    aput-byte p2, v3, v5

    invoke-static {v3, v0}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object p2

    invoke-static {p2, p1}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object p1

    .line 288
    new-array p2, v1, [B

    aput-byte p0, p2, v4

    const/16 p0, 0x4b

    aput-byte p0, p2, v2

    const/16 p0, 0x4a

    aput-byte p0, p2, v5

    .line 287
    invoke-static {p1, p2}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object p0

    return-object p0

    .line 284
    :cond_4b
    new-instance p0, Ljava/lang/StringBuilder;

    const-string/jumbo p1, "壁纸协议 ID 无效："

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final parseInner([B)Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;
    .registers 5

    const-string v0, "inner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 367
    array-length v0, p1

    const/4 v1, 0x5

    if-lt v0, v1, :cond_4c

    const/4 v0, 0x1

    .line 368
    invoke-virtual {p0, p1, v0}, Lcom/example/bleconnectse/WallpaperProtocol;->readInt32([BI)I

    move-result p0

    if-ltz p0, :cond_25

    .line 369
    array-length v0, p1

    add-int/lit8 v2, p0, 0x5

    if-ne v0, v2, :cond_25

    .line 372
    new-instance p0, Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;

    const/4 v0, 0x0

    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    array-length v2, p1

    invoke-static {p1, v1, v2}, Lkotlin/collections/ArraysKt;->copyOfRange([BII)[B

    move-result-object p1

    invoke-direct {p0, v0, p1}, Lcom/example/bleconnectse/WallpaperProtocol$InnerFrame;-><init>(I[B)V

    return-object p0

    .line 370
    :cond_25
    array-length p1, p1

    sub-int/2addr p1, v1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "壁纸命令长度不匹配：声明="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string/jumbo v0, "，实际="

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 369
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 367
    :cond_4c
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo p1, "壁纸命令帧过短"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final readInt16([BI)I
    .registers 4

    const-string p0, "bytes"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    if-ltz p2, :cond_1a

    add-int/lit8 p0, p2, 0x2

    .line 398
    array-length v0, p1

    if-gt p0, v0, :cond_1a

    .line 399
    aget-byte p0, p1, p2

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p0, p0, 0x8

    add-int/lit8 p2, p2, 0x1

    aget-byte p1, p1, p2

    and-int/lit16 p1, p1, 0xff

    or-int/2addr p0, p1

    return p0

    .line 398
    :cond_1a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo p1, "读取 16 位整数越界"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final readInt32([BI)I
    .registers 4

    const-string p0, "bytes"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    if-ltz p2, :cond_2c

    add-int/lit8 p0, p2, 0x4

    .line 403
    array-length v0, p1

    if-gt p0, v0, :cond_2c

    .line 404
    aget-byte p0, p1, p2

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p0, p0, 0x18

    add-int/lit8 v0, p2, 0x1

    .line 405
    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x10

    or-int/2addr p0, v0

    add-int/lit8 v0, p2, 0x2

    .line 406
    aget-byte v0, p1, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x8

    or-int/2addr p0, v0

    add-int/lit8 p2, p2, 0x3

    .line 407
    aget-byte p1, p1, p2

    and-int/lit16 p1, p1, 0xff

    or-int/2addr p0, p1

    return p0

    .line 403
    :cond_2c
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo p1, "读取 32 位整数越界"

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final readOuterFrame(Ljava/io/InputStream;)[B
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "input"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, -0x1

    .line 294
    :goto_a
    invoke-virtual {v1}, Ljava/io/InputStream;->read()I

    move-result v3

    if-ltz v3, :cond_1bc

    const/16 v4, 0x59

    if-ne v2, v4, :cond_1b9

    const/16 v2, 0x44

    if-eq v3, v2, :cond_1a

    goto/16 :goto_1b9

    :cond_1a
    const/4 v2, 0x1

    .line 299
    invoke-direct {v0, v1, v2}, Lcom/example/bleconnectse/WallpaperProtocol;->readExact(Ljava/io/InputStream;I)[B

    move-result-object v3

    const/4 v4, 0x0

    aget-byte v3, v3, v4

    and-int/lit16 v5, v3, 0xff

    .line 300
    const-string v6, "format(...)"

    const/16 v7, 0x4c

    const/4 v8, 0x2

    if-ne v5, v7, :cond_195

    const/4 v5, 0x4

    .line 306
    invoke-direct {v0, v1, v5}, Lcom/example/bleconnectse/WallpaperProtocol;->readExact(Ljava/io/InputStream;I)[B

    move-result-object v5

    .line 307
    invoke-virtual {v0, v5, v4}, Lcom/example/bleconnectse/WallpaperProtocol;->readInt32([BI)I

    move-result v7

    const/4 v9, 0x3

    if-gt v9, v7, :cond_17b

    const v10, 0x200004

    if-ge v7, v10, :cond_17b

    const/4 v10, 0x5

    .line 313
    invoke-direct {v0, v1, v10}, Lcom/example/bleconnectse/WallpaperProtocol;->readExact(Ljava/io/InputStream;I)[B

    move-result-object v10

    .line 314
    invoke-virtual {v0, v10, v2}, Lcom/example/bleconnectse/WallpaperProtocol;->readInt32([BI)I

    move-result v11

    if-ltz v11, :cond_161

    const v12, 0x200001

    if-ge v11, v12, :cond_161

    .line 316
    invoke-direct {v0, v1, v11}, Lcom/example/bleconnectse/WallpaperProtocol;->readExact(Ljava/io/InputStream;I)[B

    move-result-object v12

    invoke-static {v10, v12}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object v12

    .line 317
    invoke-direct {v0, v1, v9}, Lcom/example/bleconnectse/WallpaperProtocol;->readExact(Ljava/io/InputStream;I)[B

    move-result-object v1

    .line 318
    aget-byte v13, v1, v2

    const/16 v14, 0x4b

    if-ne v13, v14, :cond_154

    aget-byte v8, v1, v8

    const/16 v13, 0x4a

    if-ne v8, v13, :cond_154

    .line 321
    new-array v8, v2, [B

    aput-byte v3, v8, v4

    invoke-static {v8, v5}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object v8

    invoke-static {v8, v12}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object v8

    invoke-direct {v0, v8}, Lcom/example/bleconnectse/WallpaperProtocol;->checksum([B)B

    move-result v8

    .line 322
    aget-byte v13, v12, v4

    and-int/lit16 v13, v13, 0xff

    const/16 v14, 0x21

    const/16 v15, 0x8

    move/from16 v16, v4

    if-ne v13, v14, :cond_88

    const/16 v4, 0xc

    if-ne v7, v4, :cond_88

    if-ne v11, v15, :cond_88

    move v4, v2

    goto :goto_8a

    :cond_88
    move/from16 v4, v16

    :goto_8a
    move/from16 v17, v9

    const/16 v9, 0x10

    if-ne v13, v14, :cond_9f

    if-ne v7, v9, :cond_9f

    if-ne v11, v15, :cond_9f

    .line 331
    aget-byte v14, v1, v16

    add-int/lit8 v15, v8, 0x2

    and-int/lit16 v15, v15, 0xff

    int-to-byte v15, v15

    if-ne v14, v15, :cond_9f

    move v14, v2

    goto :goto_a1

    :cond_9f
    move/from16 v14, v16

    :goto_a1
    const/16 v15, 0x24

    const/16 v9, 0x9

    if-ne v13, v15, :cond_b6

    if-ne v7, v9, :cond_b6

    if-ne v11, v2, :cond_b6

    .line 338
    aget-byte v15, v1, v16

    add-int/lit8 v2, v8, -0x1

    and-int/lit16 v2, v2, 0xff

    int-to-byte v2, v2

    if-ne v15, v2, :cond_b6

    const/4 v2, 0x1

    goto :goto_b8

    :cond_b6
    move/from16 v2, v16

    :goto_b8
    const/16 v15, 0x23

    if-ne v13, v15, :cond_d9

    if-ne v7, v9, :cond_d9

    const/4 v9, 0x1

    if-ne v11, v9, :cond_d9

    .line 342
    aget-byte v15, v1, v16

    move-object/from16 v18, v1

    new-array v1, v9, [B

    aput-byte v3, v1, v16

    invoke-static {v1, v5}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object v1

    invoke-static {v1, v10}, Lkotlin/collections/ArraysKt;->plus([B[B)[B

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/example/bleconnectse/WallpaperProtocol;->checksum([B)B

    move-result v0

    if-ne v15, v0, :cond_db

    const/4 v9, 0x1

    goto :goto_dd

    :cond_d9
    move-object/from16 v18, v1

    :cond_db
    move/from16 v9, v16

    :goto_dd
    const/16 v0, 0x23

    if-ne v13, v0, :cond_f4

    const/16 v0, 0x10

    if-ne v7, v0, :cond_f4

    const/16 v0, 0x8

    if-ne v11, v0, :cond_f4

    .line 348
    aget-byte v0, v18, v16

    add-int/lit8 v1, v8, 0x2

    and-int/lit16 v1, v1, 0xff

    int-to-byte v1, v1

    if-ne v0, v1, :cond_f4

    const/4 v0, 0x1

    goto :goto_f6

    :cond_f4
    move/from16 v0, v16

    .line 350
    :goto_f6
    aget-byte v1, v18, v16

    if-eq v1, v8, :cond_126

    if-nez v4, :cond_126

    if-nez v14, :cond_126

    if-nez v2, :cond_126

    if-nez v9, :cond_126

    if-eqz v0, :cond_105

    goto :goto_126

    .line 357
    :cond_105
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x1

    invoke-static {v0, v9}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string/jumbo v1, "壁纸帧校验和错误：CMD=0x%02X"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 349
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 359
    :cond_126
    :goto_126
    array-length v0, v12

    add-int/lit8 v0, v0, 0x3

    if-eq v7, v0, :cond_153

    if-eqz v4, :cond_12e

    goto :goto_153

    .line 361
    :cond_12e
    new-instance v1, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "壁纸外层长度不匹配：声明="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string/jumbo v2, "，实际="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 360
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_153
    :goto_153
    return-object v12

    .line 318
    :cond_154
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string/jumbo v1, "壁纸帧尾错误"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 315
    :cond_161
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "壁纸命令数据长度无效："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 308
    :cond_17b
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "壁纸帧长度无效："

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 302
    :cond_195
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    .line 303
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    .line 301
    invoke-static {v0, v8}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string/jumbo v1, "壁纸响应协议 ID 错误：期望 0x%02X，收到 0x%02X"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 300
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_1b9
    :goto_1b9
    move v2, v3

    goto/16 :goto_a

    .line 295
    :cond_1bc
    new-instance v0, Ljava/io/EOFException;

    const-string/jumbo v1, "壁纸连接已关闭"

    invoke-direct {v0, v1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
