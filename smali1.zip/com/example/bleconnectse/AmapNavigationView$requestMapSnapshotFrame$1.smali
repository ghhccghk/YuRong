# classes2.dex

.class public final Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;
.super Ljava/lang/Object;
.source "AmapNavigationView.kt"

# interfaces
.implements Lcom/amap/api/maps/AMap$OnMapScreenShotListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/AmapNavigationView;->requestMapSnapshotFrame(J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001d\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0012\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\u0016J\u001a\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016¨\u0006\b"
    }
    d2 = {
        "com/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1",
        "Lcom/amap/api/maps/AMap$OnMapScreenShotListener;",
        "onMapScreenShot",
        "",
        "bitmap",
        "Landroid/graphics/Bitmap;",
        "status",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $delivered:Lkotlin/jvm/internal/Ref$BooleanRef;

.field final synthetic $frameStartedAt:J

.field final synthetic $generation:I

.field final synthetic this$0:Lcom/example/bleconnectse/AmapNavigationView;


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/example/bleconnectse/AmapNavigationView;IJ)V
    .registers 6

    iput-object p1, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->$delivered:Lkotlin/jvm/internal/Ref$BooleanRef;

    iput-object p2, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    iput p3, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->$generation:I

    iput-wide p4, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->$frameStartedAt:J

    .line 788
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onMapScreenShot(Landroid/graphics/Bitmap;)V
    .registers 8

    .line 790
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->$delivered:Lkotlin/jvm/internal/Ref$BooleanRef;

    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    iget v2, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->$generation:I

    iget-wide v3, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->$frameStartedAt:J

    move-object v5, p1

    invoke-static/range {v0 .. v5}, Lcom/example/bleconnectse/AmapNavigationView;->access$requestMapSnapshotFrame$deliver(Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/example/bleconnectse/AmapNavigationView;IJLandroid/graphics/Bitmap;)V

    return-void
.end method

.method public onMapScreenShot(Landroid/graphics/Bitmap;I)V
    .registers 9

    .line 794
    iget-object v0, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->$delivered:Lkotlin/jvm/internal/Ref$BooleanRef;

    iget-object v1, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->this$0:Lcom/example/bleconnectse/AmapNavigationView;

    iget v2, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->$generation:I

    iget-wide v3, p0, Lcom/example/bleconnectse/AmapNavigationView$requestMapSnapshotFrame$1;->$frameStartedAt:J

    move-object v5, p1

    invoke-static/range {v0 .. v5}, Lcom/example/bleconnectse/AmapNavigationView;->access$requestMapSnapshotFrame$deliver(Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/example/bleconnectse/AmapNavigationView;IJLandroid/graphics/Bitmap;)V

    return-void
.end method
