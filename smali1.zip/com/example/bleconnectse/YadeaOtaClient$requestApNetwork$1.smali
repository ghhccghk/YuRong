# classes2.dex

.class public final Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;
.super Landroid/net/ConnectivityManager$NetworkCallback;
.source "YadeaOtaClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/YadeaOtaClient;->requestApNetwork(Lcom/example/bleconnectse/YadeaWifiProfile;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\b\u0010\u0006\u001a\u00020\u0003H\u0016J\u0010\u0010\u0007\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\b"
    }
    d2 = {
        "com/example/bleconnectse/YadeaOtaClient$requestApNetwork$1",
        "Landroid/net/ConnectivityManager$NetworkCallback;",
        "onAvailable",
        "",
        "network",
        "Landroid/net/Network;",
        "onUnavailable",
        "onLost",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $profile:Lcom/example/bleconnectse/YadeaWifiProfile;

.field final synthetic this$0:Lcom/example/bleconnectse/YadeaOtaClient;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/YadeaOtaClient;Lcom/example/bleconnectse/YadeaWifiProfile;)V
    .registers 3

    iput-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iput-object p2, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;->$profile:Lcom/example/bleconnectse/YadeaWifiProfile;

    .line 400
    invoke-direct {p0}, Landroid/net/ConnectivityManager$NetworkCallback;-><init>()V

    return-void
.end method

.method static final onAvailable$lambda$0(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Lcom/example/bleconnectse/YadeaWifiProfile;)Lkotlin/Unit;
    .registers 6

    const/4 v0, 0x1

    .line 405
    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setApReady(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    const/4 v0, 0x0

    .line 406
    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setApConnectionRequested(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 407
    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setApConnectionFailed(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 408
    invoke-static {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setLocalIp(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 409
    sget-object v0, Lcom/example/bleconnectse/TimelineRecorder;->INSTANCE:Lcom/example/bleconnectse/TimelineRecorder;

    invoke-virtual {p2}, Lcom/example/bleconnectse/YadeaWifiProfile;->getSsid()Ljava/lang/String;

    move-result-object p2

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "AP 已连接："

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Lcom/example/bleconnectse/TimelineRecorder;->mark(Ljava/lang/String;)V

    .line 410
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "AP 已连接，本机 IP："

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 411
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onLost$lambda$2(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Network;)Lkotlin/Unit;
    .registers 3

    .line 425
    const-string v0, "AP 已断开"

    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 426
    invoke-static {p0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$getWifiNetwork$p(Lcom/example/bleconnectse/YadeaOtaClient;)Landroid/net/Network;

    move-result-object v0

    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_17

    const/4 p1, 0x0

    .line 427
    invoke-static {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setWifiNetwork$p(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Network;)V

    const/4 p1, 0x0

    .line 428
    invoke-static {p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setApReady(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 430
    :cond_17
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final onUnavailable$lambda$1(Lcom/example/bleconnectse/YadeaOtaClient;)Lkotlin/Unit;
    .registers 2

    const/4 v0, 0x0

    .line 416
    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setApReady(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 417
    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setApConnectionRequested(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    const/4 v0, 0x1

    .line 418
    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setApConnectionFailed(Lcom/example/bleconnectse/YadeaOtaClient;Z)V

    .line 419
    const-string v0, "AP 连接失败或已取消"

    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$logStatus(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)V

    .line 420
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method


# virtual methods
.method public onAvailable(Landroid/net/Network;)V
    .registers 4

    const-string v0, "network"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 402
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    invoke-static {v0, p1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$setWifiNetwork$p(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Network;)V

    .line 403
    iget-object p1, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    const-string v0, "192.168.7.1"

    invoke-static {p1, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$detectLocalIpv4(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 404
    iget-object v0, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;->$profile:Lcom/example/bleconnectse/YadeaWifiProfile;

    new-instance v1, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda2;

    invoke-direct {v1, v0, p1, p0}, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda2;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Ljava/lang/String;Lcom/example/bleconnectse/YadeaWifiProfile;)V

    invoke-static {v0, v1}, Lcom/example/bleconnectse/YadeaOtaClient;->access$post(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public onLost(Landroid/net/Network;)V
    .registers 3

    const-string v0, "network"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 424
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0, p1}, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda1;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;Landroid/net/Network;)V

    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$post(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public onUnavailable()V
    .registers 2

    .line 415
    iget-object p0, p0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1;->this$0:Lcom/example/bleconnectse/YadeaOtaClient;

    new-instance v0, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lcom/example/bleconnectse/YadeaOtaClient$requestApNetwork$1$$ExternalSyntheticLambda0;-><init>(Lcom/example/bleconnectse/YadeaOtaClient;)V

    invoke-static {p0, v0}, Lcom/example/bleconnectse/YadeaOtaClient;->access$post(Lcom/example/bleconnectse/YadeaOtaClient;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method
