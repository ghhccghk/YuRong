# classes2.dex

.class public final Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;
.super Ljava/lang/Object;
.source "BleTileClient.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/bleconnectse/BleTileClient;-><init>(Landroid/content/Context;Lcom/example/bleconnectse/SyntheticTileRepository;Lkotlin/jvm/functions/Function1;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016¨\u0006\u0004"
    }
    d2 = {
        "com/example/bleconnectse/BleTileClient$transferWatchdog$1",
        "Ljava/lang/Runnable;",
        "run",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/bleconnectse/BleTileClient;


# direct methods
.method constructor <init>(Lcom/example/bleconnectse/BleTileClient;)V
    .registers 2

    iput-object p1, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    .line 131
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 8

    .line 133
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getClosed$p(Lcom/example/bleconnectse/BleTileClient;)Z

    move-result v0

    if-eqz v0, :cond_9

    return-void

    .line 134
    :cond_9
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 135
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-virtual {v2}, Lcom/example/bleconnectse/BleTileClient;->getConnected()Z

    move-result v2

    const-wide/16 v3, 0x5dc

    if-eqz v2, :cond_54

    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v2}, Lcom/example/bleconnectse/BleTileClient;->access$getTransportReady$p(Lcom/example/bleconnectse/BleTileClient;)Z

    move-result v2

    if-eqz v2, :cond_54

    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v2}, Lcom/example/bleconnectse/BleTileClient;->access$getWriteInFlight$p(Lcom/example/bleconnectse/BleTileClient;)Z

    move-result v2

    if-eqz v2, :cond_54

    .line 136
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v2}, Lcom/example/bleconnectse/BleTileClient;->access$getDataWriteStartedAtMs$p(Lcom/example/bleconnectse/BleTileClient;)J

    move-result-wide v5

    sub-long v5, v0, v5

    cmp-long v2, v5, v3

    if-ltz v2, :cond_54

    .line 138
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getDataWriteGeneration$p(Lcom/example/bleconnectse/BleTileClient;)J

    move-result-wide v1

    const-wide/16 v3, 0x1

    add-long/2addr v1, v3

    invoke-static {v0, v1, v2}, Lcom/example/bleconnectse/BleTileClient;->access$setDataWriteGeneration$p(Lcom/example/bleconnectse/BleTileClient;J)V

    .line 139
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/example/bleconnectse/BleTileClient;->access$setWriteInFlight$p(Lcom/example/bleconnectse/BleTileClient;Z)V

    .line 140
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    const-string v1, "BLE分包提交超时，已由看门狗恢复发送"

    invoke-static {v0, v1}, Lcom/example/bleconnectse/BleTileClient;->access$logStatus(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V

    .line 141
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    const-string v1, "BLE分包提交超时"

    invoke-static {v0, v1}, Lcom/example/bleconnectse/BleTileClient;->access$retryOrFailCurrentPacket(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V

    goto :goto_99

    .line 142
    :cond_54
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-virtual {v2}, Lcom/example/bleconnectse/BleTileClient;->getConnected()Z

    move-result v2

    if-eqz v2, :cond_99

    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v2}, Lcom/example/bleconnectse/BleTileClient;->access$getTransportReady$p(Lcom/example/bleconnectse/BleTileClient;)Z

    move-result v2

    if-eqz v2, :cond_99

    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v2}, Lcom/example/bleconnectse/BleTileClient;->access$getWriteInFlight$p(Lcom/example/bleconnectse/BleTileClient;)Z

    move-result v2

    if-nez v2, :cond_99

    .line 143
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v2}, Lcom/example/bleconnectse/BleTileClient;->access$getActiveTile$p(Lcom/example/bleconnectse/BleTileClient;)Lcom/example/bleconnectse/SyntheticTile;

    move-result-object v2

    if-nez v2, :cond_82

    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v2}, Lcom/example/bleconnectse/BleTileClient;->access$getTransferQueue$p(Lcom/example/bleconnectse/BleTileClient;)Ljava/util/ArrayDeque;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_99

    .line 144
    :cond_82
    iget-object v2, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v2}, Lcom/example/bleconnectse/BleTileClient;->access$getLastTransferProgressAtMs$p(Lcom/example/bleconnectse/BleTileClient;)J

    move-result-wide v5

    sub-long/2addr v0, v5

    cmp-long v0, v0, v3

    if-ltz v0, :cond_99

    .line 146
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    const-string v1, "BLE发送队列停滞，已重新启动队列"

    invoke-static {v0, v1}, Lcom/example/bleconnectse/BleTileClient;->access$logStatus(Lcom/example/bleconnectse/BleTileClient;Ljava/lang/String;)V

    .line 147
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$pumpTransfer(Lcom/example/bleconnectse/BleTileClient;)V

    .line 149
    :cond_99
    :goto_99
    iget-object v0, p0, Lcom/example/bleconnectse/BleTileClient$transferWatchdog$1;->this$0:Lcom/example/bleconnectse/BleTileClient;

    invoke-static {v0}, Lcom/example/bleconnectse/BleTileClient;->access$getMainHandler$p(Lcom/example/bleconnectse/BleTileClient;)Landroid/os/Handler;

    move-result-object v0

    check-cast p0, Ljava/lang/Runnable;

    const-wide/16 v1, 0x1f4

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
